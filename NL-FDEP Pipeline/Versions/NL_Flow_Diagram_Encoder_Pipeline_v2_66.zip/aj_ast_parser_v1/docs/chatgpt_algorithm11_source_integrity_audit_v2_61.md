# v2.61 — ChatGPT Algorithm 11 source-integrity recovery

The stored lossy ChatGPT TXT export contains a literal `?` in the single position where the authoritative Algorithm 11 uses `←`:

```text
UniqueIPs ? Empty Set
```

v2.61 treats this as an isolated source-integrity recovery only. `?` is not an AJ token and is never a canonical alternative to `<-`.

Recovery path:

```text
stored lossy source:  UniqueIPs ? Empty Set
GC180 recovery:       UniqueIPs ← Empty Set
GC004 canonical AJ:   UniqueIPs <- Empty Set
```

GC180 activates only when the complete Algorithm 11 signature is present (`INPUT IP_List`, `FOR EACH IP IN IP_List`, `ADD IP TO UniqueIPs`, and `OUTPUT UniqueIPs`) and the exact `UniqueIPs ? Empty Set` line occurs once. An unrelated question-mark assignment is not recovered and remains invalid under the strict AJ lexer/parser.

Canonical AJ:

```text
FUNCTION unnamed_function ACCEPTS(IP_List)
    UniqueIPs <- EMPTY SET

    FOR EACH IP IN IP_List DO
        CALL add_to_set(UniqueIPs, IP)
    ENDFOR

    OUTPUT UniqueIPs
ENDFUNCTION
```

Python lowering:

```python
def unnamed_function(IP_List):
    UniqueIPs = set()
    for IP in IP_List:
        UniqueIPs.add(IP)
    print(UniqueIPs)
```

Validation:

- targeted Algorithm 11 tests: 3 passed
- full regression suite: 220 passed, 0 failed, 3 pre-existing warnings
- canonical hash corpus: 182/300 parsed (60.7%)
- ChatGPT: 38/50 parsed
- coverage change: 0
