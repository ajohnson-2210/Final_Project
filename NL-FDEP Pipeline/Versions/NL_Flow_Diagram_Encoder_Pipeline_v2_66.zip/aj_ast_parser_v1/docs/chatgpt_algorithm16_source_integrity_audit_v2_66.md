# ChatGPT Algorithm 16 Source-Integrity Audit — v2.66

## External source evidence

The external research corpus preserves the Euclidean-GCD body as `WHILE B ≠ 0`, followed by three assignment-arrow statements using `←`. The lossy stored ChatGPT TXT represents those four glyph positions with `?`.

## Recovery boundary

GC186 and GC187 operate before AJ canonicalisation and only when the complete Algorithm 16 signature and all four exact affected lines are present exactly once.

- GC186: three lost assignment arrows restored to `←`.
- GC187: one lost not-equal symbol restored to `≠`.

No generic `?` assignment or comparison alias is introduced. Unrelated `?` forms continue to fail strict AJ parsing.

## Canonical result

```text
FUNCTION unnamed_function ACCEPTS(A, B)
    WHILE B != 0 DO
        Temp <- B
        B <- A MODULUS B
        A <- Temp
    ENDWHILE

    OUTPUT A
ENDFUNCTION
```

## Validation

- Full regression suite with external research corpus configured: 235 passed, 0 failed.
- Distribution-mode suite with no research corpus present: 232 passed, 3 corpus-dependent checks skipped, 0 failed.
- 3 pre-existing pytest collection warnings in both modes.
- External corpus evaluation: 182/300 (60.7%); ChatGPT 38/50; parse coverage unchanged.
