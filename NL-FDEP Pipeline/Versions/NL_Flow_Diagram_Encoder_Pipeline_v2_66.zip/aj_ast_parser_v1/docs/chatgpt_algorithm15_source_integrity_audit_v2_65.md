# ChatGPT Algorithm 15 Source-Integrity Audit — v2.65

## Authoritative source evidence

The canonical research corpus preserves `Largest ← -∞` and `SecondLargest ← -∞`, plus three later assignment arrows. The lossy stored ChatGPT TXT represents these as five assignment-position `?` glyphs and two `-?` initialisers.

## Recovery boundary

GC184 and GC185 operate before AJ canonicalisation and only when the complete Algorithm 15 signature and all five exact affected lines are present exactly once.

- GC184: five lost assignment arrows restored to `←`.
- GC185: two lost infinity symbols restored to `∞`.

No generic `?` assignment or infinity alias is introduced. Unrelated `?` / `-?` forms continue to fail strict AJ parsing.

## Canonical result

```text
FUNCTION unnamed_function ACCEPTS(Array)
    Largest <- CALL negative_infinity()
    SecondLargest <- CALL negative_infinity()

    FOR EACH Number IN Array DO
        IF Number > Largest THEN
            SecondLargest <- Largest
            Largest <- Number
        ELSE IF Number > SecondLargest AND Number < Largest THEN
            SecondLargest <- Number
        ENDIF
    ENDFOR

    OUTPUT SecondLargest
ENDFUNCTION
```

## Validation

- 232 regression tests passed.
- 0 failures.
- 3 pre-existing pytest collection warnings.
- Corpus: 182/300 (60.7%).
- ChatGPT: 38/50.
- Parse coverage unchanged.
