# v2.62 — ChatGPT Algorithm 12 source-integrity recovery

The lossy stored ChatGPT TXT export contains three literal `?` characters in positions where the authoritative source uses the left-arrow assignment glyph `←`:

- `Sum ? 0`
- `FOR i ? 0 TO N - 1`
- `Sum ? Sum + Matrix[i][i]`

v2.62 treats these as an isolated source-integrity recovery only. `?` is not an AJ token and is never a canonical alternative to `<-`.

The recovery rule `GC181` activates only when the complete Algorithm 12 main-diagonal signature is present and all three exact lossy lines occur exactly once. It restores those three source glyphs to `←`. The ordinary character normaliser (`GC004`) then converts `←` to canonical AJ `<-`.

Authoritative-arrow input does not use `GC181`.

Canonical result:

```text
FUNCTION unnamed_function ACCEPTS(Matrix, N)
    Sum <- 0

    FOR i <- IN RANGE 0 TO (N - 1) + 1 DO
        Sum <- Sum + Matrix[i][i]
    ENDFOR

    OUTPUT Sum
ENDFUNCTION
```

The inclusive-source range correction is provided by the existing generic range rule and is not part of GC181.

Validation:

- targeted Algorithm 12 source-integrity tests: 3 passed
- complete regression suite: 223 passed, 0 failed, 3 pre-existing warnings
- canonical six-model corpus: 182/300 parsed (60.7%)
- ChatGPT: 38/50 parsed
- coverage change: 0
