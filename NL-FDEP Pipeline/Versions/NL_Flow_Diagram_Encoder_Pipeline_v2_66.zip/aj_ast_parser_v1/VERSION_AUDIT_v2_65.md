# v2.65 Audit

## ChatGPT Algorithm 15 — second-largest source integrity

Introduces two narrow source-integrity recovery rules for the lossy stored ChatGPT TXT export, independently grounded by the authoritative canonical corpus:

- GC184 restores exactly five lost assignment arrows (`?` -> `←`) in the recognised Algorithm 15 signature.
- GC185 restores exactly two lost infinity glyphs (`-?` -> `-∞`) in the two recognised initialiser lines.

These rules are upstream source recovery only. `?` is never valid AJ syntax, never a canonical alternative to `<-`, and never a canonical infinity token. After recovery, the ordinary canonical rules apply: GC004 converts `←` to `<-`, GC006 converts `∞` to `INFINITY`, and GC151 lowers negative infinity to `CALL negative_infinity()`.

The explicit second-largest procedure is preserved without repair. Behaviour for arrays with fewer than two distinct values remains the model's own behaviour and is deferred to later correctness assessment.

Validation:
- Regression suite: 232 passed, 0 failed, 3 pre-existing warnings
- Corpus: 182/300 (60.7%)
- ChatGPT: 38/50
- Coverage change: 0
