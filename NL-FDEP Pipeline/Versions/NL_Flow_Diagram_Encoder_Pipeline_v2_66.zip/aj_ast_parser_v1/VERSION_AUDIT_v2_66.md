# v2.66 Audit

## ChatGPT Algorithm 16 — Euclidean GCD source integrity

Introduces two narrow source-integrity recovery rules for the lossy stored ChatGPT TXT export, independently grounded by the external research corpus:

- GC186 restores exactly three lost assignment arrows (`?` -> `←`) in the recognised Algorithm 16 signature.
- GC187 restores exactly one lost not-equal glyph (`?` -> `≠`) in the recognised `WHILE B ... 0` line.

These rules are upstream source recovery only. `?` is never valid AJ syntax, never a canonical alternative to `<-`, and never a canonical comparison operator. Ordinary canonicalisation subsequently converts `←` to `<-` and `≠` to `!=`.

The Euclidean algorithm is otherwise preserved exactly.

## Packaging boundary correction

The six-model research corpus is study data, not implementation data. Versioned implementation ZIPs now exclude `corpus_hash_format/` and copied/raw model-response corpus files. Corpus-dependent integration checks use an external directory supplied via `AJ_RESEARCH_CORPUS_DIR` and skip cleanly when study data is not configured.

Validation:
- Regression suite with external study corpus: 235 passed, 0 failed, 3 pre-existing warnings.
- Distribution-mode suite without study corpus: 232 passed, 3 skipped, 0 failed, 3 pre-existing warnings.
- External corpus: 182/300 (60.7%).
- ChatGPT: 38/50.
- Coverage change: 0.
