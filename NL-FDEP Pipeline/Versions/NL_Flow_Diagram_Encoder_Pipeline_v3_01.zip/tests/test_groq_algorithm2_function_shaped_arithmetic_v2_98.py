from aj_parser import AJParserFacade
from flow_diagram import FlowDiagramEncoder
from aj_python_compiler import AJPythonCompiler
from pseudocode_profiles import PseudocodeProfile, PseudocodeProfileProcessor


SOURCE = '''FUNCTION DECIMAL_TO_BINARY(n)
  IF n == 0 THEN
    RETURN "0"
  END IF
  binary = ""
  WHILE n > 0
    binary = MOD(n, 2) + binary
    n = FLOOR(n / 2)
  END WHILE
  RETURN binary
END FUNCTION
'''


def _process(source: str):
    return PseudocodeProfileProcessor().process(
        source,
        PseudocodeProfile.GENERIC_COMPATIBILITY,
    )


def test_groq_algorithm2_exact_source_recovers_without_reconstructing_algorithm():
    result = _process(SOURCE)
    expected = '''FUNCTION DECIMAL_TO_BINARY ACCEPTS(n)
  IF n == 0 THEN
    RETURN STRING("0")
  ENDIF
  binary <- EMPTY STRING
  WHILE n > 0 DO
    binary <- CALL to_string((n MODULUS 2)) + binary
    n <- (n INTEGER DIVISION 2)
  ENDWHILE
  RETURN binary
ENDFUNCTION'''
    assert result.processed_source.strip() == expected

    parsed = AJParserFacade().parse(result.processed_source)
    assert parsed.success, parsed.error
    compiled = AJPythonCompiler().compile(FlowDiagramEncoder().encode(parsed.ast))
    namespace = {}
    exec(compiled.source_code, namespace)

    assert namespace["DECIMAL_TO_BINARY"](0) == "0"
    assert namespace["DECIMAL_TO_BINARY"](1) == "1"
    assert namespace["DECIMAL_TO_BINARY"](10) == "1010"
    assert namespace["DECIMAL_TO_BINARY"](31) == "11111"
