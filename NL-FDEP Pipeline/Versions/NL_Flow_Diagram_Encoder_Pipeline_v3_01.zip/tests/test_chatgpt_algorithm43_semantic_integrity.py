from aj_parser import AJParserFacade
from aj_python_compiler import AJPythonCompiler
from flow_diagram import FlowDiagramEncoder
from pseudocode_profiles import PseudocodeProfile, PseudocodeProfileProcessor


def _raw_algorithm43():
    return '''BEGIN
    INPUT N

    FUNCTION Hanoi(Discs, Source, Auxiliary, Destination)
        IF Discs = 1 THEN
            OUTPUT "Move disk from", Source, "to", Destination
        ELSE
            Hanoi(Discs-1, Source, Destination, Auxiliary)

            OUTPUT "Move disk from", Source, "to", Destination

            Hanoi(Discs-1, Auxiliary, Source, Destination)
        ENDIF
    END FUNCTION

    Hanoi(N, "A", "B", "C")
END
'''


def test_chatgpt_algorithm43_preserves_explicit_hanoi_recursion_and_message_output():
    result = PseudocodeProfileProcessor().process(
        _raw_algorithm43(), PseudocodeProfile.GENERIC_COMPATIBILITY
    )

    expected = '''N <- CALL integer_value(INPUT(STRING("Enter N")))

FUNCTION Hanoi ACCEPTS(Discs, Source, Auxiliary, Destination)
    IF Discs == 1 THEN
        OUTPUT STRING("Move disk from ") + Source + STRING(" to ") + Destination
    ELSE
        CALL Hanoi(Discs - 1, Source, Destination, Auxiliary)

        OUTPUT STRING("Move disk from ") + Source + STRING(" to ") + Destination

        CALL Hanoi(Discs - 1, Auxiliary, Source, Destination)
    ENDIF
ENDFUNCTION

CALL Hanoi(N, STRING("A"), STRING("B"), STRING("C"))'''
    assert result.processed_source == expected

    # Numeric typing is supported by the explicit Discs - 1 arithmetic. The
    # source function name and recursive peg-role swaps must remain unchanged.
    assert any(t.rule == "GC170" for t in result.transformations)
    assert all(t.rule != "GC096" for t in result.transformations)
    assert "OUTPUT TUPLE" not in result.processed_source
    assert "FUNCTION Hanoi" in result.processed_source
    assert "CALL Hanoi(Discs - 1, Source, Destination, Auxiliary)" in result.processed_source
    assert "CALL Hanoi(Discs - 1, Auxiliary, Source, Destination)" in result.processed_source

    parsed = AJParserFacade().parse(result.processed_source)
    assert parsed.success, parsed.error

    compiled = AJPythonCompiler().compile(FlowDiagramEncoder().encode(parsed.ast))
    assert "N = int(input('Enter N'))" in compiled.source_code
    assert "def Hanoi(Discs, Source, Auxiliary, Destination):" in compiled.source_code
    assert "Hanoi((Discs - 1), Source, Destination, Auxiliary)" in compiled.source_code
    assert "Hanoi((Discs - 1), Auxiliary, Source, Destination)" in compiled.source_code
    assert 'print(f"Move disk from {Source} to {Destination}")' in compiled.source_code
    assert "print(((('Move disk from ' + Source) + ' to ') + Destination))" not in compiled.source_code
    assert "print(('Move disk from'," not in compiled.source_code


def test_fstring_rendering_is_narrow_and_does_not_rewrite_arithmetic_output():
    parsed = AJParserFacade().parse("OUTPUT Left + Right")
    assert parsed.success, parsed.error
    compiled = AJPythonCompiler().compile(FlowDiagramEncoder().encode(parsed.ast))
    assert "print((Left + Right))" in compiled.source_code
    assert "print(f" not in compiled.source_code
