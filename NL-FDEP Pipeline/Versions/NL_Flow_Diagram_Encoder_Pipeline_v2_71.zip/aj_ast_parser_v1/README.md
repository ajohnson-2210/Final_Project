# NL to Flow Diagram Encoder Pipeline v1.3

A dependency-free, object-oriented Python pipeline for AJ_24038155 Dialect v1.0.
The only external program input is AJ pseudocode.

## Pipeline

1. AJ pseudocode input
2. Lexical analysis
3. Recursive-descent parsing
4. AST construction
5. Static semantic validation
6. Machine-readable flow-diagram encoding
7. Interactive AST and flow-diagram visualisation
8. Deterministic Python compilation from `flow_diagram.json`
9. Subprocess-based behavioural testing
10. JSON reporting

## PyCharm

Open `pycharm_runner.py` and press **Run**. Configure these constants at the top
of the file when required:

- `INPUT_FILE`
- `OUTPUT_DIRECTORY`
- `OPEN_VISUALISATIONS`
- `TEST_CASES`

## Outputs

The runner creates:

- `output/ast.json`
- `output/parser_report.json`
- `output/ast_visualisation.html`
- `output/flow_diagram.json`
- `output/flow_diagram.html`
- `output/generated_program.py`
- `output/compilation_report.json`
- `output/test_report.json`
- `output/pipeline_report.json`

## Important design boundary

The AST is an internal intermediate representation. It is generated from
pseudocode and is not accepted as an external pipeline input. The compiler
accepts the machine-readable flow-diagram document produced by the encoder.

## Research corpus separation

The model-response corpora used for the research study are **external test data**
and are not distributed inside versioned implementation ZIPs. Study-level corpus
integration checks can be run by setting `AJ_RESEARCH_CORPUS_DIR` to an external
directory containing the six research corpus files. When that variable is absent,
those corpus-dependent checks skip cleanly; the implementation/unit regression
suite remains runnable without the study data.

## Flow-diagram display

The generated flowchart opens at a readable 115% scale and is centred on the
first program steps. Use **Fit diagram** to display the complete program at once.
Zoom and pan remain available.

## Compilation assurance tests

The integration tests verify that:

- the saved `flow_diagram.json` document is accepted directly by the compiler;
- the compiler produces the exact expected reference Python source;
- the compiled program executes and produces the expected output;
- the visualisation contains the readable initial-view configuration.

Run all tests with:

```bash
python -m unittest discover -s tests -v
```

## Second controlled input route: draw.io

Version 1.5 adds an optional draw.io route while preserving pseudocode as the
primary route.

Configure `pycharm_runner.py` with:

```python
INPUT_ROUTE = "DRAWIO"
SELECT_FILE_WHEN_RUNNING = True
```

The runner displays a native file chooser. The controlled version 1 convention
is deliberately limited to a single linear path:

```text
Start -> AJ statement -> AJ statement -> End
```

Each executable process or input/output shape must contain one valid AJ Dialect
statement, either directly or with an `AJ:` prefix, for example:

```text
AJ: total <- INTEGER(0)
AJ: OUTPUT STRING("Total is {total}")
```

The importer reconstructs AJ pseudocode and then reuses the existing trusted
route:

```text
draw.io -> AJ pseudocode -> AST -> canonical flow JSON -> Python -> tests
```

Branching and looped draw.io imports intentionally fail with explicit diagnostics
in this first controlled version. The existing pseudocode route continues to
support the full parser grammar.

## Interactive input selection in PyCharm

Run `pycharm_runner.py` without editing an input-route flag.

The application first asks:

```text
What would you like to import?

[Pseudocode file]
[Flow diagram file]
```

After the selection, a native file chooser opens with the matching filters:

- Pseudocode: `.aj` or `.txt`
- Controlled flow diagram: `.drawio`, `.xml` or `.svg`

Closing either dialog cancels the run cleanly.

## Pseudocode processing profiles

When **Pseudocode file** is selected in `pycharm_runner.py`, the application now
asks how the source should be processed:

1. **AJ Dialect — strict** performs only non-semantic cleanup such as removing a
   surrounding Markdown fence, normalising line endings, removing trailing
   whitespace and converting `←` to `<-`.
2. **Generic — convert compatible syntax** recognises a controlled subset of
   generic structured pseudocode and converts forms such as `SET x TO value`,
   `PRINT value`, `END IF`, `END WHILE`, `NEXT`, assignment `=`, `MOD` and `DIV`
   into AJ_24038155 Dialect syntax.
3. **General — parse without conversion** passes the supplied text to the
   existing lexer and parser exactly as read from the file. It does not repair,
   normalise or rewrite the source.

Every pseudocode run writes:

- `processed_pseudocode.aj`
- `pseudocode_processing_report.json`

The report records the selected profile, whether the source changed, and every
individual transformation. The selected profile is also included in
`pipeline_report.json` under `input_metadata`.

## Draw.io overlaid labels

Version 1.8 recognises draw.io diagrams where visible `Start` and `End` text is
stored as a separate text object placed over an empty connected terminator
shape. The importer transfers the text to the underlying shape before graph
validation. Branching and loop-back import remain outside the controlled linear
importer and are rejected explicitly.

## General draw.io control-flow graphs

The draw.io route supports both linear diagrams and general graphs containing:

- decision diamonds;
- Yes/No and True/False connector labels;
- branch joins;
- loop-back connectors;
- separate text labels over Start and End shapes.

Linear diagrams are reconstructed as AJ Dialect pseudocode and use the normal
AST pipeline. Branching or cyclic diagrams are preserved as a canonical graph
and compiled into a Python state machine. This allows control flow that cannot
be represented safely as a simple nested block structure to remain executable.

When no behavioural test oracle is supplied for an imported flow diagram, the
pipeline reports behavioural testing as `SKIPPED` after successful compilation
and Python syntax validation. This avoids comparing an imported diagram against
unrelated sample outputs.

## Version 1.10: structured Tic-Tac-Toe graph compilation

The supplied Tic-Tac-Toe draw.io graph is recognised as a structured game-flow
pattern. It is compiled into a normal Python game loop instead of a verbose
state dispatcher. The generated program validates indexes and occupied cells,
alternates players, checks all eight winning lines, declares the correct winner,
and declares a draw after nine valid moves.

The compiler reports this route as `STRUCTURED_GRAPH_OPTIMISATION`. Other
arbitrary cyclic draw.io graphs continue to use the general state-machine
compiler.

## Flow-diagram input AST outputs

When an existing draw.io flow diagram is selected, the pipeline does not create a duplicate flow-diagram visualisation. After compilation it parses the generated Python into a Python AST and writes:

- `ast.json` — nested Python AST document;
- `ast_adjacency_list.json` — graph representation of the AST;
- `ast_visualisation.html` — interactive AST tree;
- `generated_program.py` — compiled Python source.

The pseudocode input route continues to generate both AST and flow-diagram artefacts.

## Editable draw.io export

The pseudocode input route also writes `output/flow_diagram.drawio`. This is an
editable diagrams.net/draw.io XML document using standard terminator, process,
decision, input/output, subroutine, and orthogonal connector conventions.

## Initial hash-comment header stripping

Before the selected pseudocode profile is applied, the pipeline checks whether the first line begins with `#`. When it does, all lines from the beginning of the file through the first blank separator line are treated as file-header metadata and removed. This supports wrapped introductory comments where continuation lines do not themselves begin with `#`.

Example:

```text
# Algorithm description
This description may wrap across several lines.
These lines are header metadata.

FUNCTION example ACCEPTS()
    OUTPUT STRING(example)
ENDFUNCTION
```

Only the pseudocode beginning with `FUNCTION` is sent to the selected profile and parser. Hash characters occurring later in the pseudocode do not trigger this preprocessing rule. The processing report records `header_comment_removed` and `header_lines_removed` separately from profile transformation counts.

## Lossy-source assignment recovery boundary

The generic compatibility route may receive study/source exports in which a
Unicode assignment arrow was lost as ASCII `?`. This is handled only in the
upstream source-integrity stage (GC193), where `?` is recoverable to source `←`
only when its syntactic position is unambiguously an assignment: a standalone
assignment target, a `FOR` initialiser, or an inline CASE-arm assignment.

`?` is **not** AJ syntax and is never a canonical alias for `<-`. Relational
forms such as `WHILE B ? 0` or `IF A ? B THEN` are left unresolved unless an
independent, narrowly scoped source-integrity rule establishes the lost glyph.
The strict AJ parser continues to reject `?`.
