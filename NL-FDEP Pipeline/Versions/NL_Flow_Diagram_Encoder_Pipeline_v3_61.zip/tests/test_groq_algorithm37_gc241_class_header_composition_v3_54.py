from pathlib import Path

from aj_parser import AJParserFacade
from aj_python_compiler import AJPythonCompiler
from corpus_evaluator import GroqAdapter, read_corpus_text
from flow_diagram import FlowDiagramEncoder
from pseudocode_profiles import PseudocodeProfile, PseudocodeProfileProcessor


def process(source: str):
    return PseudocodeProfileProcessor().process(source, PseudocodeProfile.GENERIC_COMPATIBILITY)


def compile_source(source: str) -> str:
    parsed = AJParserFacade().parse(source)
    assert parsed.success, parsed.error
    compiled = AJPythonCompiler().compile(FlowDiagramEncoder().encode(parsed.ast))
    assert compiled.success, compiled.error
    return compiled.source_code


def test_gc241_accepts_already_canonical_class_header_and_recovers_groq37():
    corpus = Path(__file__).parent / "corpora" / "groq_pseudocode_responses.txt"
    examples = GroqAdapter().extract(read_corpus_text(corpus), "Groq")
    source = next(item.source for item in examples if item.task_number == 37)

    result = process(source)

    assert any(t.rule == "GC241" for t in result.transformations)
    assert result.processed_source.startswith("CLASS STACK ACCEPTS()")
    assert "CONSTRUCTOR ACCEPTS()" in result.processed_source
    assert "METHOD PUSH ACCEPTS(element)" in result.processed_source
    assert "METHOD POP ACCEPTS()" in result.processed_source
    assert "METHOD PEEK ACCEPTS()" in result.processed_source
    assert result.processed_source.count("ENDMETHOD") == 3
    assert result.processed_source.rstrip().endswith("ENDCLASS")
    python_source = compile_source(result.processed_source)
    assert "self.array = []" in python_source
    assert "self.top = (-1)" in python_source
    assert "self.top = (self.top + 1)" in python_source
    assert "self.array[self.top] = element" in python_source

    namespace = {}
    exec(python_source, namespace)
    stack = namespace["STACK"]()
    try:
        stack.PUSH(1)
    except IndexError:
        pass
    else:
        raise AssertionError("Groq 37 must not invent list auto-growth semantics")


def test_gc241_preserves_existing_class_constructor_parameters_when_header_is_canonical():
    source = '''CLASS Box ACCEPTS(seed)
    CONSTRUCTOR(seed):
        self.value = seed
    FUNCTION Get():
        RETURN self.value
'''
    result = process(source)
    assert any(t.rule == "GC241" for t in result.transformations)
    assert result.processed_source.startswith("CLASS Box ACCEPTS(seed)")
    assert "CONSTRUCTOR ACCEPTS(seed)" in result.processed_source
    assert "METHOD Get ACCEPTS()" in result.processed_source


def test_gc241_still_refuses_canonical_class_without_both_constructor_and_method():
    source = '''CLASS Box ACCEPTS()
    FUNCTION Get():
        RETURN 1
'''
    result = process(source)
    assert all(t.rule != "GC241" for t in result.transformations)


def test_gc241_still_refuses_top_level_material_after_explicit_canonical_class():
    source = '''CLASS Box ACCEPTS()
    CONSTRUCTOR():
        self.value = 1
    FUNCTION Get():
        RETURN self.value
ENDCLASS
OUTPUT 2
'''
    result = process(source)
    assert all(t.rule != "GC241" for t in result.transformations)
