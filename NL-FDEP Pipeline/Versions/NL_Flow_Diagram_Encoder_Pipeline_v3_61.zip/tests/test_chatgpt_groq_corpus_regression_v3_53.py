"""Permanent regression checks for the supplied ChatGPT and Groq corpora.

The source exports are retained byte-for-byte under tests/corpora.  These tests
protect corpus extraction, non-lossy decoding, task numbering, and a parse-rate
floor.  Unsupported/source-level algorithms remain corpus results rather than
being silently rewritten to make the check green.
"""
from pathlib import Path

from corpus_evaluator import (
    CorpusEvaluator,
    GroqAdapter,
    NumberedSectionAdapter,
    read_corpus_text,
)

ROOT = Path(__file__).parent / "corpora"
CHATGPT = ROOT / "chatgpt_pseudocode_responses.txt"
GROQ = ROOT / "groq_pseudocode_responses.txt"


def _chatgpt_examples():
    return NumberedSectionAdapter().extract(read_corpus_text(CHATGPT), "ChatGPT")


def _groq_examples():
    return GroqAdapter().extract(read_corpus_text(GROQ), "Groq")


def test_chatgpt_source_is_decoded_losslessly_and_extracts_exactly_50_tasks():
    text = read_corpus_text(CHATGPT)
    examples = _chatgpt_examples()
    assert "Factorial × i" in text
    assert "�" not in text
    assert len(examples) == 50
    assert [item.task_number for item in examples] == list(range(1, 51))
    assert examples[0].title.startswith("Determine whether two given strings")
    assert examples[-1].title.startswith("Develop algorithms enabling autonomous drones")


def test_groq_source_extracts_exactly_50_tasks_without_example_sections():
    examples = _groq_examples()
    assert len(examples) == 50
    assert [item.task_number for item in examples] == list(range(1, 51))
    assert examples[0].source.startswith("FUNCTION ARE_ANAGRAMS")
    assert "Example:" not in examples[0].source
    assert examples[-1].source.startswith("FUNCTION COORDINATE_DRONES")


def test_new_corpora_are_part_of_the_parse_regression_gate_without_forcing_repairs():
    evaluator = CorpusEvaluator()
    chatgpt = evaluator.evaluate(_chatgpt_examples())
    groq = evaluator.evaluate(_groq_examples())

    # Floors deliberately detect regressions while permitting future evidence-backed
    # compatibility improvements to increase the number of parsed algorithms.
    assert sum(item.parse_success for item in chatgpt) >= 38
    assert sum(item.parse_success for item in groq) >= 45
    assert len(chatgpt) == 50
    assert len(groq) == 50
