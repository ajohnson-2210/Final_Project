from aj_parser import AJParserFacade
from aj_python_compiler import AJPythonCompiler
from flow_diagram import FlowDiagramEncoder
from pseudocode_profiles import PseudocodeProfile, PseudocodeProfileProcessor


def process(source: str):
    return PseudocodeProfileProcessor().process(
        source,
        PseudocodeProfile.GENERIC_COMPATIBILITY,
    )


def compile_source(processed_source: str) -> str:
    parsed = AJParserFacade().parse(processed_source)
    assert parsed.success, parsed.error
    return AJPythonCompiler().compile(
        FlowDiagramEncoder().encode(parsed.ast)
    ).source_code


def test_claude_algorithm2_exact_source_recovers_direct_mod_digit_string_prepend():
    source = '''FUNCTION decimalToBinary(n):
    IF n == 0 THEN RETURN "0"
    result ← ""
    WHILE n > 0:
        result ← (n MOD 2) + result
        n ← n DIV 2
    RETURN result
'''
    result = process(source)

    assert "result <- CALL to_string((n MODULUS 2)) + result" in result.processed_source
    assert any(t.rule == "GC230" for t in result.transformations)

    compiled = compile_source(result.processed_source)
    assert "result = (str((n % 2)) + result)" in compiled

    namespace = {}
    exec(compiled, namespace)
    decimal_to_binary = namespace["decimalToBinary"]
    for value in range(0, 4097):
        assert decimal_to_binary(value) == bin(value)[2:]


def test_gc230_accepts_already_canonical_modulus_spelling():
    source = '''FUNCTION build ACCEPTS(n)
    text <- EMPTY STRING
    text <- (n MODULUS 2) + text
    RETURN text
ENDFUNCTION
'''
    result = process(source)
    assert "text <- CALL to_string((n MODULUS 2)) + text" in result.processed_source
    assert any(t.rule == "GC230" for t in result.transformations)


def test_gc230_does_not_coerce_without_explicit_string_backing():
    source = '''FUNCTION build ACCEPTS(n)
    text <- INTEGER(0)
    text <- (n MOD 2) + text
    RETURN text
ENDFUNCTION
'''
    result = process(source)
    assert "CALL to_string" not in result.processed_source


def test_gc230_does_not_coerce_when_accumulator_is_not_the_same_destination():
    source = '''FUNCTION build ACCEPTS(n)
    text <- EMPTY STRING
    other <- EMPTY STRING
    text <- (n MOD 2) + other
    RETURN text
ENDFUNCTION
'''
    result = process(source)
    assert "CALL to_string" not in result.processed_source


def test_gc230_does_not_coerce_non_modulus_numeric_expression():
    source = '''FUNCTION build ACCEPTS(n)
    text <- EMPTY STRING
    text <- (n + 2) + text
    RETURN text
ENDFUNCTION
'''
    result = process(source)
    assert "CALL to_string" not in result.processed_source
