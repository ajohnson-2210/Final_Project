import random

from aj_parser import AJParserFacade
from aj_python_compiler import AJPythonCompiler
from flow_diagram import FlowDiagramEncoder
from pseudocode_profiles import PseudocodeProfile, PseudocodeProfileProcessor


QWEN_ALGORITHM_35 = '''INIT capacity, cache = orderedDict()

FUNCTION get(key):
    IF key in cache:
        moveToFront(cache, key)
        RETURN cache[key]
    ELSE:
        RETURN null

FUNCTION put(key, value):
    IF key in cache:
        moveToFront(cache, key)
        cache[key] = value
    ELSE:
        IF length(cache) == capacity:
            removeBack(cache)

        addToFront(cache, key, value)
'''


def _process(source: str):
    return PseudocodeProfileProcessor().process(
        source,
        PseudocodeProfile.GENERIC_COMPATIBILITY,
    )


def _compile(processed_source: str) -> str:
    parsed = AJParserFacade().parse(processed_source)
    assert parsed.success, parsed.error
    compiled = AJPythonCompiler().compile(FlowDiagramEncoder().encode(parsed.ast))
    assert compiled.success
    return compiled.source_code


def test_qwen35_recovers_evidenced_ordered_cache_as_constructor_backed_class():
    result = _process(QWEN_ALGORITHM_35)

    assert "CLASS unnamed_class" in result.processed_source
    assert "PROPERTY capacity" in result.processed_source
    assert "PROPERTY cache AS DICTIONARY" in result.processed_source
    assert "CONSTRUCTOR ACCEPTS(capacity)" in result.processed_source
    assert "PROPERTY THIS.capacity <- capacity" in result.processed_source
    assert "PROPERTY THIS.cache <- EMPTY DICTIONARY" in result.processed_source
    assert "METHOD get ACCEPTS(key)" in result.processed_source
    assert "METHOD put ACCEPTS(key, value)" in result.processed_source
    assert "CALL move_key_to_back(THIS.cache, key)" in result.processed_source
    assert "CALL remove_first_mapping(THIS.cache)" in result.processed_source
    assert "THIS.cache[key] <- value" in result.processed_source
    assert "orderedDict" not in result.processed_source
    assert "moveToFront" not in result.processed_source
    assert "removeBack" not in result.processed_source
    assert "addToFront" not in result.processed_source

    gc215 = [item for item in result.transformations if item.rule == "GC215"]
    assert len(gc215) == 1

    python_source = _compile(result.processed_source)
    assert "class unnamed_class:" in python_source
    assert "def __init__(self, capacity):" in python_source
    assert "self.capacity = capacity" in python_source
    assert "self.cache = {}" in python_source
    assert "self.cache.__setitem__(key, self.cache.pop(key))" in python_source
    assert "self.cache.pop(next(iter(self.cache)))" in python_source

    namespace = {}
    exec(python_source, namespace)
    cache = namespace["unnamed_class"](2)
    cache.put("a", 1)
    cache.put("b", 2)
    assert cache.get("a") == 1
    cache.put("c", 3)
    assert cache.get("b") is None
    assert cache.get("c") == 3
    cache.put("a", 4)
    assert cache.get("a") == 4


def test_gc215_audit_reports_source_proven_stateful_adt_recovery():
    result = _process(QWEN_ALGORITHM_35)
    entries = [
        item for item in result.to_dict()["transformations"]
        if item["branch"] == "EVIDENCED_ORDERED_CACHE_CONSTRUCTOR"
    ]
    assert len(entries) == 1
    assert entries[0]["rule_family"] == "STATEFUL_ADT_STRUCTURE"
    assert entries[0]["confidence"] == "source_proven"
    assert entries[0]["semantic_change"] is False


def test_gc215_is_not_hardcoded_to_capacity_cache_get_put_names():
    source = '''INIT limit, store = orderedDict()
FUNCTION read(k):
    IF k in store:
        moveToFront(store, k)
        RETURN store[k]
    ELSE:
        RETURN null
FUNCTION write(k, v):
    IF k in store:
        moveToFront(store, k)
        store[k] = v
    ELSE:
        IF length(store) == limit:
            removeBack(store)
        addToFront(store, k, v)
'''
    result = _process(source)
    assert "PROPERTY limit" in result.processed_source
    assert "PROPERTY store AS DICTIONARY" in result.processed_source
    assert "CONSTRUCTOR ACCEPTS(limit)" in result.processed_source
    assert "METHOD read ACCEPTS(k)" in result.processed_source
    assert "METHOD write ACCEPTS(k, v)" in result.processed_source
    assert any(item.rule == "GC215" for item in result.transformations)


def test_gc215_refuses_unrelated_multi_target_init():
    source = '''INIT count, values = orderedDict()
FUNCTION first(key):
    RETURN values[key]
FUNCTION second(key):
    RETURN values[key]
'''
    result = _process(source)
    assert not any(item.rule == "GC215" for item in result.transformations)
    assert "INIT count, values" in result.processed_source


def test_gc215_refuses_move_to_front_without_membership_proof():
    source = QWEN_ALGORITHM_35.replace(
        "    IF key in cache:\n        moveToFront(cache, key)\n        RETURN cache[key]",
        "    moveToFront(cache, key)\n    RETURN cache[key]",
        1,
    )
    result = _process(source)
    assert not any(item.rule == "GC215" for item in result.transformations)


def test_gc215_refuses_remove_back_without_fullness_guard():
    source = QWEN_ALGORITHM_35.replace(
        "        IF length(cache) == capacity:\n            removeBack(cache)",
        "        removeBack(cache)",
    )
    result = _process(source)
    assert not any(item.rule == "GC215" for item in result.transformations)


def test_gc215_refuses_add_to_front_outside_absent_key_branch():
    source = QWEN_ALGORITHM_35.replace(
        "\n        addToFront(cache, key, value)",
        "\n    addToFront(cache, key, value)",
    )
    result = _process(source)
    assert not any(item.rule == "GC215" for item in result.transformations)


def test_gc215_refuses_unknown_call_escape():
    source = QWEN_ALGORITHM_35.replace(
        "        moveToFront(cache, key)\n        RETURN cache[key]",
        "        inspect(cache)\n        moveToFront(cache, key)\n        RETURN cache[key]",
        1,
    )
    result = _process(source)
    assert not any(item.rule == "GC215" for item in result.transformations)


def test_gc215_constructor_capacity_matches_reference_lru_for_random_sequences():
    result = _process(QWEN_ALGORITHM_35)
    python_source = _compile(result.processed_source)
    namespace = {}
    exec(python_source, namespace)
    Cache = namespace["unnamed_class"]

    rng = random.Random(24038155)
    for capacity in range(1, 6):
        for _ in range(100):
            actual = Cache(capacity)
            # Reference order is LRU -> MRU.
            reference = {}
            order = []
            for _ in range(40):
                key = rng.randrange(6)
                if rng.random() < 0.62:
                    value = rng.randrange(1000)
                    actual.put(key, value)
                    if key in reference:
                        reference[key] = value
                        order.remove(key)
                        order.append(key)
                    else:
                        if len(reference) == capacity:
                            oldest = order.pop(0)
                            del reference[oldest]
                        reference[key] = value
                        order.append(key)
                else:
                    got = actual.get(key)
                    expected = reference.get(key)
                    assert got == expected
                    if key in reference:
                        order.remove(key)
                        order.append(key)

                assert actual.cache == {key: reference[key] for key in order}
