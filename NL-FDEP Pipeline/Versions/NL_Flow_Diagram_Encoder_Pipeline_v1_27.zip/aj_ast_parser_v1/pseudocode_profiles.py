"""Controlled pseudocode processing profiles for the input pipeline."""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from enum import Enum
import json
import re


class PseudocodeProfile(str, Enum):
    """Available pseudocode processing profiles."""

    AJ_DIALECT_STRICT = "AJ_DIALECT_STRICT"
    GENERIC_COMPATIBILITY = "GENERIC_COMPATIBILITY"
    GENERAL_NO_CONVERSION = "GENERAL_NO_CONVERSION"


@dataclass
class SourceTransformation:
    """Records one deliberate source transformation."""

    line: int | None
    rule: str
    source: str
    target: str


@dataclass
class PseudocodeProcessingResult:
    """Contains processed source and an auditable transformation report."""

    profile: PseudocodeProfile
    original_source: str
    processed_source: str
    transformations: list[SourceTransformation] = field(default_factory=list)
    header_comment_removed: bool = False
    header_lines_removed: int = 0

    @property
    def source_modified(self) -> bool:
        """Returns whether the selected profile changed the supplied source."""

        return self.original_source != self.processed_source

    @property
    def transformation_count(self) -> int:
        """Returns the number of logged transformations."""

        return len(self.transformations)

    def to_dict(self) -> dict:
        """Returns a serialisable processing report."""

        transformations = []

        for transformation in self.transformations:
            transformations.append(
                asdict(transformation)
            )

        return {
            "profile": self.profile.value,
            "source_modified": self.source_modified,
            "transformation_count": self.transformation_count,
            "transformations": transformations,
            "header_comment_removed": self.header_comment_removed,
            "header_lines_removed": self.header_lines_removed,
        }

    def to_json(self) -> str:
        """Returns the processing report as formatted JSON."""

        return json.dumps(
            self.to_dict(),
            indent=2,
        )


class InitialHashCommentStripper:
    """Removes an optional leading hash-comment metadata block before parsing."""

    PSEUDOCODE_START_PATTERN = re.compile(
        r"^(?:"
        r"INPUT\b|OUTPUT\b|FUNCTION\b|CLASS\b|IF\b|WHILE\b|FOR\b|"
        r"RETURN\b|CALL\b|TRY\b|RAISE\b|COMMENT\b|BREAK\b|"
        r"[A-Za-z_][A-Za-z0-9_]*(?:\[[^\]]+\])?\s*(?:<-|=)"
        r")",
        re.IGNORECASE,
    )

    def strip(self, source: str) -> tuple[str, bool, int]:
        """Removes a leading hash-comment metadata block before pseudocode begins."""

        source_lines = source.splitlines(keepends=True)

        if not source_lines:
            return source, False, 0

        header_start_index = 0

        while header_start_index < len(source_lines):
            candidate_line = source_lines[header_start_index]
            candidate_line = candidate_line.lstrip("\ufeff \t\r\n")

            if candidate_line != "":
                break

            header_start_index += 1

        if header_start_index >= len(source_lines):
            return source, False, 0

        first_content_line = source_lines[header_start_index]
        first_content_line = first_content_line.lstrip("\ufeff \t")

        if not first_content_line.startswith("#"):
            return source, False, 0

        first_pseudocode_index = None

        for index in range(header_start_index + 1, len(source_lines)):
            candidate = source_lines[index]
            stripped_candidate = candidate.strip()

            if stripped_candidate == "":
                first_pseudocode_index = index + 1

                while first_pseudocode_index < len(source_lines):
                    if source_lines[first_pseudocode_index].strip() != "":
                        break

                    first_pseudocode_index += 1

                break

            if self._looks_like_pseudocode(stripped_candidate):
                first_pseudocode_index = index
                break

        if first_pseudocode_index is None:
            first_pseudocode_index = header_start_index + 1

        processed_source = "".join(
            source_lines[first_pseudocode_index:]
        )

        return processed_source, True, first_pseudocode_index

    def _looks_like_pseudocode(self, line: str) -> bool:
        """Returns whether a line clearly begins with executable pseudocode."""

        return bool(
            self.PSEUDOCODE_START_PATTERN.match(
                line
            )
        )


@dataclass(frozen=True)
class CharacterNormalisationRule:
    """Defines one auditable Generic compatibility character rule."""

    rule_id: str
    source: str
    target: str
    description: str


class GenericCharacterNormaliser:
    """Normalises characters observed across the six-model pseudocode corpus."""

    RULES = (
        CharacterNormalisationRule("GC001", "≠", "!=", "Unicode not-equal operator"),
        CharacterNormalisationRule("GC002", "≤", "<=", "Unicode less-than-or-equal operator"),
        CharacterNormalisationRule("GC003", "≥", ">=", "Unicode greater-than-or-equal operator"),
        CharacterNormalisationRule("GC004", "←", "<-", "Unicode assignment arrow"),
        CharacterNormalisationRule("GC005", "×", "*", "Unicode multiplication operator"),
        CharacterNormalisationRule("GC006", "∞", "INFINITY", "Unicode infinity symbol"),
        CharacterNormalisationRule("GC007", "→", "TO", "Unicode right arrow"),
        CharacterNormalisationRule("GC008", "“", '"', "Opening smart double quote"),
        CharacterNormalisationRule("GC009", "”", '"', "Closing smart double quote"),
        CharacterNormalisationRule("GC010", "‘", "'", "Opening smart single quote"),
        CharacterNormalisationRule("GC011", "’", "'", "Closing smart single quote"),
        CharacterNormalisationRule("GC012", "–", "-", "Unicode en dash"),
        CharacterNormalisationRule("GC013", "\u2005", " ", "Unicode four-per-em space"),
        CharacterNormalisationRule("GC014", "\u00a0", " ", "Non-breaking space"),
        CharacterNormalisationRule("GC015", "\u200b", "", "Zero-width space"),
        CharacterNormalisationRule("GC016", "\ufeff", "", "UTF-8 BOM / zero-width no-break space"),
    )

    def process(self, source: str) -> tuple[str, list[SourceTransformation]]:
        """Applies corpus-derived character rules and records every changed line."""

        source_lines = source.splitlines(keepends=True)
        transformations = []
        processed_lines = []

        for line_number, source_line in enumerate(source_lines, start=1):
            transformed_line = source_line

            for rule in self.RULES:
                if rule.source not in transformed_line:
                    continue

                before = transformed_line
                transformed_line = transformed_line.replace(
                    rule.source,
                    rule.target,
                )

                transformations.append(
                    SourceTransformation(
                        line=line_number,
                        rule=rule.rule_id,
                        source=before.rstrip("\r\n"),
                        target=transformed_line.rstrip("\r\n"),
                    )
                )

            degree_before = transformed_line
            transformed_line = re.sub(
                r"(?<=\d)°",
                " DEG",
                transformed_line,
            )

            if transformed_line != degree_before:
                transformations.append(
                    SourceTransformation(
                        line=line_number,
                        rule="GC017",
                        source=degree_before.rstrip("\r\n"),
                        target=transformed_line.rstrip("\r\n"),
                    )
                )

            processed_lines.append(
                transformed_line
            )

        return "".join(processed_lines), transformations


class GenericStatementBoundaryNormaliser:
    """Reconstructs logical lines in pseudocode compressed onto one physical line."""

    START_PATTERN = re.compile(
        r"(?i)(?:^|\s+)(?=(?:"
        r"INPUT\b|OUTPUT\b|PRINT\b|DISPLAY\b|RETURN\b|RAISE\b|"
        r"IF\b|ELSE\s+IF\b|ELSE\b|WHILE\b|FOR\s+EACH\b|FOR\b|"
        r"FUNCTION\b|PROCEDURE\b|CALL\b|APPEND\b|ADD\b|REMOVE\b|"
        r"SWAP\b|REVERSE\b|ENQUEUE\b|DEQUEUE\b|PUSH\b|POP\b|"
        r"CREATE\b|INIT\b|[A-Za-z_][A-Za-z0-9_]*(?:\[[^\]]+\])?\.(?:append|add|enqueue|dequeue|push|pop|popFront|popBack|pushBack)\b|"
        r"[A-Za-z_][A-Za-z0-9_]*(?:\[[^\]]+\])?\s*(?:<-|\+=|-=|\*=|/=|%=|\+\+|--|(?<![<>=!])=(?!=))"
        r"))"
    )

    def process(self, source: str) -> tuple[str, list[SourceTransformation]]:
        transformations: list[SourceTransformation] = []
        output: list[str] = []

        for line_number, source_line in enumerate(source.splitlines(), start=1):
            stripped = source_line.strip()

            if not self._is_compressed_candidate(stripped):
                output.append(source_line)
                continue

            statements = self._split_statements(stripped)

            if len(statements) <= 1:
                output.append(source_line)
                continue

            reconstructed = self._reconstruct_indentation(statements)
            output.extend(reconstructed)
            transformations.append(
                SourceTransformation(
                    line=line_number,
                    rule="GC085",
                    source=source_line,
                    target="\n".join(reconstructed),
                )
            )

        return "\n".join(output), transformations

    def _is_compressed_candidate(self, line: str) -> bool:
        if not line or len(line) < 35:
            return False
        starts = self._candidate_positions(line)
        return len(starts) >= 3

    def _candidate_positions(self, line: str) -> list[int]:
        masked = self._mask_nested_and_quoted_text(line)
        positions = {0}
        for match in self.START_PATTERN.finditer(masked):
            pos = match.start()
            while pos < len(masked) and masked[pos].isspace():
                pos += 1
            if masked[pos:pos + 2].upper() == "IF":
                prefix = masked[:pos].rstrip().upper()
                if prefix.endswith("ELSE"):
                    continue
            positions.add(pos)
        return sorted(positions)

    def _split_statements(self, line: str) -> list[str]:
        positions = self._candidate_positions(line)
        pieces: list[str] = []
        for index, start in enumerate(positions):
            end = positions[index + 1] if index + 1 < len(positions) else len(line)
            piece = line[start:end].strip()
            if piece.endswith(","):
                piece = piece[:-1].rstrip()
            if piece:
                pieces.append(piece)
        return self._repair_control_headers(pieces)

    def _repair_control_headers(self, pieces: list[str]) -> list[str]:
        repaired: list[str] = []
        for piece in pieces:
            piece = piece.strip()
            if piece.endswith(":"):
                piece = piece[:-1].rstrip()
            repaired.append(piece)
        return repaired

    def _reconstruct_indentation(self, statements: list[str]) -> list[str]:
        output: list[str] = []
        indent = 0
        stack: list[str] = []

        for index, statement in enumerate(statements):
            upper = statement.upper()
            next_upper = statements[index + 1].upper() if index + 1 < len(statements) else ""

            if upper.startswith("ELSE IF ") or upper == "ELSE" or upper.startswith("ELSE "):
                if stack and stack[-1] == "IF":
                    indent = max(0, indent - 4)
                output.append(" " * indent + statement)
                indent += 4
                continue

            # A return immediately after IF belongs to that branch. A return after a
            # loop body normally follows the loop, so close active loop scopes first.
            if upper.startswith("RETURN ") and stack and stack[-1] != "IF":
                while stack and stack[-1] in {"FOR", "WHILE"}:
                    stack.pop()
                    indent = max(0, indent - 4)

            output.append(" " * indent + statement)

            opener = None
            if upper.startswith("FUNCTION ") or upper.startswith("PROCEDURE "):
                opener = "FUNCTION"
            elif upper.startswith("IF "):
                opener = "IF"
            elif upper.startswith("WHILE "):
                opener = "WHILE"
            elif upper.startswith("FOR "):
                opener = "FOR"

            if opener is not None:
                stack.append(opener)
                indent += 4
                continue

            # A single compact branch such as IF condition RETURN value ends after
            # the return unless an ELSE/ELSE IF immediately follows.
            if upper.startswith("RETURN ") and stack and stack[-1] == "IF":
                if not (next_upper == "ELSE" or next_upper.startswith("ELSE ") or next_upper.startswith("ELSE IF ")):
                    stack.pop()
                    indent = max(0, indent - 4)

        return output

    def _mask_nested_and_quoted_text(self, text: str) -> str:
        chars = list(text)
        quote = None
        escape = False
        depth = 0

        for index, char in enumerate(text):
            if quote is not None:
                chars[index] = " "
                if escape:
                    escape = False
                elif char == "\\":
                    escape = True
                elif char == quote:
                    quote = None
                continue

            if char in {"'", '"'}:
                quote = char
                chars[index] = " "
                continue

            if char in "([{":
                depth += 1
                chars[index] = " "
                continue

            if char in "})]":
                chars[index] = " "
                depth = max(0, depth - 1)
                continue

            if depth > 0:
                chars[index] = " "

        return "".join(chars)


@dataclass(frozen=True)
class OperatorNormalisationRule:
    """Defines one auditable Generic compatibility operator rule."""

    rule_id: str
    source: str
    target: str
    description: str


class GenericOperatorNormaliser:
    """Normalises operator forms observed across the six-model corpus."""

    COMPOUND_RULES = (
        OperatorNormalisationRule("GC018", "+=", "<-", "Compound addition assignment"),
        OperatorNormalisationRule("GC019", "-=", "<-", "Compound subtraction assignment"),
        OperatorNormalisationRule("GC020", "*=", "<-", "Compound multiplication assignment"),
        OperatorNormalisationRule("GC021", "/=", "<-", "Compound division assignment"),
        OperatorNormalisationRule("GC022", "%=", "<-", "Compound modulus assignment"),
    )

    def process(self, source: str) -> tuple[str, list[SourceTransformation]]:
        """Applies context-aware operator rules and records each changed line."""

        transformations = []
        processed_lines = []

        for line_number, source_line in enumerate(source.splitlines(keepends=True), start=1):
            transformed_line = source_line

            transformed_line, line_transformations = self._normalise_line(
                transformed_line,
                line_number,
            )
            transformations.extend(line_transformations)
            processed_lines.append(transformed_line)

        return "".join(processed_lines), transformations

    def _normalise_line(
        self,
        line: str,
        line_number: int,
    ) -> tuple[str, list[SourceTransformation]]:
        """Normalises one line without confusing comparison and assignment equals."""

        transformations = []
        transformed = line

        for rule in self.COMPOUND_RULES:
            pattern = re.compile(
                rf"(?P<target>[A-Za-z_][A-Za-z0-9_]*(?:\[[^\]]+\])?(?:\.[A-Za-z_][A-Za-z0-9_]*)*)\s*{re.escape(rule.source)}\s*(?P<value>[^,;\n]+)"
            )

            def replace_compound(match):
                target = match.group("target")
                value = match.group("value").strip()
                operator = rule.source[0]
                return f"{target} <- {target} {operator} {value}"

            before = transformed
            transformed = pattern.sub(replace_compound, transformed)
            self._record_if_changed(
                transformations, line_number, rule.rule_id, before, transformed
            )

        for rule_id, suffix, operator in (
            ("GC023", "++", "+"),
            ("GC024", "--", "-"),
        ):
            pattern = re.compile(
                rf"(?P<target>[A-Za-z_][A-Za-z0-9_]*(?:\[[^\]]+\])?(?:\.[A-Za-z_][A-Za-z0-9_]*)*)\s*{re.escape(suffix)}"
            )

            def replace_step(match, op=operator):
                target = match.group("target")
                return f"{target} <- {target} {op} 1"

            before = transformed
            transformed = pattern.sub(replace_step, transformed)
            self._record_if_changed(
                transformations, line_number, rule_id, before, transformed
            )

        before = transformed
        transformed = self._normalise_condition_equals(transformed)
        self._record_if_changed(
            transformations, line_number, "GC025", before, transformed
        )

        before = transformed
        transformed = self._normalise_assignment_equals(transformed)
        self._record_if_changed(
            transformations, line_number, "GC026", before, transformed
        )

        return transformed, transformations

    def _normalise_condition_equals(self, line: str) -> str:
        """Converts single equals to equality only in explicit condition clauses."""

        line_ending = ""

        if line.endswith("\r\n"):
            line_ending = "\r\n"
            content = line[:-2]
        elif line.endswith("\n") or line.endswith("\r"):
            line_ending = line[-1]
            content = line[:-1]
        else:
            content = line

        condition_match = re.match(
            r"^(?P<prefix>\s*(?:IF|ELSE\s+IF|WHILE)\s+)(?P<body>.*)$",
            content,
            re.IGNORECASE,
        )

        if condition_match is None:
            return line

        prefix = condition_match.group("prefix")
        body = condition_match.group("body")

        boundary_match = re.search(
            r"\s+THEN\b|:",
            body,
            re.IGNORECASE,
        )

        if boundary_match is None:
            condition_text = body
            suffix = ""
        else:
            condition_text = body[:boundary_match.start()]
            suffix = body[boundary_match.start():]

        condition_text = re.sub(
            r"(?<![<>=!])=(?!=)",
            "==",
            condition_text,
        )
        return f"{prefix}{condition_text}{suffix}{line_ending}"

    def _normalise_assignment_equals(self, line: str) -> str:
        """Converts a leading lvalue assignment equals to AJ assignment syntax."""

        return re.sub(
            r"^(?P<indent>\s*)(?P<target>[A-Za-z_][A-Za-z0-9_]*(?:\[[^\]]+\])?(?:\.[A-Za-z_][A-Za-z0-9_]*)*)\s*(?<![<>=!])=(?!=)\s*",
            lambda match: f"{match.group('indent')}{match.group('target')} <- ",
            line,
            count=1,
        )

    def _record_if_changed(
        self,
        transformations: list[SourceTransformation],
        line_number: int,
        rule_id: str,
        before: str,
        after: str,
    ) -> None:
        """Adds one transformation record when a rule changes a line."""

        if before == after:
            return

        transformations.append(
            SourceTransformation(
                line=line_number,
                rule=rule_id,
                source=before.rstrip("\r\n"),
                target=after.rstrip("\r\n"),
            )
        )


class GenericCollectionNormaliser:
    """Normalises collection literals and operations observed in the corpus."""

    def process(self, source: str) -> tuple[str, list[SourceTransformation]]:
        transformations = []
        processed_lines = []

        for line_number, source_line in enumerate(source.splitlines(keepends=True), start=1):
            transformed = source_line
            rules = (
                ("GC027", r"(?i)\bempty\s+list\b", "EMPTY LIST"),
                ("GC028", r"(?i)\bempty\s+set\b", "EMPTY SET"),
                ("GC029", r"(?i)\bempty\s+(?:hash\s*map|dictionary|map)\b", "EMPTY DICTIONARY"),
                ("GC030", r"(?i)\bordered\s+dictionary\b", "EMPTY DICTIONARY"),
                ("GC031", r"(?i)\bempty\s+queue\b", "EMPTY QUEUE"),
                ("GC032", r"(?i)\bempty\s+(?:deque|doubleendedqueue|double\s*ended\s*queue)\b", "EMPTY DEQUE"),
            )

            for rule_id, pattern, replacement in rules:
                before = transformed
                transformed = re.sub(pattern, replacement, transformed)
                self._record(transformations, line_number, rule_id, before, transformed)

            before = transformed
            transformed = re.sub(
                r"(?P<name>[A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*)*)\.append\((?P<value>[^()]*)\)",
                lambda m: f"APPEND {m.group('value').strip()} TO {m.group('name')}",
                transformed,
                flags=re.IGNORECASE,
            )
            self._record(transformations, line_number, "GC033", before, transformed)

            before = transformed
            transformed = re.sub(
                r"(?P<name>[A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*)*)\.add\((?P<value>[^()]*)\)",
                lambda m: f"ADD {m.group('value').strip()} TO {m.group('name')}",
                transformed,
                flags=re.IGNORECASE,
            )
            self._record(transformations, line_number, "GC034", before, transformed)

            before = transformed
            transformed = re.sub(
                r"(?P<name>[A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*)*)\.enqueue\((?P<value>[^()]*)\)",
                lambda m: f"ENQUEUE {m.group('value').strip()} TO {m.group('name')}",
                transformed,
                flags=re.IGNORECASE,
            )
            self._record(transformations, line_number, "GC035", before, transformed)

            before = transformed
            transformed = re.sub(
                r"(?P<name>[A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*)*)\.dequeue\(\)",
                lambda m: f"DEQUEUE FROM {m.group('name')}",
                transformed,
                flags=re.IGNORECASE,
            )
            self._record(transformations, line_number, "GC036", before, transformed)

            before = transformed
            transformed = re.sub(
                r"(?P<name>[A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*)*)\.(?:push_back|push)\((?P<value>[^()]*)\)",
                lambda m: f"PUSH {m.group('value').strip()} TO {m.group('name')}",
                transformed,
                flags=re.IGNORECASE,
            )
            self._record(transformations, line_number, "GC037", before, transformed)

            before = transformed
            transformed = re.sub(
                r"(?P<name>[A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*)*)\.pop_front\(\)",
                lambda m: f"REMOVE FIRST ITEM FROM {m.group('name')}",
                transformed,
                flags=re.IGNORECASE,
            )
            self._record(transformations, line_number, "GC038", before, transformed)

            before = transformed
            transformed = re.sub(
                r"(?P<name>[A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*)*)\.pop_back\(\)",
                lambda m: f"REMOVE LAST ITEM FROM {m.group('name')}",
                transformed,
                flags=re.IGNORECASE,
            )
            self._record(transformations, line_number, "GC039", before, transformed)

            processed_lines.append(transformed)

        return "".join(processed_lines), transformations

    def _record(self, transformations, line_number, rule_id, before, after):
        if before == after:
            return
        transformations.append(SourceTransformation(
            line=line_number, rule=rule_id,
            source=before.rstrip("\r\n"), target=after.rstrip("\r\n")
        ))


class GenericStatementNormaliser:
    """Normalises common built-in and procedural statement forms from the corpus."""

    def process(self, source: str) -> tuple[str, list[SourceTransformation]]:
        transformations = []
        processed_lines = []

        for line_number, source_line in enumerate(source.splitlines(keepends=True), start=1):
            transformed = source_line

            rules = (
                ("GC040", r"(?i)\b(?:length|len)\s*\(([^()]+)\)", r"LENGTH OF \1"),
                ("GC041", r"(?i)\b(?:lowercase|tolower|toLower)\s*\(([^()]+)\)", r"LOWERCASE(\1)"),
                ("GC042", r"(?i)\b(?:uppercase|toupper|toUpper)\s*\(([^()]+)\)", r"UPPERCASE(\1)"),
                ("GC043", r"(?i)^([ \t]*)PRINT\s+", r"\1OUTPUT "),
                ("GC044", r"(?i)^([ \t]*)DISPLAY\s+", r"\1OUTPUT "),
                ("GC045", r"(?i)\.size\(\)", r"~LENGTH"),
                ("GC046", r"(?i)\.front\(\)", r"[0]"),
                ("GC047", r"(?i)\.back\(\)", r"[LAST]"),
                ("GC048", r"(?i)([A-Za-z_][A-Za-z0-9_.]*)\.isEmpty\(\)", r"LENGTH OF \1 == 0"),
            )

            for rule_id, pattern, replacement in rules:
                before = transformed
                transformed = re.sub(pattern, replacement, transformed)
                self._record(transformations, line_number, rule_id, before, transformed)

            # Function-style split and join forms with simple arguments.
            before = transformed
            transformed = re.sub(
                r"(?i)\bSPLIT\(([^,()]+),\s*([^()]+)\)",
                lambda m: f"SPLIT {m.group(1).strip()} BY {m.group(2).strip()}",
                transformed,
            )
            self._record(transformations, line_number, "GC049", before, transformed)

            before = transformed
            transformed = re.sub(
                r"(?i)\bJOIN\(([^,()]+),\s*([^()]+)\)",
                lambda m: f"JOIN({m.group(1).strip()}, {m.group(2).strip()})",
                transformed,
            )
            self._record(transformations, line_number, "GC050", before, transformed)

            # Normalise simple function-style SWAP(a, b) to the dialect statement form.
            before = transformed
            transformed = re.sub(
                r"(?i)\bSWAP\(([^,()]+),\s*([^()]+)\)",
                lambda m: f"SWAP {m.group(1).strip()} AND {m.group(2).strip()}",
                transformed,
            )
            self._record(transformations, line_number, "GC051", before, transformed)

            # Normalise simple REVERSE(x) calls used as standalone procedural shorthand.
            before = transformed
            transformed = re.sub(
                r"(?i)^([ \t]*)REVERSE\(([^()]+)\)\s*$",
                lambda m: f"{m.group(1)}REVERSE {m.group(2).strip()}",
                transformed.rstrip("\r\n"),
            ) + ("\n" if source_line.endswith("\n") else "")
            self._record(transformations, line_number, "GC052", before, transformed)

            processed_lines.append(transformed)

        return "".join(processed_lines), transformations

    def _record(self, transformations, line_number, rule_id, before, after):
        if before == after:
            return
        transformations.append(SourceTransformation(
            line=line_number, rule=rule_id,
            source=before.rstrip("\r\n"), target=after.rstrip("\r\n")
        ))


class GenericGrammarNormaliser:
    """Normalises structural grammar variants observed in the six-model corpus."""

    def process(self, source: str) -> tuple[str, list[SourceTransformation]]:
        transformations = []
        processed_lines = []

        for line_number, source_line in enumerate(source.splitlines(), start=1):
            transformed_lines, rule_ids = self._normalise_line(source_line)

            if transformed_lines != [source_line]:
                target = "\n".join(transformed_lines)
                for rule_id in rule_ids:
                    transformations.append(
                        SourceTransformation(
                            line=line_number,
                            rule=rule_id,
                            source=source_line,
                            target=target,
                        )
                    )

            processed_lines.extend(transformed_lines)

        return "\n".join(processed_lines), transformations

    def _normalise_line(self, line: str) -> tuple[list[str], list[str]]:
        indent = line[: len(line) - len(line.lstrip())]
        content = line.strip()
        rules = []

        if content == "":
            return [line], rules

        if re.fullmatch(r"BEGIN", content, re.IGNORECASE):
            return [], ["GC053"]

        if re.fullmatch(r"END", content, re.IGNORECASE):
            return [], ["GC054"]

        match = re.fullmatch(r"FUNCTION\s+([A-Za-z_][A-Za-z0-9_]*)\s*\((.*?)\)\s*:?", content, re.IGNORECASE)
        if match is not None:
            return [f"{indent}FUNCTION {match.group(1)} ACCEPTS({match.group(2).strip()})"], ["GC055"]

        match = re.fullmatch(r"PROCEDURE\s+([A-Za-z_][A-Za-z0-9_]*)\s*\((.*?)\)\s*:?", content, re.IGNORECASE)
        if match is not None:
            return [f"{indent}FUNCTION {match.group(1)} ACCEPTS({match.group(2).strip()})"], ["GC056"]

        terminators = (
            (r"END\s+FUNCTION", "ENDFUNCTION", "GC057"),
            (r"END\s+PROCEDURE", "ENDFUNCTION", "GC058"),
            (r"END\s+IF", "ENDIF", "GC059"),
            (r"END\s+WHILE", "ENDWHILE", "GC060"),
            (r"END\s+FOR", "ENDFOR", "GC061"),
        )
        for pattern, replacement, rule_id in terminators:
            if re.fullmatch(pattern, content, re.IGNORECASE):
                return [f"{indent}{replacement}"], [rule_id]

        if re.fullmatch(r"ELSE\s*:", content, re.IGNORECASE):
            return [f"{indent}ELSE"], ["GC062"]

        match = re.fullmatch(r"ELSE\s+IF\s+(.+?)(?:\s+THEN)?\s*:?", content, re.IGNORECASE)
        if match is not None:
            condition = match.group(1).strip()
            condition = re.sub(r"\s+THEN$", "", condition, flags=re.IGNORECASE).strip()
            return [f"{indent}ELSE IF {condition} THEN"], ["GC063"]

        match = re.fullmatch(r"IF\s+(.+?)\s+THEN\s+RETURN\s+(.+)", content, re.IGNORECASE)
        if match is not None:
            condition = match.group(1).strip()
            value = match.group(2).strip().rstrip(":")
            return [
                f"{indent}IF {condition} THEN",
                f"{indent}    RETURN {value}",
                f"{indent}ENDIF",
            ], ["GC064"]

        match = re.fullmatch(r"IF\s+(.+?)\s+RETURN\s+(.+)", content, re.IGNORECASE)
        if match is not None:
            condition = match.group(1).strip().rstrip(":")
            value = match.group(2).strip()
            return [
                f"{indent}IF {condition} THEN",
                f"{indent}    RETURN {value}",
                f"{indent}ENDIF",
            ], ["GC065"]

        match = re.fullmatch(r"IF\s+(.+?)\s*:?", content, re.IGNORECASE)
        if match is not None:
            condition = match.group(1).strip()
            condition = re.sub(r"\s+THEN$", "", condition, flags=re.IGNORECASE).strip()
            return [f"{indent}IF {condition} THEN"], ["GC066"]

        match = re.fullmatch(r"WHILE\s+(.+?)\s*:?", content, re.IGNORECASE)
        if match is not None:
            condition = match.group(1).strip()
            condition = re.sub(r"\s+DO$", "", condition, flags=re.IGNORECASE).strip()
            return [f"{indent}WHILE {condition} DO"], ["GC067"]

        match = re.fullmatch(r"FOR\s+EACH\s+([A-Za-z_][A-Za-z0-9_]*)\s+IN\s+(.+?)\s*:?", content, re.IGNORECASE)
        if match is not None:
            collection = re.sub(r"\s+DO$", "", match.group(2).strip(), flags=re.IGNORECASE).strip()
            return [f"{indent}FOR EACH {match.group(1)} IN {collection} DO"], ["GC068"]

        match = re.fullmatch(r"FOR\s+([A-Za-z_][A-Za-z0-9_]*)\s+IN\s+(.+?)\s*:?", content, re.IGNORECASE)
        if match is not None:
            collection = re.sub(r"\s+DO$", "", match.group(2).strip(), flags=re.IGNORECASE).strip()
            return [f"{indent}FOR EACH {match.group(1)} IN {collection} DO"], ["GC069"]

        match = re.fullmatch(r"FOR\s+([A-Za-z_][A-Za-z0-9_]*)\s+FROM\s+(.+?)\s+(DOWN\s*TO|DOWNTO|TO)\s+(.+?)\s*(?:DO)?\s*:?", content, re.IGNORECASE)
        if match is not None:
            iterator, start, direction, end = match.group(1), match.group(2).strip(), match.group(3).upper().replace(" ", ""), match.group(4).strip()
            end = re.sub(r"\s+DO$", "", end, flags=re.IGNORECASE).strip()
            step = " STEP -1" if direction == "DOWNTO" else ""
            return [f"{indent}FOR {iterator} <- IN RANGE {start} TO {end}{step} DO"], ["GC070"]

        match = re.fullmatch(r"FOR\s+([A-Za-z_][A-Za-z0-9_]*)\s*(?:<-|=)\s*(.+?)\s+TO\s+(.+?)\s*:?", content, re.IGNORECASE)
        if match is not None:
            start = match.group(2).strip()
            end = re.sub(r"\s+DO$", "", match.group(3).strip(), flags=re.IGNORECASE).strip()
            return [f"{indent}FOR {match.group(1)} <- IN RANGE {start} TO {end} DO"], ["GC071"]

        if content.endswith(":"):
            return [f"{indent}{content[:-1].rstrip()}"], ["GC072"]

        return [line], rules



class GenericRecoveryNormaliser:
    """Applies corpus-derived parser recovery rules after grammar normalisation."""

    RESERVED_IDENTIFIER_RENAMES = {
        "char": "character",
        "list": "values",
    }

    KNOWN_CALL_WORDS = {
        "FUNCTION", "INPUT", "OUTPUT", "BOOLEAN", "STRING", "CHAR",
        "INTEGER", "FLOAT", "LIST", "TUPLE", "JOIN", "IF", "WHILE",
        "FOR", "CALL", "LENGTH", "COMMENT", "LOWERCASE", "UPPERCASE",
        "SPLIT", "REVERSE", "SWAP", "MAX", "MIN",
    }

    def process(self, source: str) -> tuple[str, list[SourceTransformation]]:
        transformations: list[SourceTransformation] = []
        lines = source.splitlines()
        expanded: list[tuple[int, str]] = []

        for line_number, line in enumerate(lines, start=1):
            before = line
            produced, rules = self._normalise_line(line)
            for rule_id in rules:
                transformations.append(
                    SourceTransformation(
                        line=line_number,
                        rule=rule_id,
                        source=before,
                        target="\\n".join(produced),
                    )
                )
            for produced_line in produced:
                expanded.append((line_number, produced_line))

        closed_lines, closure_transforms = self._insert_indentation_closures(expanded)
        transformations.extend(closure_transforms)

        closed_lines, wrapper_transform = self._wrap_functionless_return_program(closed_lines)
        if wrapper_transform is not None:
            transformations.append(wrapper_transform)

        return "\n".join(closed_lines), transformations

    def _wrap_functionless_return_program(
        self,
        lines: list[str],
    ) -> tuple[list[str], SourceTransformation | None]:
        has_function = any(
            line.strip().upper().startswith("FUNCTION ")
            for line in lines
        )
        has_top_level_return = any(
            line == line.lstrip() and line.strip().upper().startswith("RETURN ")
            for line in lines
        )

        if has_function or not has_top_level_return:
            return lines, None

        body = []
        for line in lines:
            if line.strip():
                body.append("    " + line)
            else:
                body.append(line)

        wrapped = ["FUNCTION generic_algorithm ACCEPTS()"]
        wrapped.extend(body)
        wrapped.append("ENDFUNCTION")
        wrapped.append("CALL generic_algorithm()")

        return wrapped, SourceTransformation(
            line=None,
            rule="GC086",
            source="Functionless program containing top-level RETURN",
            target="Wrapped in FUNCTION generic_algorithm ACCEPTS()",
        )

    def _normalise_line(self, line: str) -> tuple[list[str], list[str]]:
        indent = line[: len(line) - len(line.lstrip())]
        content = line.strip()
        rules: list[str] = []

        if content == "":
            return [line], rules

        if content.startswith("#"):
            return [f"{indent}COMMENT {content[1:].strip()}"], ["GC073"]
        if content.startswith("//"):
            return [f"{indent}COMMENT {content[2:].strip()}"], ["GC074"]

        # Standalone generic input declarations become explicit AJ INPUT assignments.
        m = re.fullmatch(r"INPUT\s+(.+)", content, re.IGNORECASE)
        if m and "(" not in m.group(1):
            names = [x.strip() for x in m.group(1).split(",") if x.strip()]
            if names and all(re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", x) for x in names):
                out = []
                for name in names:
                    safe_name = self.RESERVED_IDENTIFIER_RENAMES.get(name.lower(), name)
                    out.append(f'{indent}{safe_name} <- INPUT(STRING("Enter {name}"))')
                return out, ["GC075"]

        # Rename identifiers that collide with AJ literal/type keywords.
        renamed = content
        for source_name, target_name in self.RESERVED_IDENTIFIER_RENAMES.items():
            renamed = re.sub(rf"(?<!EMPTY )\b{re.escape(source_name)}\b", target_name, renamed)
        if renamed != content:
            content = renamed
            rules.append("GC076")

        # Bare booleans are valid generic pseudocode but AJ expects BOOLEAN(...).
        boolean_before = content
        content = re.sub(r"(?<!BOOLEAN\()\bTRUE\b", "BOOLEAN(True)", content, flags=re.IGNORECASE)
        content = re.sub(r"(?<!BOOLEAN\()\bFALSE\b", "BOOLEAN(False)", content, flags=re.IGNORECASE)
        if content != boolean_before:
            rules.append("GC077")

        # Multiple simple assignments on one line.
        pieces = self._split_top_level_commas(content)
        if len(pieces) > 1 and all("<-" in piece for piece in pieces):
            assignment_lines = []
            valid = True
            for piece in pieces:
                if not re.match(r"^[A-Za-z_][A-Za-z0-9_]*(?:\[[^\]]+\])?\s*<-\s*.+$", piece.strip()):
                    valid = False
                    break
                assignment_lines.append(f"{indent}{piece.strip()}")
            if valid:
                return assignment_lines, rules + ["GC078"]

        # Chained assignment: a <- b <- expression.
        m = re.fullmatch(r"([A-Za-z_]\w*)\s*<-\s*([A-Za-z_]\w*)\s*<-\s*(.+)", content)
        if m:
            return [
                f"{indent}{m.group(2)} <- {m.group(3)}",
                f"{indent}{m.group(1)} <- {m.group(2)}",
            ], rules + ["GC079"]

        # AJ RETURN/OUTPUT are single-expression statements; preserve multiple values as tuples.
        m = re.fullmatch(r"RETURN\s+(.+)", content, re.IGNORECASE)
        if m:
            vals = self._split_top_level_commas(m.group(1))
            if len(vals) > 1:
                content = f"RETURN TUPLE({', '.join(v.strip() for v in vals)})"
                rules.append("GC080")
        m = re.fullmatch(r"OUTPUT\s+(.+)", content, re.IGNORECASE)
        if m:
            vals = self._split_top_level_commas(m.group(1))
            if len(vals) > 1:
                content = f"OUTPUT TUPLE({', '.join(v.strip() for v in vals)})"
                rules.append("GC081")

        # Generic object.member notation is flattened into a stable identifier form.
        member_before = content
        content = re.sub(r"\b([A-Za-z_]\w*)\.([A-Za-z_]\w*)", r"\1_\2", content)
        if content != member_before:
            rules.append("GC082")

        # Prefix generic function calls with CALL so the AJ expression parser can represent them.
        call_before = content
        content = self._prefix_generic_calls(content)
        if content != call_before:
            rules.append("GC083")

        return [f"{indent}{content}"], rules

    def _prefix_generic_calls(self, content: str) -> str:
        # Avoid declarations and already canonical CALL expressions.
        if re.match(r"^(FUNCTION|COMMENT)\b", content, re.IGNORECASE):
            return content
        pattern = re.compile(r"\b([A-Za-z_][A-Za-z0-9_]*)\s*\(")
        offset = 0
        while True:
            m = pattern.search(content, offset)
            if not m:
                break
            name = m.group(1)
            prefix = content[max(0, m.start()-6):m.start()].upper()
            if name.upper() in self.KNOWN_CALL_WORDS or prefix.endswith("CALL "):
                offset = m.end()
                continue
            content = content[:m.start()] + "CALL " + content[m.start():]
            offset = m.end() + 5
        return content

    @staticmethod
    def _split_top_level_commas(text: str) -> list[str]:
        parts=[]; current=[]; depth=0; quote=None; escape=False
        for ch in text:
            if quote is not None:
                current.append(ch)
                if escape:
                    escape=False
                elif ch == "\\":
                    escape=True
                elif ch == quote:
                    quote=None
                continue
            if ch in "'\"":
                quote=ch; current.append(ch); continue
            if ch in "([{": depth += 1
            elif ch in ")]}": depth = max(0, depth-1)
            if ch == "," and depth == 0:
                parts.append("".join(current)); current=[]
            else:
                current.append(ch)
        parts.append("".join(current))
        return parts

    def _insert_indentation_closures(self, expanded: list[tuple[int, str]]) -> tuple[list[str], list[SourceTransformation]]:
        output: list[str] = []
        transforms: list[SourceTransformation] = []
        stack: list[tuple[int, str, int]] = []
        opener_patterns = (
            (re.compile(r"^FUNCTION\b", re.I), "ENDFUNCTION"),
            (re.compile(r"^IF\b.*\bTHEN$", re.I), "ENDIF"),
            (re.compile(r"^WHILE\b.*\bDO$", re.I), "ENDWHILE"),
            (re.compile(r"^FOR\b.*\bDO$", re.I), "ENDFOR"),
        )
        explicit = {"ENDFUNCTION", "ENDIF", "ENDWHILE", "ENDFOR"}

        for line_number, line in expanded:
            content=line.strip()
            if not content:
                output.append(line); continue
            indent=len(line)-len(line.lstrip())
            upper=content.upper()
            continuation = upper == "ELSE" or upper.startswith("ELSE IF ")

            if upper in explicit:
                while stack and stack[-1][1] != upper:
                    i, closer, opened_line = stack.pop()
                    output.append(" " * i + closer)
                    transforms.append(SourceTransformation(line=line_number, rule="GC084", source="", target=closer))
                if stack and stack[-1][1] == upper:
                    stack.pop()
                output.append(line)
                continue

            while stack and indent <= stack[-1][0] and not (continuation and stack[-1][1] == "ENDIF" and indent == stack[-1][0]):
                i, closer, opened_line = stack.pop()
                output.append(" " * i + closer)
                transforms.append(SourceTransformation(line=line_number, rule="GC084", source="", target=closer))

            output.append(line)
            for pattern, closer in opener_patterns:
                if pattern.match(content):
                    stack.append((indent, closer, line_number))
                    break

        while stack:
            i, closer, opened_line = stack.pop()
            output.append(" " * i + closer)
            transforms.append(SourceTransformation(line=opened_line, rule="GC084", source="", target=closer))
        return output, transforms


@dataclass
class GenericLineToken:
    """Represents one classified line of generic pseudocode."""

    line_number: int
    indentation: str
    content: str
    category: str


class GenericPseudocodeLexer:
    """Classifies common generic pseudocode statements without parsing them."""

    def tokenise(self, source: str) -> list[GenericLineToken]:
        """Converts generic pseudocode into classified line tokens."""

        tokens = []
        source_lines = source.splitlines()

        for line_number, source_line in enumerate(source_lines, start=1):
            indentation = source_line[: len(source_line) - len(source_line.lstrip())]
            content = source_line.strip()
            category = self._classify_line(
                content=content,
            )

            line_token = GenericLineToken(
                line_number=line_number,
                indentation=indentation,
                content=content,
                category=category,
            )

            tokens.append(
                line_token
            )

        return tokens

    def _classify_line(self, content: str) -> str:
        """Returns the recognised category for one source line."""

        upper_content = content.upper()

        if not content:
            return "BLANK"

        if re.match(r"^SET\s+.+?\s+TO\s+.+$", content, re.IGNORECASE):
            return "SET_ASSIGNMENT"

        if re.match(r"^(PRINT|DISPLAY)\s+.+$", content, re.IGNORECASE):
            return "OUTPUT"

        if upper_content == "END IF":
            return "END_IF"

        if upper_content == "END WHILE":
            return "END_WHILE"

        if re.match(r"^NEXT(?:\s+\w+)?$", content, re.IGNORECASE):
            return "NEXT"

        if re.match(r"^IF\s+.+$", content, re.IGNORECASE):
            return "IF"

        if re.match(r"^WHILE\s+.+$", content, re.IGNORECASE):
            return "WHILE"

        if re.match(r"^FOR\s+EACH\s+\w+\s+IN\s+.+$", content, re.IGNORECASE):
            return "FOR_EACH"

        if self._is_simple_assignment(content):
            return "EQUALS_ASSIGNMENT"

        return "UNCHANGED"

    def _is_simple_assignment(self, content: str) -> bool:
        """Identifies assignment equals without confusing comparison operators."""

        assignment_pattern = r"^[A-Za-z_][A-Za-z0-9_]*(?:\[[^\]]+\])?\s*=\s*.+$"

        if not re.match(assignment_pattern, content):
            return False

        comparison_operators = [
            "==",
            "!=",
            "<=",
            ">=",
        ]

        for comparison_operator in comparison_operators:
            if comparison_operator in content:
                return False

        return True


class StrictPseudocodeProcessor:
    """Performs only non-semantic AJ Dialect source cleanup."""

    def process(self, source: str) -> PseudocodeProcessingResult:
        """Processes source using strict, auditable cleanup rules."""

        processed_source = source
        transformations = []

        normalised_line_endings = processed_source.replace("\r\n", "\n").replace("\r", "\n")

        if normalised_line_endings != processed_source:
            transformations.append(
                SourceTransformation(
                    line=None,
                    rule="NORMALISE_LINE_ENDINGS",
                    source="Mixed platform line endings",
                    target="Unix line endings",
                )
            )

            processed_source = normalised_line_endings

        processed_source, fence_transformations = self._remove_markdown_fences(
            source=processed_source,
        )
        transformations.extend(
            fence_transformations
        )

        source_lines = processed_source.splitlines()
        normalised_lines = []

        for line_number, source_line in enumerate(source_lines, start=1):
            transformed_line = source_line.rstrip()

            if transformed_line != source_line:
                transformations.append(
                    SourceTransformation(
                        line=line_number,
                        rule="REMOVE_TRAILING_WHITESPACE",
                        source=source_line,
                        target=transformed_line,
                    )
                )

            arrow_normalised_line = transformed_line.replace("←", "<-")

            if arrow_normalised_line != transformed_line:
                transformations.append(
                    SourceTransformation(
                        line=line_number,
                        rule="NORMALISE_ASSIGNMENT_ARROW",
                        source=transformed_line,
                        target=arrow_normalised_line,
                    )
                )

            normalised_lines.append(
                arrow_normalised_line
            )

        processed_source = "\n".join(normalised_lines)

        return PseudocodeProcessingResult(
            profile=PseudocodeProfile.AJ_DIALECT_STRICT,
            original_source=source,
            processed_source=processed_source,
            transformations=transformations,
        )

    def _remove_markdown_fences(
        self,
        source: str,
    ) -> tuple[str, list[SourceTransformation]]:
        """Removes a surrounding Markdown code fence when present."""

        source_lines = source.splitlines()
        transformations = []

        if len(source_lines) < 2:
            return source, transformations

        first_line = source_lines[0].strip()
        final_line = source_lines[-1].strip()

        if first_line.startswith("```") and final_line == "```":
            transformed_source = "\n".join(source_lines[1:-1])

            transformations.append(
                SourceTransformation(
                    line=None,
                    rule="REMOVE_MARKDOWN_CODE_FENCE",
                    source=f"{first_line} ... {final_line}",
                    target="Code-fence contents",
                )
            )

            return transformed_source, transformations

        return source, transformations


class GenericPseudocodeProcessor:
    """Converts recognised generic structured pseudocode into AJ Dialect syntax."""

    def __init__(self) -> None:
        self.character_normaliser = GenericCharacterNormaliser()
        self.boundary_normaliser = GenericStatementBoundaryNormaliser()
        self.operator_normaliser = GenericOperatorNormaliser()
        self.collection_normaliser = GenericCollectionNormaliser()
        self.statement_normaliser = GenericStatementNormaliser()
        self.grammar_normaliser = GenericGrammarNormaliser()
        self.recovery_normaliser = GenericRecoveryNormaliser()
        self.lexer = GenericPseudocodeLexer()
        self.strict_processor = StrictPseudocodeProcessor()

    def process(self, source: str) -> PseudocodeProcessingResult:
        """Applies compatibility conversions and records every changed line."""

        character_source, character_transformations = self.character_normaliser.process(
            source=source,
        )
        boundary_source, boundary_transformations = self.boundary_normaliser.process(
            source=character_source,
        )
        operator_source, operator_transformations = self.operator_normaliser.process(
            source=boundary_source,
        )
        collection_source, collection_transformations = self.collection_normaliser.process(
            source=operator_source,
        )
        statement_source, statement_transformations = self.statement_normaliser.process(
            source=collection_source,
        )
        grammar_source, grammar_transformations = self.grammar_normaliser.process(
            source=statement_source,
        )
        recovery_source, recovery_transformations = self.recovery_normaliser.process(
            source=grammar_source,
        )
        strict_result = self.strict_processor.process(
            source=recovery_source,
        )
        generic_tokens = self.lexer.tokenise(
            source=strict_result.processed_source,
        )
        processed_lines = []
        transformations = list(character_transformations)
        transformations.extend(
            boundary_transformations
        )
        transformations.extend(
            operator_transformations
        )
        transformations.extend(
            collection_transformations
        )
        transformations.extend(
            statement_transformations
        )
        transformations.extend(
            grammar_transformations
        )
        transformations.extend(
            recovery_transformations
        )
        transformations.extend(
            strict_result.transformations
        )

        for line_token in generic_tokens:
            transformed_content = self._convert_token(
                line_token=line_token,
            )
            transformed_content = self._convert_operators(
                content=transformed_content,
            )
            transformed_line = f"{line_token.indentation}{transformed_content}"
            source_line = f"{line_token.indentation}{line_token.content}"

            if transformed_line != source_line:
                transformations.append(
                    SourceTransformation(
                        line=line_token.line_number,
                        rule=f"GENERIC_{line_token.category}",
                        source=source_line,
                        target=transformed_line,
                    )
                )

            processed_lines.append(
                transformed_line
            )

        processed_source = "\n".join(processed_lines)

        return PseudocodeProcessingResult(
            profile=PseudocodeProfile.GENERIC_COMPATIBILITY,
            original_source=source,
            processed_source=processed_source,
            transformations=transformations,
        )

    def _convert_token(self, line_token: GenericLineToken) -> str:
        """Converts one classified generic line into AJ Dialect syntax."""

        content = line_token.content

        if line_token.category == "SET_ASSIGNMENT":
            match = re.match(
                r"^SET\s+(.+?)\s+TO\s+(.+)$",
                content,
                re.IGNORECASE,
            )

            if match is not None:
                target = match.group(1).strip()
                value = match.group(2).strip()
                return f"{target} <- {value}"

        if line_token.category == "OUTPUT":
            match = re.match(
                r"^(?:PRINT|DISPLAY)\s+(.+)$",
                content,
                re.IGNORECASE,
            )

            if match is not None:
                output_expression = match.group(1).strip()
                return f"OUTPUT {output_expression}"

        if line_token.category == "END_IF":
            return "ENDIF"

        if line_token.category == "END_WHILE":
            return "ENDWHILE"

        if line_token.category == "NEXT":
            return "ENDFOR"

        if line_token.category == "IF":
            if not re.search(r"\sTHEN$", content, re.IGNORECASE):
                return f"{content} THEN"

        if line_token.category == "WHILE":
            if not re.search(r"\sDO$", content, re.IGNORECASE):
                return f"{content} DO"

        if line_token.category == "FOR_EACH":
            if not re.search(r"\sDO$", content, re.IGNORECASE):
                return f"{content} DO"

        if line_token.category == "EQUALS_ASSIGNMENT":
            return re.sub(
                r"\s*=\s*",
                " <- ",
                content,
                count=1,
            )

        return content

    def _convert_operators(self, content: str) -> str:
        """Converts supported generic arithmetic operator words."""

        converted_content = re.sub(
            r"\bMOD\b",
            "MODULUS",
            content,
            flags=re.IGNORECASE,
        )
        converted_content = re.sub(
            r"\bDIV\b",
            "INTEGER DIVISION",
            converted_content,
            flags=re.IGNORECASE,
        )

        return converted_content


class GeneralPseudocodeProcessor:
    """Passes supplied pseudocode to the parser without source conversion."""

    def process(self, source: str) -> PseudocodeProcessingResult:
        """Returns the original source unchanged."""

        return PseudocodeProcessingResult(
            profile=PseudocodeProfile.GENERAL_NO_CONVERSION,
            original_source=source,
            processed_source=source,
            transformations=[],
        )


class PseudocodeProfileProcessor:
    """Selects the correct processor for a requested pseudocode profile."""

    def __init__(self) -> None:
        self.strict_processor = StrictPseudocodeProcessor()
        self.generic_processor = GenericPseudocodeProcessor()
        self.general_processor = GeneralPseudocodeProcessor()
        self.header_comment_stripper = InitialHashCommentStripper()

    def process(
        self,
        source: str,
        profile: PseudocodeProfile,
    ) -> PseudocodeProcessingResult:
        """Strips an optional file header and applies the selected profile."""

        profile_source, header_removed, header_lines_removed = (
            self.header_comment_stripper.strip(
                source=source,
            )
        )

        if profile == PseudocodeProfile.AJ_DIALECT_STRICT:
            result = self.strict_processor.process(
                source=profile_source,
            )

        elif profile == PseudocodeProfile.GENERIC_COMPATIBILITY:
            result = self.generic_processor.process(
                source=profile_source,
            )

        elif profile == PseudocodeProfile.GENERAL_NO_CONVERSION:
            result = self.general_processor.process(
                source=profile_source,
            )

        else:
            raise ValueError(
                f"Unsupported pseudocode profile: {profile}"
            )

        result.original_source = source
        result.header_comment_removed = header_removed
        result.header_lines_removed = header_lines_removed

        return result
