# NL to Flow Diagram Encoder Pipeline v3.34

A dependency-free, object-oriented Python pipeline for AJ_24038155 Dialect v1.1.

## v3.34 explicit square-root representation recovery

v3.34 adds GC233 for the exact free single-argument call `SQUARE_ROOT(value)`. With the user-approved mathematical representation, the source operation is canonicalised to AJ v1.1 exponentiation as `(value EXP 0.5)`, which lowers deterministically to Python `(value ** 0.5)`. Routine declarations named `SQUARE_ROOT`, member methods, quoted text, and zero/multi-argument calls are refused. GC233 deliberately does not add integer, floor, or range-bound coercion. Gemini Algorithm 20 therefore now preserves its explicit square-root operation through strict AJ parsing and Python compilation, while its separate use of that floating result as a Python range endpoint remains visible as an executable-correctness boundary. AJ_24038155 Dialect v1.1 remains frozen.

## v3.33 evidenced set-to-list conversion recovery

v3.33 adds GC232 for the exact free call `ConvertSetToList(name)` when the same lexical routine has already established `name` as `EMPTY SET` and no later direct reassignment invalidates that evidence. The explicit conversion is represented through the existing `CALL to_list(name)` compatibility intrinsic, which lowers deterministically to Python `list(name)`. Cross-routine evidence, forward evidence, member calls, wrong arity and unproven identifiers are refused. Gemini Algorithm 11 therefore preserves its supplied set-deduplication followed by set-to-list conversion without changing AJ_24038155 Dialect v1.1.

## v3.32 quoted dictionary-key recovery

v3.32 refines the existing GC097 simple dictionary-literal expansion so explicitly quoted string-scalar keys are rendered directly as canonical AJ `STRING(...)` expressions before the expanded indexed assignments are returned. This preserves Gemini Algorithm 10's source-evidenced vowel keys (including normal AJ escaping) while keeping the established bare-key stringification unchanged. No dictionary semantics are inferred beyond the existing GC097 literal expansion, and AJ_24038155 Dialect v1.1 remains frozen.

## v3.31 quoted scalar set-literal recovery

v3.31 adds GC231 for a non-empty Python-style brace literal whose members are all explicitly quoted string scalars. The source-evidenced set is represented through the existing compatibility intrinsics as `CALL to_set(CALL list_value(...))`, preserving punctuation characters including escaped apostrophe and double-quote members without changing the frozen AJ parser. The rule runs before raw-string wrapping and refuses dictionaries, empty braces, mixed or unquoted members, comprehensions, and string scalars containing unsupported control characters. Gemini Algorithm 5 therefore reaches the frozen AJ parser and deterministic Python compilation without inventing a punctuation predicate or changing AJ_24038155 Dialect v1.1.

## v3.30 standalone SWAP boundary fix

v3.30 narrows GC051 to the standalone procedural shorthand `SWAP(a, b)` only. A case-sensitive routine declaration such as `FUNCTION swap(a, b):` is therefore left for the ordinary function-header recovery and preserves the source identifier as `swap`, while genuine standalone `SWAP(a, b)` statements continue through the existing SWAP lowering. Calls such as `CALL swap(a, b)` and member invocations such as `obj.swap(a, b)` are also outside GC051. No new compatibility meaning is introduced, and AJ_24038155 Dialect v1.1 remains frozen.
The only external program input is AJ pseudocode.

## Pipeline

1. AJ pseudocode input
2. Lexical analysis
3. Recursive-descent parsing
4. AST construction
5. Static semantic validation
6. Machine-readable flow-diagram encoding
7. Interactive AST and flow-diagram visualisation
8. Deterministic Python compilation from `flow_diagram.json`
9. Subprocess-based behavioural testing
10. JSON reporting

## PyCharm

Open `pycharm_runner.py` and press **Run**. Configure these constants at the top
of the file when required:

- `INPUT_FILE`
- `OUTPUT_DIRECTORY`
- `OPEN_VISUALISATIONS`
- `TEST_CASES`

## Outputs

The runner creates:

- `output/ast.json`
- `output/parser_report.json`
- `output/ast_visualisation.html`
- `output/flow_diagram.json`
- `output/flow_diagram.html`
- `output/generated_program.py`
- `output/compilation_report.json`
- `output/test_report.json`
- `output/pipeline_report.json`

## Important design boundary

The AST is an internal intermediate representation. It is generated from
pseudocode and is not accepted as an external pipeline input. The compiler
accepts the machine-readable flow-diagram document produced by the encoder.


## v3.29 chained-assignment negative-infinity pass-order fix

v3.29 fixes the composition of the existing GC079 chained-assignment expansion with the existing GC151 negative-infinity representation recovery. When source such as `largest <- second <- -INFINITY` is expanded, the newly exposed assignment is now canonicalised as `second <- CALL negative_infinity()` before `largest <- second`. This preserves the source-supplied shared negative-infinity initialiser and lowers deterministically to Python `float('-inf')`. The fix is deliberately limited to the negative-infinity surfaces already accepted by GC151; positive infinity identifiers, member properties, and arbitrary chained right-hand expressions are unchanged. No new compatibility meaning is introduced, and AJ_24038155 Dialect v1.1 remains frozen.

## v3.28 direct modulus-digit string-accumulator recovery

v3.28 adds GC230 for the exact representation case where a destination is explicitly string-backed, the source directly prepends one parenthesised `MOD`/`MODULUS` result to that same accumulator, and the later generic arithmetic canonicalisation has not yet rewritten `MOD` to `MODULUS`. The guarded recovery makes only the required digit-to-string representation explicit as `CALL to_string((... MODULUS ...))`; unrelated mixed numeric/string addition, different accumulators, non-string destinations, and non-modulus expressions remain untouched. Claude Sonnet 4.6 Algorithm 2 therefore compiles without changing its supplied decimal-to-binary algorithm. AJ_24038155 Dialect v1.1 remains frozen.

## v3.27 seeded list-backed queue recovery

v3.27 adds GC229 for source forms that explicitly initialise a queue receiver from a non-empty list literal (for example `queue = [root]`) and then explicitly use that same receiver with free `DEQUEUE(queue)` / `ENQUEUE(queue, value)` operations. The earlier list-literal canonicalisation is accepted as representation evidence, and the queue operations are routed only to the existing list-backed FIFO operations (`REMOVE FIRST ITEM FROM` / `APPEND`). Unproven receivers, unrelated seeded lists, and arbitrary queue-like names remain untouched. AJ_24038155 Dialect v1.1 remains frozen.

## v3.26 explicit alphabetical sort-mode recovery

v3.26 adds GC228 for the exact free two-argument form `SORT(value, ALPHABETICAL_ORDER)`. The explicit `ALPHABETICAL_ORDER` marker is treated as source-supplied ascending alphabetical ordering and routed through the existing `sort_value` compatibility intrinsic, which lowers to Python `sorted(value)` (equivalent to `sorted(value, reverse=False)`). The rule is restricted to a simple identifier first argument and leaves arbitrary comparators, descending markers, member methods, and other arities untouched. AJ_24038155 Dialect v1.1 remains frozen.

## v3.25 evidenced regex `REPLACE_ALL` recovery

v3.25 adds GC227 for free three-argument `REPLACE_ALL(text, pattern, replacement)` calls whose quoted pattern contains direct regular-expression syntax evidence. The rule protects regex backslashes across compatibility-to-AJ string representation and lowers the supplied operation through an internal `regex_replace` intrinsic backed by Python `re.sub`. Plain literal replacement calls, member methods, and other arities remain untouched. AJ_24038155 Dialect v1.1 remains frozen.

## v3.24 trailing explanatory parenthetical comment recovery

v3.24 adds GC226 for a narrowly guarded source-surface case where an assignment already has a complete `empty <collection>` right-hand side and is followed by a trailing parenthetical beginning with explanatory `or` or `for` prose. The suffix is detached from executable syntax before literal/collection parsing, so a line such as `order = empty list (or a doubly linked list to maintain access order)` is represented as the explicit empty-list initialiser plus non-executable commentary rather than being misread as a `list(...)` constructor. Arithmetic/grouping parentheses, arbitrary calls, and non-comment parentheticals are unchanged. The existing DeepSeek LRU class recovery also accepts its legacy `FUNCTION get(key):` / `FUNCTION put(key, value):` header surface, allowing the already source-evidenced LRU logic to reach the frozen class grammar without inventing cache behaviour. AJ_24038155 Dialect v1.1 remains frozen.

## v3.23 DeepSeek 2 source-evidenced numeric STRING conversion

v3.23 adds GC225 for the exact compatibility case where a variable is independently proven numeric by a `MOD`/`MODULUS` assignment, a destination is independently proven string-backed by `EMPTY STRING`, and the source explicitly prepends `STRING(variable)` to that same string accumulator. Under those safeguards, the non-literal constructor-like source form is represented as `CALL to_string(variable)`, which lowers through the existing Python intrinsic to `str(variable)`. Quoted `STRING("...")` literals, unproven identifiers, non-string destinations, and unrelated `STRING(...)` calls are unchanged. DeepSeek Algorithm 2 therefore preserves its supplied decimal-to-binary algorithm while making only the explicit numeric-to-text conversion executable. AJ_24038155 Dialect v1.1 remains frozen.

## v3.22 Qwen 46 source-evidenced linked matrix dimensions

v3.22 adds GC224 for the exact matrix-multiplication shape `INPUT A (M x N), B (N x P)` followed by `INIT C as M x P matrix`, the complete nested `M`/`P`/`N` loops, the explicit `sum += A[i][k] * B[k][j]` accumulation, direct `C[i][j] = sum`, and `RETURN C`. Under those safeguards, annotation-only `M`, `N`, and `P` are represented by `LENGTH OF A`, `LENGTH OF B`, and `LENGTH OF B[0]`; `C` is materialised with the existing `create_matrix` intrinsic. The rule refuses independently bound dimensions, mismatched result or loop shapes, altered accumulation/index relations, conditional result writes, dimension-symbol escape, and explicit routine declarations. No matrix-multiplication logic or synthetic dimension parameter is invented. AJ_24038155 Dialect v1.1 remains frozen.

## v3.21 Qwen 45 source-evidenced rectangular matrix recovery

v3.21 adds GC223 for the exact unnamed matrix-addition shape where two supplied matrices are explicitly annotated as sharing dimensions `R x C`, the source requests `INIT result as R x C matrix`, the matching nested `0..R-1` / `0..C-1` loops directly overwrite every `result[i][j]`, and the result matrix is returned. Under those safeguards, annotation-only `R` and `C` are represented by `LENGTH OF A` and `LENGTH OF A[0]`, and the result storage is materialised with the existing `create_matrix` intrinsic. No synthetic `R`/`C` parameters are introduced. The zero fill is permitted only because the guarded source shape proves every allocated cell is overwritten before observation. Independent dimensions, mismatched bounds, conditional writes, explicit routine declarations, and non-returned targets are refused. AJ_24038155 Dialect v1.1 remains frozen.

## v3.20 Qwen 42 collection-evidence and deduplication recovery

v3.20 adds three narrowly evidenced compatibility recoveries for the Qwen 42 pair-sum form. A bare `{}` declaration is resolved to `EMPTY DICTIONARY` when a later indexed assignment on the same receiver proves mapping use (GC220), overriding weaker identifier-name set hints. A nested `list.add(expression)` is recovered with balanced-parenthesis scanning only when the receiver is independently proven list-backed (GC221); the recovered expression then continues through the existing tuple/MIN/MAX canonicalisation passes. Finally, after the stronger GC214 proof-based redundant-uniqueness rule has had first priority, an exact remaining one-argument `unique(name)` call is represented by the existing `to_set` compatibility intrinsic (GC222), producing Python `set(name)`. No pair-search logic is invented, ordering is not inferred, and AJ_24038155 Dialect v1.1 remains frozen.

## v3.19 guarded RANGE integer-offset folding

v3.19 broadens the v3.18 Python RANGE rendering cleanup into a guarded additive-integer offset fold. Within RANGE end expressions only, two or more literal integer offsets on the same left-associated `+`/`-` chain are combined while non-literal terms retain their relative order. Examples include `(Limit - 2) + 1 -> Limit - 1`, `(Index + 3) - 1 -> Index + 2`, `(Value - 4) - 2 -> Value - 6`, `(Value + 2) - 2 -> Value`, and `((LENGTH OF xs - 2) - i) + 1 -> LENGTH OF xs - 1 - i` at Python rendering time. Single-offset expressions, floats, multiplication/division, and nested right-hand additive algebra are not reassociated. AJ_24038155 Dialect v1.1 remains frozen.

## v3.18 evidenced input/helper wrapper recovery and canonical range rendering

v3.18 adds guarded GC219 for an omitted neutral outer algorithm wrapper when generic pseudocode supplies one or more bare top-level `INPUT` declarations, one or more complete indentation-style helper routines, and a single final top-level `RETURN` that calls an explicitly supplied helper. The recovery promotes only the input names to `FUNCTION unnamed_function` parameters and nests the supplied helpers/return without implementing any missing dependency. Qwen Algorithm 41 therefore parses and compiles structurally, while its undefined `isSafe(...)` and `emptyBoard(...)` routines remain source-level expected-failure dependencies. v3.18 also makes Python RANGE rendering cleaner: when inclusive-source endpoint canonicalisation has produced exactly `(X - 1) + 1`, the Python compiler emits `X` in the `range()` stop position (for example `0 TO N - 1` now renders as `range(0, N)`). This cancellation is restricted to RANGE end expressions and is not a general arithmetic optimiser. AJ_24038155 Dialect v1.1 remains frozen.

## v3.17 evidenced connected multi-list stateful-ADT recovery

v3.17 adds guarded GC218 structural recovery for multiple explicitly initialised `EMPTY LIST` states followed by multiple top-level operations. The rule requires the complete state/operation graph to be connected, every state to be actively mutated, and at least one explicit destructive cross-state transfer such as `APPEND a.pop() TO b`; it also refuses unknown call escape, state shadowing, direct rebinding, indexed writes, nested functions, free executable statements and disconnected global-list utilities. Eligible source is represented as neutral `CLASS unnamed_class` with a zero-argument constructor containing only the source-supplied empty-list initialisers. Qwen Algorithm 40 therefore becomes a trustworthy executable stateful queue abstraction while preserving its source-supplied empty-dequeue underflow. AJ_24038155 Dialect v1.1 remains frozen.

## v3.16 evidenced counted-list stateful-ADT and standalone-error recovery

v3.16 adds guarded GC216 structural recovery for an explicitly initialised counted-list ADT written as top-level state plus multiple shared-state functions. The rule requires exactly one `EMPTY LIST` state and one zero counter, at least three operations that all share both values, and source evidence for append, zero-argument list `pop()`, indexed top access, and counter `+1`/`-1` updates. Eligible source is represented as neutral `CLASS unnamed_class` with a zero-argument constructor containing only the supplied initial values; no semantic class name, constructor parameter, stack operation, or data value is invented. v3.16 also adds GC217 for an exact standalone `ERROR` statement, mapping it to AJ `RAISE STRING("ERROR")`. GC217 is statement-position only and leaves the established GC204 `RETURN ERROR` string-sentinel policy unchanged. Qwen Algorithm 37 therefore becomes a trustworthy executable without changing AJ_24038155 Dialect v1.1.

## v3.15 evidenced ordered-cache stateful-ADT recovery

v3.15 adds guarded GC215 recovery for the source shape `INIT limit, cache = orderedDict()` followed by multiple top-level operations that share the ordered key/value state. The rule activates only when the same source proves a cache-size bound (`LENGTH OF cache == limit`), keyed membership/indexing, and safe recency-helper contexts: move-to-front only for a present key, remove-back only under the full-capacity guard, and add-to-front only in the absent-key branch. The first INIT name becomes a constructor-supplied property rather than receiving a synthetic numeric default; the ordered cache becomes an AJ `DICTIONARY` property, and existing ordered-mapping compiler intrinsics provide the physical MRU/LRU lowering. The recovered wrapper is the neutral `unnamed_class`, so no semantic class name is invented. Qwen Algorithm 35 therefore becomes a trustworthy executable for positive fixed capacities without changing AJ_24038155 Dialect v1.1.

## v3.14 provable redundant-uniqueness alignment

v3.14 adds guarded GC214 semantic alignment for a final `RETURN unique(result)` abstraction only when the same routine mechanically proves that `result` is already unique: the collection is explicitly initialised as `EMPTY LIST`, every append is protected by a matching `value NOT IN result` guard that is re-evaluated before that append, and no rebinding, indexed/insert mutation, alias/call escape, repeated append under one guard, or nested-loop bypass invalidates the proof. The alignment preserves the source-created order by returning `result` directly; it does not implement a generic `unique` routine or rewrite arbitrary `unique(x)` calls. Qwen Algorithm 34 therefore becomes a trustworthy executable after source-proven semantic alignment. AJ_24038155 Dialect v1.1 remains frozen.

## v3.13 bare CALL-argument binding validation

v3.13 extends the frozen AJ v1.1 declared/assigned-before-read check to immediate bare value identifiers supplied as arguments to `CALL routine(...)`. Routine names remain syntax and are not treated as value reads, undefined external-routine policy is unchanged, and compound-expression definite-assignment analysis remains deliberately out of scope. Qwen Algorithm 30 now fails during static semantic analysis on the unbound `numTopics` argument instead of producing executable-looking Python with a latent `NameError`. Its abstract NLP/LDA routine dependencies remain source-level expected failures. AJ_24038155 Dialect v1.1 remains frozen.

## v3.12 evidenced camelCase deque-operation recovery

v3.12 adds guarded GC213 compatibility recovery for Qwen-style `popFront()`, `popBack()`, and `pushBack(value)` calls when the receiver is independently established as list-backed in the same source. The rule maps directly to the existing AJ list operations `REMOVE FIRST ITEM FROM`, `REMOVE LAST ITEM FROM`, and `APPEND ... TO ...`; arbitrary user-defined methods with the same names are not rewritten. Qwen Algorithm 28 still retains its source-level empty-deque indexing defect and is audit-locked as an expected executable-correctness failure. AJ_24038155 Dialect v1.1 remains frozen.

## v3.11 square-dimension identifier-reference recovery

v3.11 adds generic GC212 compatibility recovery for otherwise-unbound executable references to a dimension symbol explicitly established by `INPUT collection (D x D)`. The symbol resolves directly to `LENGTH OF collection` within the same routine, without creating a synthetic `D` variable. GC208 retains its exact `0 .. D-1` loop-bound ownership. Arithmetic is preserved exactly: Qwen Algorithm 27 now eliminates unbound `N`, but its source `N / 2` remains ordinary division and is audit-locked as an expected executable-correctness failure rather than silently corrected to integer division. AJ_24038155 Dialect v1.1 remains frozen.

## v3.10 omitted-`IS` non-empty predicate recovery

v3.10 adds generic GC211 compatibility recovery for the exact surface `identifier NOT EMPTY`, mapping it to the already-supported canonical empty-state test `LENGTH OF identifier > 0`. The rule is case-insensitive, quote/comment-safe, and deliberately does not broaden to blank/null/whitespace/missing predicates or member expressions. Qwen Algorithm 26 now passes without inventing tree semantics. AJ_24038155 Dialect v1.1 remains frozen.

## Research corpus and audit evidence

The complete six model-response corpora used for the research study remain external
study data and are not copied wholesale into versioned implementation ZIPs.
Study-level corpus integration checks can be run by setting `AJ_RESEARCH_CORPUS_DIR`
to an external directory containing those files. When that variable is absent,
corpus-dependent checks skip cleanly.

When an exact study occurrence motivates a general parsing or normalisation measure,
that occurrence may be retained as a focused regression fixture together with its
audit record. These selected cases are version-controlled evidence for why the
measure was introduced; they are distinct from bundling the complete research corpus.

## Flow-diagram display

The generated flowchart opens at a readable 115% scale and is centred on the
first program steps. Use **Fit diagram** to display the complete program at once.
Zoom and pan remain available.

## Compilation assurance tests

The integration tests verify that:

- the saved `flow_diagram.json` document is accepted directly by the compiler;
- the compiler produces the exact expected reference Python source;
- the compiled program executes and produces the expected output;
- the visualisation contains the readable initial-view configuration.

Run all tests with:

```bash
python -m unittest discover -s tests -v
```

## Second controlled input route: draw.io

Version 1.5 adds an optional draw.io route while preserving pseudocode as the
primary route.

Configure `pycharm_runner.py` with:

```python
INPUT_ROUTE = "DRAWIO"
SELECT_FILE_WHEN_RUNNING = True
```

The runner displays a native file chooser. The controlled version 1 convention
is deliberately limited to a single linear path:

```text
Start -> AJ statement -> AJ statement -> End
```

Each executable process or input/output shape must contain one valid AJ Dialect
statement, either directly or with an `AJ:` prefix, for example:

```text
AJ: total <- INTEGER(0)
AJ: OUTPUT STRING("Total is {total}")
```

The importer reconstructs AJ pseudocode and then reuses the existing trusted
route:

```text
draw.io -> AJ pseudocode -> AST -> canonical flow JSON -> Python -> tests
```

Branching and looped draw.io imports intentionally fail with explicit diagnostics
in this first controlled version. The existing pseudocode route continues to
support the full parser grammar.

## Interactive input selection in PyCharm

Run `pycharm_runner.py` without editing an input-route flag.

The application first asks:

```text
What would you like to import?

[Pseudocode file]
[Flow diagram file]
```

After the selection, a native file chooser opens with the matching filters:

- Pseudocode: `.aj` or `.txt`
- Controlled flow diagram: `.drawio`, `.xml` or `.svg`

Closing either dialog cancels the run cleanly.

## Pseudocode processing profiles

When **Pseudocode file** is selected in `pycharm_runner.py`, the application now
asks how the source should be processed:

1. **AJ Dialect — strict** performs only non-semantic cleanup such as removing a
   surrounding Markdown fence, normalising line endings, removing trailing
   whitespace and converting `←` to `<-`.
2. **Generic — convert compatible syntax** recognises a controlled subset of
   generic structured pseudocode and converts forms such as `SET x TO value`,
   `PRINT value`, `END IF`, `END WHILE`, `NEXT`, assignment `=`, `MOD` and `DIV`
   into AJ_24038155 Dialect syntax.
3. **General — parse without conversion** passes the supplied text to the
   existing lexer and parser exactly as read from the file. It does not repair,
   normalise or rewrite the source.

Every pseudocode run writes:

- `processed_pseudocode.aj`
- `pseudocode_processing_report.json`

The report records the selected profile, whether the source changed, and every
individual transformation. The selected profile is also included in
`pipeline_report.json` under `input_metadata`.

## Draw.io overlaid labels

Version 1.8 recognises draw.io diagrams where visible `Start` and `End` text is
stored as a separate text object placed over an empty connected terminator
shape. The importer transfers the text to the underlying shape before graph
validation. Branching and loop-back import remain outside the controlled linear
importer and are rejected explicitly.

## General draw.io control-flow graphs

The draw.io route supports both linear diagrams and general graphs containing:

- decision diamonds;
- Yes/No and True/False connector labels;
- branch joins;
- loop-back connectors;
- separate text labels over Start and End shapes.

Linear diagrams are reconstructed as AJ Dialect pseudocode and use the normal
AST pipeline. Branching or cyclic diagrams are preserved as a canonical graph
and compiled into a Python state machine. This allows control flow that cannot
be represented safely as a simple nested block structure to remain executable.

When no behavioural test oracle is supplied for an imported flow diagram, the
pipeline reports behavioural testing as `SKIPPED` after successful compilation
and Python syntax validation. This avoids comparing an imported diagram against
unrelated sample outputs.

## Version 1.10: structured Tic-Tac-Toe graph compilation

The supplied Tic-Tac-Toe draw.io graph is recognised as a structured game-flow
pattern. It is compiled into a normal Python game loop instead of a verbose
state dispatcher. The generated program validates indexes and occupied cells,
alternates players, checks all eight winning lines, declares the correct winner,
and declares a draw after nine valid moves.

The compiler reports this route as `STRUCTURED_GRAPH_OPTIMISATION`. Other
arbitrary cyclic draw.io graphs continue to use the general state-machine
compiler.

## Flow-diagram input AST outputs

When an existing draw.io flow diagram is selected, the pipeline does not create a duplicate flow-diagram visualisation. After compilation it parses the generated Python into a Python AST and writes:

- `ast.json` — nested Python AST document;
- `ast_adjacency_list.json` — graph representation of the AST;
- `ast_visualisation.html` — interactive AST tree;
- `generated_program.py` — compiled Python source.

The pseudocode input route continues to generate both AST and flow-diagram artefacts.

## Editable draw.io export

The pseudocode input route also writes `output/flow_diagram.drawio`. This is an
editable diagrams.net/draw.io XML document using standard terminator, process,
decision, input/output, subroutine, and orthogonal connector conventions.

## Initial hash-comment header stripping

Before the selected pseudocode profile is applied, the pipeline checks whether the first line begins with `#`. When it does, all lines from the beginning of the file through the first blank separator line are treated as file-header metadata and removed. This supports wrapped introductory comments where continuation lines do not themselves begin with `#`.

Example:

```text
# Algorithm description
This description may wrap across several lines.
These lines are header metadata.

FUNCTION example ACCEPTS()
    OUTPUT STRING(example)
ENDFUNCTION
```

Only the pseudocode beginning with `FUNCTION` is sent to the selected profile and parser. Hash characters occurring later in the pseudocode do not trigger this preprocessing rule. The processing report records `header_comment_removed` and `header_lines_removed` separately from profile transformation counts.

## Lossy-source assignment recovery boundary

The generic compatibility route may receive study/source exports in which a
Unicode assignment arrow was lost as ASCII `?`. This is handled only in the
upstream source-integrity stage (GC193), where `?` is recoverable to source `←`
only when its syntactic position is unambiguously an assignment: a standalone
assignment target, a `FOR` initialiser, or an inline CASE-arm assignment.

`?` is **not** AJ syntax and is never a canonical alias for `<-`. Relational
forms such as `WHILE B ? 0` or `IF A ? B THEN` are left unresolved unless an
entry in the evidence-backed lossy-glyph lookup table establishes the original
source glyph from a recognised full source signature. Table recoveries are
logged as `GC194:<evidence-id>` and restore source glyphs such as `≠`, `≤`, or
`≥`; the deterministic character lookup then maps those glyphs to strict AJ
operators (`!=`, `<=`, `>=`). There is deliberately no `?` entry in the
canonical character lookup. The strict AJ parser continues to reject `?`.
