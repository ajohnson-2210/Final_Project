"""Flatten per-algorithm scoring JSON into analysis-ready CSV/JSON tables."""

from __future__ import annotations

from pathlib import Path
from typing import Any
import csv
import json

CRITERIA = [
    "C1", "C2", "C3", "C4",
    "A1", "A2", "A3", "A4",
    "F1", "F2", "F3", "F4",
    "P1", "P2", "P3", "P4",
]


def _read_json(path: Path) -> dict[str, Any] | None:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else None
    except (OSError, json.JSONDecodeError):
        return None


def _criterion_map(score: dict[str, Any]) -> dict[str, dict[str, Any]]:
    out = {}
    for stage in score.get("stages", {}).values():
        for criterion in stage.get("criteria", []):
            cid = criterion.get("criterion_id")
            if cid:
                out[cid] = criterion
    return out


def _selected_score(criterion: dict[str, Any]) -> tuple[int | None, str, str]:
    final = criterion.get("final_assessment")
    if isinstance(final, dict) and "score" in final:
        return final.get("score"), str(final.get("status")), str(final.get("source"))
    auto = criterion.get("automated_assessment", {})
    return auto.get("score"), str(auto.get("status")), "AUTOMATED"


def aggregate_algorithm_folders(parent: Path, analysis_directory: Path | None = None) -> dict[str, str]:
    parent = Path(parent)
    analysis_directory = Path(analysis_directory) if analysis_directory else parent / "study_analysis"
    analysis_directory.mkdir(parents=True, exist_ok=True)

    score_files = sorted(parent.glob("Algorithm - */pipeline_artifacts/scoring/final_score.json"))
    rows: list[dict[str, Any]] = []
    evidence_rows: list[dict[str, Any]] = []
    review_rows: list[dict[str, Any]] = []
    flow_rows: list[dict[str, Any]] = []
    review_status_rows: list[dict[str, Any]] = []

    for score_path in score_files:
        score = _read_json(score_path)
        if not score:
            continue
        algorithm = score.get("algorithm", {})
        dataset = algorithm.get("dataset")
        algorithm_id = algorithm.get("algorithm_id")
        criteria = _criterion_map(score)
        row: dict[str, Any] = {
            "Dataset": dataset,
            "Algorithm": algorithm_id,
            "SourceSufficiency": score.get("source_sufficiency", {}).get("final_result") or score.get("source_sufficiency", {}).get("result"),
        }
        for cid in CRITERIA:
            c = criteria.get(cid, {})
            selected, status, source = _selected_score(c) if c else (None, "NOT_EVALUABLE", "NONE")
            row[cid] = selected
            row[f"{cid}_Status"] = status
            row[f"{cid}_Source"] = source
        stages = score.get("stages", {})
        row.update({
            "CanonicalisationPercent": (stages.get("canonicalisation", {}).get("stage_summary") or {}).get("percentage"),
            "ASTPercent": (stages.get("ast", {}).get("stage_summary") or {}).get("percentage"),
            "FlowPercent": (stages.get("flow_diagram", {}).get("stage_summary") or {}).get("percentage"),
            "PythonPercent": (stages.get("python", {}).get("stage_summary") or {}).get("percentage"),
            "TestAccuracyPercent": (score.get("behavioural_testing") or {}).get("accuracy_percentage"),
            "CompleteCorrectness": (score.get("behavioural_testing") or {}).get("complete_correctness"),
            "FlowchartDelta": (score.get("derived_metrics") or {}).get("flowchart_delta"),
            "FlowchartEffect": (score.get("derived_metrics") or {}).get("flowchart_effect"),
            "FlowMediationDelta": (score.get("derived_metrics") or {}).get("flow_mediation_delta"),
            "FlowMediationEffect": (score.get("derived_metrics") or {}).get("flow_mediation_effect"),
            "DirectASTTestAccuracyPercent": (score.get("derived_metrics") or {}).get("direct_ast_test_accuracy_percentage"),
            "FlowMediatedTestAccuracyPercent": (score.get("derived_metrics") or {}).get("flow_mediated_test_accuracy_percentage"),
            "FailureTaxonomy": (score.get("derived_metrics") or {}).get("failure_taxonomy"),
            "FirstSemanticLossStage": ((score.get("derived_metrics") or {}).get("first_semantic_loss") or {}).get("stage"),
            "FirstSemanticLossCriterion": ((score.get("derived_metrics") or {}).get("first_semantic_loss") or {}).get("criterion"),
            "CyclomaticComplexity": (score.get("complexity") or {}).get("cyclomatic_complexity"),
            "DecisionCount": (score.get("complexity") or {}).get("decision_count"),
            "LoopCount": (score.get("complexity") or {}).get("loop_count"),
            "MaximumLoopNesting": (score.get("complexity") or {}).get("maximum_loop_nesting"),
            "ExecutableASTNodes": (score.get("complexity") or {}).get("ast_executable_nodes"),
            "ScoreStatus": score.get("score_status"),
            "ReviewerAgreementPercent": (score.get("derived_metrics") or {}).get("automated_human_agreement_percentage"),
        })
        benchmark = score.get("benchmark") or {}
        row["BaselineBehaviouralAgreementPercent"] = benchmark.get("behavioural_agreement_percentage")
        rows.append(row)

        for cid, c in criteria.items():
            auto = c.get("automated_assessment", {})
            selected, final_status, final_source = _selected_score(c)
            evidence_rows.append({
                "Dataset": dataset,
                "Algorithm": algorithm_id,
                "Criterion": cid,
                "Question": c.get("question"),
                "AutomatedScore": auto.get("score"),
                "AutomatedStatus": auto.get("status"),
                "AutomatedConfidence": auto.get("confidence"),
                "AutomatedJustification": auto.get("justification"),
                "FinalScore": selected,
                "FinalStatus": final_status,
                "FinalSource": final_source,
                "EvidenceJSON": json.dumps(c.get("evidence", []), ensure_ascii=False),
            })
            if auto.get("status") == "REVIEW_REQUIRED" or auto.get("confidence") == "LOW":
                review_rows.append({
                    "Dataset": dataset,
                    "Algorithm": algorithm_id,
                    "Criterion": cid,
                    "Question": c.get("question"),
                    "AutomatedScore": auto.get("score"),
                    "Reason": auto.get("justification"),
                })

        flow_rows.append({
            "Dataset": dataset,
            "Algorithm": algorithm_id,
            "PreFlowStagePercent": (score.get("derived_metrics") or {}).get("pre_flow_stage_percentage"),
            "PostFlowStagePercent": (score.get("derived_metrics") or {}).get("post_flow_stage_percentage"),
            "FlowchartDelta": (score.get("derived_metrics") or {}).get("flowchart_delta"),
            "FlowchartEffect": (score.get("derived_metrics") or {}).get("flowchart_effect"),
            "FlowMediationDelta": (score.get("derived_metrics") or {}).get("flow_mediation_delta"),
            "FlowMediationEffect": (score.get("derived_metrics") or {}).get("flow_mediation_effect"),
            "DirectASTTestAccuracyPercent": (score.get("derived_metrics") or {}).get("direct_ast_test_accuracy_percentage"),
            "FlowMediatedTestAccuracyPercent": (score.get("derived_metrics") or {}).get("flow_mediated_test_accuracy_percentage"),
        })
        scoring_dir = score_path.parent
        review_status_rows.append({
            "Dataset": dataset,
            "Algorithm": algorithm_id,
            "QuestionnaireGenerated": (scoring_dir / "human_review_questionnaire.html").exists(),
            "HumanReviewPresent": (scoring_dir / "human_review.json").exists(),
            "FinalScoreStatus": score.get("score_status"),
        })

    outputs = {}
    outputs["algorithm_scores_csv"] = str(_write_csv(analysis_directory / "algorithm_scores.csv", rows))
    outputs["criterion_evidence_csv"] = str(_write_csv(analysis_directory / "criterion_evidence.csv", evidence_rows))
    outputs["review_queue_csv"] = str(_write_csv(analysis_directory / "review_queue.csv", review_rows))
    outputs["flowchart_impact_csv"] = str(_write_csv(analysis_directory / "flowchart_impact.csv", flow_rows))
    outputs["human_review_status_csv"] = str(_write_csv(analysis_directory / "human_review_status.csv", review_status_rows))
    json_path = analysis_directory / "algorithm_scores.json"
    json_path.write_text(json.dumps(rows, indent=2), encoding="utf-8")
    outputs["algorithm_scores_json"] = str(json_path.resolve())
    return outputs


def _write_csv(path: Path, rows: list[dict[str, Any]]) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    fieldnames: list[str] = []
    seen = set()
    for row in rows:
        for key in row:
            if key not in seen:
                seen.add(key)
                fieldnames.append(key)
    with path.open("w", encoding="utf-8", newline="") as handle:
        if fieldnames:
            writer = csv.DictWriter(handle, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(rows)
    return path.resolve()


def aggregate_study_root(study_root: Path, analysis_directory: Path | None = None) -> dict[str, str]:
    """Aggregate baseline plus all ``*/results`` datasets under one study root."""
    study_root = Path(study_root)
    analysis_directory = Path(analysis_directory) if analysis_directory else study_root / "analysis"
    analysis_directory.mkdir(parents=True, exist_ok=True)

    score_files = []
    baseline_scores = study_root.glob("Baseline/pseudocode/Algorithm - */pipeline_artifacts/scoring/final_score.json")
    score_files.extend(baseline_scores)
    for results_dir in study_root.glob("*/results"):
        score_files.extend(results_dir.glob("Algorithm - */pipeline_artifacts/scoring/final_score.json"))
    score_files = sorted(set(score_files), key=lambda p: str(p).casefold())

    # Reuse the same flattening logic by reading each score directly.
    rows=[]; evidence_rows=[]; review_rows=[]; flow_rows=[]; review_status_rows=[]
    for score_path in score_files:
        score=_read_json(score_path)
        if not score: continue
        algorithm=score.get("algorithm",{}); dataset=algorithm.get("dataset"); algorithm_id=algorithm.get("algorithm_id")
        criteria=_criterion_map(score)
        row={"Dataset":dataset,"Algorithm":algorithm_id,"SourceSufficiency":score.get("source_sufficiency",{}).get("final_result") or score.get("source_sufficiency",{}).get("result")}
        for cid in CRITERIA:
            c=criteria.get(cid,{})
            selected,status,source=_selected_score(c) if c else (None,"NOT_EVALUABLE","NONE")
            row[cid]=selected; row[f"{cid}_Status"]=status; row[f"{cid}_Source"]=source
        stages=score.get("stages",{}); derived=score.get("derived_metrics") or {}; beh=score.get("behavioural_testing") or {}; comp=score.get("complexity") or {}; benchmark=score.get("benchmark") or {}
        row.update({
            "CanonicalisationPercent":(stages.get("canonicalisation",{}).get("stage_summary") or {}).get("percentage"),
            "ASTPercent":(stages.get("ast",{}).get("stage_summary") or {}).get("percentage"),
            "FlowPercent":(stages.get("flow_diagram",{}).get("stage_summary") or {}).get("percentage"),
            "PythonPercent":(stages.get("python",{}).get("stage_summary") or {}).get("percentage"),
            "TestAccuracyPercent":beh.get("accuracy_percentage"),"CompleteCorrectness":beh.get("complete_correctness"),
            "FlowchartDelta":derived.get("flowchart_delta"),"FlowchartEffect":derived.get("flowchart_effect"),
            "FlowMediationDelta":derived.get("flow_mediation_delta"),"FlowMediationEffect":derived.get("flow_mediation_effect"),
            "DirectASTTestAccuracyPercent":derived.get("direct_ast_test_accuracy_percentage"),"FlowMediatedTestAccuracyPercent":derived.get("flow_mediated_test_accuracy_percentage"),
            "FailureTaxonomy":derived.get("failure_taxonomy"),"FirstSemanticLossStage":(derived.get("first_semantic_loss") or {}).get("stage"),
            "FirstSemanticLossCriterion":(derived.get("first_semantic_loss") or {}).get("criterion"),
            "CyclomaticComplexity":comp.get("cyclomatic_complexity"),"DecisionCount":comp.get("decision_count"),"LoopCount":comp.get("loop_count"),
            "MaximumLoopNesting":comp.get("maximum_loop_nesting"),"ExecutableASTNodes":comp.get("ast_executable_nodes"),
            "ScoreStatus":score.get("score_status"),"ReviewerAgreementPercent":derived.get("automated_human_agreement_percentage"),
            "BaselineBehaviouralAgreementPercent":benchmark.get("behavioural_agreement_percentage"),
            "BaselineReferenceValidationStatus":(benchmark.get("reference_validation") or {}).get("status"),
            "BaselineReferenceValidationPercent":(benchmark.get("reference_validation") or {}).get("validation_percentage"),
            "BaselineReferenceValidationStatus":(benchmark.get("reference_validation") or {}).get("status"),
            "BaselineReferenceValidationPercent":(benchmark.get("reference_validation") or {}).get("validation_percentage"),
        })
        rows.append(row)
        for cid,c in criteria.items():
            auto=c.get("automated_assessment",{}); selected,final_status,final_source=_selected_score(c)
            evidence_rows.append({"Dataset":dataset,"Algorithm":algorithm_id,"Criterion":cid,"Question":c.get("question"),"AutomatedScore":auto.get("score"),"AutomatedStatus":auto.get("status"),"AutomatedConfidence":auto.get("confidence"),"AutomatedJustification":auto.get("justification"),"FinalScore":selected,"FinalStatus":final_status,"FinalSource":final_source,"EvidenceJSON":json.dumps(c.get("evidence",[]),ensure_ascii=False)})
            if auto.get("status")=="REVIEW_REQUIRED" or auto.get("confidence")=="LOW":
                review_rows.append({"Dataset":dataset,"Algorithm":algorithm_id,"Criterion":cid,"Question":c.get("question"),"AutomatedScore":auto.get("score"),"Reason":auto.get("justification")})
        flow_rows.append({"Dataset":dataset,"Algorithm":algorithm_id,"PreFlowStagePercent":derived.get("pre_flow_stage_percentage"),"PostFlowStagePercent":derived.get("post_flow_stage_percentage"),"FlowchartDelta":derived.get("flowchart_delta"),"FlowchartEffect":derived.get("flowchart_effect"),"DirectASTTestAccuracyPercent":derived.get("direct_ast_test_accuracy_percentage"),"FlowMediatedTestAccuracyPercent":derived.get("flow_mediated_test_accuracy_percentage"),"FlowMediationDelta":derived.get("flow_mediation_delta"),"FlowMediationEffect":derived.get("flow_mediation_effect")})
        scoring_dir=score_path.parent
        review_status_rows.append({"Dataset":dataset,"Algorithm":algorithm_id,"QuestionnaireGenerated":(scoring_dir/"human_review_questionnaire.html").exists(),"HumanReviewPresent":(scoring_dir/"human_review.json").exists(),"FinalScoreStatus":score.get("score_status")})

    outputs={}
    outputs["all_models_scores_csv"]=str(_write_csv(analysis_directory/"all_models_scores.csv",rows))
    outputs["criterion_evidence_csv"]=str(_write_csv(analysis_directory/"criterion_evidence.csv",evidence_rows))
    outputs["review_queue_csv"]=str(_write_csv(analysis_directory/"review_queue.csv",review_rows))
    outputs["flowchart_impact_csv"]=str(_write_csv(analysis_directory/"flowchart_impact.csv",flow_rows))
    outputs["human_review_status_csv"]=str(_write_csv(analysis_directory/"human_review_status.csv",review_status_rows))

    # Dataset-level means, ignoring unavailable values.
    numeric_fields=["CanonicalisationPercent","ASTPercent","FlowPercent","PythonPercent","TestAccuracyPercent","FlowchartDelta","FlowMediationDelta","CyclomaticComplexity"]
    by_dataset={}
    for row in rows: by_dataset.setdefault(row.get("Dataset"),[]).append(row)
    model_summary=[]
    for dataset,items in sorted(by_dataset.items(), key=lambda kv:str(kv[0]).casefold()):
        summary={"Dataset":dataset,"Algorithms":len(items)}
        for field in numeric_fields:
            vals=[float(r[field]) for r in items if r.get(field) is not None]
            summary[f"Mean{field}"]=round(sum(vals)/len(vals),2) if vals else None
        summary["CompleteCorrectCount"]=sum(r.get("CompleteCorrectness") is True for r in items)
        model_summary.append(summary)
    outputs["model_summary_csv"]=str(_write_csv(analysis_directory/"model_summary.csv",model_summary))

    # Task difficulty across non-baseline model datasets.
    by_algorithm={}
    for row in rows:
        if str(row.get("Dataset")).casefold()=="baseline": continue
        by_algorithm.setdefault(row.get("Algorithm"),[]).append(row)
    difficulty=[]
    for aid,items in sorted(by_algorithm.items(), key=lambda kv:(kv[0] is None,kv[0])):
        test_vals=[float(r["TestAccuracyPercent"]) for r in items if r.get("TestAccuracyPercent") is not None]
        py_vals=[float(r["PythonPercent"]) for r in items if r.get("PythonPercent") is not None]
        difficulty.append({"Algorithm":aid,"ModelCount":len(items),"MeanTestAccuracyPercent":round(sum(test_vals)/len(test_vals),2) if test_vals else None,"MeanPythonPercent":round(sum(py_vals)/len(py_vals),2) if py_vals else None})
    outputs["algorithm_difficulty_csv"]=str(_write_csv(analysis_directory/"algorithm_difficulty.csv",difficulty))

    json_path=analysis_directory/"all_models_scores.json"; json_path.write_text(json.dumps(rows,indent=2),encoding="utf-8"); outputs["all_models_scores_json"]=str(json_path.resolve())
    return outputs
