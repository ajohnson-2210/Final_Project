"""Merge a completed human-review artefact with automated scores."""

from __future__ import annotations

from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
import json


def _summary(criteria: list[dict[str, Any]]) -> dict[str, Any]:
    values=[]
    semantic_failure=False
    review_required=False
    for c in criteria:
        final=c.get('final_assessment',{})
        score=final.get('score')
        if score is not None:
            values.append(score)
        if c.get('critical_semantic_criterion') and score == 0:
            semantic_failure=True
        if final.get('status') in {'REVIEW_REQUIRED','PARTIAL'}:
            review_required=True
    maximum=len(values)*2
    obtained=sum(values)
    pct=round(obtained/maximum*100,2) if maximum else None
    if not values: status='NOT_EVALUABLE'
    elif semantic_failure: status='SEMANTIC_FAILURE'
    elif review_required: status='REVIEW_REQUIRED'
    elif pct == 100: status='PASS'
    else: status='PARTIAL'
    return {
        'score_obtained': obtained if values else None,
        'maximum_applicable_score': maximum if values else None,
        'percentage': pct,
        'semantic_failure': semantic_failure,
        'review_required': review_required,
        'status': status,
    }


def adjudicate(automated: dict[str, Any], human: dict[str, Any]) -> dict[str, Any]:
    out=deepcopy(automated)
    human_by_id={item.get('criterion_id'):item for item in human.get('criteria',[])}
    agreements=0
    compared=0

    for stage in out.get('stages',{}).values():
        for criterion in stage.get('criteria',[]):
            cid=criterion.get('criterion_id')
            auto=criterion.get('automated_assessment',{})
            hitem=human_by_id.get(cid,{})
            h=hitem.get('human_assessment',{})
            human_label=h.get('score_label')
            human_score=h.get('score')
            human_completed=human_label is not None
            if human_completed:
                agreement=h.get('agreement_with_automated_score')
                compared += 1
                if agreement == 'AGREE' or human_score == auto.get('score'):
                    agreements += 1
                final_score=human_score
                final_status='NOT_EVALUABLE' if human_label == 'NA' else (
                    'FAIL' if human_score == 0 else ('PARTIAL' if human_score == 1 else 'PASS')
                )
                source='HUMAN_ADJUDICATED'
            else:
                final_score=auto.get('score')
                final_status=auto.get('status')
                source='AUTOMATED_PROVISIONAL'
            criterion['human_assessment']={
                'completed': human_completed,
                'score': human_score,
                'score_label': human_label,
                'agreement_with_automated_score': h.get('agreement_with_automated_score'),
                'semantic_issue': h.get('semantic_issue'),
                'reviewer_justification': h.get('reviewer_justification'),
            }
            criterion['final_assessment']={
                'score': final_score,
                'status': final_status,
                'source': source,
            }
        stage['stage_summary']=_summary(stage.get('criteria',[]))

    source_review=human.get('source_sufficiency',{})
    human_gate=source_review.get('human_result')
    if human_gate:
        out['source_sufficiency']['human_assessment']={
            'completed': True,
            'result': human_gate,
            'agreement_with_automated_result': source_review.get('agreement_with_automated_result'),
            'reviewer_justification': source_review.get('reviewer_justification'),
        }
        out['source_sufficiency']['final_result']=human_gate
    else:
        out['source_sufficiency']['final_result']=out['source_sufficiency'].get('result')

    ast_pct=out['stages']['ast']['stage_summary']['percentage']
    flow_pct=out['stages']['flow_diagram']['stage_summary']['percentage']
    if ast_pct is None or flow_pct is None:
        delta=None; effect='NOT_EVALUABLE'
    else:
        delta=round(flow_pct-ast_pct,2)
        effect='IMPROVEMENT' if delta>0 else ('DEGRADATION' if delta<0 else 'NO_CHANGE')
    out['derived_metrics']['pre_flow_stage_percentage']=ast_pct
    out['derived_metrics']['post_flow_stage_percentage']=flow_pct
    out['derived_metrics']['flowchart_delta']=delta
    out['derived_metrics']['flowchart_effect']=effect

    first=None; taxonomy=None
    for key,tax in [('canonicalisation','CANONICALISATION_ERROR'),('ast','AST_SEMANTIC_ERROR'),('flow_diagram','FLOW_CONTROL_ERROR'),('python','PYTHON_OR_BEHAVIOURAL_ERROR')]:
        stage=out['stages'][key]
        for criterion in stage['criteria']:
            if criterion.get('critical_semantic_criterion') and criterion.get('final_assessment',{}).get('score') == 0:
                first={
                    'stage':stage['stage_name'],
                    'criterion':criterion['criterion_id'],
                    'reason':criterion.get('human_assessment',{}).get('reviewer_justification') or criterion.get('automated_assessment',{}).get('justification'),
                }
                taxonomy=tax
                break
        if first: break
    if first is None and out['source_sufficiency'].get('final_result') == 'EXPECTED_FAILURE':
        taxonomy='SOURCE_UNDERSPECIFIED'
    out['derived_metrics']['first_semantic_loss']=first
    out['derived_metrics']['failure_taxonomy']=taxonomy
    out['derived_metrics']['automated_human_agreement_percentage']=round(agreements/compared*100,2) if compared else None

    out['review']={
        'status':'COMPLETED' if compared else 'PARTIAL_OR_EMPTY',
        'reviewer_id':(human.get('reviewer') or {}).get('reviewer_id'),
        'reviewed_at_utc':(human.get('reviewer') or {}).get('reviewed_at_utc'),
        'overall_reviewer_confidence':(human.get('reviewer') or {}).get('overall_reviewer_confidence'),
        'overall_review':human.get('overall_review'),
    }
    out['score_status']='HUMAN_ADJUDICATED' if compared else 'PROVISIONAL_AUTOMATED'
    out['adjudication']={
        'human_review_completed': bool(compared),
        'criteria_compared': compared,
        'criteria_agreed': agreements,
        'agreement_percentage': round(agreements/compared*100,2) if compared else None,
        'final_score_source':'HUMAN_WHERE_AVAILABLE_OTHERWISE_AUTOMATED',
        'adjudicated_at_utc':datetime.now(timezone.utc).isoformat(),
    }
    return out


def adjudicate_files(scoring_directory: Path) -> Path | None:
    scoring_directory=Path(scoring_directory)
    auto_path=scoring_directory/'automated_score.json'
    human_path=scoring_directory/'human_review.json'
    if not auto_path.exists() or not human_path.exists():
        return None
    try:
        auto=json.loads(auto_path.read_text(encoding='utf-8'))
        human=json.loads(human_path.read_text(encoding='utf-8'))
    except (OSError,json.JSONDecodeError):
        return None
    final=adjudicate(auto,human)
    final_path=scoring_directory/'final_score.json'
    final_path.write_text(json.dumps(final,indent=2),encoding='utf-8')
    return final_path
