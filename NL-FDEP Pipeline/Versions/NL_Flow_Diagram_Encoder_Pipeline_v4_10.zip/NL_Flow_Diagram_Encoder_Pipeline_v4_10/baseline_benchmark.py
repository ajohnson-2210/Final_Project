"""Baseline reference pairing and behavioural-oracle support for study runs."""

from __future__ import annotations

from dataclasses import asdict
from pathlib import Path
from typing import Any
import ast
import hashlib
import json
import subprocess
import sys
import time

from aj_test_harness import AJTestHarness, TestCase


def _error_type(stderr: str) -> str | None:
    for line in reversed(stderr.splitlines()):
        stripped = line.strip()
        if not stripped:
            continue
        head = stripped.split(":", 1)[0]
        if head.endswith("Error") or head.endswith("Exception"):
            return head
        break
    return None


def load_test_spec(path: Path) -> list[dict[str, Any]]:
    """Load a study test JSON file.

    Accepted forms are either ``{"tests": [...]}`` or a top-level list.  Each test
    may supply expected output/return-code/error fields.  Missing expected fields can
    later be populated from the baseline reference implementation.
    """
    if not path.exists():
        return []
    data = json.loads(path.read_text(encoding="utf-8"))
    if isinstance(data, dict):
        tests = data.get("tests", [])
    elif isinstance(data, list):
        tests = data
    else:
        raise ValueError(f"Unsupported test specification in {path}")
    if not isinstance(tests, list):
        raise ValueError(f"'tests' must be a list in {path}")
    return [item for item in tests if isinstance(item, dict)]


def _run_reference(program_path: Path, spec: dict[str, Any]) -> dict[str, Any]:
    standard_input = [str(v) for v in spec.get("standard_input", [])]
    input_text = "\n".join(standard_input)
    if input_text:
        input_text += "\n"
    timeout = float(spec.get("timeout_seconds", 3.0))
    start = time.perf_counter()
    try:
        completed = subprocess.run(
            [sys.executable, "-S", str(program_path.resolve())],
            input=input_text,
            capture_output=True,
            text=True,
            timeout=timeout,
            cwd=program_path.resolve().parent,
            check=False,
        )
        return {
            "status": "COMPLETED",
            "standard_input": standard_input,
            "stdout": completed.stdout.splitlines(),
            "stderr": completed.stderr,
            "return_code": completed.returncode,
            "error_type": _error_type(completed.stderr),
            "duration_ms": round((time.perf_counter() - start) * 1000, 3),
        }
    except subprocess.TimeoutExpired as error:
        stdout = error.stdout or ""
        if isinstance(stdout, bytes):
            stdout = stdout.decode(errors="replace")
        return {
            "status": "TIMEOUT",
            "standard_input": standard_input,
            "stdout": stdout.splitlines(),
            "stderr": "Execution exceeded the configured timeout.",
            "return_code": None,
            "error_type": None,
            "duration_ms": round((time.perf_counter() - start) * 1000, 3),
        }


def test_cases_from_spec(
    spec_items: list[dict[str, Any]],
    reference_python: Path | None = None,
) -> tuple[list[TestCase], list[dict[str, Any]]]:
    """Create harness test cases, deriving omitted expectations from reference Python."""
    cases: list[TestCase] = []
    oracle_records: list[dict[str, Any]] = []
    for index, spec in enumerate(spec_items, start=1):
        reference = None
        if reference_python is not None:
            reference = _run_reference(reference_python, spec)
            explicit_fields = [name for name in ("expected_output", "expected_return_code", "expected_error_type") if name in spec]
            oracle_records.append({
                "name": spec.get("name", f"Test {index}"),
                "reference": reference,
                "expected_result_source": "RESEARCHER_VERIFIED" if explicit_fields else "REFERENCE_PYTHON",
                "explicit_expectation_fields": explicit_fields,
            })

        expected_output = spec.get("expected_output")
        expected_return_code = spec.get("expected_return_code")
        expected_error_type = spec.get("expected_error_type")
        if expected_output is None and reference is not None and reference["status"] == "COMPLETED":
            expected_output = reference["stdout"]
        if expected_return_code is None and reference is not None and reference["status"] == "COMPLETED":
            expected_return_code = reference["return_code"]
        if expected_error_type is None and reference is not None and reference["status"] == "COMPLETED":
            expected_error_type = reference["error_type"]
        if expected_output is None:
            expected_output = []
        if expected_return_code is None:
            expected_return_code = 0

        cases.append(TestCase(
            name=str(spec.get("name", f"Test {index}")),
            standard_input=[str(v) for v in spec.get("standard_input", [])],
            expected_output=[str(v) for v in expected_output],
            timeout_seconds=float(spec.get("timeout_seconds", 3.0)),
            category=str(spec.get("category", "NORMAL")).upper(),
            semantic_feature=spec.get("semantic_feature"),
            expected_return_code=int(expected_return_code) if expected_return_code is not None else None,
            expected_error_type=str(expected_error_type) if expected_error_type else None,
        ))
    return cases, oracle_records


def validate_reference_python(reference_python: Path | None, spec_items: list[dict[str, Any]]) -> dict[str, Any]:
    """Validate the supplied baseline reference against researcher-specified expectations.

    Only tests that explicitly carry an expected field are used to validate the reference;
    tests whose expectations are derived from the reference cannot validate that same oracle.
    """
    base={"validation_schema_version":"1.0","reference_python":str(reference_python.resolve()) if reference_python and reference_python.exists() else None}
    if reference_python is None or not reference_python.exists():
        return {**base,"status":"NOT_EVALUATED","reason":"Reference Python implementation was not found.","explicit_tests_total":0}
    explicit=[]
    for index,spec in enumerate(spec_items,start=1):
        fields=[k for k in ("expected_output","expected_return_code","expected_error_type") if k in spec]
        if not fields: continue
        run=_run_reference(reference_python,spec); checks=[]
        if "expected_output" in spec:
            exp=[str(v) for v in (spec.get("expected_output") or [])]; checks.append(("expected_output",run.get("stdout")==exp,exp,run.get("stdout")))
        if "expected_return_code" in spec:
            exp=spec.get("expected_return_code"); checks.append(("expected_return_code",run.get("return_code")==exp,exp,run.get("return_code")))
        if "expected_error_type" in spec:
            exp=spec.get("expected_error_type"); checks.append(("expected_error_type",run.get("error_type")==exp,exp,run.get("error_type")))
        explicit.append({"name":spec.get("name",f"Test {index}"),"fields":fields,"passed":all(c[1] for c in checks),
                         "checks":[{"field":c[0],"passed":c[1],"expected":c[2],"actual":c[3]} for c in checks],"reference_run":run})
    if not explicit:
        return {**base,"status":"REVIEW_REQUIRED","reason":"No researcher-specified expected outcomes are present; the reference can serve as an oracle but has not been independently behaviourally validated.","explicit_tests_total":0,"tests":[]}
    passed=sum(t["passed"] for t in explicit)
    return {**base,"status":"VALIDATED" if passed==len(explicit) else "FAILED","explicit_tests_total":len(explicit),"explicit_tests_passed":passed,
            "validation_percentage":round(passed/len(explicit)*100,2),"tests":explicit}


def write_reference_validation(path: Path, reference_python: Path | None, spec_items: list[dict[str, Any]]) -> dict[str, Any]:
    doc=validate_reference_python(reference_python,spec_items); Path(path).write_text(json.dumps(doc,indent=2),encoding="utf-8"); return doc



def _python_structural_comparison(generated_python: Path | None, reference_python: Path | None) -> dict[str, Any]:
    if generated_python is None or not generated_python.exists() or reference_python is None or not reference_python.exists():
        return {
            "status": "NOT_EVALUATED",
            "reason": "Both generated and reference Python files are required for structural comparison.",
        }
    generated_source = generated_python.read_text(encoding="utf-8")
    reference_source = reference_python.read_text(encoding="utf-8")
    result: dict[str, Any] = {
        "status": "EVALUATED",
        "generated_python": str(generated_python.resolve()),
        "reference_python": str(reference_python.resolve()),
        "exact_source_match": generated_source == reference_source,
        "generated_sha256": hashlib.sha256(generated_source.encode("utf-8")).hexdigest(),
        "reference_sha256": hashlib.sha256(reference_source.encode("utf-8")).hexdigest(),
        "note": (
            "Exact-source and normalised-AST comparisons are descriptive only. A structural mismatch is not scored as incorrect, "
            "because behaviourally equivalent Python implementations may differ syntactically."
        ),
    }
    try:
        generated_ast = ast.dump(ast.parse(generated_source), include_attributes=False)
        result["generated_syntax_valid"] = True
    except SyntaxError as error:
        generated_ast = None
        result["generated_syntax_valid"] = False
        result["generated_syntax_error"] = str(error)
    try:
        reference_ast = ast.dump(ast.parse(reference_source), include_attributes=False)
        result["reference_syntax_valid"] = True
    except SyntaxError as error:
        reference_ast = None
        result["reference_syntax_valid"] = False
        result["reference_syntax_error"] = str(error)
    result["normalised_python_ast_match"] = (
        generated_ast is not None and reference_ast is not None and generated_ast == reference_ast
    )
    return result


def build_baseline_comparison(
    generated_test_report: dict[str, Any] | None,
    reference_python: Path | None,
    tests_path: Path | None,
    oracle_records: list[dict[str, Any]] | None = None,
    generated_python: Path | None = None,
) -> dict[str, Any]:
    structural = _python_structural_comparison(generated_python, reference_python)
    base = {
        "is_baseline": True,
        "reference_python": str(reference_python.resolve()) if reference_python and reference_python.exists() else None,
        "structural_comparison": structural,
    }
    if reference_python is None or not reference_python.exists():
        return {
            **base,
            "status": "NOT_EVALUATED",
            "reason": "Reference Python implementation was not found.",
        }
    if tests_path is None or not tests_path.exists():
        return {
            **base,
            "status": "STRUCTURAL_ONLY",
            "reason": "No baseline test specification was found; behavioural correctness is not inferred from source similarity.",
        }
    if generated_test_report is None:
        return {
            **base,
            "status": "STRUCTURAL_ONLY",
            "tests_file": str(tests_path.resolve()),
            "reason": "Generated Python was not behaviourally tested.",
            "reference_oracle_runs": oracle_records or [],
        }

    total = int(generated_test_report.get("total_tests", 0) or 0)
    passed = int(generated_test_report.get("passed_tests", 0) or 0)
    return {
        **base,
        "status": "EVALUATED" if total else "STRUCTURAL_ONLY",
        "tests_file": str(tests_path.resolve()),
        "tests_total": total,
        "behaviour_matches": passed,
        "behaviour_mismatches": max(total - passed, 0),
        "behavioural_agreement_percentage": round((passed / total) * 100, 2) if total else None,
        "reference_oracle_runs": oracle_records or [],
    }
