from __future__ import annotations
from abc import ABC
from dataclasses import dataclass, field, fields, asdict
from enum import Enum
from itertools import count
from typing import Any, Iterable
import json, re, time

class AJParserError(Exception): pass
class LexerError(AJParserError): pass
class ParserError(AJParserError): pass
class SemanticError(AJParserError): pass

class StageStatus(str, Enum):
    SUCCESS='SUCCESS'; FAILURE='FAILURE'; PARTIAL='PARTIAL'; NOT_RUN='NOT_RUN'

@dataclass(slots=True)
class StageResult:
    name:str; status:StageStatus; message:str; duration_ms:float=0.0; details:dict[str,Any]=field(default_factory=dict)
    def to_dict(self):
        d=asdict(self); d['status']=self.status.value; return d

@dataclass
class ProcessReport:
    stages:list[StageResult]=field(default_factory=list)
    def add(self,name,status,message,duration_ms=0.0,**details):
        self.stages.append(StageResult(name,status,message,round(duration_ms,3),details))
    @property
    def success(self): return bool(self.stages) and all(s.status==StageStatus.SUCCESS for s in self.stages)
    def to_dict(self): return {'success':self.success,'stages':[s.to_dict() for s in self.stages]}
    def to_json(self): return json.dumps(self.to_dict(),indent=2)
    def pretty(self):
        out=[]
        for s in self.stages:
            out.append(f'[{s.status.value:7}] {s.name:<26} {s.duration_ms:>8.3f} ms  {s.message}')
            for k,v in s.details.items(): out.append(f'           - {k}: {v}')
        return '\n'.join(out)

class TokenType(str,Enum):
    IDENT='IDENT'; INT='INT'; FLOAT='FLOAT'; STRING='STRING'; KEYWORD='KEYWORD'; OP='OP'; LP='LP'; RP='RP'; LB='LB'; RB='RB'; COMMA='COMMA'; DOT='DOT'; NEWLINE='NEWLINE'; EOF='EOF'; GET='GET'
@dataclass(frozen=True,slots=True)
class Token:
    type:TokenType; value:str; line:int; column:int
    def loc(self): return f'line {self.line}, column {self.column}'

class AJLexer:
    PHRASES=sorted({'REMOVE FIRST ITEM FROM','REMOVE LAST ITEM FROM','INTEGER DIVISION','FOR EACH','IN RANGE','LENGTH OF','EMPTY DICTIONARY','EMPTY STRING','EMPTY LIST','EMPTY SET','EMPTY TUPLE','ELSE IF','NOT IN','LIST OF'},key=len,reverse=True)
    WORDS={'FUNCTION','ACCEPTS','ENDFUNCTION','RETURN','CALL','IF','THEN','ELSE','ENDIF','WHILE','DO','ENDWHILE','FOR','TO','STEP','ENDFOR','IN','BREAK','STOP','CONTINUE','OUTPUT','INPUT','APPEND','TRY','CATCH','ENDTRY','RAISE','INTEGER','FLOAT','STRING','CHAR','BOOLEAN','TRUE','FALSE','LIST','TUPLE','SET','JOIN','NOT','AND','OR','XOR','EXP','MODULUS','AS','COMMENT'}
    OPS=('<-','==','!=','<=','>=','+','-','*','/','<','>')
    def tokenise(self,source:str)->list[Token]:
        if not isinstance(source,str): raise LexerError('Source must be text.')
        tokens=[]
        lines=source.splitlines() or ['']
        for ln,line in enumerate(lines,1):
            i=0
            while i<len(line):
                if line[i].isspace(): i+=1; continue
                col=i+1; rem=line[i:]; up=rem.upper()
                phrase=next((p for p in self.PHRASES if up.startswith(p) and (len(rem)==len(p) or not (rem[len(p)].isalnum() or rem[len(p)]=='_'))),None)
                if phrase: tokens.append(Token(TokenType.KEYWORD,phrase,ln,col)); i+=len(phrase); continue
                if rem.startswith('~GET'): tokens.append(Token(TokenType.GET,'~GET',ln,col)); i+=4; continue
                op=next((o for o in self.OPS if rem.startswith(o)),None)
                if op: tokens.append(Token(TokenType.OP,op,ln,col)); i+=len(op); continue
                punct={'(':TokenType.LP,')':TokenType.RP,'[':TokenType.LB,']':TokenType.RB,',':TokenType.COMMA,'.':TokenType.DOT}
                if line[i] in punct: tokens.append(Token(punct[line[i]],line[i],ln,col)); i+=1; continue
                if line[i] in '\"\'':
                    q=line[i]; i+=1; chars=[]; esc=False
                    while i<len(line):
                        c=line[i]
                        if esc: chars.append({'n':'\n','t':'\t'}.get(c,c)); esc=False
                        elif c=='\\': esc=True
                        elif c==q: break
                        else: chars.append(c)
                        i+=1
                    if i>=len(line): raise LexerError(f'Unterminated string at line {ln}, column {col}.')
                    i+=1; tokens.append(Token(TokenType.STRING,''.join(chars),ln,col)); continue
                m=re.match(r'\d+\.\d+|\d+',rem)
                if m:
                    v=m.group(); tokens.append(Token(TokenType.FLOAT if '.' in v else TokenType.INT,v,ln,col)); i+=len(v); continue
                m=re.match(r'[A-Za-z_][A-Za-z0-9_]*',rem)
                if m:
                    v=m.group(); u=v.upper(); tokens.append(Token(TokenType.KEYWORD if u in self.WORDS else TokenType.IDENT,u if u in self.WORDS else v,ln,col)); i+=len(v); continue
                raise LexerError(f'Unrecognised character {line[i]!r} at line {ln}, column {col}.')
            tokens.append(Token(TokenType.NEWLINE,'\\n',ln,len(line)+1))
        tokens.append(Token(TokenType.EOF,'',len(lines)+1,1)); return tokens

_ids=count(1)
@dataclass
class ASTNode(ABC):
    line:int; node_id:str=field(default_factory=lambda:f'N{next(_ids)}',init=False)
    @property
    def kind(self): return type(self).__name__
    def children(self)->Iterable['ASTNode']:
        for f in fields(self):
            if f.name in {'line','node_id'}: continue
            v=getattr(self,f.name)
            if isinstance(v,ASTNode): yield v
            elif isinstance(v,list):
                for x in v:
                    if isinstance(x,ASTNode): yield x
    def attrs(self):
        d={}
        for f in fields(self):
            if f.name in {'line','node_id'}: continue
            v=getattr(self,f.name)
            if isinstance(v,ASTNode) or (isinstance(v,list) and any(isinstance(x,ASTNode) for x in v)): continue
            d[f.name]=v
        return d
@dataclass
class ProgramNode(ASTNode): body:list[ASTNode]
@dataclass
class BlockNode(ASTNode): statements:list[ASTNode]
@dataclass
class IdentifierNode(ASTNode): name:str
@dataclass
class LiteralNode(ASTNode): value:Any; data_type:str
@dataclass
class EmptyLiteralNode(ASTNode): empty_type:str
@dataclass
class ListLiteralNode(ASTNode): items:list[ASTNode]; declared_type:str|None=None
@dataclass
class TupleLiteralNode(ASTNode): items:list[ASTNode]
@dataclass
class BinaryNode(ASTNode): operator:str; left:ASTNode; right:ASTNode
@dataclass
class UnaryNode(ASTNode): operator:str; operand:ASTNode
@dataclass
class IndexNode(ASTNode): collection:ASTNode; index:ASTNode
@dataclass
class MemberAccessNode(ASTNode): object:ASTNode; member:str
@dataclass
class RemoveFirstExpressionNode(ASTNode): collection:ASTNode
@dataclass
class RemoveLastExpressionNode(ASTNode): collection:ASTNode
@dataclass
class CallNode(ASTNode): name:str; arguments:list[ASTNode]
@dataclass
class InputNode(ASTNode): prompt:ASTNode
@dataclass
class LengthNode(ASTNode): expression:ASTNode
@dataclass
class JoinNode(ASTNode): collection:ASTNode; separator:ASTNode
@dataclass
class GetNode(ASTNode): dictionary:ASTNode; key:ASTNode; default:ASTNode|None=None
@dataclass
class AssignmentNode(ASTNode): target:ASTNode; value:ASTNode
@dataclass
class OutputNode(ASTNode): expression:ASTNode
@dataclass
class ReturnNode(ASTNode): expression:ASTNode|None=None
@dataclass
class BreakNode(ASTNode): pass
@dataclass
class StopNode(ASTNode): pass
@dataclass
class ContinueNode(ASTNode): pass
@dataclass
class AppendNode(ASTNode): value:ASTNode; collection:ASTNode
@dataclass
class RemoveFirstNode(ASTNode): collection:ASTNode
@dataclass
class RemoveLastNode(ASTNode): collection:ASTNode
@dataclass
class RaiseNode(ASTNode): expression:ASTNode
@dataclass
class ElseIfNode(ASTNode): condition:ASTNode; body:BlockNode
@dataclass
class IfNode(ASTNode): condition:ASTNode; then_body:BlockNode; else_if:list[ElseIfNode]; else_body:BlockNode|None=None
@dataclass
class WhileNode(ASTNode): condition:ASTNode; body:BlockNode
@dataclass
class ForEachNode(ASTNode): variable:IdentifierNode; collection:ASTNode; body:BlockNode
@dataclass
class ForRangeNode(ASTNode): variable:IdentifierNode; start:ASTNode; end:ASTNode; step:ASTNode|None; body:BlockNode
@dataclass
class TryCatchNode(ASTNode): try_body:BlockNode; error:IdentifierNode|None; catch_body:BlockNode
@dataclass
class ParameterNode(ASTNode): name:str; declared_type:str|None=None
@dataclass
class FunctionNode(ASTNode): name:str; parameters:list[ParameterNode]; body:BlockNode
@dataclass
class CommentNode(ASTNode): text:str

class AJParser:
    PREC={'OR':1,'XOR':2,'AND':3,'==':4,'!=':4,'<':4,'>':4,'<=':4,'>=':4,'IN':4,'NOT IN':4,'+':5,'-':5,'*':6,'/':6,'INTEGER DIVISION':6,'MODULUS':6,'EXP':7}
    def __init__(self,tokens): self.t=tokens; self.i=0; self.loop_depth=0; self.fn_depth=0
    def parse(self):
        body=[]; self.skip_nl()
        while not self.check(TokenType.EOF): body.append(self.statement()); self.skip_nl()
        return ProgramNode(1,body)
    def statement(self):
        if self.kw('FUNCTION'): return self.function()
        if self.kw('IF'): return self.if_stmt()
        if self.kw('WHILE'): return self.while_stmt()
        if self.kw('FOR EACH'): return self.foreach()
        if self.kw('FOR'): return self.forrange()
        if self.kw('TRY'): return self.trycatch()
        if self.kw('OUTPUT'):
            s=self.prev(); e=self.expr(); self.eol(); return OutputNode(s.line,e)
        if self.kw('RETURN'):
            s=self.prev();
            if self.fn_depth==0: raise ParserError(f'RETURN outside function at {s.loc()}.')
            e=None if self.check(TokenType.NEWLINE) else self.expr(); self.eol(); return ReturnNode(s.line,e)
        if self.kw('BREAK'):
            s=self.prev();
            if not self.loop_depth: raise ParserError(f'BREAK outside loop at {s.loc()}.')
            self.eol(); return BreakNode(s.line)
        if self.kw('STOP'):
            s=self.prev(); self.eol(); return StopNode(s.line)
        if self.kw('CONTINUE'):
            s=self.prev();
            if not self.loop_depth: raise ParserError(f'CONTINUE outside loop at {s.loc()}.')
            self.eol(); return ContinueNode(s.line)
        if self.kw('APPEND'):
            s=self.prev(); v=self.expr(); self.need_kw('TO'); c=self.expr(); self.eol(); return AppendNode(s.line,v,c)
        if self.kw('REMOVE FIRST ITEM FROM'):
            s=self.prev(); c=self.expr(); self.eol(); return RemoveFirstNode(s.line,c)
        if self.kw('REMOVE LAST ITEM FROM'):
            s=self.prev(); c=self.expr(); self.eol(); return RemoveLastNode(s.line,c)
        if self.kw('RAISE'):
            s=self.prev(); e=self.expr(); self.eol(); return RaiseNode(s.line,e)
        if self.kw('COMMENT'):
            s=self.prev(); text=''
            while not self.check(TokenType.NEWLINE): text += (' ' if text else '') + self.advance().value
            self.eol(); return CommentNode(s.line,text)
        start=self.peek(); left=self.expr()
        if self.op('<-'):
            if not isinstance(left,(IdentifierNode,IndexNode)): raise ParserError(f'Invalid assignment target at {start.loc()}.')
            val=self.expr(); self.eol(); return AssignmentNode(start.line,left,val)
        if isinstance(left,CallNode): self.eol(); return left
        raise ParserError(f'Expected assignment or CALL statement at {start.loc()}.')
    def function(self):
        s=self.prev(); name=self.need(TokenType.IDENT,'Expected function name.'); self.need_kw('ACCEPTS'); self.need(TokenType.LP,"Expected '('.")
        params=[]
        if not self.check(TokenType.RP):
            while True:
                p=self.need(TokenType.IDENT,'Expected parameter.'); typ=None
                if self.kw('AS'): typ=self.advance().value
                params.append(ParameterNode(p.line,p.value,typ))
                if not self.match(TokenType.COMMA): break
        self.need(TokenType.RP,"Expected ')'."); self.eol(); self.fn_depth+=1; body=self.block({'ENDFUNCTION'}); self.fn_depth-=1; self.need_kw('ENDFUNCTION'); self.eol(); return FunctionNode(s.line,name.value,params,body)
    def if_stmt(self):
        s=self.prev(); cond=self.expr(); self.need_kw('THEN'); self.eol(); then=self.block({'ELSE IF','ELSE','ENDIF'}); clauses=[]
        while self.kw('ELSE IF'):
            c=self.prev(); ce=self.expr(); self.need_kw('THEN'); self.eol(); clauses.append(ElseIfNode(c.line,ce,self.block({'ELSE IF','ELSE','ENDIF'})))
        other=None
        if self.kw('ELSE'): self.eol(); other=self.block({'ENDIF'})
        self.need_kw('ENDIF'); self.eol(); return IfNode(s.line,cond,then,clauses,other)
    def while_stmt(self):
        s=self.prev(); c=self.expr(); self.need_kw('DO'); self.eol(); self.loop_depth+=1; b=self.block({'ENDWHILE'}); self.loop_depth-=1; self.need_kw('ENDWHILE'); self.eol(); return WhileNode(s.line,c,b)
    def foreach(self):
        s=self.prev(); v=self.need(TokenType.IDENT,'Expected iterator.'); self.need_kw('IN'); c=self.expr(); self.need_kw('DO'); self.eol(); self.loop_depth+=1; b=self.block({'ENDFOR'}); self.loop_depth-=1; self.need_kw('ENDFOR'); self.eol(); return ForEachNode(s.line,IdentifierNode(v.line,v.value),c,b)
    def forrange(self):
        s=self.prev(); v=self.need(TokenType.IDENT,'Expected iterator.'); self.need_op('<-'); self.need_kw('IN RANGE'); a=self.expr(); self.need_kw('TO'); z=self.expr(); step=None
        if self.kw('STEP'): step=self.expr()
        self.need_kw('DO'); self.eol(); self.loop_depth+=1; b=self.block({'ENDFOR'}); self.loop_depth-=1; self.need_kw('ENDFOR'); self.eol(); return ForRangeNode(s.line,IdentifierNode(v.line,v.value),a,z,step,b)
    def trycatch(self):
        s=self.prev(); self.eol(); tb=self.block({'CATCH'}); self.need_kw('CATCH'); err=None
        if self.check(TokenType.IDENT): x=self.advance(); err=IdentifierNode(x.line,x.value)
        self.eol(); cb=self.block({'ENDTRY'}); self.need_kw('ENDTRY'); self.eol(); return TryCatchNode(s.line,tb,err,cb)
    def block(self,ends):
        st=[]; self.skip_nl(); line=self.peek().line
        while not self.check(TokenType.EOF) and not (self.peek().type==TokenType.KEYWORD and self.peek().value in ends): st.append(self.statement()); self.skip_nl()
        if self.check(TokenType.EOF): raise ParserError(f'Unexpected end of file; expected one of {sorted(ends)}.')
        return BlockNode(line,st)
    def expr(self,minp=1):
        left=self.unary()
        while True:
            op=self.binop()
            if op is None or self.PREC[op]<minp: break
            tok=self.advance()
            right=self.expr(self.PREC[op] if op=='EXP' else self.PREC[op]+1); left=BinaryNode(tok.line,op,left,right)
        return left
    def unary(self):
        if self.kw('NOT'): s=self.prev(); return UnaryNode(s.line,'NOT',self.unary())
        if self.op('-'): s=self.prev(); return UnaryNode(s.line,'-',self.unary())
        return self.postfix()
    def postfix(self):
        n=self.primary()
        while True:
            if self.match(TokenType.LB): s=self.prev(); idx=self.expr(); self.need(TokenType.RB,"Expected ']'."); n=IndexNode(s.line,n,idx)
            elif self.match(TokenType.DOT):
                s=self.prev(); member=self.need(TokenType.IDENT,'Expected property name after dot.'); n=MemberAccessNode(s.line,n,member.value)
            elif self.match(TokenType.GET):
                s=self.prev(); self.need(TokenType.LP,"Expected '('."); key=self.expr(); default=None
                if self.match(TokenType.COMMA): default=self.expr()
                self.need(TokenType.RP,"Expected ')'."); n=GetNode(s.line,n,key,default)
            else: break
        return n
    def primary(self):
        t=self.peek()
        if self.match(TokenType.INT): return LiteralNode(t.line,int(t.value),'INTEGER')
        if self.match(TokenType.FLOAT): return LiteralNode(t.line,float(t.value),'FLOAT')
        if self.match(TokenType.IDENT): return IdentifierNode(t.line,t.value)
        if self.match(TokenType.LP): n=self.expr(); self.need(TokenType.RP,"Expected ')'."); return n
        for kw,typ in [('EMPTY LIST','LIST'),('EMPTY DICTIONARY','DICTIONARY'),('EMPTY STRING','STRING'),('EMPTY SET','SET'),('EMPTY TUPLE','TUPLE')]:
            if self.kw(kw): return EmptyLiteralNode(t.line,typ)
        if self.kw('BOOLEAN'):
            self.need(TokenType.LP,"Expected '('.")
            if self.kw('TRUE'): v=True
            elif self.kw('FALSE'): v=False
            else: raise ParserError(f'Expected TRUE or FALSE at {self.peek().loc()}.')
            self.need(TokenType.RP,"Expected ')'."); return LiteralNode(t.line,v,'BOOLEAN')
        for typ in ('STRING','CHAR','INTEGER','FLOAT'):
            if self.kw(typ):
                self.need(TokenType.LP,"Expected '('."); x=self.advance()
                allowed={TokenType.STRING,TokenType.INT,TokenType.FLOAT,TokenType.IDENT}
                if x.type not in allowed: raise ParserError(f'Invalid {typ} literal at {x.loc()}.')
                self.need(TokenType.RP,"Expected ')'."); val=x.value
                if typ=='CHAR' and x.type==TokenType.IDENT:
                    return CallNode(t.line,'CHAR',[IdentifierNode(t.line,x.value)])
                if typ=='INTEGER' and x.type==TokenType.INT: val=int(val)
                if typ=='FLOAT' and x.type in {TokenType.INT,TokenType.FLOAT}: val=float(val)
                if typ=='CHAR' and len(str(val))!=1: raise ParserError(f'CHAR must contain one character at {t.loc()}.')
                return LiteralNode(t.line,val,typ)
        if self.kw('LIST') or self.kw('LIST OF'):
            declared=None
            if self.prev().value=='LIST OF' and self.peek().type in {TokenType.KEYWORD,TokenType.IDENT}: declared=self.advance().value
            return ListLiteralNode(t.line,self.sequence(TokenType.LB,TokenType.RB),declared)
        if self.kw('TUPLE'): return TupleLiteralNode(t.line,self.sequence(TokenType.LP,TokenType.RP))
        if self.kw('CALL'):
            name=self.need(TokenType.IDENT,'Expected called function name.'); return CallNode(t.line,name.value,self.sequence(TokenType.LP,TokenType.RP))
        if self.kw('INPUT'):
            self.need(TokenType.LP,"Expected '('."); p=self.expr(); self.need(TokenType.RP,"Expected ')'."); return InputNode(t.line,p)
        if self.kw('LENGTH OF'): return LengthNode(t.line,self.unary())
        if self.kw('REMOVE FIRST ITEM FROM'): return RemoveFirstExpressionNode(t.line,self.unary())
        if self.kw('REMOVE LAST ITEM FROM'): return RemoveLastExpressionNode(t.line,self.unary())
        if self.kw('JOIN'):
            self.need(TokenType.LP,"Expected '('."); a=self.expr(); self.need(TokenType.COMMA,"Expected ','."); b=self.expr(); self.need(TokenType.RP,"Expected ')'."); return JoinNode(t.line,a,b)
        raise ParserError(f'Expected expression at {t.loc()}, found {t.value!r}.')
    def sequence(self,left,right):
        self.need(left,'Expected opening delimiter.'); xs=[]
        if not self.check(right):
            while True:
                xs.append(self.expr())
                if not self.match(TokenType.COMMA): break
        self.need(right,'Expected closing delimiter.'); return xs
    def binop(self):
        t=self.peek()
        if t.type in {TokenType.OP,TokenType.KEYWORD}:
            if t.value=='NOT' and self.peek2().value=='IN': return 'NOT IN'
            if t.value in self.PREC: return t.value
        return None
    def eol(self):
        if not self.match(TokenType.NEWLINE): raise ParserError(f'Expected end of line at {self.peek().loc()}.')
    def skip_nl(self):
        while self.match(TokenType.NEWLINE): pass
    def kw(self,v):
        if self.peek().type==TokenType.KEYWORD and self.peek().value==v: self.advance(); return True
        return False
    def op(self,v):
        if self.peek().type==TokenType.OP and self.peek().value==v: self.advance(); return True
        return False
    def need_kw(self,v):
        if not self.kw(v): raise ParserError(f'Expected {v!r} at {self.peek().loc()}, found {self.peek().value!r}.')
    def need_op(self,v):
        if not self.op(v): raise ParserError(f'Expected operator {v!r} at {self.peek().loc()}.')
    def match(self,typ):
        if self.check(typ): self.advance(); return True
        return False
    def need(self,typ,msg):
        if self.check(typ): return self.advance()
        raise ParserError(f'{msg} Found {self.peek().value!r} at {self.peek().loc()}.')
    def check(self,typ): return self.peek().type==typ
    def advance(self):
        x=self.peek();
        if x.type!=TokenType.EOF: self.i+=1
        return x
    def peek(self): return self.t[self.i]
    def peek2(self): return self.t[min(self.i+1,len(self.t)-1)]
    def prev(self): return self.t[self.i-1]

class SemanticValidator:
    def validate(self,root:ProgramNode)->list[str]:
        warnings=[]
        for n in self.walk(root):
            if isinstance(n,ForRangeNode) and isinstance(n.step,LiteralNode) and n.step.value==0: raise SemanticError(f'FOR STEP cannot be zero at line {n.line}.')
        return warnings
    def walk(self,n):
        yield n
        for c in n.children(): yield from self.walk(c)

@dataclass
class AdjacencyList:
    root_id:str; nodes:dict[str,dict]=field(default_factory=dict); adjacency:dict[str,list[str]]=field(default_factory=dict)
    @classmethod
    def from_ast(cls,root):
        g=cls(root.node_id); g._walk(root); g.validate(); return g
    def _walk(self,n):
        self.nodes[n.node_id]={'kind':n.kind,'line':n.line,'attributes':n.attrs()}; cs=list(n.children()); self.adjacency[n.node_id]=[c.node_id for c in cs]
        for c in cs: self._walk(c)
    def validate(self):
        if self.root_id not in self.nodes: raise ValueError('Missing root node.')
        for a,bs in self.adjacency.items():
            if a not in self.nodes: raise ValueError(f'Missing source node {a}.')
            for b in bs:
                if b not in self.nodes: raise ValueError(f'Missing target node {b}.')
    def to_dict(self): return {'root_id':self.root_id,'nodes':self.nodes,'adjacency':self.adjacency}
    def to_json(self): return json.dumps(self.to_dict(),indent=2,default=str)
    def pretty(self): return '\n'.join(f"{n} ({self.nodes[n]['kind']}) -> {self.adjacency[n] or '[]'}" for n in self.adjacency)

@dataclass
class ParseResult:
    success:bool; ast:ProgramNode|None; adjacency_list:AdjacencyList|None; tokens:list[Token]; report:ProcessReport; error:str|None=None

class AJParserFacade:
    def __init__(self,lexer=None,validator=None): self.lexer=lexer or AJLexer(); self.validator=validator or SemanticValidator()
    def parse(self,source:str)->ParseResult:
        report=ProcessReport(); tokens=[]; ast=None; graph=None
        def stage(name,fn,success_message,**meta):
            start=time.perf_counter()
            try:
                value=fn(); details={k:f(value) for k,f in meta.items()}; report.add(name,StageStatus.SUCCESS,success_message,(time.perf_counter()-start)*1000,**details); return value,None
            except Exception as e:
                report.add(name,StageStatus.FAILURE,str(e),(time.perf_counter()-start)*1000); return None,e
        _,err=stage('INPUT_VALIDATION',lambda:self._validate(source),'Input accepted.',characters=lambda _:len(source))
        if err:return ParseResult(False,None,None,[],report,str(err))
        tokens,err=stage('LEXICAL_ANALYSIS',lambda:self.lexer.tokenise(source),'Source tokenised.',token_count=lambda x:len(x))
        if err:return ParseResult(False,None,None,[],report,str(err))
        ast,err=stage('SYNTAX_ANALYSIS',lambda:AJParser(tokens).parse(),'AST constructed.',top_level_nodes=lambda x:len(x.body))
        if err:return ParseResult(False,None,None,tokens,report,str(err))
        _,err=stage('STATIC_SEMANTIC_ANALYSIS',lambda:self.validator.validate(ast),'Static semantic analysis completed.',warning_count=lambda x:len(x))
        if err:return ParseResult(False,ast,None,tokens,report,str(err))
        graph,err=stage('ADJACENCY_LIST_GENERATION',lambda:AdjacencyList.from_ast(ast),'Adjacency list generated.',node_count=lambda x:len(x.nodes),edge_count=lambda x:sum(map(len,x.adjacency.values())))
        if err:return ParseResult(False,ast,None,tokens,report,str(err))
        report.add('PIPELINE_RESULT',StageStatus.SUCCESS,'All stages completed successfully.')
        return ParseResult(True,ast,graph,tokens,report)
    @staticmethod
    def _validate(source):
        if not isinstance(source,str): raise TypeError('Pseudocode must be text.')
        if not source.strip(): raise ValueError('Pseudocode cannot be empty.')
        return True
