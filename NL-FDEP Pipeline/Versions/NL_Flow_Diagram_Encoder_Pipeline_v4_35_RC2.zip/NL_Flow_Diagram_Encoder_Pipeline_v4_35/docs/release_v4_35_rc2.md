# NL-FDEP v4.35 Release Candidate 2

v4.35 RC2 advances packaged Common Tests to v1.3 / test-spec schema v1.4 and keeps experimental task-semantic scoring runtime-independent of the baseline benchmark.

Key properties:

- 50 suites / 113 retained cases; 75 frozen automated semantic cases.
- explicit static expected semantic values (`STATIC_FROZEN_VALUE`);
- no runtime baseline/reference/oracle execution for experimental expected values;
- declarative, algorithm-agnostic invocation adapters and result observers;
- valid function return values are first-class observations;
- neutral structured-object member aliases for declared tree/list fixtures;
- declared canonical equivalence for empty/not-found states;
- exact frozen matrix fixtures and expectations are internally consistent;
- safely derivable implementation arguments may be declared by the task contract;
- stack and queue state behaviour can be exercised by frozen operation sequences;
- human review remains integrated with the same semantic contract;
- no named model/vendor validation artefacts are distributed in the candidate.

## RC2 runner correction

RC2 removes a residual v4.34 assumption from the LLM-results folder selector. Experimental scoring in v4.35 is baseline-independent, so `baseline_root` is optional. The selector no longer attempts `Path(None)` when the LLM route is chosen without a baseline and instead proceeds directly to the experimental results-folder chooser. If an optional baseline path is available to a caller, it is used only as a folder-selection safety guard and never to generate experimental expected values.

The baseline-calibration route remains available as a separate validation operation. It is not invoked automatically for LLM scoring and is not used to produce experimental expected results.

This build remains a release candidate for cross-dataset stress testing and is not the final study freeze.
