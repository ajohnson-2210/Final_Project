import unittest

from aj_parser import AJParserFacade
from pseudocode_profiles import PseudocodeProfile, PseudocodeProfileProcessor


class GenericObviousMismatchTests(unittest.TestCase):
    def setUp(self):
        self.processor = PseudocodeProfileProcessor()

    def process(self, source):
        return self.processor.process(source, PseudocodeProfile.GENERIC_COMPATIBILITY)

    def test_raw_output_string_and_sort_characters_parse(self):
        source = """String1 <- INPUT(STRING(\"Enter String1\"))
String2 <- INPUT(STRING(\"Enter String2\"))
IF LENGTH OF String1 != LENGTH OF String2 THEN
    OUTPUT \"Not Anagrams\"
ELSE
    SORT characters of String1
    SORT characters of String2
    IF String1 == String2 THEN
        OUTPUT \"Anagrams\"
    ELSE
        OUTPUT \"Not Anagrams\"
    ENDIF
ENDIF
"""
        result = self.process(source)
        self.assertIn('OUTPUT STRING("Not Anagrams")', result.processed_source)
        self.assertIn('String1 <- CALL sort_characters(String1)', result.processed_source)
        parsed = AJParserFacade().parse(result.processed_source)
        self.assertTrue(parsed.success, parsed.error)

    def test_not_in_operator_parses(self):
        parsed = AJParserFacade().parse("FUNCTION f ACCEPTS(x, seen)\n    IF x NOT IN seen THEN\n        RETURN BOOLEAN(True)\n    ENDIF\n    RETURN BOOLEAN(False)\nENDFUNCTION\n")
        self.assertTrue(parsed.success, parsed.error)

    def test_swap_expands_to_assignments(self):
        result = self.process("SWAP left AND right\n")
        self.assertIn('_swap_temp <- left', result.processed_source)
        self.assertIn('left <- right', result.processed_source)


if __name__ == '__main__':
    unittest.main()
