"""Editable draw.io XML export for generated flow diagrams."""

from __future__ import annotations

from pathlib import Path
from xml.etree import ElementTree

from flow_diagram import FlowDiagram, FlowEdge, FlowNode
from flow_diagram_visualizer import FlowDiagramVisualizer


class DrawIOFlowExporter:
    """Exports a canonical flow diagram as an editable draw.io XML file."""

    NODE_WIDTH = FlowDiagramVisualizer.NODE_WIDTH
    NODE_HEIGHT = FlowDiagramVisualizer.NODE_HEIGHT
    DECISION_WIDTH = FlowDiagramVisualizer.DECISION_WIDTH
    DECISION_HEIGHT = FlowDiagramVisualizer.DECISION_HEIGHT

    DECISION_TYPES = FlowDiagramVisualizer.DECISION_TYPES
    INPUT_OUTPUT_TYPES = FlowDiagramVisualizer.INPUT_OUTPUT_TYPES
    TERMINATOR_TYPES = FlowDiagramVisualizer.TERMINATOR_TYPES
    SUBROUTINE_TYPES = FlowDiagramVisualizer.SUBROUTINE_TYPES

    def __init__(self) -> None:
        self.layout_engine = FlowDiagramVisualizer()

    def export(
        self,
        flow_diagram: FlowDiagram,
        output_path: str | Path,
    ) -> Path:
        """Write an editable draw.io file and return its absolute path."""

        destination = Path(output_path).resolve()
        positions = self.layout_engine._calculate_positions(flow_diagram)

        mxfile = ElementTree.Element(
            "mxfile",
            {
                "host": "app.diagrams.net",
                "modified": "2026-08-04T00:00:00.000Z",
                "agent": "NL to Flow Diagram Encoder Pipeline",
                "version": "24.7.17",
                "type": "device",
                "compressed": "false",
            },
        )
        diagram = ElementTree.SubElement(
            mxfile,
            "diagram",
            {
                "id": "generated-flow-diagram",
                "name": "Generated Flow Diagram",
            },
        )
        model = ElementTree.SubElement(
            diagram,
            "mxGraphModel",
            {
                "dx": "1200",
                "dy": "800",
                "grid": "1",
                "gridSize": "10",
                "guides": "1",
                "tooltips": "1",
                "connect": "1",
                "arrows": "1",
                "fold": "1",
                "page": "1",
                "pageScale": "1",
                "pageWidth": "1169",
                "pageHeight": "827",
                "math": "0",
                "shadow": "0",
            },
        )
        root = ElementTree.SubElement(model, "root")
        ElementTree.SubElement(root, "mxCell", {"id": "0"})
        ElementTree.SubElement(root, "mxCell", {"id": "1", "parent": "0"})

        for node_id, node in flow_diagram.nodes.items():
            self._append_node(root, node, positions[node_id])

        for index, edge in enumerate(flow_diagram.edges, start=1):
            self._append_edge(root, edge, index)

        ElementTree.indent(mxfile, space="  ")
        xml_document = ElementTree.tostring(
            mxfile,
            encoding="utf-8",
            xml_declaration=True,
        )
        destination.write_bytes(xml_document)

        return destination

    def _append_node(
        self,
        root: ElementTree.Element,
        node: FlowNode,
        position: tuple[float, float],
    ) -> None:
        x_position, y_position = position
        width, height = self._node_dimensions(node)
        style = self._node_style(node)

        cell = ElementTree.SubElement(
            root,
            "mxCell",
            {
                "id": node.node_id,
                "value": node.label,
                "style": style,
                "vertex": "1",
                "parent": "1",
            },
        )
        ElementTree.SubElement(
            cell,
            "mxGeometry",
            {
                "x": self._number(x_position),
                "y": self._number(y_position),
                "width": self._number(width),
                "height": self._number(height),
                "as": "geometry",
            },
        )

    def _append_edge(
        self,
        root: ElementTree.Element,
        edge: FlowEdge,
        index: int,
    ) -> None:
        visible_label = self._edge_label(edge.label)
        cell = ElementTree.SubElement(
            root,
            "mxCell",
            {
                "id": f"E{index}",
                "value": visible_label,
                "style": (
                    "edgeStyle=orthogonalEdgeStyle;rounded=0;orthogonalLoop=1;"
                    "jettySize=auto;html=1;endArrow=block;endFill=1;"
                ),
                "edge": "1",
                "parent": "1",
                "source": edge.source,
                "target": edge.target,
            },
        )
        ElementTree.SubElement(
            cell,
            "mxGeometry",
            {
                "relative": "1",
                "as": "geometry",
            },
        )

    def _node_dimensions(self, node: FlowNode) -> tuple[float, float]:
        if node.node_type in self.DECISION_TYPES:
            return self.DECISION_WIDTH, self.DECISION_HEIGHT

        return self.NODE_WIDTH, self.NODE_HEIGHT

    def _node_style(self, node: FlowNode) -> str:
        common = "whiteSpace=wrap;html=1;align=center;verticalAlign=middle;"

        if node.node_type in self.TERMINATOR_TYPES:
            return common + "rounded=1;arcSize=50;"

        if node.node_type in self.DECISION_TYPES:
            return common + "rhombus;perimeter=rhombusPerimeter;"

        if node.node_type in self.INPUT_OUTPUT_TYPES:
            return common + "shape=parallelogram;perimeter=parallelogramPerimeter;"

        if node.node_type in self.SUBROUTINE_TYPES:
            return common + "shape=process;"

        return common + "rounded=0;"

    def _edge_label(self, label: str) -> str:
        normalised = label.strip().upper()

        if normalised == "TRUE":
            return "Yes"

        if normalised == "FALSE":
            return "No"

        if normalised in {"NEXT", ""}:
            return ""

        if normalised == "LOOP":
            return "Repeat"

        return label.title()

    def _number(self, value: float) -> str:
        rounded = round(value, 3)

        if rounded.is_integer():
            return str(int(rounded))

        return str(rounded)
