"""Controlled draw.io import for the NL Flow Diagram Encoder Pipeline.

The importer deliberately accepts a constrained convention. Executable draw.io
shapes contain AJ_24038155 Dialect statements. The importer reconstructs a
continuous AJ pseudocode program, which is then passed through the existing
lexer, recursive parser, AST encoder and Python compiler.
"""

from __future__ import annotations

from dataclasses import dataclass
from html import unescape
from pathlib import Path
from urllib.parse import unquote
import base64
import re
import xml.etree.ElementTree as ElementTree
import zlib


class DrawIOImportError(ValueError):
    """Raised when a draw.io document does not satisfy the controlled convention."""


@dataclass
class DrawIOShape:
    """Represents one executable or structural draw.io vertex."""

    shape_id: str
    label: str
    style: str
    x: float
    y: float


@dataclass
class DrawIOConnector:
    """Represents one directed draw.io connector."""

    source: str
    target: str
    label: str


@dataclass
class DrawIOImportResult:
    """Contains the AJ source reconstructed from a draw.io file."""

    pseudocode: str
    shape_count: int
    connector_count: int
    ordered_shape_ids: list[str]


class DrawIOFlowImporter:
    """Imports constrained draw.io diagrams as AJ pseudocode.

    Version 1 supports a single linear executable path:

    Start -> AJ statement -> AJ statement -> End

    Labels may be written directly as AJ statements or prefixed with ``AJ:``.
    Start and End labels are structural and are not emitted as pseudocode.
    """

    START_LABELS = {"START", "BEGIN"}
    END_LABELS = {"END", "STOP", "FINISH"}

    def import_file(self, input_path: Path) -> DrawIOImportResult:
        """Reads and validates a draw.io or draw.io SVG source file."""

        if not input_path.exists():
            raise FileNotFoundError(f"Flow diagram file not found: {input_path.resolve()}")

        source_text = input_path.read_text(encoding="utf-8")
        graph_root = self._extract_graph_model(source_text)
        shapes, connectors = self._read_graph(graph_root)
        ordered_ids = self._validate_and_order(shapes, connectors)
        pseudocode_lines = self._build_pseudocode(ordered_ids, shapes)

        return DrawIOImportResult(
            pseudocode="\n".join(pseudocode_lines),
            shape_count=len(shapes),
            connector_count=len(connectors),
            ordered_shape_ids=ordered_ids,
        )

    def _extract_graph_model(self, source_text: str) -> ElementTree.Element:
        """Returns an mxGraphModel from plain or compressed draw.io XML."""

        try:
            root = ElementTree.fromstring(source_text)
        except ElementTree.ParseError as error:
            raise DrawIOImportError(f"The selected file is not valid XML: {error}") from error

        graph_model = self._find_graph_model(root)

        if graph_model is not None:
            return graph_model

        diagram = root.find(".//diagram")

        if diagram is not None and diagram.text:
            decoded_xml = self._decode_diagram_text(diagram.text.strip())

            try:
                decoded_root = ElementTree.fromstring(decoded_xml)
            except ElementTree.ParseError as error:
                raise DrawIOImportError(
                    "The compressed draw.io diagram could not be decoded."
                ) from error

            graph_model = self._find_graph_model(decoded_root)

            if graph_model is not None:
                return graph_model

        embedded_xml = self._extract_embedded_drawio_xml(source_text)

        if embedded_xml is not None:
            return self._extract_graph_model(embedded_xml)

        raise DrawIOImportError("No mxGraphModel was found in the selected draw.io file.")

    @staticmethod
    def _find_graph_model(root: ElementTree.Element) -> ElementTree.Element | None:
        if root.tag.endswith("mxGraphModel"):
            return root

        for element in root.iter():
            if element.tag.endswith("mxGraphModel"):
                return element

        return None

    @staticmethod
    def _decode_diagram_text(encoded_text: str) -> str:
        compressed_bytes = base64.b64decode(encoded_text)
        decompressed_bytes = zlib.decompress(compressed_bytes, -15)
        return unquote(decompressed_bytes.decode("utf-8"))

    @staticmethod
    def _extract_embedded_drawio_xml(source_text: str) -> str | None:
        patterns = [
            r"content=\"([^\"]*%3Cmxfile[^\"]+)\"",
            r"data-mxgraph=\"([^\"]+)\"",
        ]

        for pattern in patterns:
            match = re.search(pattern, source_text, flags=re.IGNORECASE)

            if match is not None:
                candidate = unescape(match.group(1))
                candidate = unquote(candidate)

                if "<mxfile" in candidate or "<mxGraphModel" in candidate:
                    return candidate

        return None

    def _read_graph(
        self,
        graph_model: ElementTree.Element,
    ) -> tuple[dict[str, DrawIOShape], list[DrawIOConnector]]:
        shapes: dict[str, DrawIOShape] = {}
        connectors: list[DrawIOConnector] = []

        for cell in graph_model.iter():
            if not cell.tag.endswith("mxCell"):
                continue

            cell_id = cell.get("id")

            if not cell_id:
                continue

            if cell.get("vertex") == "1":
                label = self._clean_label(cell.get("value", ""))
                style = cell.get("style", "")
                x, y = self._read_geometry(cell)
                shapes[cell_id] = DrawIOShape(cell_id, label, style, x, y)

            if cell.get("edge") == "1":
                source = cell.get("source")
                target = cell.get("target")

                if source and target:
                    connectors.append(
                        DrawIOConnector(
                            source=source,
                            target=target,
                            label=self._clean_label(cell.get("value", "")),
                        )
                    )

        if not shapes:
            raise DrawIOImportError("The draw.io file contains no flowchart shapes.")

        return shapes, connectors

    @staticmethod
    def _read_geometry(cell: ElementTree.Element) -> tuple[float, float]:
        for child in cell:
            if child.tag.endswith("mxGeometry"):
                return float(child.get("x", 0)), float(child.get("y", 0))

        return 0.0, 0.0

    @staticmethod
    def _clean_label(raw_label: str) -> str:
        label = unescape(raw_label)
        label = re.sub(r"<br\s*/?>", "\n", label, flags=re.IGNORECASE)
        label = re.sub(r"<[^>]+>", "", label)
        label = label.replace("&nbsp;", " ")
        return label.strip()

    def _validate_and_order(
        self,
        shapes: dict[str, DrawIOShape],
        connectors: list[DrawIOConnector],
    ) -> list[str]:
        outgoing: dict[str, list[str]] = {shape_id: [] for shape_id in shapes}
        incoming: dict[str, list[str]] = {shape_id: [] for shape_id in shapes}

        for connector in connectors:
            if connector.source not in shapes or connector.target not in shapes:
                continue

            outgoing[connector.source].append(connector.target)
            incoming[connector.target].append(connector.source)

        start_ids = [
            shape_id
            for shape_id, shape in shapes.items()
            if self._is_start(shape) or not incoming[shape_id]
        ]
        end_ids = [
            shape_id
            for shape_id, shape in shapes.items()
            if self._is_end(shape) or not outgoing[shape_id]
        ]

        start_ids = list(dict.fromkeys(start_ids))
        end_ids = list(dict.fromkeys(end_ids))

        if len(start_ids) != 1:
            raise DrawIOImportError(
                "Controlled draw.io import requires exactly one Start shape."
            )

        if len(end_ids) != 1:
            raise DrawIOImportError(
                "Controlled draw.io import requires exactly one End shape."
            )

        for shape_id in shapes:
            if shape_id == end_ids[0]:
                continue

            if len(outgoing[shape_id]) != 1:
                raise DrawIOImportError(
                    "Version 1 draw.io import supports one linear outgoing path per shape."
                )

        ordered_ids: list[str] = []
        visited: set[str] = set()
        current_id = start_ids[0]

        while True:
            if current_id in visited:
                raise DrawIOImportError(
                    "Version 1 draw.io import does not support loops or cycles."
                )

            visited.add(current_id)
            ordered_ids.append(current_id)

            if current_id == end_ids[0]:
                break

            current_id = outgoing[current_id][0]

        disconnected = set(shapes).difference(visited)

        if disconnected:
            raise DrawIOImportError(
                "The diagram contains disconnected executable shapes: "
                + ", ".join(sorted(disconnected))
            )

        return ordered_ids

    def _build_pseudocode(
        self,
        ordered_ids: list[str],
        shapes: dict[str, DrawIOShape],
    ) -> list[str]:
        pseudocode_lines: list[str] = []

        for shape_id in ordered_ids:
            shape = shapes[shape_id]

            if self._is_start(shape) or self._is_end(shape):
                continue

            statement = shape.label

            if statement.upper().startswith("AJ:"):
                statement = statement[3:].strip()

            if not statement:
                raise DrawIOImportError(
                    f"Executable shape {shape_id} has no AJ statement label."
                )

            statement_lines = [line.strip() for line in statement.splitlines() if line.strip()]
            pseudocode_lines.extend(statement_lines)

        if not pseudocode_lines:
            raise DrawIOImportError("The flow diagram contains no executable AJ statements.")

        return pseudocode_lines

    def _is_start(self, shape: DrawIOShape) -> bool:
        return shape.label.upper() in self.START_LABELS

    def _is_end(self, shape: DrawIOShape) -> bool:
        return shape.label.upper() in self.END_LABELS
