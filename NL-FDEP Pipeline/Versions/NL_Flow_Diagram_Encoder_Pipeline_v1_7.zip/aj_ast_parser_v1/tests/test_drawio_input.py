import tempfile
import unittest
from pathlib import Path

from aj_test_harness import TestCase
from drawio_importer import DrawIOFlowImporter, DrawIOImportError
from flow_input_pipeline import DrawIOFlowInputPipeline


VALID_DRAWIO = """<?xml version="1.0" encoding="UTF-8"?>
<mxfile>
  <diagram>
    <mxGraphModel>
      <root>
        <mxCell id="0"/>
        <mxCell id="1" parent="0"/>
        <mxCell id="start" value="Start" vertex="1" parent="1">
          <mxGeometry x="100" y="20" width="120" height="50" as="geometry"/>
        </mxCell>
        <mxCell id="assign" value="AJ: total &lt;- INTEGER(0)" vertex="1" parent="1">
          <mxGeometry x="100" y="100" width="180" height="60" as="geometry"/>
        </mxCell>
        <mxCell id="output" value="AJ: OUTPUT total" vertex="1" parent="1">
          <mxGeometry x="100" y="190" width="180" height="60" as="geometry"/>
        </mxCell>
        <mxCell id="end" value="End" vertex="1" parent="1">
          <mxGeometry x="100" y="280" width="120" height="50" as="geometry"/>
        </mxCell>
        <mxCell id="e1" edge="1" source="start" target="assign" parent="1"/>
        <mxCell id="e2" edge="1" source="assign" target="output" parent="1"/>
        <mxCell id="e3" edge="1" source="output" target="end" parent="1"/>
      </root>
    </mxGraphModel>
  </diagram>
</mxfile>
"""


class DrawIOInputTests(unittest.TestCase):

    def test_drawio_import_reconstructs_aj_pseudocode(self):
        with tempfile.TemporaryDirectory() as directory:
            input_path = Path(directory) / "linear.drawio"
            input_path.write_text(VALID_DRAWIO, encoding="utf-8")
            result = DrawIOFlowImporter().import_file(input_path)

        self.assertEqual(result.pseudocode, "total <- INTEGER(0)\nOUTPUT total")

    def test_drawio_route_generates_and_executes_python(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            input_path = root / "linear.drawio"
            input_path.write_text(VALID_DRAWIO, encoding="utf-8")
            result = DrawIOFlowInputPipeline().run(
                input_path=input_path,
                output_directory=root / "output",
                test_cases=[TestCase("Draw.io total", expected_output=["0"])],
                open_visualisations=False,
            )

            generated_source = Path(
                result.output_files["generated_python"]
            ).read_text(encoding="utf-8")

        self.assertTrue(result.success, result.to_json())
        self.assertIn("total = 0", generated_source)
        self.assertIn("print(total)", generated_source)
        self.assertEqual(result.stages[0].name, "DRAWIO_IMPORT")

    def test_branching_diagram_fails_explicitly_in_version_one(self):
        branching = VALID_DRAWIO.replace(
            '<mxCell id="e2" edge="1" source="assign" target="output" parent="1"/>',
            '<mxCell id="e2" edge="1" source="assign" target="output" parent="1"/>'
            '<mxCell id="e4" edge="1" source="assign" target="end" parent="1"/>',
        )

        with tempfile.TemporaryDirectory() as directory:
            input_path = Path(directory) / "branch.drawio"
            input_path.write_text(branching, encoding="utf-8")

            with self.assertRaises(DrawIOImportError):
                DrawIOFlowImporter().import_file(input_path)


if __name__ == "__main__":
    unittest.main()
