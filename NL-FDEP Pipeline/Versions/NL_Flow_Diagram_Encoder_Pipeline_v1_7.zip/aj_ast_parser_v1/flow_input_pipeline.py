"""Second controlled input route for draw.io flow diagrams."""

from __future__ import annotations

from pathlib import Path
import time

from aj_test_harness import TestCase
from drawio_importer import DrawIOFlowImporter
from nl_flow_pipeline import NLFlowDiagramEncoderPipeline, PipelineResult, PipelineStage


class DrawIOFlowInputPipeline:
    """Imports a draw.io file and then reuses the canonical AJ pipeline."""

    def __init__(self) -> None:
        self.importer = DrawIOFlowImporter()
        self.canonical_pipeline = NLFlowDiagramEncoderPipeline()

    def run(
        self,
        input_path: Path,
        output_directory: Path,
        test_cases: list[TestCase],
        open_visualisations: bool = False,
    ) -> PipelineResult:
        import_started = time.perf_counter()

        try:
            import_result = self.importer.import_file(input_path)
        except Exception as error:
            return PipelineResult(
                success=False,
                stages=[
                    PipelineStage(
                        name="DRAWIO_IMPORT",
                        status="FAILURE",
                        message=str(error),
                        duration_ms=round(
                            (time.perf_counter() - import_started) * 1000,
                            3,
                        ),
                    )
                ],
                output_files={},
                error=str(error),
            )

        output_directory.mkdir(parents=True, exist_ok=True)
        imported_source_path = output_directory / "imported_flow_pseudocode.aj"
        imported_source_path.write_text(import_result.pseudocode, encoding="utf-8")

        result = self.canonical_pipeline.run(
            pseudocode=import_result.pseudocode,
            output_directory=output_directory,
            test_cases=test_cases,
            open_visualisations=open_visualisations,
        )

        import_stage = PipelineStage(
            name="DRAWIO_IMPORT",
            status="SUCCESS",
            message=(
                f"Imported {import_result.shape_count} shapes and "
                f"{import_result.connector_count} connectors."
            ),
            duration_ms=round(
                (time.perf_counter() - import_started) * 1000,
                3,
            ),
        )

        result.stages.insert(0, import_stage)
        result.output_files["imported_pseudocode"] = str(
            imported_source_path.resolve()
        )

        pipeline_report_path = output_directory / "pipeline_report.json"
        pipeline_report_path.write_text(result.to_json(), encoding="utf-8")

        return result
