# NL to Flow Diagram Encoder Pipeline v1.3

A dependency-free, object-oriented Python pipeline for AJ_24038155 Dialect v1.0.
The only external program input is AJ pseudocode.

## Pipeline

1. AJ pseudocode input
2. Lexical analysis
3. Recursive-descent parsing
4. AST construction
5. Static semantic validation
6. Machine-readable flow-diagram encoding
7. Interactive AST and flow-diagram visualisation
8. Deterministic Python compilation from `flow_diagram.json`
9. Subprocess-based behavioural testing
10. JSON reporting

## PyCharm

Open `pycharm_runner.py` and press **Run**. Configure these constants at the top
of the file when required:

- `INPUT_FILE`
- `OUTPUT_DIRECTORY`
- `OPEN_VISUALISATIONS`
- `TEST_CASES`

## Outputs

The runner creates:

- `output/ast.json`
- `output/parser_report.json`
- `output/ast_visualisation.html`
- `output/flow_diagram.json`
- `output/flow_diagram.html`
- `output/generated_program.py`
- `output/compilation_report.json`
- `output/test_report.json`
- `output/pipeline_report.json`

## Important design boundary

The AST is an internal intermediate representation. It is generated from
pseudocode and is not accepted as an external pipeline input. The compiler
accepts the machine-readable flow-diagram document produced by the encoder.

## Flow-diagram display

The generated flowchart opens at a readable 115% scale and is centred on the
first program steps. Use **Fit diagram** to display the complete program at once.
Zoom and pan remain available.

## Compilation assurance tests

The integration tests verify that:

- the saved `flow_diagram.json` document is accepted directly by the compiler;
- the compiler produces the exact expected reference Python source;
- the compiled program executes and produces the expected output;
- the visualisation contains the readable initial-view configuration.

Run all tests with:

```bash
python -m unittest discover -s tests -v
```

## Second controlled input route: draw.io

Version 1.5 adds an optional draw.io route while preserving pseudocode as the
primary route.

Configure `pycharm_runner.py` with:

```python
INPUT_ROUTE = "DRAWIO"
SELECT_FILE_WHEN_RUNNING = True
```

The runner displays a native file chooser. The controlled version 1 convention
is deliberately limited to a single linear path:

```text
Start -> AJ statement -> AJ statement -> End
```

Each executable process or input/output shape must contain one valid AJ Dialect
statement, either directly or with an `AJ:` prefix, for example:

```text
AJ: total <- INTEGER(0)
AJ: OUTPUT STRING("Total is {total}")
```

The importer reconstructs AJ pseudocode and then reuses the existing trusted
route:

```text
draw.io -> AJ pseudocode -> AST -> canonical flow JSON -> Python -> tests
```

Branching and looped draw.io imports intentionally fail with explicit diagnostics
in this first controlled version. The existing pseudocode route continues to
support the full parser grammar.

## Interactive input selection in PyCharm

Run `pycharm_runner.py` without editing an input-route flag.

The application first asks:

```text
What would you like to import?

[Pseudocode file]
[Flow diagram file]
```

After the selection, a native file chooser opens with the matching filters:

- Pseudocode: `.aj` or `.txt`
- Controlled flow diagram: `.drawio`, `.xml` or `.svg`

Closing either dialog cancels the run cleanly.

## Pseudocode processing profiles

When **Pseudocode file** is selected in `pycharm_runner.py`, the application now
asks how the source should be processed:

1. **AJ Dialect — strict** performs only non-semantic cleanup such as removing a
   surrounding Markdown fence, normalising line endings, removing trailing
   whitespace and converting `←` to `<-`.
2. **Generic — convert compatible syntax** recognises a controlled subset of
   generic structured pseudocode and converts forms such as `SET x TO value`,
   `PRINT value`, `END IF`, `END WHILE`, `NEXT`, assignment `=`, `MOD` and `DIV`
   into AJ_24038155 Dialect syntax.
3. **General — parse without conversion** passes the supplied text to the
   existing lexer and parser exactly as read from the file. It does not repair,
   normalise or rewrite the source.

Every pseudocode run writes:

- `processed_pseudocode.aj`
- `pseudocode_processing_report.json`

The report records the selected profile, whether the source changed, and every
individual transformation. The selected profile is also included in
`pipeline_report.json` under `input_metadata`.
