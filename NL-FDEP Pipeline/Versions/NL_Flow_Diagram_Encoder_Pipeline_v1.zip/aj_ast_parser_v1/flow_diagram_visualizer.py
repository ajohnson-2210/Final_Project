"""Dependency-free HTML visualisation for machine-readable flow diagrams."""

from __future__ import annotations

from pathlib import Path
import html
import json
import webbrowser

from flow_diagram import FlowDiagram


class FlowDiagramVisualizer:
    """Creates a readable interactive HTML representation of a flow diagram."""

    def generate(
        self,
        flow_diagram: FlowDiagram,
        output_path: str | Path,
        open_browser: bool = False,
    ) -> Path:
        destination = Path(output_path).resolve()
        diagram_json = json.dumps(flow_diagram.to_dict())
        node_rows = []

        for node_id, node in flow_diagram.nodes.items():
            node_rows.append(
                "<div class='node' data-node-id='{}'>"
                "<strong>{}</strong><span>{}</span>"
                "<small>Line {} · {}</small></div>".format(
                    html.escape(node_id),
                    html.escape(node.label),
                    html.escape(node.node_type),
                    node.line,
                    html.escape(node_id),
                )
            )

        document = f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>NL-FDEP Flow Diagram</title>
<style>
body {{ font-family: Arial, sans-serif; margin: 0; background: #f5f6f8; color: #202124; }}
header {{ padding: 20px; background: white; border-bottom: 1px solid #d9dce1; position: sticky; top: 0; }}
main {{ max-width: 900px; margin: 0 auto; padding: 24px; }}
.controls {{ display: flex; gap: 10px; margin-top: 12px; }}
input {{ flex: 1; padding: 10px; border: 1px solid #aeb4bd; border-radius: 6px; }}
.node {{ background: white; border: 2px solid #697386; border-radius: 10px; padding: 14px; margin: 12px 0; display: grid; gap: 5px; }}
.node strong {{ font-size: 17px; }}
.node span {{ font-size: 13px; text-transform: uppercase; letter-spacing: .08em; }}
.node small {{ color: #5f6368; }}
.node.match {{ outline: 4px solid #f4c542; }}
.edge {{ margin-left: 28px; color: #5f6368; }}
pre {{ white-space: pre-wrap; background: #111827; color: #e5e7eb; padding: 16px; border-radius: 8px; }}
</style>
</head>
<body>
<header>
<h1>NL to Flow Diagram Encoder Pipeline</h1>
<p>Machine-readable flow diagram generated from AJ pseudocode.</p>
<div class="controls"><input id="search" placeholder="Search node label or type"></div>
</header>
<main>
<section id="nodes">{''.join(node_rows)}</section>
<h2>Edges</h2>
<pre id="edges"></pre>
</main>
<script>
const diagram = {diagram_json};
const edgeLines = diagram.edges.map(edge => `${{edge.source}} --${{edge.label}}--> ${{edge.target}}`);
document.getElementById('edges').textContent = edgeLines.join('\n');
document.getElementById('search').addEventListener('input', event => {{
    const query = event.target.value.toLowerCase();
    document.querySelectorAll('.node').forEach(node => {{
        node.classList.toggle('match', query.length > 0 && node.textContent.toLowerCase().includes(query));
    }});
}});
</script>
</body>
</html>"""

        destination.write_text(document, encoding="utf-8")

        if open_browser:
            webbrowser.open(destination.as_uri())

        return destination
