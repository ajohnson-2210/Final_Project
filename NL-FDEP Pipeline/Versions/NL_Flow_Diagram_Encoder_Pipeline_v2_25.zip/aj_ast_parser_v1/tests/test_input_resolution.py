import unittest

from input_resolution import score_input_resolution


class InputResolutionTests(unittest.TestCase):
    def test_list_semantics_can_be_high_confidence_while_encoding_is_insufficient(self):
        source = """IP_List <- INPUT(STRING("Enter IP_List"))
FOR EACH IP IN IP_List DO
    OUTPUT IP
ENDFOR
"""
        result = score_input_resolution(source, "IP_List")
        self.assertEqual(result.semantic_type, "LIST")
        self.assertEqual(result.semantic_confidence, "high")
        self.assertEqual(result.encoding_confidence, "insufficient")
        self.assertEqual(result.resolution, "PROMOTE_TO_PARAMETER")
        self.assertIsNone(result.encoding)

    def test_tuple_semantics_do_not_invent_delimiter(self):
        source = """Coordinates <- INPUT(STRING("Enter Coordinates"))
x <- Coordinates[0]
y <- Coordinates[1]
RETURN TUPLE(x, y)
"""
        result = score_input_resolution(source, "Coordinates")
        self.assertEqual(result.semantic_type, "TUPLE")
        self.assertEqual(result.encoding_confidence, "insufficient")
        self.assertIsNone(result.encoding)


if __name__ == "__main__":
    unittest.main()
