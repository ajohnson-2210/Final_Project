"""Integrated human-review session and lightweight Tk dashboard."""
from __future__ import annotations
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
import json

from adjudication import adjudicate_files

class ReviewSession:
    def __init__(self, scoring_directory: Path):
        self.scoring_directory=Path(scoring_directory)
        q=self.scoring_directory/'human_review_questionnaire.json'
        if not q.is_file(): raise FileNotFoundError(q)
        self.document=json.loads(q.read_text(encoding='utf-8'))
    def save(self, *, reviewer_id: str, confidence: str|None, gate_result: str|None, gate_agreement: str|None,
             gate_justification: str, criteria: dict[str,dict[str,Any]], overall: dict[str,Any], baseline_reference_appropriate: str|None=None,
             baseline_reference_justification: str='') -> Path:
        out=deepcopy(self.document); out['reviewer']={'reviewer_id':reviewer_id,'reviewed_at_utc':datetime.now(timezone.utc).isoformat(),'overall_reviewer_confidence':confidence}
        ss=out['source_sufficiency']; ss['human_result']=gate_result; ss['agreement_with_automated_result']=gate_agreement; ss['reviewer_justification']=gate_justification
        for item in out.get('criteria',[]):
            cid=item.get('criterion_id'); values=criteria.get(cid,{})
            ha=item.setdefault('human_assessment',{}); ha.update(values); ha['completed']=values.get('score_label') is not None
        out['overall_review'].update(overall)
        if out.get('benchmark_validation') is not None:
            out['benchmark_validation']['human_reference_appropriate']=baseline_reference_appropriate
            out['benchmark_validation']['reviewer_justification']=baseline_reference_justification
        path=self.scoring_directory/'human_review.json'; path.write_text(json.dumps(out,indent=2),encoding='utf-8')
        adjudicate_files(self.scoring_directory); return path


def review_status(parent: Path) -> list[dict[str,Any]]:
    rows=[]
    for sd in sorted(Path(parent).glob('Algorithm - */pipeline_artifacts/scoring')):
        try: aid=int(sd.parents[1].name.split('-')[-1].strip())
        except Exception: aid=None
        rows.append({'algorithm_id':aid,'scoring_directory':str(sd.resolve()),'questionnaire':(sd/'human_review_questionnaire.json').exists(),
                     'reviewed':(sd/'human_review.json').exists(),'final_score':(sd/'final_score.json').exists()})
    return rows


def launch_review_dashboard(parent: Path) -> None:
    import tkinter as tk
    from tkinter import messagebox, ttk
    parent=Path(parent); rows=review_status(parent)
    root=tk.Tk(); root.title('NL-FDEP Human Review'); root.geometry('1050x760')
    left=tk.Frame(root); left.pack(side='left',fill='y',padx=8,pady=8); right=tk.Frame(root); right.pack(side='right',fill='both',expand=True,padx=8,pady=8)
    lb=tk.Listbox(left,width=28,height=35); lb.pack(fill='y',expand=True)
    for r in rows: lb.insert('end',f"Algorithm {r['algorithm_id']}  {'✓' if r['reviewed'] else 'Pending'}")
    state={'session':None,'items':[],'index':0}
    title=tk.Label(right,text='Select an algorithm',font=('Arial',14,'bold')); title.pack(anchor='w')
    question=tk.Message(right,text='',width=740,font=('Arial',11)); question.pack(anchor='w',pady=8)
    auto=tk.Message(right,text='',width=740); auto.pack(anchor='w',pady=4)
    score_var=tk.StringVar(value=''); agree_var=tk.StringVar(value=''); semantic_var=tk.StringVar(value='')
    rowf=tk.Frame(right); rowf.pack(anchor='w',pady=6)
    for v,t in [('2','2'),('1','1'),('0','0'),('NA','N/A')]: tk.Radiobutton(rowf,text=t,variable=score_var,value=v).pack(side='left')
    ttk.Combobox(right,textvariable=agree_var,values=['AGREE','PARTIALLY_AGREE','DISAGREE'],state='readonly').pack(anchor='w')
    ttk.Combobox(right,textvariable=semantic_var,values=['false','true'],state='readonly').pack(anchor='w',pady=4)
    notes=tk.Text(right,height=8,width=88); notes.pack(fill='x',pady=6)
    reviewer=tk.Entry(right); reviewer.insert(0,'REVIEWER_01'); reviewer.pack(anchor='w',pady=4)
    confidence=ttk.Combobox(right,values=['HIGH','MODERATE','LOW'],state='readonly'); confidence.set('HIGH'); confidence.pack(anchor='w')
    collected={}
    def load_item():
        if not state['items']: return
        item=state['items'][state['index']]; title.config(text=f"{item.get('criterion_id')}  ({state['index']+1}/{len(state['items'])})")
        question.config(text=item.get('question','')); auto.config(text=f"Automated: {item.get('automated_score')} / 2 — {item.get('automated_status')}\n{item.get('automated_justification','')}")
        prev=collected.get(item.get('criterion_id'),{}); score_var.set(prev.get('score_label','')); agree_var.set(prev.get('agreement_with_automated_score','')); semantic_var.set('true' if prev.get('semantic_issue') is True else ('false' if prev.get('semantic_issue') is False else '')); notes.delete('1.0','end'); notes.insert('1.0',prev.get('reviewer_justification',''))
    def capture():
        if not state['items']: return
        cid=state['items'][state['index']].get('criterion_id'); raw=score_var.get() or None
        collected[cid]={'score':None if raw in {None,'NA'} else int(raw),'score_label':raw,'agreement_with_automated_score':agree_var.get() or None,'semantic_issue':True if semantic_var.get()=='true' else (False if semantic_var.get()=='false' else None),'reviewer_justification':notes.get('1.0','end').strip()}
    def select(_=None):
        if not lb.curselection(): return
        r=rows[lb.curselection()[0]]; state['session']=ReviewSession(Path(r['scoring_directory'])); state['items']=state['session'].document.get('criteria',[]); state['index']=0; collected.clear(); load_item()
    def move(delta): capture(); state['index']=max(0,min(len(state['items'])-1,state['index']+delta)); load_item()
    def save():
        if not state['session']: return
        capture(); doc=state['session'].document
        try:
            state['session'].save(reviewer_id=reviewer.get().strip() or 'REVIEWER_01',confidence=confidence.get() or None,
                gate_result=doc.get('source_sufficiency',{}).get('automated_result'),gate_agreement='AGREE',gate_justification='',criteria=collected,
                overall={'material_semantic_error_not_captured':False,'first_semantic_loss_stage':None,'final_python_behaviourally_faithful':None,'additional_observations':''},
                baseline_reference_appropriate=None)
            messagebox.showinfo('Saved','human_review.json and final_score.json updated.')
        except Exception as e: messagebox.showerror('Review save failed',str(e))
    lb.bind('<<ListboxSelect>>',select)
    nav=tk.Frame(right); nav.pack(anchor='w',pady=8); tk.Button(nav,text='Previous',command=lambda:move(-1)).pack(side='left'); tk.Button(nav,text='Next',command=lambda:move(1)).pack(side='left',padx=6); tk.Button(nav,text='Save review',command=save).pack(side='left',padx=12)
    root.mainloop()
