# Postfix statement-boundary correction — v2.77

## Scope

The generic statement-boundary normaliser previously treated any physical line ending in `+` or `-` as an arithmetic expression continuation. Because postfix pseudocode increments/decrements end in `++` / `--`, a complete statement such as `i++, j++` could incorrectly absorb the following `ELSE`, `RETURN`, or other source line.

## Correction

The existing GC126 expression-continuation rule now explicitly excludes physical lines ending in postfix `++` or `--`. No new algorithmic operation is introduced. Existing operator and grammar normalisers then perform the already-supported transformations:

- `i++` -> `i <- i + 1`
- comma-separated explicit assignments -> separate AJ statements
- `ELSE IF condition THEN statement` -> branch header plus explicit body
- `ELSE statement` -> branch header plus explicit body

True dangling arithmetic expressions such as `total <- a +` followed by the continuation operand are still joined by GC126. Commas nested inside call arguments are unaffected.

## Audited effects

The correction resolves the structural boundary failure in Claude Sonnet 4.6 Algorithm 4 (intersection of two sorted arrays). The same general correction also allows Claude Algorithm 18 (character frequency count) to retain its explicit inline `freq[char]++` branch without absorbing the following `ELSE`.

This is representational recovery only; no algorithmic reconstruction or semantic inference is performed.
