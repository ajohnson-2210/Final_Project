import unittest

from aj_parser import AJParserFacade
from aj_python_compiler import AJPythonCompiler
from flow_diagram import FlowDiagramEncoder
from pseudocode_profiles import GenericPseudocodeProcessor


class ClaudeAlgorithm4StructuralIntegrityTests(unittest.TestCase):
    def setUp(self):
        self.processor = GenericPseudocodeProcessor()

    def test_postfix_increment_line_does_not_absorb_following_branch_lines(self):
        source = '''FUNCTION intersection(A, B):
    result ← []
    i ← 0, j ← 0
    WHILE i < length(A) AND j < length(B):
        IF A[i] == B[j] THEN
            APPEND A[i] TO result
            i++, j++
        ELSE IF A[i] < B[j] THEN i++
        ELSE j++
    RETURN result
'''
        result = self.processor.process(source)
        expected = '''FUNCTION intersection ACCEPTS(A, B)
    result <- EMPTY LIST
    i <- 0
    j <- 0
    WHILE i < LENGTH OF A AND j < LENGTH OF B DO
        IF A[i] == B[j] THEN
            APPEND A[i] TO result
            i <- i + 1
            j <- j + 1
        ELSE IF A[i] < B[j] THEN
            i <- i + 1
        ELSE
            j <- j + 1
        ENDIF
    ENDWHILE
    RETURN result
ENDFUNCTION'''
        self.assertEqual(result.processed_source, expected)
        self.assertFalse(any(t.rule == 'GC126' and 'i++' in t.source for t in result.transformations))

        parsed = AJParserFacade().parse(result.processed_source)
        self.assertTrue(parsed.success, parsed.error)
        flow = FlowDiagramEncoder().encode(parsed.ast)
        compiled = AJPythonCompiler().compile(flow)
        self.assertIn('while ((i < len(A)) and (j < len(B))):', compiled.source_code)
        self.assertIn('i = (i + 1)', compiled.source_code)
        self.assertIn('j = (j + 1)', compiled.source_code)
        self.assertIn('elif (A[i] < B[j]):', compiled.source_code)
        self.assertIn('return result', compiled.source_code)


    def test_same_postfix_boundary_rule_preserves_inline_frequency_branch(self):
        source = """FUNCTION charFrequency(str):
    freq ← empty dictionary
    FOR each char IN str:
        IF char IN freq THEN freq[char]++
        ELSE freq[char] ← 1
    RETURN freq
"""
        result = self.processor.process(source)
        self.assertIn('IF __reserved_keyword__char IN freq THEN', result.processed_source)
        self.assertIn('freq[__reserved_keyword__char] <- freq[__reserved_keyword__char] + 1', result.processed_source)
        self.assertIn('ELSE\n            freq[__reserved_keyword__char] <- 1', result.processed_source)
        self.assertFalse(any(t.rule == 'GC126' and 'freq[char]++' in t.source for t in result.transformations))
        parsed = AJParserFacade().parse(result.processed_source)
        self.assertTrue(parsed.success, parsed.error)

    def test_postfix_decrement_is_also_a_complete_statement(self):
        source = '''FUNCTION countdown(n):
    WHILE n > 0:
        n--
    RETURN n
'''
        result = self.processor.process(source)
        self.assertIn('n <- n - 1', result.processed_source)
        self.assertIn('RETURN n', result.processed_source)
        self.assertFalse(any(t.rule == 'GC126' and 'n--' in t.source for t in result.transformations))
        parsed = AJParserFacade().parse(result.processed_source)
        self.assertTrue(parsed.success, parsed.error)

    def test_true_dangling_addition_still_joins_expression_continuation(self):
        source = '''FUNCTION addParts(a, b):
    total ← a +
        b
    RETURN total
'''
        result = self.processor.process(source)
        self.assertIn('total <- a + b', result.processed_source)
        self.assertTrue(any(t.rule == 'GC126' for t in result.transformations))
        parsed = AJParserFacade().parse(result.processed_source)
        self.assertTrue(parsed.success, parsed.error)

    def test_commas_inside_call_arguments_are_not_statement_boundaries(self):
        source = '''FUNCTION usePair(a, b):
    value ← combine(a, b)
    RETURN value
'''
        result = self.processor.process(source)
        self.assertIn('value <- CALL combine(a, b)', result.processed_source)
        parsed = AJParserFacade().parse(result.processed_source)
        self.assertTrue(parsed.success, parsed.error)


if __name__ == '__main__':
    unittest.main()
