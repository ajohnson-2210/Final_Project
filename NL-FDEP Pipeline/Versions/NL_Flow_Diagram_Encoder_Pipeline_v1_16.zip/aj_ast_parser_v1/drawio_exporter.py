"""Editable draw.io XML export for generated flow diagrams."""

from __future__ import annotations

from pathlib import Path
from xml.etree import ElementTree
import html

from flow_diagram import FlowDiagram, FlowEdge, FlowNode
from flow_diagram_visualizer import FlowDiagramVisualizer


class DrawIOFlowExporter:
    """Exports a canonical flow diagram using the HTML visualiser's layout."""

    NODE_WIDTH = FlowDiagramVisualizer.NODE_WIDTH
    NODE_HEIGHT = FlowDiagramVisualizer.NODE_HEIGHT
    DECISION_WIDTH = FlowDiagramVisualizer.DECISION_WIDTH
    DECISION_HEIGHT = FlowDiagramVisualizer.DECISION_HEIGHT

    DECISION_TYPES = FlowDiagramVisualizer.DECISION_TYPES
    INPUT_OUTPUT_TYPES = FlowDiagramVisualizer.INPUT_OUTPUT_TYPES
    TERMINATOR_TYPES = FlowDiagramVisualizer.TERMINATOR_TYPES
    SUBROUTINE_TYPES = FlowDiagramVisualizer.SUBROUTINE_TYPES

    def __init__(self) -> None:
        self.layout_engine = FlowDiagramVisualizer()

    def export(
        self,
        flow_diagram: FlowDiagram,
        output_path: str | Path,
    ) -> Path:
        """Write an editable draw.io file and return its absolute path."""

        destination = Path(output_path).resolve()
        positions = self.layout_engine._calculate_positions(flow_diagram)
        canvas_width, canvas_height = self.layout_engine._calculate_canvas_size(
            positions
        )

        mxfile = ElementTree.Element(
            "mxfile",
            {
                "host": "app.diagrams.net",
                "modified": "2026-08-04T00:00:00.000Z",
                "agent": "NL to Flow Diagram Encoder Pipeline",
                "version": "24.7.17",
                "type": "device",
                "compressed": "false",
            },
        )

        diagram = ElementTree.SubElement(
            mxfile,
            "diagram",
            {
                "id": "generated-flow-diagram",
                "name": "Generated Flow Diagram",
            },
        )

        model = ElementTree.SubElement(
            diagram,
            "mxGraphModel",
            {
                "dx": str(canvas_width),
                "dy": str(canvas_height),
                "grid": "1",
                "gridSize": "10",
                "guides": "1",
                "tooltips": "1",
                "connect": "1",
                "arrows": "1",
                "fold": "1",
                "page": "0",
                "pageScale": "1",
                "pageWidth": str(canvas_width),
                "pageHeight": str(canvas_height),
                "math": "0",
                "shadow": "0",
                "background": "#ffffff",
            },
        )

        root = ElementTree.SubElement(
            model,
            "root",
        )

        ElementTree.SubElement(
            root,
            "mxCell",
            {
                "id": "0",
            },
        )

        ElementTree.SubElement(
            root,
            "mxCell",
            {
                "id": "1",
                "parent": "0",
            },
        )

        for node_id, node in flow_diagram.nodes.items():
            self._append_node(
                root=root,
                node=node,
                position=positions[node_id],
            )

        for index, edge in enumerate(
            flow_diagram.edges,
            start=1,
        ):
            self._append_edge(
                root=root,
                flow_diagram=flow_diagram,
                edge=edge,
                index=index,
                positions=positions,
            )

        ElementTree.indent(
            mxfile,
            space="  ",
        )

        xml_document = ElementTree.tostring(
            mxfile,
            encoding="utf-8",
            xml_declaration=True,
        )

        destination.write_bytes(
            xml_document
        )

        return destination

    def _append_node(
        self,
        root: ElementTree.Element,
        node: FlowNode,
        position: tuple[float, float],
    ) -> None:
        x_position, y_position = position
        width, height = self._node_dimensions(
            node
        )

        node_type = node.node_type.upper()
        uses_overlay_label = node_type in self.SUBROUTINE_TYPES

        node_value = self._node_value(
            node
        )

        if uses_overlay_label:
            node_value = ""

        cell = ElementTree.SubElement(
            root,
            "mxCell",
            {
                "id": node.node_id,
                "value": node_value,
                "style": self._node_style(node),
                "vertex": "1",
                "parent": "1",
            },
        )

        ElementTree.SubElement(
            cell,
            "mxGeometry",
            {
                "x": self._number(x_position),
                "y": self._number(y_position),
                "width": self._number(width),
                "height": self._number(height),
                "as": "geometry",
            },
        )

        if uses_overlay_label:
            self._append_overlay_label(
                root=root,
                node=node,
                x_position=x_position,
                y_position=y_position,
                width=width,
                height=height,
            )


    def _append_overlay_label(
        self,
        root: ElementTree.Element,
        node: FlowNode,
        x_position: float,
        y_position: float,
        width: float,
        height: float,
    ) -> None:
        """Place a full-width text cell over inset draw.io shapes."""

        label_cell = ElementTree.SubElement(
            root,
            "mxCell",
            {
                "id": f"{node.node_id}_LABEL",
                "value": self._node_value(node),
                "style": (
                    "text;"
                    "html=1;"
                    "whiteSpace=wrap;"
                    "overflow=hidden;"
                    "align=center;"
                    "verticalAlign=middle;"
                    "fontFamily=Arial;"
                    "fontSize=13;"
                    "fontColor=#111418;"
                    "strokeColor=none;"
                    "fillColor=none;"
                    "spacing=0;"
                    "connectable=0;"
                    "movable=0;"
                    "resizable=0;"
                ),
                "vertex": "1",
                "parent": "1",
            },
        )

        ElementTree.SubElement(
            label_cell,
            "mxGeometry",
            {
                "x": self._number(x_position),
                "y": self._number(y_position),
                "width": self._number(width),
                "height": self._number(height),
                "as": "geometry",
            },
        )

    def _append_edge(
        self,
        root: ElementTree.Element,
        flow_diagram: FlowDiagram,
        edge: FlowEdge,
        index: int,
        positions: dict[str, tuple[float, float]],
    ) -> None:
        visible_label = self._edge_label(
            edge.label
        )

        cell = ElementTree.SubElement(
            root,
            "mxCell",
            {
                "id": f"E{index}",
                "value": visible_label,
                "style": self._edge_style(
                    edge=edge,
                    positions=positions,
                ),
                "edge": "1",
                "parent": "1",
                "source": edge.source,
                "target": edge.target,
            },
        )

        geometry = ElementTree.SubElement(
            cell,
            "mxGeometry",
            {
                "relative": "1",
                "as": "geometry",
            },
        )

        waypoints = self._edge_waypoints(
            flow_diagram=flow_diagram,
            edge=edge,
            positions=positions,
        )

        if waypoints:
            points = ElementTree.SubElement(
                geometry,
                "Array",
                {
                    "as": "points",
                },
            )

            for x_position, y_position in waypoints:
                ElementTree.SubElement(
                    points,
                    "mxPoint",
                    {
                        "x": self._number(x_position),
                        "y": self._number(y_position),
                    },
                )

    def _edge_style(
        self,
        edge: FlowEdge,
        positions: dict[str, tuple[float, float]],
    ) -> str:
        source_x, source_y = positions[edge.source]
        target_x, target_y = positions[edge.target]

        common = (
            "edgeStyle=orthogonalEdgeStyle;"
            "rounded=0;"
            "orthogonalLoop=1;"
            "jettySize=auto;"
            "html=1;"
            "strokeColor=#252a31;"
            "strokeWidth=1.45;"
            "fontFamily=Arial;"
            "fontSize=11;"
            "fontColor=#20242a;"
            "labelBackgroundColor=#ffffff;"
            "endArrow=block;"
            "endSize=9;"
            "endFill=1;"
        )

        if target_y > source_y:
            return (
                common
                + "exitX=0.5;"
                + "exitY=1;"
                + "exitDx=0;"
                + "exitDy=0;"
                + "entryX=0.5;"
                + "entryY=0;"
                + "entryDx=0;"
                + "entryDy=0;"
            )

        return (
            common
            + "exitX=0;"
            + "exitY=0.5;"
            + "exitDx=0;"
            + "exitDy=0;"
            + "entryX=0;"
            + "entryY=0.5;"
            + "entryDx=0;"
            + "entryDy=0;"
        )

    def _node_value(
        self,
        node: FlowNode,
    ) -> str:
        wrapped_lines = self.layout_engine._wrap_label(
            node.label,
            30,
        )

        label = "<br>".join(
            html.escape(line)
            for line in wrapped_lines
        )

        metadata = html.escape(
            f"Line {node.line} · {node.node_id}"
        )

        return (
            '<div style="font-family:Arial;font-size:13px;'
            'line-height:16px;text-align:center;">'
            f"{label}"
            '<div style="margin-top:6px;font-size:10px;'
            f'color:#606874;">{metadata}</div>'
            "</div>"
        )

    def _node_dimensions(
        self,
        node: FlowNode,
    ) -> tuple[float, float]:
        if node.node_type.upper() in self.DECISION_TYPES:
            return (
                self.DECISION_WIDTH,
                self.DECISION_HEIGHT,
            )

        return (
            self.NODE_WIDTH,
            self.NODE_HEIGHT,
        )

    def _node_style(
        self,
        node: FlowNode,
    ) -> str:
        common = (
            "whiteSpace=wrap;"
            "html=1;"
            "align=center;"
            "verticalAlign=middle;"
            "fontFamily=Arial;"
            "fontSize=13;"
            "fontColor=#111418;"
            "strokeColor=#20242a;"
            "strokeWidth=1.6;"
            "fillColor=#ffffff;"
            "spacing=0;"
        )

        node_type = node.node_type.upper()

        if node_type in self.TERMINATOR_TYPES:
            return (
                common
                + "rounded=1;"
                + "arcSize=100;"
            )

        if node_type in self.DECISION_TYPES:
            return (
                common
                + "rhombus;"
                + "perimeter=rhombusPerimeter;"
            )

        if node_type in self.INPUT_OUTPUT_TYPES:
            return (
                common
                + "shape=parallelogram;"
                + "perimeter=parallelogramPerimeter;"
                + "fixedSize=1;"
            )

        if node_type in self.SUBROUTINE_TYPES:
            return (
                common
                + "shape=process;"
                + "size=12;"
                + "overflow=hidden;"
            )

        return (
            common
            + "rounded=1;"
            + "arcSize=8;"
        )

    def _edge_waypoints(
        self,
        flow_diagram: FlowDiagram,
        edge: FlowEdge,
        positions: dict[str, tuple[float, float]],
    ) -> list[tuple[float, float]]:
        source = flow_diagram.nodes[edge.source]
        target = flow_diagram.nodes[edge.target]

        source_x, source_y = positions[edge.source]
        target_x, target_y = positions[edge.target]

        source_width = self.layout_engine._node_width(
            source
        )
        source_height = self.layout_engine._node_height(
            source
        )
        target_width = self.layout_engine._node_width(
            target
        )
        target_height = self.layout_engine._node_height(
            target
        )

        if target_y > source_y:
            start_x = source_x + source_width / 2
            start_y = source_y + source_height
            end_x = target_x + target_width / 2
            end_y = target_y
            middle_y = (start_y + end_y) / 2

            return [
                (
                    start_x,
                    middle_y,
                ),
                (
                    end_x,
                    middle_y,
                ),
            ]

        start_x = source_x
        start_y = source_y + source_height / 2
        end_x = target_x
        end_y = target_y + target_height / 2
        loop_x = min(
            start_x,
            end_x,
        ) - 55

        return [
            (
                loop_x,
                start_y,
            ),
            (
                loop_x,
                end_y,
            ),
        ]

    def _edge_label(
        self,
        label: str,
    ) -> str:
        normalised = label.strip().upper()

        translations = {
            "TRUE": "Yes",
            "FALSE": "No",
            "ITERATE": "Yes",
            "BODY": "",
            "NEXT": "",
            "LOOP": "Repeat",
            "CATCH": "Exception",
        }

        return translations.get(
            normalised,
            label.title(),
        )

    def _number(
        self,
        value: float,
    ) -> str:
        rounded = round(
            value,
            3,
        )

        if rounded.is_integer():
            return str(
                int(rounded)
            )

        return str(
            rounded
        )
