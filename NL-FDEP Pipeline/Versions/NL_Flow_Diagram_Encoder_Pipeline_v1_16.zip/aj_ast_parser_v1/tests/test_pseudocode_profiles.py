import json
import tempfile
import unittest
from pathlib import Path

from aj_test_harness import TestCase
from nl_flow_pipeline import NLFlowDiagramEncoderPipeline
from pseudocode_profiles import (
    GenericPseudocodeLexer,
    PseudocodeProfile,
    PseudocodeProfileProcessor,
)


class PseudocodeProfileTests(unittest.TestCase):

    def setUp(self):
        self.processor = PseudocodeProfileProcessor()

    def test_strict_profile_performs_only_safe_cleanup(self):
        source = "```text\ntotal ← INTEGER(0)   \nOUTPUT total\n```"

        result = self.processor.process(
            source=source,
            profile=PseudocodeProfile.AJ_DIALECT_STRICT,
        )

        self.assertEqual(
            result.processed_source,
            "total <- INTEGER(0)\nOUTPUT total",
        )
        self.assertTrue(result.source_modified)
        self.assertGreaterEqual(result.transformation_count, 2)

    def test_generic_lexer_classifies_supported_statements(self):
        tokens = GenericPseudocodeLexer().tokenise(
            "SET total TO 0\nPRINT total\nEND IF"
        )

        categories = []

        for token in tokens:
            categories.append(token.category)

        self.assertEqual(
            categories,
            ["SET_ASSIGNMENT", "OUTPUT", "END_IF"],
        )

    def test_generic_profile_converts_compatible_syntax(self):
        source = "SET total TO 0\ntotal = total + 3\nPRINT total"

        result = self.processor.process(
            source=source,
            profile=PseudocodeProfile.GENERIC_COMPATIBILITY,
        )

        self.assertEqual(
            result.processed_source,
            "total <- 0\ntotal <- total + 3\nOUTPUT total",
        )
        self.assertEqual(result.transformation_count, 3)

    def test_general_profile_preserves_source_exactly(self):
        source = "set total to 0  \r\nprint total"

        result = self.processor.process(
            source=source,
            profile=PseudocodeProfile.GENERAL_NO_CONVERSION,
        )

        self.assertEqual(result.processed_source, source)
        self.assertFalse(result.source_modified)
        self.assertEqual(result.transformation_count, 0)

    def test_generic_profile_runs_complete_pipeline(self):
        source = "SET total TO 0\ntotal = total + 3\nPRINT total"

        with tempfile.TemporaryDirectory() as directory:
            result = NLFlowDiagramEncoderPipeline().run(
                pseudocode=source,
                output_directory=Path(directory),
                test_cases=[
                    TestCase(
                        name="Generic total",
                        expected_output=["3"],
                    )
                ],
                pseudocode_profile=PseudocodeProfile.GENERIC_COMPATIBILITY,
            )

            report_path = Path(
                result.output_files["pseudocode_processing_report"]
            )
            report = json.loads(
                report_path.read_text(encoding="utf-8")
            )

        self.assertTrue(result.success, result.to_json())
        self.assertEqual(
            result.input_metadata["pseudocode_profile"],
            PseudocodeProfile.GENERIC_COMPATIBILITY.value,
        )
        self.assertEqual(report["transformation_count"], 3)

    def test_general_profile_does_not_repair_generic_syntax(self):
        source = "SET total TO 0\nPRINT total"

        with tempfile.TemporaryDirectory() as directory:
            result = NLFlowDiagramEncoderPipeline().run(
                pseudocode=source,
                output_directory=Path(directory),
                test_cases=[],
                pseudocode_profile=PseudocodeProfile.GENERAL_NO_CONVERSION,
            )

        self.assertFalse(result.success)
        self.assertEqual(
            result.input_metadata["pseudocode_profile"],
            PseudocodeProfile.GENERAL_NO_CONVERSION.value,
        )
        self.assertIn("Expected", result.error)


if __name__ == "__main__":
    unittest.main()
