import json
import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from pseudocode_profiles import PseudocodeProfile
from pycharm_runner import (
    _clear_baseline_preference,
    _runner_state_path,
    _save_baseline_preference,
    _saved_baseline_root,
    resolve_baseline_dependency,
)


READY_PREFLIGHT = {
    "baseline_root_structure_valid": True,
    "issue_count": 0,
    "algorithms": [],
}
READY_STATE = {
    "terminal": 50,
    "evaluated": 50,
    "full_score": 50,
    "pipeline_failure": 0,
    "behavioural_not_evaluated": 0,
    "other_unavailable": 0,
}
STALE_STATE = {
    "terminal": 0,
    "evaluated": 0,
    "full_score": 0,
    "pipeline_failure": 0,
    "behavioural_not_evaluated": 0,
    "other_unavailable": 0,
}


class _NoPromptDialog:
    def __init__(self):
        self.infos = []
        self.errors = []

    def ask_yes_no(self, title, message):
        raise AssertionError(f"Unexpected question: {title}: {message}")

    def select_optional_directory(self, title):
        raise AssertionError(f"Unexpected baseline chooser: {title}")

    def show_info(self, title, message):
        self.infos.append((title, message))

    def show_error(self, title, message):
        self.errors.append((title, message))


class _AcceptCalibrationDialog(_NoPromptDialog):
    def __init__(self):
        super().__init__()
        self.questions = []

    def ask_yes_no(self, title, message):
        self.questions.append((title, message))
        return True


class RunnerBaselinePersistenceV434Tests(unittest.TestCase):
    def test_state_file_can_live_outside_release_and_round_trip_baseline_path(self):
        with tempfile.TemporaryDirectory() as temp:
            state_path = Path(temp) / "user-state" / "runner_state.json"
            baseline = Path(temp) / "Baselines"
            baseline.mkdir()
            with patch.dict(os.environ, {"NL_FDEP_RUNNER_STATE_FILE": str(state_path)}, clear=False):
                _save_baseline_preference(baseline)
                self.assertEqual(state_path, _runner_state_path())
                self.assertEqual(baseline.resolve(), _saved_baseline_root().resolve())
                payload = json.loads(state_path.read_text(encoding="utf-8"))
                self.assertEqual(str(baseline.resolve()), payload["last_baseline_root"])
                self.assertEqual("4.35", payload["last_selected_pipeline_version"])
                _clear_baseline_preference()
                self.assertFalse(state_path.exists())

    def test_ready_saved_baseline_is_reused_without_missing_baseline_prompt(self):
        with tempfile.TemporaryDirectory() as temp:
            baseline = Path(temp) / "Baselines"
            baseline.mkdir()
            state_path = Path(temp) / "runner_state.json"
            dialog = _NoPromptDialog()
            with patch.dict(os.environ, {"NL_FDEP_RUNNER_STATE_FILE": str(state_path)}, clear=False), \
                 patch("pycharm_runner.validate_baseline", return_value=READY_PREFLIGHT), \
                 patch("pycharm_runner._current_baseline_state", return_value=READY_STATE):
                _save_baseline_preference(baseline)
                result = resolve_baseline_dependency(dialog, PseudocodeProfile.GENERIC_COMPATIBILITY)

            self.assertEqual(baseline.resolve(), result.resolve())
            self.assertEqual([], dialog.errors)
            self.assertTrue(any(title == "Ready baseline benchmark detected" for title, _ in dialog.infos))

    def test_saved_stale_baseline_is_offered_recalibration_then_reused(self):
        with tempfile.TemporaryDirectory() as temp:
            baseline = Path(temp) / "Baselines"
            baseline.mkdir()
            state_path = Path(temp) / "runner_state.json"
            dialog = _AcceptCalibrationDialog()
            calibration_result = {
                "report": {
                    "algorithm_count": 50,
                    "calibration_status_counts": {"CALIBRATED": 50},
                }
            }
            with patch.dict(os.environ, {"NL_FDEP_RUNNER_STATE_FILE": str(state_path)}, clear=False), \
                 patch("pycharm_runner.validate_baseline", return_value=READY_PREFLIGHT), \
                 patch("pycharm_runner._current_baseline_state", side_effect=[STALE_STATE, READY_STATE, READY_STATE]), \
                 patch("pycharm_runner.run_baseline_folder", return_value=calibration_result) as calibrate:
                _save_baseline_preference(baseline)
                result = resolve_baseline_dependency(dialog, PseudocodeProfile.GENERIC_COMPATIBILITY)

            self.assertEqual(baseline.resolve(), result.resolve())
            calibrate.assert_called_once()
            self.assertTrue(any(title == "Baseline calibration required" for title, _ in dialog.questions))
            self.assertTrue(any(title == "Ready baseline benchmark detected" for title, _ in dialog.infos))

    def test_missing_saved_baseline_is_cleared_before_normal_dependency_flow(self):
        with tempfile.TemporaryDirectory() as temp:
            missing = Path(temp) / "Moved Baselines"
            replacement = Path(temp) / "Replacement"
            state_path = Path(temp) / "runner_state.json"
            dialog = _NoPromptDialog()
            with patch.dict(os.environ, {"NL_FDEP_RUNNER_STATE_FILE": str(state_path)}, clear=False):
                state_path.write_text(
                    json.dumps({"last_baseline_root": str(missing)}),
                    encoding="utf-8",
                )
                with patch("pycharm_runner.ensure_baseline_available", return_value=replacement) as fallback:
                    result = resolve_baseline_dependency(dialog, PseudocodeProfile.GENERIC_COMPATIBILITY)

            self.assertEqual(replacement, result)
            fallback.assert_called_once()
            self.assertTrue(any(title == "Previously selected baseline unavailable" for title, _ in dialog.infos))
            self.assertFalse(state_path.exists())


if __name__ == "__main__":
    unittest.main()
