"""Task-semantic behavioural evaluation for Common Tests v1.2.

The semantic layer evaluates generated experimental Python through the task's
explicit input/output contract.  It is intentionally separate from the historic
PROGRAM/stdout reference harness so a function-only generic translation is not
mis-scored as 0% merely because its function was never invoked.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any
import json
import math
import os
import re
import subprocess
import sys
import tempfile
import textwrap


@dataclass
class SemanticTestResult:
    name: str
    status: str
    expected_semantic_result: Any
    actual_semantic_result: Any
    semantic_match: bool | None
    reason: str | None
    duration_ms: float | None
    category: str
    semantic_feature: str | None
    fixture_source: str | None
    oracle_source: str | None
    selected_entrypoint: str | None = None
    invocation_capture: dict[str, Any] | None = None


@dataclass
class SemanticTestReport:
    program_path: str
    algorithm_id: int
    contract_version: str
    results: list[SemanticTestResult]

    @property
    def evaluable_tests(self) -> int:
        return sum(r.status in {"PASSED", "FAILED"} for r in self.results)

    @property
    def passed_tests(self) -> int:
        return sum(r.status == "PASSED" for r in self.results)

    @property
    def failed_tests(self) -> int:
        return sum(r.status == "FAILED" for r in self.results)

    @property
    def not_evaluable_tests(self) -> int:
        return sum(r.status == "NOT_EVALUABLE" for r in self.results)

    @property
    def accuracy_percentage(self) -> float | None:
        if not self.evaluable_tests:
            return None
        return round(self.passed_tests / self.evaluable_tests * 100.0, 2)

    def to_dict(self) -> dict[str, Any]:
        return {
            "semantic_report_schema_version": "1.0",
            "program_path": self.program_path,
            "algorithm_id": self.algorithm_id,
            "contract_version": self.contract_version,
            "evaluable_tests": self.evaluable_tests,
            "passed_tests": self.passed_tests,
            "failed_tests": self.failed_tests,
            "not_evaluable_tests": self.not_evaluable_tests,
            "accuracy_percentage": self.accuracy_percentage,
            "results": [asdict(r) for r in self.results],
        }

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), indent=2, ensure_ascii=False)


_DRIVER = r'''
import ast, builtins, inspect, json, pathlib, random, sys, traceback, types

program_path = pathlib.Path(sys.argv[1]).resolve()
fixture_path = pathlib.Path(sys.argv[2]).resolve()
fixture = json.loads(fixture_path.read_text(encoding="utf-8"))

captures = []
def capture_print(*args, **kwargs):
    captures.append(list(args))

def to_jsonable(value, depth=0):
    if depth > 12:
        return {"$repr": repr(value)}
    if value is None or isinstance(value, (bool, int, float, str)):
        if isinstance(value, float) and (value != value or value in (float('inf'), float('-inf'))):
            return {"$repr": repr(value)}
        return value
    if isinstance(value, dict):
        return {str(k): to_jsonable(v, depth+1) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [to_jsonable(v, depth+1) for v in value]
    if isinstance(value, set):
        vals = [to_jsonable(v, depth+1) for v in value]
        try:
            return sorted(vals, key=lambda x: json.dumps(x, sort_keys=True, ensure_ascii=False))
        except Exception:
            return vals
    if hasattr(value, "__dict__"):
        return {"$object": value.__class__.__name__, "attrs": to_jsonable(vars(value), depth+1)}
    return {"$repr": repr(value)}

class Obj:
    pass

def build(value, shared):
    if isinstance(value, list):
        return [build(v, shared) for v in value]
    if not isinstance(value, dict):
        return value
    if "$ref" in value:
        return shared[value["$ref"]]
    kind = value.get("$type")
    if kind == "BINARY_TREE":
        raw = value.get("level_order", [])
        nodes = [None if v is None else Obj() for v in raw]
        for idx, raw_value in enumerate(raw):
            node = nodes[idx]
            if node is None:
                continue
            node.Value = raw_value
            li, ri = 2*idx+1, 2*idx+2
            node.Left = nodes[li] if li < len(nodes) else None
            node.Right = nodes[ri] if ri < len(nodes) else None
        return nodes[0] if nodes else None
    if kind == "LINKED_LIST":
        vals = value.get("values", [])
        nodes = []
        for raw_value in vals:
            node = Obj(); node.Value = raw_value; node.Next = None; nodes.append(node)
        for i in range(len(nodes)-1):
            nodes[i].Next = nodes[i+1]
        cycle = value.get("cycle_to_index")
        if nodes and cycle is not None:
            nodes[-1].Next = nodes[int(cycle)]
        return nodes[0] if nodes else None
    if kind == "OBJECT":
        obj = Obj()
        for k, v in value.get("attrs", {}).items():
            setattr(obj, k, build(v, shared))
        return obj
    return {str(k): build(v, shared) for k, v in value.items()}

source = program_path.read_text(encoding="utf-8")
try:
    tree = ast.parse(source)
except Exception as exc:
    sys.__stdout__.write(json.dumps({"status":"NOT_EVALUABLE","reason":f"Generated Python is not syntax-valid: {exc}"}))
    raise SystemExit(0)

top_level_function_names = [n.name for n in tree.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))]
# Semantic function mode must not silently execute a program with arbitrary top-level work.
unsafe_top_level = []
for node in tree.body:
    if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef, ast.Import, ast.ImportFrom)):
        continue
    if isinstance(node, ast.Expr) and isinstance(node.value, ast.Constant) and isinstance(node.value.value, str):
        continue
    unsafe_top_level.append(type(node).__name__)

if unsafe_top_level and fixture.get("require_function_only", True):
    sys.__stdout__.write(json.dumps({
        "status":"NOT_EVALUABLE",
        "reason":"Semantic function invocation is not used because generated Python contains top-level executable statements.",
        "top_level_statement_kinds":unsafe_top_level,
    }))
    raise SystemExit(0)

ns = {"__name__":"__semantic_test__", "print":capture_print}
try:
    exec(compile(source, str(program_path), "exec"), ns, ns)
except Exception as exc:
    sys.__stdout__.write(json.dumps({"status":"NOT_EVALUABLE","reason":f"Generated Python could not be loaded for semantic invocation: {type(exc).__name__}: {exc}"}))
    raise SystemExit(0)

candidate = None
preferred = fixture.get("entrypoint_candidates") or ["unnamed_function"]
for name in preferred:
    value = ns.get(name)
    if callable(value):
        candidate = value
        break

if candidate is None:
    possible = []
    for name in top_level_function_names:
        value = ns.get(name)
        if callable(value):
            possible.append(value)
    arities = set(int(v) for v in fixture.get("allowed_arities", []) if isinstance(v, int) or str(v).isdigit())
    if arities:
        filtered = []
        for fn in possible:
            try:
                sig = inspect.signature(fn)
                required = [p for p in sig.parameters.values() if p.default is inspect._empty and p.kind in (p.POSITIONAL_ONLY,p.POSITIONAL_OR_KEYWORD)]
                total_pos = [p for p in sig.parameters.values() if p.kind in (p.POSITIONAL_ONLY,p.POSITIONAL_OR_KEYWORD)]
                if len(required) in arities or len(total_pos) in arities:
                    filtered.append(fn)
            except Exception:
                pass
        possible = filtered
    if len(possible) == 1:
        candidate = possible[0]

if candidate is None:
    sys.__stdout__.write(json.dumps({"status":"NOT_EVALUABLE","reason":"No unambiguous task entrypoint function could be identified.","top_level_functions":top_level_function_names}))
    raise SystemExit(0)

shared = {name: build(value, {}) for name, value in (fixture.get("shared_values") or {}).items()}
# Resolve references now that the dictionary exists.
for name, value in list((fixture.get("shared_values") or {}).items()):
    shared[name] = build(value, shared)

invocations = fixture.get("invocations")
if invocations is None:
    invocations = [{"arguments": fixture.get("arguments", [])}]

returns = []
post_arguments = []
errors = []
for inv in invocations:
    args = [build(v, shared) for v in inv.get("arguments", [])]
    try:
        result = candidate(*args)
        returns.append(to_jsonable(result))
        post_arguments.append(to_jsonable(args))
        errors.append(None)
    except BaseException as exc:
        returns.append(None)
        post_arguments.append(to_jsonable(args))
        errors.append({"type":type(exc).__name__,"message":str(exc)})
        if not fixture.get("continue_after_error", False):
            break

out = {
    "status":"COMPLETED" if not any(errors) else "ERROR",
    "selected_entrypoint":getattr(candidate,"__name__",None),
    "prints":to_jsonable(captures),
    "returns":returns,
    "post_arguments":post_arguments,
    "shared_values":to_jsonable(shared),
    "errors":errors,
}
sys.__stdout__.write(json.dumps(out, ensure_ascii=False))
'''


def _run_invocation(program_path: Path, semantic: dict[str, Any], timeout: float, random_seed: int | None, environment: dict[str, str] | None, requires_modules: list[str] | None) -> dict[str, Any]:
    fixture = dict(semantic.get("fixture") or {})
    fixture.setdefault("entrypoint_candidates", semantic.get("entrypoint_candidates") or ["unnamed_function"])
    fixture.setdefault("allowed_arities", semantic.get("allowed_arities") or [])
    fixture.setdefault("require_function_only", True)
    with tempfile.TemporaryDirectory(prefix="nl_fdep_semantic_") as td:
        fixture_path = Path(td) / "fixture.json"
        fixture_path.write_text(json.dumps(fixture, ensure_ascii=False), encoding="utf-8")
        env = dict(os.environ)
        for key, value in (environment or {}).items():
            env[str(key)] = str(value)
        if random_seed is not None:
            env.setdefault("PYTHONHASHSEED", str(int(random_seed)))
        cmd = [sys.executable]
        if not requires_modules:
            cmd.append("-S")
        cmd.extend(["-c", _DRIVER, str(Path(program_path).resolve()), str(fixture_path)])
        try:
            cp = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, env=env, check=False)
        except subprocess.TimeoutExpired:
            return {"status":"NOT_EVALUABLE","reason":"Semantic invocation exceeded the configured timeout."}
        if cp.returncode != 0:
            return {"status":"NOT_EVALUABLE","reason":f"Semantic invocation driver failed with return code {cp.returncode}.","stderr":cp.stderr}
        try:
            return json.loads(cp.stdout or "{}")
        except json.JSONDecodeError:
            return {"status":"NOT_EVALUABLE","reason":"Semantic invocation driver did not return valid JSON.","stdout":cp.stdout,"stderr":cp.stderr}


def _flatten_prints(capture: dict[str, Any]) -> list[list[Any]]:
    value = capture.get("prints") or []
    return [row if isinstance(row, list) else [row] for row in value]


def _last_scalar(capture: dict[str, Any]) -> Any:
    rows = _flatten_prints(capture)
    for row in reversed(rows):
        if row:
            return row[-1] if len(row) == 1 else row
    returns = capture.get("returns") or []
    for value in reversed(returns):
        if value is not None:
            return value
    return None


def _normalise_algorithm_result(algorithm_id: int, capture: dict[str, Any], semantic: dict[str, Any]) -> tuple[Any, str | None]:
    rows = _flatten_prints(capture)
    text = "\n".join(" ".join(str(v) for v in row) for row in rows)
    low = text.lower()
    try:
        if algorithm_id == 1:
            if "not anagram" in low:
                return False, None
            if "anagram" in low:
                return True, None
        elif algorithm_id == 2:
            value = str(_last_scalar(capture)).strip().lower().replace("0b", "")
            digits = re.findall(r"[01]+", value)
            return ((digits[-1].lstrip("0") or "0") if digits else None), None
        elif algorithm_id == 3:
            if "not leap" in low:
                return False, None
            if "leap" in low:
                return True, None
        elif algorithm_id == 4:
            return [row[0] for row in rows if row], None
        elif algorithm_id == 5:
            return str(_last_scalar(capture)), None
        elif algorithm_id == 6:
            return int(_last_scalar(capture)), None
        elif algorithm_id in {7, 8, 27}:
            return _last_scalar(capture), None
        elif algorithm_id == 9:
            if "not found" in low:
                return None, None
            m = re.search(r"(?:position|index)[^\d-]*(-?\d+)", text, re.I)
            if m:
                return int(m.group(1)), None
            value = _last_scalar(capture)
            return int(value), None
        elif algorithm_id == 10:
            if len(rows) == 1 and len(rows[0]) >= 5:
                vals = rows[0][:5]
                return {k:int(v) for k,v in zip("aeiou", vals)}, None
            counts = {}
            for ch in "aeiou":
                m = re.search(rf"\b{ch}\b[^\d-]*(-?\d+)", text, re.I)
                if m: counts[ch] = int(m.group(1))
            return counts, None
        elif algorithm_id == 11:
            value = _last_scalar(capture)
            if isinstance(value, list):
                return sorted(value, key=str), None
            return value, None
        elif algorithm_id in {12, 14, 15, 16, 22, 25, 33, 44}:
            value = _last_scalar(capture)
            return (float(value) if isinstance(value, float) else int(value)), None
        elif algorithm_id == 13:
            return str(_last_scalar(capture)), None
        elif algorithm_id == 17:
            vals=[]
            for row in rows:
                if len(row)==1 and isinstance(row[0], (int,float)):
                    vals.append(float(row[0]))
            return vals[:2], None
        elif algorithm_id == 18:
            value = _last_scalar(capture)
            return value if isinstance(value, dict) else None, None
        elif algorithm_id == 19:
            if rows:
                row=rows[-1]
                return row[:2] if len(row)>=2 else row, None
        elif algorithm_id == 20:
            vals=[]
            for row in rows:
                if row and isinstance(row[0], (int,float)):
                    vals.append(int(row[0]))
            return vals, None
        elif algorithm_id == 21:
            if "even" in low: return "EVEN", None
            if "odd" in low: return "ODD", None
        elif algorithm_id == 23:
            for grade in ("DISTINCTION","MERIT","PASS","FAIL"):
                if grade.lower() in low: return grade, None
        elif algorithm_id == 24:
            if "invalid" in low: return False, None
            if "valid" in low: return True, None
        elif algorithm_id == 26:
            vals=[]
            for row in rows:
                if row and isinstance(row[0], (int,float,str)):
                    vals.append(row[0])
            return vals, None
        elif algorithm_id == 28:
            vals=[]
            for row in rows:
                if row and isinstance(row[0], (int,float)):
                    vals.append(row[0])
            return vals, None
        elif algorithm_id == 29:
            return [str(row[-1]) for row in rows if row], None
        elif algorithm_id == 31:
            return [row for row in rows if row], None
        elif algorithm_id == 32:
            return str(_last_scalar(capture)), None
        elif algorithm_id == 34:
            value=_last_scalar(capture)
            if isinstance(value,list): return sorted(set(value), key=str), None
            return value,None
        elif algorithm_id == 36:
            results=[]
            for row in rows:
                if not row: continue
                v=row[-1]
                if isinstance(v,int): results.append(v)
                elif "not found" in str(v).lower(): results.append(None)
            return (results[0] if len(results)==1 else results), None
        elif algorithm_id == 38:
            vals=[]
            for row in rows:
                if row: vals.append(row[-1])
            return vals, None
        elif algorithm_id == 39:
            if "cycle detected" in low: return True, None
            if "no cycle" in low: return False, None
        elif algorithm_id == 42:
            pairs=[]
            for row in rows:
                if len(row)>=2 and isinstance(row[0],(int,float)) and isinstance(row[1],(int,float)):
                    a,b=row[0],row[1]; pairs.append([a,b])
            return sorted(pairs, key=lambda p:(float(p[0]),float(p[1]))), None
        elif algorithm_id == 43:
            moves=[]
            pat=re.compile(r"move\s+disk(?:\s+\d+)?\s+from\s+([A-Za-z])\s+to\s+([A-Za-z])", re.I)
            for row in rows:
                for v in row:
                    m=pat.search(str(v))
                    if m: moves.append([m.group(1).upper(),m.group(2).upper()])
            return moves,None
        elif algorithm_id == 45 or algorithm_id == 46:
            value=_last_scalar(capture)
            return value,None
        elif algorithm_id == 47:
            value=_last_scalar(capture)
            if isinstance(value,dict): return value,None
            shared=(capture.get("shared_values") or {}).get("inventory")
            return shared if isinstance(shared,dict) else value,None
        elif algorithm_id == 48:
            return [row[-1] for row in rows if row],None
        elif algorithm_id == 49:
            if "path found" in low: return True,None
            if "no path" in low: return False,None
        elif algorithm_id == 50:
            if "safely" in low and "destination" in low: return True,None
    except Exception as exc:
        return None, f"Semantic observer failed: {type(exc).__name__}: {exc}"
    return None, "The semantic observer could not derive the task result from the invocation evidence."


def _deep_equal(actual: Any, expected: Any, mode: str = "EXACT", tolerance: float = 1e-9) -> bool:
    mode = str(mode or "EXACT").upper()
    if mode == "NUMERIC":
        try: return math.isclose(float(actual), float(expected), rel_tol=tolerance, abs_tol=tolerance)
        except Exception: return False
    if mode == "NUMERIC_SEQUENCE":
        if not isinstance(actual,list) or not isinstance(expected,list) or len(actual)!=len(expected): return False
        return all(_deep_equal(a,e,"NUMERIC",tolerance) for a,e in zip(actual,expected))
    if mode == "SET":
        try:
            ka=lambda x: json.dumps(x,sort_keys=True,ensure_ascii=False)
            return sorted(actual,key=ka)==sorted(expected,key=ka)
        except Exception: return False
    if mode == "PAIR_SET":
        try:
            def canon(seq):
                out=[]
                for pair in seq:
                    a,b=pair
                    out.append(sorted([a,b], key=lambda x:(str(type(x)),str(x))))
                return sorted(out,key=lambda p:json.dumps(p,sort_keys=True,ensure_ascii=False))
            return canon(actual)==canon(expected)
        except Exception: return False
    if mode == "MATRIX_NUMERIC":
        if not isinstance(actual,list) or not isinstance(expected,list) or len(actual)!=len(expected): return False
        return all(_deep_equal(a,e,"NUMERIC_SEQUENCE",tolerance) for a,e in zip(actual,expected))
    return actual == expected


class SemanticTestHarness:
    """Execute task-semantic tests declared by Common Tests v1.2."""

    def run(self, program_path: Path, algorithm_id: int, suite_metadata: dict[str, Any], spec_items: list[dict[str, Any]]) -> SemanticTestReport:
        contract = suite_metadata.get("semantic_contract") or {}
        contract_version = str(contract.get("contract_version") or "1.2")
        results: list[SemanticTestResult] = []
        for index, spec in enumerate(spec_items, start=1):
            semantic = spec.get("semantic_test") or {}
            name = str(spec.get("name", f"Test {index}"))
            category = str(spec.get("category", "NORMAL")).upper()
            feature = spec.get("semantic_feature")
            expected = semantic.get("expected_semantic_result")
            if not semantic.get("enabled"):
                results.append(SemanticTestResult(name,"NOT_EVALUABLE",expected,None,None,semantic.get("reason") or "This Common Test is not a task-level semantic function test.",None,category,feature,semantic.get("fixture_source"),semantic.get("oracle_source")))
                continue
            import time
            start=time.perf_counter()
            capture=_run_invocation(
                Path(program_path), semantic,
                float(spec.get("timeout_seconds",3.0)),
                int(spec["random_seed"]) if spec.get("random_seed") is not None else None,
                {str(k):str(v) for k,v in (spec.get("environment") or {}).items()},
                [str(v) for v in spec.get("requires_modules",[])],
            )
            duration=round((time.perf_counter()-start)*1000,3)
            if capture.get("status") not in {"COMPLETED","ERROR"}:
                results.append(SemanticTestResult(name,"NOT_EVALUABLE",expected,None,None,capture.get("reason") or "Semantic invocation was not evaluable.",duration,category,feature,semantic.get("fixture_source"),semantic.get("oracle_source"),capture.get("selected_entrypoint"),capture))
                continue
            if capture.get("status") == "ERROR":
                results.append(SemanticTestResult(name,"FAILED",expected,{"runtime_errors":capture.get("errors")},False,"The task entrypoint raised a runtime error for the semantic fixture.",duration,category,feature,semantic.get("fixture_source"),semantic.get("oracle_source"),capture.get("selected_entrypoint"),capture))
                continue
            actual, reason = _normalise_algorithm_result(int(algorithm_id), capture, semantic)
            if reason is not None:
                results.append(SemanticTestResult(name,"NOT_EVALUABLE",expected,actual,None,reason,duration,category,feature,semantic.get("fixture_source"),semantic.get("oracle_source"),capture.get("selected_entrypoint"),capture))
                continue
            match=_deep_equal(actual, expected, semantic.get("comparison_mode","EXACT"), float(semantic.get("numeric_tolerance",1e-9)))
            results.append(SemanticTestResult(name,"PASSED" if match else "FAILED",expected,actual,match,None if match else "Observed task-semantic result did not match the expected semantic result.",duration,category,feature,semantic.get("fixture_source"),semantic.get("oracle_source"),capture.get("selected_entrypoint"),capture))
        return SemanticTestReport(str(Path(program_path).resolve()), int(algorithm_id), contract_version, results)
