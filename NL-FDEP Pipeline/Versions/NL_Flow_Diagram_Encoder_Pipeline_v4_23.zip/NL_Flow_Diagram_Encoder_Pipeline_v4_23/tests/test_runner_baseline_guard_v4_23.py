import unittest

from pseudocode_profiles import PseudocodeProfile
from pycharm_runner import ensure_baseline_available


class _DeclineDialog:
    def ask_yes_no(self, title, message):
        self.title = title
        self.message = message
        return False


class RunnerBaselineGuardV423Tests(unittest.TestCase):
    def test_declining_missing_baseline_cancels_dependent_operation_cleanly(self):
        dialog = _DeclineDialog()
        result = ensure_baseline_available(dialog, PseudocodeProfile.GENERIC_COMPATIBILITY)
        self.assertIsNone(result)
        self.assertIn("Baseline benchmark required", dialog.title)
        self.assertIn("provide one now", dialog.message)


if __name__ == "__main__":
    unittest.main()
