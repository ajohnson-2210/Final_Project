"""Interactive PyCharm entry point for the controlled NL-FDEP routes."""

from __future__ import annotations

import json
from pathlib import Path
import sys

PROJECT_ROOT = Path(__file__).resolve().parent
COMPONENT_DIRECTORIES = [
    PROJECT_ROOT / 'parser components',
    PROJECT_ROOT / 'compiler components',
    PROJECT_ROOT / 'flow diagram components',
    PROJECT_ROOT / 'pipeline components',
    PROJECT_ROOT / 'study components',
    PROJECT_ROOT / 'cli components',
]
for component_directory in reversed(COMPONENT_DIRECTORIES):
    component_path = str(component_directory)
    if component_path not in sys.path:
        sys.path.insert(0, component_path)

from aj_test_harness import TestCase
from common_test_resources import DEFAULT_COMMON_TESTS_ROOT, validate_common_test_pack
from flow_input_pipeline import DrawIOFlowInputPipeline
from input_selection import (
    InputRoute,
    InputSelectionCancelledError,
    InputSelectionDialog,
)
from nl_flow_pipeline import NLFlowDiagramEncoderPipeline
from pseudocode_profiles import PseudocodeProfile
from study_batch import StudyBatchProcessor
from study_provenance import validate_baseline
from study_review import launch_review_dashboard
from study_rubric import PIPELINE_VERSION


OUTPUT_DIRECTORY = Path("output")
OPEN_VISUALISATIONS = True
BASELINE_REQUIRED_ROUTES = {InputRoute.LLM_RESULTS_FOLDER}
TERMINAL_BASELINE_STATUSES = {"SUCCESS", "FAILURE", "EXPECTED_FAILURE", "REVIEW_REQUIRED"}

TEST_CASES = [
    TestCase(
        name="Pipeline test",
        standard_input=[],
        expected_output=["6", "6"],
        timeout_seconds=3.0,
    )
]


def run_pseudocode_pipeline(input_path: Path, pseudocode_profile: PseudocodeProfile):
    """Run the canonical pipeline using a selected AJ pseudocode file."""
    pseudocode = input_path.read_text(encoding="utf-8")
    return NLFlowDiagramEncoderPipeline().run(
        pseudocode=pseudocode,
        output_directory=OUTPUT_DIRECTORY,
        test_cases=TEST_CASES,
        open_visualisations=OPEN_VISUALISATIONS,
        pseudocode_profile=pseudocode_profile,
    )


def run_flow_diagram_pipeline(input_path: Path):
    """Run the controlled draw.io import route."""
    return DrawIOFlowInputPipeline().run(
        input_path=input_path,
        output_directory=OUTPUT_DIRECTORY,
        test_cases=[],
        open_visualisations=OPEN_VISUALISATIONS,
    )


def run_llm_results_folder(
    input_path: Path,
    pseudocode_profile: PseudocodeProfile,
    baseline_root: Path | None = None,
):
    """Batch-process Algorithm - n folders using the selected benchmark oracle."""
    return StudyBatchProcessor().process_llm_results(
        results_directory=input_path,
        profile=pseudocode_profile,
        baseline_root=baseline_root,
        open_visualisations=False,
    )


def run_baseline_folder(input_path: Path, pseudocode_profile: PseudocodeProfile):
    """Process a runtime-selected baseline using packaged Common Tests v1.1."""
    return StudyBatchProcessor().process_baseline(
        baseline_root=input_path,
        profile=pseudocode_profile,
        open_visualisations=False,
    )


def run_human_review_folder(input_path: Path):
    """Launch the integrated review dashboard for an algorithm parent folder."""
    launch_review_dashboard(input_path)
    return {"status": "REVIEW_SESSION_CLOSED", "review_root": str(input_path.resolve())}


def _read_json(path: Path) -> dict | None:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else None
    except Exception:
        return None


def _current_baseline_calibration_count(baseline_root: Path, expected_ids=range(1, 51)) -> int:
    """Count algorithm calibrations current for this pipeline version."""
    current = 0
    for algorithm_id in expected_ids:
        artifact_directory = (
            Path(baseline_root)
            / "pseudocode"
            / f"Algorithm - {algorithm_id}"
            / "pipeline_artifacts"
        )
        manifest = _read_json(artifact_directory / "manifest.json") or {}
        calibration = (
            _read_json(artifact_directory / "baseline_calibration.json")
            or _read_json(artifact_directory / "baseline_python_comparison.json")
            or {}
        )
        if (
            manifest.get("pipeline_version") == PIPELINE_VERSION
            and manifest.get("processing_status") in TERMINAL_BASELINE_STATUSES
            and calibration.get("status") == "EVALUATED"
            and calibration.get("calibration_score_percentage") is not None
        ):
            current += 1
    return current


def _baseline_problem_summary(report: dict) -> str:
    rows = [row for row in report.get("algorithms", []) if row.get("status") != "READY"]
    examples = []
    for row in rows[:8]:
        issues = ", ".join(row.get("issues") or ["unknown issue"])
        examples.append(f"Algorithm {row.get('algorithm_id')}: {issues}")
    suffix = "" if len(rows) <= 8 else f"\n...and {len(rows) - 8} more algorithm issue(s)."
    return "\n".join(examples) + suffix


def ensure_baseline_available(
    selection_dialog: InputSelectionDialog,
    pseudocode_profile: PseudocodeProfile,
) -> Path | None:
    """Obtain, validate and if necessary calibrate a baseline dependency.

    This is the central v4.23 dependency guard used by routes that require a
    benchmark.  Cancelling or declining returns ``None`` and the requested
    dependent operation is not started.
    """
    if not selection_dialog.ask_yes_no(
        "Baseline benchmark required",
        "This operation requires a baseline benchmark.\n\n"
        "No benchmark has been provided for this run. Would you like to provide one now?",
    ):
        return None

    baseline_root = selection_dialog.select_optional_directory(
        "Select the Baseline benchmark folder containing pseudocode and python folders"
    )
    if baseline_root is None:
        return None

    report = validate_baseline(
        baseline_root,
        common_tests_root=DEFAULT_COMMON_TESTS_ROOT,
    )
    if not report.get("baseline_root_structure_valid") or report.get("issue_count", 0):
        pack = report.get("common_test_pack") or {}
        pack_note = ""
        if not pack.get("complete"):
            pack_note = (
                "\n\nPackaged Common Tests v1.1 are incomplete in this build. "
                "Baseline-local Tests.json files can be used only as a backward-compatible fallback."
            )
        selection_dialog.show_error(
            "Baseline benchmark is not ready",
            "The selected baseline did not pass preflight.\n\n"
            + (_baseline_problem_summary(report) or "Required baseline structure was not found.")
            + pack_note,
        )
        return None

    current_count = _current_baseline_calibration_count(baseline_root)
    if current_count < 50:
        if not selection_dialog.ask_yes_no(
            "Baseline calibration required",
            f"The selected baseline has {current_count}/50 current NL-FDEP v{PIPELINE_VERSION} "
            "calibrations.\n\nWould you like to calibrate it now and then continue with the selected operation?",
        ):
            return None
        calibration_result = run_baseline_folder(
            input_path=baseline_root,
            pseudocode_profile=pseudocode_profile,
        )
        after_count = _current_baseline_calibration_count(baseline_root)
        if after_count < 50:
            selection_dialog.show_info(
                "Baseline calibration completed with limitations",
                f"Calibration processing completed, but {after_count}/50 algorithms currently have "
                "evaluated v4.23 behavioural calibration. The requested operation will continue; "
                "algorithms without an eligible calibration will be reported as not evaluable.",
            )
        report_block = calibration_result.get("report", {})
        print("BASELINE CALIBRATION COMPLETE")
        print("=" * 52)
        print(f"Algorithms represented: {report_block.get('algorithm_count', 0)}")
        print(f"Calibration status counts: {report_block.get('calibration_status_counts', {})}")

    return baseline_root


def run_selected_pipeline(
    route: InputRoute,
    input_path: Path,
    pseudocode_profile: PseudocodeProfile | None = None,
    baseline_root: Path | None = None,
):
    """Route a selected source file/folder to its controlled pipeline."""
    if route == InputRoute.PSEUDOCODE:
        return run_pseudocode_pipeline(
            input_path=input_path,
            pseudocode_profile=pseudocode_profile or PseudocodeProfile.AJ_DIALECT_STRICT,
        )
    if route == InputRoute.FLOW_DIAGRAM:
        return run_flow_diagram_pipeline(input_path=input_path)
    if route == InputRoute.LLM_RESULTS_FOLDER:
        return run_llm_results_folder(
            input_path=input_path,
            pseudocode_profile=pseudocode_profile or PseudocodeProfile.GENERIC_COMPATIBILITY,
            baseline_root=baseline_root,
        )
    if route == InputRoute.BASELINE_BENCHMARK_FOLDER:
        return run_baseline_folder(
            input_path=input_path,
            pseudocode_profile=pseudocode_profile or PseudocodeProfile.GENERIC_COMPATIBILITY,
        )
    if route == InputRoute.HUMAN_REVIEW_FOLDER:
        return run_human_review_folder(input_path)
    raise ValueError(f"Unsupported input route: {route}")


def print_pipeline_report(result) -> None:
    """Print a concise pipeline report in the PyCharm console."""
    print("NL TO FLOW DIAGRAM ENCODER PIPELINE")
    print("=" * 52)
    for stage in result.stages:
        print(
            f"[{stage.status:7}] "
            f"{stage.name:<28} "
            f"{stage.duration_ms:>9.3f} ms  "
            f"{stage.message}"
        )
    print("\nOUTPUT FILES")
    for output_name, output_path in result.output_files.items():
        print(f"- {output_name}: {output_path}")
    if result.test_report is not None:
        print(
            "\nTests passed: "
            f"{result.test_report.passed_tests}/{len(result.test_report.results)}"
        )
    if not result.success:
        print(f"\nPipeline failed: {result.error or 'One or more tests failed.'}")


def main() -> None:
    """Select a route, satisfy its dependencies and run the correct pipeline."""
    selection_dialog = InputSelectionDialog()
    selected_profile = None
    selected_baseline_root = None

    try:
        selected_route = selection_dialog.select_route()

        if selected_route in {
            InputRoute.PSEUDOCODE,
            InputRoute.LLM_RESULTS_FOLDER,
            InputRoute.BASELINE_BENCHMARK_FOLDER,
        }:
            selected_profile = selection_dialog.select_pseudocode_profile()

        if selected_route in BASELINE_REQUIRED_ROUTES:
            selected_baseline_root = ensure_baseline_available(
                selection_dialog,
                selected_profile or PseudocodeProfile.GENERIC_COMPATIBILITY,
            )
            if selected_baseline_root is None:
                print("Selected operation cancelled because no ready baseline benchmark was provided.")
                return

        selected_file = selection_dialog.select_file(route=selected_route)

    except InputSelectionCancelledError as error:
        print(str(error))
        return

    pack_status = validate_common_test_pack(DEFAULT_COMMON_TESTS_ROOT)
    print(f"NL-FDEP pipeline version: {PIPELINE_VERSION}")
    print(f"Selected input type: {selected_route.value}")
    print(f"Selected file: {selected_file.resolve()}")
    if selected_profile is not None:
        print(f"Selected pseudocode profile: {selected_profile.value}")
    if selected_baseline_root is not None:
        print(f"Selected baseline root: {selected_baseline_root.resolve()}")
    print(
        "Packaged Common Tests v1.1: "
        f"{'READY' if pack_status.complete else 'INCOMPLETE'} "
        f"({pack_status.suite_count}/50 suites, {pack_status.test_count}/113 tests)"
    )

    result = run_selected_pipeline(
        route=selected_route,
        input_path=selected_file,
        pseudocode_profile=selected_profile,
        baseline_root=selected_baseline_root,
    )

    if selected_route == InputRoute.HUMAN_REVIEW_FOLDER:
        print("Human review session closed.")
    elif selected_route in {InputRoute.LLM_RESULTS_FOLDER, InputRoute.BASELINE_BENCHMARK_FOLDER}:
        report = result.get("report", {})
        print("STUDY BATCH COMPLETE")
        print("=" * 52)
        print(f"Dataset: {report.get('dataset')}")
        print(f"Algorithms represented: {report.get('algorithm_count', 0)}")
        print(f"Pipeline status counts: {report.get('pipeline_status_counts', report.get('status_counts', {}))}")
        if report.get('batch_type') == 'BASELINE':
            print(f"Baseline calibration counts: {report.get('calibration_status_counts', {})}")
            print(f"Mean baseline calibration score: {report.get('mean_baseline_calibration_percentage')}")
        elif report.get('batch_type') == 'LLM_RESULTS':
            print(f"Comparison to baseline: {report.get('comparison_to_baseline_counts', {})}")
            print(f"Mean experimental behavioural score: {report.get('mean_experimental_behavioural_percentage')}")
            print(f"Mean delta from baseline (percentage points): {report.get('mean_delta_from_baseline_percentage_points')}")
        common_pack = result.get("common_test_pack") or {}
        if common_pack:
            print(
                "Common Test Pack: "
                f"{'READY' if common_pack.get('complete') else 'INCOMPLETE'} "
                f"({common_pack.get('suite_count', 0)}/50 suites, {common_pack.get('test_count', 0)}/113 tests)"
            )
        print(f"Batch JSON: {result.get('json_path')}")
        print(f"Batch CSV: {result.get('csv_path')}")
    else:
        print_pipeline_report(result=result)


if __name__ == "__main__":
    main()
