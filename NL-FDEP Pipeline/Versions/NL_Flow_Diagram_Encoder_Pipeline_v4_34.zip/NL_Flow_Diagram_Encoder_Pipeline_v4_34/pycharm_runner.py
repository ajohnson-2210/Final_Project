"""Interactive PyCharm entry point for the controlled NL-FDEP routes."""

from __future__ import annotations

import json
import os
from pathlib import Path
import sys

PROJECT_ROOT = Path(__file__).resolve().parent
COMPONENT_DIRECTORIES = [
    PROJECT_ROOT / 'parser components',
    PROJECT_ROOT / 'compiler components',
    PROJECT_ROOT / 'flow diagram components',
    PROJECT_ROOT / 'pipeline components',
    PROJECT_ROOT / 'study components',
    PROJECT_ROOT / 'cli components',
]
for component_directory in reversed(COMPONENT_DIRECTORIES):
    component_path = str(component_directory)
    if component_path not in sys.path:
        sys.path.insert(0, component_path)

from aj_test_harness import TestCase
from common_test_resources import DEFAULT_COMMON_TESTS_ROOT, TEST_DESIGN_VERSION, validate_common_test_pack
from flow_input_pipeline import DrawIOFlowInputPipeline
from input_selection import (
    InputRoute,
    InputSelectionCancelledError,
    InputSelectionDialog,
)
from nl_flow_pipeline import NLFlowDiagramEncoderPipeline
from pseudocode_profiles import PseudocodeProfile
from study_batch import StudyBatchProcessor, discover_algorithm_folders
from study_provenance import validate_baseline
from study_review import launch_review_dashboard
from study_rubric import PIPELINE_VERSION


OUTPUT_DIRECTORY = Path("output")
OPEN_VISUALISATIONS = True
BASELINE_REQUIRED_ROUTES = {InputRoute.LLM_RESULTS_FOLDER}
BASELINE_CALIBRATION_PROFILE = PseudocodeProfile.AJ_DIALECT_STRICT
TERMINAL_BASELINE_STATUSES = {"SUCCESS", "FAILURE", "EXPECTED_FAILURE", "REVIEW_REQUIRED"}
RUNNER_STATE_SCHEMA_VERSION = "1.0"
RUNNER_STATE_FILE_ENV = "NL_FDEP_RUNNER_STATE_FILE"



def _runner_state_path() -> Path:
    """Return the per-user runner-state path used to remember the last baseline.

    The state file deliberately lives outside the checksummed release tree.  Tests
    and managed environments can override the location with
    ``NL_FDEP_RUNNER_STATE_FILE``.
    """
    override = os.environ.get(RUNNER_STATE_FILE_ENV)
    if override:
        return Path(override).expanduser()

    local_app_data = os.environ.get("LOCALAPPDATA")
    if local_app_data:
        return Path(local_app_data) / "NL-FDEP" / "runner_state.json"

    xdg_config_home = os.environ.get("XDG_CONFIG_HOME")
    if xdg_config_home:
        return Path(xdg_config_home) / "NL-FDEP" / "runner_state.json"

    return Path.home() / ".config" / "NL-FDEP" / "runner_state.json"


def _load_runner_state() -> dict:
    path = _runner_state_path()
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    return value if isinstance(value, dict) else {}


def _saved_baseline_root() -> Path | None:
    value = _load_runner_state().get("last_baseline_root")
    if not isinstance(value, str) or not value.strip():
        return None
    return Path(value).expanduser()


def _save_baseline_preference(baseline_root: Path) -> None:
    """Persist only the baseline location; readiness is always revalidated later."""
    path = _runner_state_path()
    payload = {
        "schema_version": RUNNER_STATE_SCHEMA_VERSION,
        "last_baseline_root": str(Path(baseline_root).resolve()),
        "last_selected_pipeline_version": PIPELINE_VERSION,
    }
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        temporary = path.with_name(path.name + ".tmp")
        temporary.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
        temporary.replace(path)
    except OSError as error:
        # Preference persistence is a convenience feature, not a reason to fail a run.
        print(f"WARNING: Could not save baseline runner preference: {error}")


def _clear_baseline_preference() -> None:
    path = _runner_state_path()
    try:
        path.unlink(missing_ok=True)
    except OSError as error:
        print(f"WARNING: Could not clear baseline runner preference: {error}")


TEST_CASES = [
    TestCase(
        name="Pipeline test",
        standard_input=[],
        expected_output=["6", "6"],
        timeout_seconds=3.0,
    )
]


def run_pseudocode_pipeline(input_path: Path, pseudocode_profile: PseudocodeProfile):
    """Run the canonical pipeline using a selected AJ pseudocode file."""
    pseudocode = input_path.read_text(encoding="utf-8")
    return NLFlowDiagramEncoderPipeline().run(
        pseudocode=pseudocode,
        output_directory=OUTPUT_DIRECTORY,
        test_cases=TEST_CASES,
        open_visualisations=OPEN_VISUALISATIONS,
        pseudocode_profile=pseudocode_profile,
    )


def run_flow_diagram_pipeline(input_path: Path):
    """Run the controlled draw.io import route."""
    return DrawIOFlowInputPipeline().run(
        input_path=input_path,
        output_directory=OUTPUT_DIRECTORY,
        test_cases=[],
        open_visualisations=OPEN_VISUALISATIONS,
    )


def run_llm_results_folder(
    input_path: Path,
    pseudocode_profile: PseudocodeProfile,
    baseline_root: Path | None = None,
):
    """Batch-process Algorithm - n folders using the selected benchmark oracle."""
    return StudyBatchProcessor().process_llm_results(
        results_directory=input_path,
        profile=pseudocode_profile,
        baseline_root=baseline_root,
        open_visualisations=False,
    )


def run_baseline_folder(input_path: Path, pseudocode_profile: PseudocodeProfile):
    """Process a runtime-selected baseline using the packaged Common Test design."""
    return StudyBatchProcessor().process_baseline(
        baseline_root=input_path,
        profile=pseudocode_profile,
        open_visualisations=False,
    )


def run_human_review_folder(input_path: Path):
    """Launch the integrated review dashboard for an algorithm parent folder."""
    launch_review_dashboard(input_path)
    return {"status": "REVIEW_SESSION_CLOSED", "review_root": str(input_path.resolve())}


def _normalise_llm_results_directory(selected_path: Path) -> Path | None:
    """Resolve a user-selected LLM root to the directory containing Algorithm - n folders.

    Accepted layouts are either::

        selected_root/Algorithm - 1/...

    or::

        selected_root/results/Algorithm - 1/...

    The second form matches the study export layout used by the LLM result sets.
    """
    selected_path = Path(selected_path)
    if not selected_path.is_dir():
        return None

    if discover_algorithm_folders(selected_path):
        return selected_path

    results_children = [
        child for child in selected_path.iterdir()
        if child.is_dir() and child.name.casefold() == "results"
    ]
    if len(results_children) == 1 and discover_algorithm_folders(results_children[0]):
        return results_children[0]

    return None


def select_llm_results_directory(
    selection_dialog: InputSelectionDialog,
    baseline_root: Path,
) -> Path:
    """Prompt explicitly for the experimental LLM dataset after baseline setup.

    A baseline folder cannot be silently reused as the LLM results folder. Invalid
    selections are explained and re-prompted until the user selects a usable LLM
    root or cancels the directory chooser.
    """
    selection_dialog.show_info(
        "Baseline benchmark ready",
        "The baseline benchmark is ready.\n\n"
        "Now select the LLM results dataset. You may select either:\n"
        "- the folder that directly contains 'Algorithm - 1' ... 'Algorithm - 50'; or\n"
        "- its parent folder when the Algorithm folders are inside a child folder named 'results'.",
    )

    baseline_resolved = Path(baseline_root).resolve()
    while True:
        selected_path = selection_dialog.select_file(route=InputRoute.LLM_RESULTS_FOLDER)
        selected_resolved = Path(selected_path).resolve()

        if selected_resolved == baseline_resolved:
            selection_dialog.show_error(
                "LLM results folder required",
                "The Baseline benchmark folder cannot also be used as the LLM results folder.\n\n"
                "Please select the experimental LLM dataset instead.",
            )
            continue

        normalised = _normalise_llm_results_directory(selected_path)
        if normalised is None:
            selection_dialog.show_error(
                "LLM results folder not recognised",
                "No 'Algorithm - n' folders were found in the selected directory.\n\n"
                "Select either the directory that directly contains the Algorithm folders, "
                "or their parent directory when they are inside a child folder named 'results'.",
            )
            continue

        if normalised.resolve() == baseline_resolved:
            selection_dialog.show_error(
                "LLM results folder required",
                "The resolved LLM results directory is the Baseline benchmark folder.\n\n"
                "Please select the experimental LLM dataset instead.",
            )
            continue

        return normalised


def _read_json(path: Path) -> dict | None:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else None
    except Exception:
        return None


def _current_baseline_state(baseline_root: Path, expected_ids=range(1, 51)) -> dict:
    """Summarise current baseline outcomes without conflating disagreement with availability."""
    state = {
        "terminal": 0,
        "evaluated": 0,
        "pipeline_failure": 0,
        "behavioural_not_evaluated": 0,
        "other_unavailable": 0,
    }
    for algorithm_id in expected_ids:
        artifact_directory = (
            Path(baseline_root)
            / "pseudocode"
            / f"Algorithm - {algorithm_id}"
            / "pipeline_artifacts"
        )
        manifest = _read_json(artifact_directory / "manifest.json") or {}
        calibration = (
            _read_json(artifact_directory / "baseline_calibration.json")
            or _read_json(artifact_directory / "baseline_python_comparison.json")
            or {}
        )
        if not (
            manifest.get("pipeline_version") == PIPELINE_VERSION
            and manifest.get("pseudocode_profile") == BASELINE_CALIBRATION_PROFILE.value
            and manifest.get("processing_status") in TERMINAL_BASELINE_STATUSES
        ):
            continue
        state["terminal"] += 1
        if (
            calibration.get("status") == "EVALUATED"
            and calibration.get("calibration_score_percentage") is not None
        ):
            state["evaluated"] += 1
        elif manifest.get("processing_status") == "FAILURE":
            state["pipeline_failure"] += 1
        elif manifest.get("processing_status") == "SUCCESS":
            state["behavioural_not_evaluated"] += 1
        else:
            state["other_unavailable"] += 1
    return state


def _current_baseline_calibration_count(baseline_root: Path, expected_ids=range(1, 51)) -> int:
    """Count current evaluated calibration measurements."""
    return _current_baseline_state(baseline_root, expected_ids)["evaluated"]


def _baseline_problem_summary(report: dict) -> str:
    rows = [row for row in report.get("algorithms", []) if row.get("status") != "READY"]
    examples = []
    for row in rows[:8]:
        issues = ", ".join(row.get("issues") or ["unknown issue"])
        examples.append(f"Algorithm {row.get('algorithm_id')}: {issues}")
    suffix = "" if len(rows) <= 8 else f"\n...and {len(rows) - 8} more algorithm issue(s)."
    return "\n".join(examples) + suffix


def ensure_baseline_available(
    selection_dialog: InputSelectionDialog,
    pseudocode_profile: PseudocodeProfile,
    baseline_root: Path | None = None,
) -> Path | None:
    """Obtain, validate and if necessary calibrate a baseline dependency.

    This is the central v4.29 dependency guard used by routes that require a
    benchmark.  Cancelling or declining returns ``None`` and the requested
    dependent operation is not started.
    """
    if baseline_root is None:
        if not selection_dialog.ask_yes_no(
            "Baseline benchmark required",
            "This operation requires a baseline benchmark.\n\n"
            "No ready benchmark has been discovered. Would you like to provide one now?",
        ):
            return None

        baseline_root = selection_dialog.select_optional_directory(
            "Select the Baseline benchmark folder containing pseudocode and python folders"
        )
        if baseline_root is None:
            return None
    else:
        baseline_root = Path(baseline_root)

    report = validate_baseline(
        baseline_root,
        common_tests_root=DEFAULT_COMMON_TESTS_ROOT,
    )
    if not report.get("baseline_root_structure_valid") or report.get("issue_count", 0):
        pack = report.get("common_test_pack") or {}
        pack_note = ""
        if not pack.get("complete"):
            pack_note = (
                f"\n\nPackaged Common Tests v{TEST_DESIGN_VERSION} are incomplete in this build. "
                "Baseline-local Tests.json files can be used only as a backward-compatible fallback."
            )
        selection_dialog.show_error(
            "Baseline benchmark is not ready",
            "The selected baseline did not pass preflight.\n\n"
            + (_baseline_problem_summary(report) or "Required baseline structure was not found.")
            + pack_note,
        )
        return None

    state = _current_baseline_state(baseline_root)
    if state["terminal"] < 50:
        if not selection_dialog.ask_yes_no(
            "Baseline calibration required",
            f"The selected baseline has {state['terminal']}/50 current NL-FDEP v{PIPELINE_VERSION} "
            "terminal calibration runs and "
            f"{state['evaluated']}/50 evaluated behavioural calibrations.\n\n"
            "Would you like to calibrate it now and then continue with the selected operation?",
        ):
            return None
        calibration_result = run_baseline_folder(
            input_path=baseline_root,
            pseudocode_profile=BASELINE_CALIBRATION_PROFILE,
        )
        state = _current_baseline_state(baseline_root)
        report_block = calibration_result.get("report", {})
        print("BASELINE CALIBRATION COMPLETE")
        print("=" * 52)
        print(f"Algorithms represented: {report_block.get('algorithm_count', 0)}")
        print(f"Calibration status counts: {report_block.get('calibration_status_counts', {})}")
        print(f"Evaluated behavioural calibrations: {state['evaluated']}/50")

    if state["evaluated"] < 50:
        unavailable = 50 - state["evaluated"]
        if not selection_dialog.ask_yes_no(
            "Baseline calibration has limitations",
            f"The selected benchmark has {state['evaluated']}/50 evaluated behavioural calibrations.\n\n"
            f"Unavailable for baseline-relative behavioural comparison: {unavailable}\n"
            f"- pipeline/structural failure: {state['pipeline_failure']}\n"
            f"- behavioural test not evaluable: {state['behavioural_not_evaluated']}\n"
            f"- other unavailable current outcomes: {state['other_unavailable']}\n\n"
            "You can continue. Algorithms without an eligible calibration will be reported as NOT_EVALUABLE "
            "for baseline-relative behavioural comparison rather than being assigned an invented score.\n\n"
            "Continue with the selected operation?",
        ):
            return None

    _save_baseline_preference(baseline_root)
    return baseline_root


def resolve_baseline_dependency(
    selection_dialog: InputSelectionDialog,
    pseudocode_profile: PseudocodeProfile,
) -> Path | None:
    """Reuse the last ready baseline across independent runner sessions when possible.

    The persisted value is only a path hint.  The benchmark is revalidated against
    the current pipeline/Common Test build on every dependent run.  Missing or
    structurally invalid saved paths are discarded and the normal baseline chooser
    is used.  A structurally valid but stale baseline follows the existing
    recalibration prompt and, when accepted, resumes the requested operation.
    """
    saved_root = _saved_baseline_root()
    if saved_root is None:
        return ensure_baseline_available(selection_dialog, pseudocode_profile)

    if not saved_root.is_dir():
        _clear_baseline_preference()
        selection_dialog.show_info(
            "Previously selected baseline unavailable",
            "The previously selected baseline benchmark could not be found:\n\n"
            f"{saved_root}\n\n"
            "Select a baseline benchmark to continue.",
        )
        return ensure_baseline_available(selection_dialog, pseudocode_profile)

    preflight = validate_baseline(saved_root, common_tests_root=DEFAULT_COMMON_TESTS_ROOT)
    if not preflight.get("baseline_root_structure_valid") or preflight.get("issue_count", 0):
        _clear_baseline_preference()
        selection_dialog.show_info(
            "Previously selected baseline is no longer ready",
            "The saved baseline path no longer passes the current baseline preflight:\n\n"
            f"{saved_root}\n\n"
            "Select another baseline benchmark to continue.",
        )
        return ensure_baseline_available(selection_dialog, pseudocode_profile)

    result = ensure_baseline_available(
        selection_dialog,
        pseudocode_profile,
        baseline_root=saved_root,
    )
    if result is not None:
        state = _current_baseline_state(result)
        selection_dialog.show_info(
            "Ready baseline benchmark detected",
            "Using the previously selected baseline benchmark for this operation:\n\n"
            f"{Path(result).resolve()}\n\n"
            f"Current NL-FDEP v{PIPELINE_VERSION} calibration: "
            f"{state['evaluated']}/50 behaviourally evaluated.",
        )
    return result


def run_selected_pipeline(
    route: InputRoute,
    input_path: Path,
    pseudocode_profile: PseudocodeProfile | None = None,
    baseline_root: Path | None = None,
):
    """Route a selected source file/folder to its controlled pipeline."""
    if route == InputRoute.PSEUDOCODE:
        return run_pseudocode_pipeline(
            input_path=input_path,
            pseudocode_profile=pseudocode_profile or PseudocodeProfile.AJ_DIALECT_STRICT,
        )
    if route == InputRoute.FLOW_DIAGRAM:
        return run_flow_diagram_pipeline(input_path=input_path)
    if route == InputRoute.LLM_RESULTS_FOLDER:
        return run_llm_results_folder(
            input_path=input_path,
            pseudocode_profile=pseudocode_profile or PseudocodeProfile.GENERIC_COMPATIBILITY,
            baseline_root=baseline_root,
        )
    if route == InputRoute.BASELINE_BENCHMARK_FOLDER:
        return run_baseline_folder(
            input_path=input_path,
            pseudocode_profile=pseudocode_profile or PseudocodeProfile.GENERIC_COMPATIBILITY,
        )
    if route == InputRoute.HUMAN_REVIEW_FOLDER:
        return run_human_review_folder(input_path)
    raise ValueError(f"Unsupported input route: {route}")


def print_pipeline_report(result) -> None:
    """Print a concise pipeline report in the PyCharm console."""
    print("NL TO FLOW DIAGRAM ENCODER PIPELINE")
    print("=" * 52)
    for stage in result.stages:
        print(
            f"[{stage.status:7}] "
            f"{stage.name:<28} "
            f"{stage.duration_ms:>9.3f} ms  "
            f"{stage.message}"
        )
    print("\nOUTPUT FILES")
    for output_name, output_path in result.output_files.items():
        print(f"- {output_name}: {output_path}")
    if result.test_report is not None:
        print(
            "\nTests passed: "
            f"{result.test_report.passed_tests}/{len(result.test_report.results)}"
        )
    if not result.success:
        print(f"\nPipeline failed: {result.error or 'One or more tests failed.'}")


def main() -> None:
    """Select a route, satisfy its dependencies and run the correct pipeline."""
    selection_dialog = InputSelectionDialog()
    selected_profile = None
    selected_baseline_root = None

    try:
        selected_route = selection_dialog.select_route()

        if selected_route in {
            InputRoute.PSEUDOCODE,
            InputRoute.LLM_RESULTS_FOLDER,
        }:
            selected_profile = selection_dialog.select_pseudocode_profile()
        elif selected_route == InputRoute.BASELINE_BENCHMARK_FOLDER:
            # Baseline calibration has one controlled study profile. Do not ask the
            # user to select a profile that can make benchmark calibration invalid.
            selected_profile = BASELINE_CALIBRATION_PROFILE

        if selected_route in BASELINE_REQUIRED_ROUTES:
            selected_baseline_root = resolve_baseline_dependency(
                selection_dialog,
                selected_profile,
            )
            if selected_baseline_root is None:
                print("Selected operation cancelled because no ready baseline benchmark was provided.")
                return

        if selected_route == InputRoute.LLM_RESULTS_FOLDER:
            selected_file = select_llm_results_directory(
                selection_dialog,
                selected_baseline_root,
            )
        else:
            selected_file = selection_dialog.select_file(route=selected_route)

    except InputSelectionCancelledError as error:
        print(str(error))
        return

    pack_status = validate_common_test_pack(DEFAULT_COMMON_TESTS_ROOT)
    print(f"NL-FDEP pipeline version: {PIPELINE_VERSION}")
    print(f"Selected input type: {selected_route.value}")
    print(f"Selected file: {selected_file.resolve()}")
    if selected_profile is not None:
        print(f"Selected pseudocode profile: {selected_profile.value}")
    if selected_baseline_root is not None:
        print(f"Selected baseline root: {selected_baseline_root.resolve()}")
    print(
        f"Packaged Common Tests v{TEST_DESIGN_VERSION}: "
        f"{'READY' if pack_status.complete else 'INCOMPLETE'} "
        f"({pack_status.suite_count}/50 suites, {pack_status.test_count}/113 tests)"
    )

    result = run_selected_pipeline(
        route=selected_route,
        input_path=selected_file,
        pseudocode_profile=selected_profile,
        baseline_root=selected_baseline_root,
    )

    if selected_route == InputRoute.BASELINE_BENCHMARK_FOLDER:
        baseline_state = _current_baseline_state(selected_file)
        if baseline_state["terminal"] == 50:
            _save_baseline_preference(selected_file)

    if selected_route == InputRoute.HUMAN_REVIEW_FOLDER:
        print("Human review session closed.")
    elif selected_route in {InputRoute.LLM_RESULTS_FOLDER, InputRoute.BASELINE_BENCHMARK_FOLDER}:
        report = result.get("report", {})
        print("STUDY BATCH COMPLETE")
        print("=" * 52)
        print(f"Dataset: {report.get('dataset')}")
        print(f"Algorithms represented: {report.get('algorithm_count', 0)}")
        print(f"Pipeline status counts: {report.get('pipeline_status_counts', report.get('status_counts', {}))}")
        if report.get('batch_type') == 'BASELINE':
            calibration_counts = report.get('calibration_status_counts', {}) or {}
            evaluated = int(report.get('evaluated_baseline_calibration_count') or 0)
            print(f"Baseline calibration counts: {calibration_counts}")
            print(f"Evaluated behavioural calibrations: {evaluated}/{report.get('algorithm_count', 0)}")
            print(f"Mean baseline calibration score: {report.get('mean_baseline_calibration_percentage')}")
            print("Note: pipeline FAILURE may represent measured behavioural disagreement; calibration availability is reported separately above.")
            structural_failures = int(calibration_counts.get('PIPELINE_FAILURE', 0))
            if structural_failures:
                print(f"WARNING: {structural_failures} algorithm(s) did not reach an evaluated baseline calibration.")
            unavailable = int(report.get('baseline_calibration_unavailable_count') or 0)
            if unavailable:
                print(
                    f"Baseline-relative behavioural comparison is available for {evaluated}/{report.get('algorithm_count', 0)} algorithms; "
                    f"the remaining {unavailable} will be reported as NOT_EVALUABLE if used experimentally."
                )
        elif report.get('batch_type') == 'LLM_RESULTS':
            print(f"Comparison to baseline: {report.get('comparison_to_baseline_counts', {})}")
            print(f"Mean experimental semantic behavioural score: {report.get('mean_experimental_behavioural_percentage')}")
            print(f"Mean delta from baseline (percentage points): {report.get('mean_delta_from_baseline_percentage_points')}")
            semantic_evaluable=int(report.get('semantic_tests_evaluable') or 0)
            semantic_passed=int(report.get('semantic_tests_passed') or 0)
            semantic_ne=int(report.get('semantic_tests_not_evaluable') or 0)
            if semantic_evaluable or semantic_ne:
                print(f"Task-semantic Common Tests: {semantic_passed}/{semantic_evaluable} passed; {semantic_ne} not evaluable/reference-only")
                print(f"Aggregate task-semantic test accuracy: {report.get('semantic_test_accuracy_percentage')}")
        common_pack = result.get("common_test_pack") or {}
        if common_pack:
            print(
                "Common Test Pack: "
                f"{'READY' if common_pack.get('complete') else 'INCOMPLETE'} "
                f"({common_pack.get('suite_count', 0)}/50 suites, {common_pack.get('test_count', 0)}/113 tests)"
            )
        print(f"Batch JSON: {result.get('json_path')}")
        print(f"Batch CSV: {result.get('csv_path')}")
    else:
        print_pipeline_report(result=result)


if __name__ == "__main__":
    main()
