"""Interactive PyCharm entry point for the controlled NL-FDEP routes."""

from __future__ import annotations

import json
import os
from pathlib import Path
import sys

PROJECT_ROOT = Path(__file__).resolve().parent
COMPONENT_DIRECTORIES = [
    PROJECT_ROOT / 'parser components',
    PROJECT_ROOT / 'compiler components',
    PROJECT_ROOT / 'flow diagram components',
    PROJECT_ROOT / 'pipeline components',
    PROJECT_ROOT / 'study components',
    PROJECT_ROOT / 'cli components',
]
for component_directory in reversed(COMPONENT_DIRECTORIES):
    component_path = str(component_directory)
    if component_path not in sys.path:
        sys.path.insert(0, component_path)

from aj_test_harness import TestCase
from common_test_resources import DEFAULT_COMMON_TESTS_ROOT, TEST_DESIGN_VERSION, validate_common_test_pack
from flow_input_pipeline import DrawIOFlowInputPipeline
from input_selection import (
    BaselineStartupAction,
    InputRoute,
    InputSelectionCancelledError,
    InputSelectionDialog,
    PostLLMAction,
)
from nl_flow_pipeline import NLFlowDiagramEncoderPipeline
from pseudocode_profiles import PseudocodeProfile
from study_batch import StudyBatchProcessor, discover_algorithm_folders
from study_provenance import validate_baseline
from study_review import launch_review_dashboard
from study_rubric import PIPELINE_VERSION


OUTPUT_DIRECTORY = Path("output")
OPEN_VISUALISATIONS = True
BASELINE_REQUIRED_ROUTES = {InputRoute.LLM_RESULTS_FOLDER}
BASELINE_CALIBRATION_PROFILE = PseudocodeProfile.AJ_DIALECT_STRICT
TERMINAL_BASELINE_STATUSES = {"SUCCESS", "FAILURE", "EXPECTED_FAILURE", "REVIEW_REQUIRED"}
RUNNER_STATE_SCHEMA_VERSION = "1.1"
RUNNER_STATE_PURPOSE = "SESSION_CRASH_RECOVERY_HINT"
RUNNER_STATE_FILE_ENV = "NL_FDEP_RUNNER_STATE_FILE"

# Session-only acknowledgement of a deliberately degraded 49/50 baseline gate.
# This is never persisted and never supplied to experimental scoring.
_DEGRADED_BASELINE_SESSION_OVERRIDES: dict[str, dict] = {}



def _runner_state_path() -> Path:
    """Return the per-user path for the temporary baseline recovery hint.

    The file deliberately lives outside the checksummed release tree so an
    unexpectedly terminated runner can expose the last established baseline as an
    explicit recovery hint on the next launch.  Orderly runner exits delete it.
    Tests and managed environments can override the location with
    ``NL_FDEP_RUNNER_STATE_FILE``.
    """
    override = os.environ.get(RUNNER_STATE_FILE_ENV)
    if override:
        return Path(override).expanduser()

    local_app_data = os.environ.get("LOCALAPPDATA")
    if local_app_data:
        return Path(local_app_data) / "NL-FDEP" / "runner_state.json"

    xdg_config_home = os.environ.get("XDG_CONFIG_HOME")
    if xdg_config_home:
        return Path(xdg_config_home) / "NL-FDEP" / "runner_state.json"

    return Path.home() / ".config" / "NL-FDEP" / "runner_state.json"


def _load_runner_state() -> dict:
    path = _runner_state_path()
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    return value if isinstance(value, dict) else {}


def _saved_baseline_root() -> Path | None:
    value = _load_runner_state().get("last_baseline_root")
    if not isinstance(value, str) or not value.strip():
        return None
    return Path(value).expanduser()


def _save_baseline_preference(baseline_root: Path) -> None:
    """Write a temporary crash-recovery hint for the active session baseline.

    The historical function name is retained for regression compatibility.  The
    file is not a durable preference: orderly runner exits delete it, and any hint
    found at startup must still be explicitly accepted and fully revalidated.
    """
    path = _runner_state_path()
    payload = {
        "schema_version": RUNNER_STATE_SCHEMA_VERSION,
        "state_purpose": RUNNER_STATE_PURPOSE,
        "last_baseline_root": str(Path(baseline_root).resolve()),
        "last_selected_pipeline_version": PIPELINE_VERSION,
    }
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        temporary = path.with_name(path.name + ".tmp")
        temporary.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
        temporary.replace(path)
    except OSError as error:
        # Recovery-hint persistence is a convenience feature, not a reason to fail a run.
        print(f"WARNING: Could not save baseline recovery hint: {error}")


def _clear_baseline_preference() -> None:
    path = _runner_state_path()
    try:
        path.unlink(missing_ok=True)
    except OSError as error:
        print(f"WARNING: Could not clear baseline recovery hint: {error}")


TEST_CASES = [
    TestCase(
        name="Pipeline test",
        standard_input=[],
        expected_output=["6", "6"],
        timeout_seconds=3.0,
    )
]


def run_pseudocode_pipeline(input_path: Path, pseudocode_profile: PseudocodeProfile):
    """Run the canonical pipeline using a selected AJ pseudocode file."""
    pseudocode = input_path.read_text(encoding="utf-8")
    return NLFlowDiagramEncoderPipeline().run(
        pseudocode=pseudocode,
        output_directory=OUTPUT_DIRECTORY,
        test_cases=TEST_CASES,
        open_visualisations=OPEN_VISUALISATIONS,
        pseudocode_profile=pseudocode_profile,
    )


def run_flow_diagram_pipeline(input_path: Path):
    """Run the controlled draw.io import route."""
    return DrawIOFlowInputPipeline().run(
        input_path=input_path,
        output_directory=OUTPUT_DIRECTORY,
        test_cases=[],
        open_visualisations=OPEN_VISUALISATIONS,
    )


def run_llm_results_folder(
    input_path: Path,
    pseudocode_profile: PseudocodeProfile,
):
    """Batch-process Algorithm - n folders using frozen static semantic expectations.

    The procedural baseline-readiness gate is enforced by ``main`` before this
    function is called.  The baseline path is deliberately not accepted here, so
    experimental scoring cannot consult the benchmark at runtime.
    """
    return StudyBatchProcessor().process_llm_results(
        results_directory=input_path,
        profile=pseudocode_profile,
        baseline_root=None,
        open_visualisations=False,
    )


def run_baseline_folder(input_path: Path, pseudocode_profile: PseudocodeProfile):
    """Process a runtime-selected baseline using the packaged Common Test design."""
    return StudyBatchProcessor().process_baseline(
        baseline_root=input_path,
        profile=pseudocode_profile,
        open_visualisations=False,
    )


def run_human_review_folder(input_path: Path | list[Path]):
    """Launch the integrated LLM-only review dashboard for one or more datasets."""
    roots = [Path(value) for value in input_path] if isinstance(input_path, list) else [Path(input_path)]
    opened = launch_review_dashboard(roots)
    return {
        "status": "REVIEW_SESSION_CLOSED" if opened else "NO_REVIEWABLE_LLM_DATASETS",
        "review_roots": [str(value.resolve()) for value in roots],
    }


def _normalise_llm_results_directory(selected_path: Path) -> Path | None:
    """Resolve a user-selected LLM root to the directory containing Algorithm - n folders.

    Accepted layouts are either::

        selected_root/Algorithm - 1/...

    or::

        selected_root/results/Algorithm - 1/...

    The second form matches the study export layout used by the LLM result sets.
    """
    selected_path = Path(selected_path)
    if not selected_path.is_dir():
        return None

    if discover_algorithm_folders(selected_path):
        return selected_path

    results_children = [
        child for child in selected_path.iterdir()
        if child.is_dir() and child.name.casefold() == "results"
    ]
    if len(results_children) == 1 and discover_algorithm_folders(results_children[0]):
        return results_children[0]

    return None


def select_llm_results_directory(
    selection_dialog: InputSelectionDialog,
    baseline_root: Path | None = None,
) -> Path:
    """Prompt explicitly for the experimental LLM dataset.

    v4.35 experimental scoring is baseline-independent.  ``baseline_root`` is
    the already validated procedural readiness-gate path and is used here only
    to prevent accidentally selecting the benchmark itself as the experimental
    dataset.  It is never used to generate or score expected results. Invalid selections are explained and
    re-prompted until the user selects a usable LLM root or cancels the chooser.
    """
    selection_dialog.show_info(
        "Select LLM results dataset",
        "Select the LLM results dataset. You may select either:\n"
        "- the folder that directly contains 'Algorithm - 1' ... 'Algorithm - 50'; or\n"
        "- its parent folder when the Algorithm folders are inside a child folder named 'results'.",
    )

    baseline_resolved = Path(baseline_root).resolve() if baseline_root is not None else None
    while True:
        selected_path = selection_dialog.select_file(route=InputRoute.LLM_RESULTS_FOLDER)
        selected_resolved = Path(selected_path).resolve()

        if baseline_resolved is not None and selected_resolved == baseline_resolved:
            selection_dialog.show_error(
                "LLM results folder required",
                "The Baseline benchmark folder cannot also be used as the LLM results folder.\n\n"
                "Please select the experimental LLM dataset instead.",
            )
            continue

        normalised = _normalise_llm_results_directory(selected_path)
        if normalised is None:
            selection_dialog.show_error(
                "LLM results folder not recognised",
                "No 'Algorithm - n' folders were found in the selected directory.\n\n"
                "Select either the directory that directly contains the Algorithm folders, "
                "or their parent directory when they are inside a child folder named 'results'.",
            )
            continue

        if baseline_resolved is not None and normalised.resolve() == baseline_resolved:
            selection_dialog.show_error(
                "LLM results folder required",
                "The resolved LLM results directory is the Baseline benchmark folder.\n\n"
                "Please select the experimental LLM dataset instead.",
            )
            continue

        return normalised


def _read_json(path: Path) -> dict | None:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else None
    except Exception:
        return None


def _current_baseline_state(baseline_root: Path, expected_ids=range(1, 51)) -> dict:
    """Summarise current baseline outcomes without conflating disagreement with availability."""
    state = {
        "terminal": 0,
        "evaluated": 0,
        "full_score": 0,
        "pipeline_failure": 0,
        "behavioural_not_evaluated": 0,
        "other_unavailable": 0,
    }
    for algorithm_id in expected_ids:
        artifact_directory = (
            Path(baseline_root)
            / "pseudocode"
            / f"Algorithm - {algorithm_id}"
            / "pipeline_artifacts"
        )
        manifest = _read_json(artifact_directory / "manifest.json") or {}
        calibration = (
            _read_json(artifact_directory / "baseline_calibration.json")
            or _read_json(artifact_directory / "baseline_python_comparison.json")
            or {}
        )
        if not (
            manifest.get("pipeline_version") == PIPELINE_VERSION
            and manifest.get("pseudocode_profile") == BASELINE_CALIBRATION_PROFILE.value
            and manifest.get("processing_status") in TERMINAL_BASELINE_STATUSES
        ):
            continue
        state["terminal"] += 1
        if (
            calibration.get("status") == "EVALUATED"
            and calibration.get("calibration_score_percentage") is not None
        ):
            state["evaluated"] += 1
            try:
                score = float(calibration.get("calibration_score_percentage"))
            except (TypeError, ValueError):
                score = None
            if score is not None and abs(score - 100.0) <= 1e-9:
                state["full_score"] += 1
        elif manifest.get("processing_status") == "FAILURE":
            state["pipeline_failure"] += 1
        elif manifest.get("processing_status") == "SUCCESS":
            state["behavioural_not_evaluated"] += 1
        else:
            state["other_unavailable"] += 1
    return state


def _current_baseline_calibration_count(baseline_root: Path, expected_ids=range(1, 51)) -> int:
    """Count current evaluated calibration measurements."""
    return _current_baseline_state(baseline_root, expected_ids)["evaluated"]


def _baseline_study_ready(state: dict) -> bool:
    """Return whether the benchmark satisfies the v4.35 experimental readiness gate."""
    return (
        int(state.get("terminal", 0)) == 50
        and int(state.get("evaluated", 0)) == 50
        and int(state.get("full_score", 0)) == 50
    )


def _baseline_problem_summary(report: dict) -> str:
    rows = [row for row in report.get("algorithms", []) if row.get("status") != "READY"]
    examples = []
    for row in rows[:8]:
        issues = ", ".join(row.get("issues") or ["unknown issue"])
        examples.append(f"Algorithm {row.get('algorithm_id')}: {issues}")
    suffix = "" if len(rows) <= 8 else f"\n...and {len(rows) - 8} more algorithm issue(s)."
    return "\n".join(examples) + suffix


def _baseline_override_key(baseline_root: Path) -> str:
    try:
        return str(Path(baseline_root).resolve())
    except OSError:
        return str(Path(baseline_root).absolute())


def _baseline_calibration_problem_details(
    baseline_root: Path,
    report: dict | None = None,
    expected_ids=range(1, 51),
) -> list[dict]:
    """Return current non-100%-calibrated algorithms with the best available reason.

    The latest baseline batch report is used for human-readable runtime errors (for
    example a missing optional dependency).  Current manifests/calibration files remain
    authoritative for deciding whether an algorithm is actually ready.
    """
    baseline_root = Path(baseline_root)
    if report is None:
        report = _read_json(baseline_root / "study_analysis" / "batch_report.json") or {}
    report_rows = {
        int(row.get("algorithm_id")): row
        for row in report.get("algorithms", [])
        if isinstance(row, dict) and str(row.get("algorithm_id", "")).isdigit()
    }
    problems: list[dict] = []
    for algorithm_id in expected_ids:
        artifact_directory = (
            baseline_root / "pseudocode" / f"Algorithm - {algorithm_id}" / "pipeline_artifacts"
        )
        manifest = _read_json(artifact_directory / "manifest.json") or {}
        calibration = (
            _read_json(artifact_directory / "baseline_calibration.json")
            or _read_json(artifact_directory / "baseline_python_comparison.json")
            or {}
        )
        current_terminal = (
            manifest.get("pipeline_version") == PIPELINE_VERSION
            and manifest.get("pseudocode_profile") == BASELINE_CALIBRATION_PROFILE.value
            and manifest.get("processing_status") in TERMINAL_BASELINE_STATUSES
        )
        score = calibration.get("calibration_score_percentage")
        try:
            numeric_score = float(score) if score is not None else None
        except (TypeError, ValueError):
            numeric_score = None
        fully_calibrated = (
            current_terminal
            and calibration.get("status") == "EVALUATED"
            and numeric_score is not None
            and abs(numeric_score - 100.0) <= 1e-9
        )
        if fully_calibrated:
            continue

        row = report_rows.get(int(algorithm_id), {})
        pipeline_report = _read_json(artifact_directory / "pipeline_report.json") or {}
        if not current_terminal:
            category = "CURRENT_CALIBRATION_MISSING_OR_STALE"
        elif manifest.get("processing_status") == "FAILURE":
            category = "PIPELINE_FAILURE"
        elif calibration.get("status") != "EVALUATED":
            category = str(calibration.get("status") or "BEHAVIOURAL_NOT_EVALUATED")
        elif numeric_score is not None and abs(numeric_score - 100.0) > 1e-9:
            category = "CALIBRATION_BELOW_100"
        else:
            category = "CALIBRATION_UNAVAILABLE"

        reason = (
            row.get("error")
            or pipeline_report.get("error")
            or calibration.get("reason")
        )
        if not reason and category == "CALIBRATION_BELOW_100":
            reason = f"Calibration score is {numeric_score:g}% rather than the required 100%."
        if not reason:
            reason = (
                f"processing_status={manifest.get('processing_status') or 'missing'}; "
                f"calibration_status={calibration.get('status') or 'missing'}"
            )
        problems.append({
            "algorithm_id": int(algorithm_id),
            "category": category,
            "reason": str(reason),
            "processing_status": manifest.get("processing_status"),
            "calibration_status": calibration.get("status"),
            "calibration_score_percentage": numeric_score,
        })
    return problems


def _format_baseline_calibration_problems(problems: list[dict], limit: int = 8) -> str:
    if not problems:
        return "No individual calibration problem could be identified."
    rows = []
    for problem in problems[:limit]:
        rows.append(
            f"Algorithm {problem.get('algorithm_id')}: {problem.get('category')}\n"
            f"Reason: {problem.get('reason')}"
        )
    if len(problems) > limit:
        rows.append(f"...and {len(problems) - limit} more calibration problem(s).")
    return "\n\n".join(rows)


def _degraded_baseline_override_eligible(state: dict, problems: list[dict]) -> bool:
    """Allow an explicit override only for one unavailable calibration, never a sub-100 score."""
    return (
        int(state.get("terminal", 0)) == 50
        and int(state.get("evaluated", 0)) == 49
        and int(state.get("full_score", 0)) == 49
        and len(problems) == 1
        and problems[0].get("category") != "CALIBRATION_BELOW_100"
    )


def _register_degraded_baseline_override(baseline_root: Path, state: dict, problems: list[dict]) -> None:
    _DEGRADED_BASELINE_SESSION_OVERRIDES[_baseline_override_key(baseline_root)] = {
        "evaluated": int(state.get("evaluated", 0)),
        "full_score": int(state.get("full_score", 0)),
        "unavailable_algorithm_ids": tuple(sorted(int(p["algorithm_id"]) for p in problems)),
    }


def _clear_degraded_baseline_override(baseline_root: Path | None = None) -> None:
    if baseline_root is None:
        _DEGRADED_BASELINE_SESSION_OVERRIDES.clear()
        return
    _DEGRADED_BASELINE_SESSION_OVERRIDES.pop(_baseline_override_key(baseline_root), None)


def _baseline_session_ready(baseline_root: Path, state: dict | None = None) -> bool:
    """Return strict readiness or a still-valid, explicitly accepted 49/50 session override."""
    state = state or _current_baseline_state(baseline_root)
    if _baseline_study_ready(state):
        return True
    accepted = _DEGRADED_BASELINE_SESSION_OVERRIDES.get(_baseline_override_key(baseline_root))
    if not accepted:
        return False
    problems = _baseline_calibration_problem_details(baseline_root)
    if not _degraded_baseline_override_eligible(state, problems):
        return False
    current_ids = tuple(sorted(int(p["algorithm_id"]) for p in problems))
    return (
        current_ids == tuple(accepted.get("unavailable_algorithm_ids", ()))
        and int(state.get("evaluated", 0)) == int(accepted.get("evaluated", -1))
        and int(state.get("full_score", 0)) == int(accepted.get("full_score", -1))
    )


def ensure_baseline_available(
    selection_dialog: InputSelectionDialog,
    pseudocode_profile: PseudocodeProfile,
    baseline_root: Path | None = None,
    require_full_study_readiness: bool = False,
    persist_preference: bool = True,
    force_recalibration: bool = False,
) -> Path | None:
    """Obtain, validate and if necessary calibrate a baseline dependency.

    When ``require_full_study_readiness`` is true, the benchmark is a procedural
    gate only: all 50 algorithms must have current evaluated calibrations and all
    50 must score 100%.  This establishes study readiness before an experimental
    LLM run, but the baseline is not supplied to experimental scoring.

    Cancelling or declining returns ``None`` and the requested dependent
    operation is not started.
    """
    if baseline_root is None:
        if not selection_dialog.ask_yes_no(
            "Baseline benchmark required",
            "This operation requires a baseline benchmark.\n\n"
            "No ready benchmark has been discovered. Would you like to provide one now?",
        ):
            return None

        baseline_root = selection_dialog.select_optional_directory(
            "Select the Baseline benchmark folder containing pseudocode and python folders"
        )
        if baseline_root is None:
            return None
    else:
        baseline_root = Path(baseline_root)

    report = validate_baseline(
        baseline_root,
        common_tests_root=DEFAULT_COMMON_TESTS_ROOT,
    )
    if not report.get("baseline_root_structure_valid") or report.get("issue_count", 0):
        pack = report.get("common_test_pack") or {}
        pack_note = ""
        if not pack.get("complete"):
            pack_note = (
                f"\n\nPackaged Common Tests v{TEST_DESIGN_VERSION} are incomplete in this build. "
                "Baseline-local Tests.json files can be used only as a backward-compatible fallback."
            )
        selection_dialog.show_error(
            "Baseline benchmark is not ready",
            "The selected baseline did not pass preflight.\n\n"
            + (_baseline_problem_summary(report) or "Required baseline structure was not found.")
            + pack_note,
        )
        return None

    state = _current_baseline_state(baseline_root)
    calibration_needed = force_recalibration or (
        not _baseline_study_ready(state)
        if require_full_study_readiness
        else state["terminal"] < 50
    )
    if calibration_needed:
        if require_full_study_readiness:
            readiness_detail = (
                f"Current NL-FDEP v{PIPELINE_VERSION} readiness:\n"
                f"- terminal calibration runs: {state['terminal']}/50\n"
                f"- behaviourally evaluated: {state['evaluated']}/50\n"
                f"- calibration score 100%: {state.get('full_score', 0)}/50\n\n"
                "The normal study-readiness gate is 50/50 fully calibrated. Would you like "
                "to calibrate it now and then resume the selected LLM operation? If exactly "
                "one algorithm remains unavailable after calibration, an explicit degraded "
                "49/50 continuation option may be offered with the failure reason shown."
            )
        else:
            readiness_detail = (
                f"The selected baseline has {state['terminal']}/50 current NL-FDEP v{PIPELINE_VERSION} "
                "terminal calibration runs and "
                f"{state['evaluated']}/50 evaluated behavioural calibrations.\n\n"
                "Would you like to calibrate it now and then continue with the selected operation?"
            )

        # Choosing the explicit "Choose baseline folder and recalibrate" action is
        # itself authorisation for the calibration; do not ask a redundant second
        # yes/no question.  Other stale/missing-currentness paths still require
        # the existing confirmation.
        if not force_recalibration and not selection_dialog.ask_yes_no(
            "Baseline calibration required",
            readiness_detail,
        ):
            return None
        calibration_result = run_baseline_folder(
            input_path=baseline_root,
            pseudocode_profile=BASELINE_CALIBRATION_PROFILE,
        )
        state = _current_baseline_state(baseline_root)
        report_block = calibration_result.get("report", {})
        print("BASELINE CALIBRATION COMPLETE")
        print("=" * 52)
        print(f"Algorithms represented: {report_block.get('algorithm_count', 0)}")
        print(f"Calibration status counts: {report_block.get('calibration_status_counts', {})}")
        print(f"Evaluated behavioural calibrations: {state['evaluated']}/50")
        if require_full_study_readiness:
            print(f"100% calibration outcomes: {state.get('full_score', 0)}/50")

    if require_full_study_readiness:
        if _baseline_study_ready(state):
            _clear_degraded_baseline_override(baseline_root)
        else:
            problems = _baseline_calibration_problem_details(
                baseline_root,
                report=(calibration_result.get("report", {}) if calibration_needed else None),
            )
            detail = _format_baseline_calibration_problems(problems)
            if _degraded_baseline_override_eligible(state, problems):
                unavailable_id = problems[0].get("algorithm_id")
                if not selection_dialog.ask_yes_no(
                    "Baseline calibration incomplete — continue with 49/50?",
                    "The baseline calibration completed with 49/50 fully evaluated calibrations "
                    "scoring 100%. One algorithm is unavailable.\n\n"
                    f"{detail}\n\n"
                    "Normal study readiness remains 50/50. If you continue, this process will be "
                    "marked as DEGRADED_49_OF_50_OVERRIDE for the current session only. The "
                    f"unavailable Algorithm {unavailable_id} will remain explicitly uncalibrated, "
                    "and the baseline will still be used only as a procedural readiness gate — it "
                    "will not be supplied to experimental scoring.\n\n"
                    "Would you like to proceed with the 49 fully calibrated baseline algorithms?",
                ):
                    return None
                _register_degraded_baseline_override(baseline_root, state, problems)
            else:
                selection_dialog.show_error(
                    "Baseline calibration is not study-ready",
                    "The selected benchmark does not satisfy the v4.35 experimental readiness gate.\n\n"
                    f"Required: 50/50 behaviourally evaluated and 50/50 scoring 100%.\n"
                    f"Current: {state['evaluated']}/50 evaluated; "
                    f"{state.get('full_score', 0)}/50 scoring 100%.\n\n"
                    f"Calibration problem details:\n{detail}\n\n"
                    "A degraded continuation is offered only when exactly 49/50 algorithms are fully "
                    "calibrated at 100% and the remaining algorithm is unavailable rather than "
                    "behaviourally below 100%. The LLM operation has not started.",
                )
                return None
    elif state["evaluated"] < 50:
        unavailable = 50 - state["evaluated"]
        if not selection_dialog.ask_yes_no(
            "Baseline calibration has limitations",
            f"The selected benchmark has {state['evaluated']}/50 evaluated behavioural calibrations.\n\n"
            f"Unavailable for baseline-relative behavioural comparison: {unavailable}\n"
            f"- pipeline/structural failure: {state['pipeline_failure']}\n"
            f"- behavioural test not evaluable: {state['behavioural_not_evaluated']}\n"
            f"- other unavailable current outcomes: {state['other_unavailable']}\n\n"
            "You can continue. Algorithms without an eligible calibration will be reported as NOT_EVALUABLE "
            "for baseline-relative behavioural comparison rather than being assigned an invented score.\n\n"
            "Continue with the selected operation?",
        ):
            return None

    if persist_preference:
        _save_baseline_preference(baseline_root)
    return baseline_root


def establish_session_baseline(
    selection_dialog: InputSelectionDialog,
    pseudocode_profile: PseudocodeProfile,
) -> Path | None:
    """Establish one explicit study-ready baseline for the current LLM session.

    On the first LLM operation in a process, any runner-state file left by an
    unfinished or legacy session is treated only as a recovery hint.  If a previous
    benchmark is found, the user must explicitly choose whether to reuse it or choose
    a baseline folder and recalibrate.  If no previous benchmark is found, the user is
    directed straight to the baseline-folder chooser and the selected benchmark is
    calibrated when necessary.

    Once established, the baseline remains in memory for subsequent LLM folders in
    the same process.  It is a procedural readiness gate only and is never forwarded
    into experimental semantic scoring.
    """
    saved_root = _saved_baseline_root()

    if saved_root is not None:
        saved_root = Path(saved_root).expanduser()
        if not saved_root.is_dir():
            _clear_baseline_preference()
            selection_dialog.show_info(
                "Previously selected baseline unavailable",
                "A previously selected baseline was recorded, but the folder can no longer be found:\n\n"
                f"{saved_root}\n\n"
                "Select a baseline benchmark folder to establish the study-readiness gate.",
            )
            saved_root = None
        else:
            preflight = validate_baseline(saved_root, common_tests_root=DEFAULT_COMMON_TESTS_ROOT)
            if not preflight.get("baseline_root_structure_valid") or preflight.get("issue_count", 0):
                _clear_baseline_preference()
                selection_dialog.show_info(
                    "Previously selected baseline is no longer valid",
                    "A previous baseline folder was detected, but it no longer passes the current "
                    "baseline preflight:\n\n"
                    f"{saved_root}\n\n"
                    "Select a baseline benchmark folder to establish the study-readiness gate.",
                )
                saved_root = None

    if saved_root is not None:
        detected_state = _current_baseline_state(saved_root)
        action = selection_dialog.select_detected_baseline_action(
            saved_root,
            _baseline_study_ready(detected_state),
        )
        if action == BaselineStartupAction.QUIT:
            return None
        if action == BaselineStartupAction.USE_DETECTED_BASELINE:
            return ensure_baseline_available(
                selection_dialog,
                pseudocode_profile,
                baseline_root=saved_root,
                require_full_study_readiness=True,
                persist_preference=True,
            )
        if action != BaselineStartupAction.CHOOSE_AND_RECALIBRATE:
            raise ValueError(f"Unsupported baseline startup action: {action}")

        chosen_root = selection_dialog.select_optional_directory(
            "Select the Baseline benchmark folder to recalibrate"
        )
        if chosen_root is None:
            return None
        return ensure_baseline_available(
            selection_dialog,
            pseudocode_profile,
            baseline_root=chosen_root,
            require_full_study_readiness=True,
            persist_preference=True,
            force_recalibration=True,
        )

    selection_dialog.show_info(
        "Baseline benchmark required",
        "No previously selected baseline benchmark was detected.\n\n"
        "Select the trusted Baseline benchmark folder. It will be validated and, "
        "when necessary, calibrated before the LLM dataset is selected.",
    )
    chosen_root = selection_dialog.select_optional_directory(
        "Select the Baseline benchmark folder containing pseudocode and python folders"
    )
    if chosen_root is None:
        return None

    return ensure_baseline_available(
        selection_dialog,
        pseudocode_profile,
        baseline_root=chosen_root,
        require_full_study_readiness=True,
        persist_preference=True,
    )



def run_selected_pipeline(
    route: InputRoute,
    input_path: Path,
    pseudocode_profile: PseudocodeProfile | None = None,
    baseline_root: Path | None = None,
):
    """Route a selected source file/folder to its controlled pipeline."""
    if route == InputRoute.PSEUDOCODE:
        return run_pseudocode_pipeline(
            input_path=input_path,
            pseudocode_profile=pseudocode_profile or PseudocodeProfile.AJ_DIALECT_STRICT,
        )
    if route == InputRoute.FLOW_DIAGRAM:
        return run_flow_diagram_pipeline(input_path=input_path)
    if route == InputRoute.LLM_RESULTS_FOLDER:
        # The baseline has already served its procedural readiness-gate role in
        # ``main``.  Do not forward its path into experimental scoring.
        return run_llm_results_folder(
            input_path=input_path,
            pseudocode_profile=pseudocode_profile or PseudocodeProfile.GENERIC_COMPATIBILITY,
        )
    if route == InputRoute.BASELINE_BENCHMARK_FOLDER:
        return run_baseline_folder(
            input_path=input_path,
            pseudocode_profile=pseudocode_profile or PseudocodeProfile.GENERIC_COMPATIBILITY,
        )
    if route == InputRoute.HUMAN_REVIEW_FOLDER:
        return run_human_review_folder(input_path)
    raise ValueError(f"Unsupported input route: {route}")


def print_pipeline_report(result) -> None:
    """Print a concise pipeline report in the PyCharm console."""
    print("NL TO FLOW DIAGRAM ENCODER PIPELINE")
    print("=" * 52)
    for stage in result.stages:
        print(
            f"[{stage.status:7}] "
            f"{stage.name:<28} "
            f"{stage.duration_ms:>9.3f} ms  "
            f"{stage.message}"
        )
    print("\nOUTPUT FILES")
    for output_name, output_path in result.output_files.items():
        print(f"- {output_name}: {output_path}")
    if result.test_report is not None:
        print(
            "\nTests passed: "
            f"{result.test_report.passed_tests}/{len(result.test_report.results)}"
        )
    if not result.success:
        print(f"\nPipeline failed: {result.error or 'One or more tests failed.'}")


def _print_study_batch_result(
    selected_route: InputRoute,
    result: dict,
) -> None:
    """Print a study-batch summary for baseline or LLM processing."""
    report = result.get("report", {})
    print("STUDY BATCH COMPLETE")
    print("=" * 52)
    print(f"Dataset: {report.get('dataset')}")
    print(f"Algorithms represented: {report.get('algorithm_count', 0)}")
    print(f"Pipeline status counts: {report.get('pipeline_status_counts', report.get('status_counts', {}))}")
    if report.get('batch_type') == 'BASELINE':
        calibration_counts = report.get('calibration_status_counts', {}) or {}
        evaluated = int(report.get('evaluated_baseline_calibration_count') or 0)
        print(f"Baseline calibration counts: {calibration_counts}")
        print(f"Evaluated behavioural calibrations: {evaluated}/{report.get('algorithm_count', 0)}")
        print(f"Mean baseline calibration score: {report.get('mean_baseline_calibration_percentage')}")
        print("Note: pipeline FAILURE may represent measured behavioural disagreement; calibration availability is reported separately above.")
        structural_failures = int(calibration_counts.get('PIPELINE_FAILURE', 0))
        if structural_failures:
            print(f"WARNING: {structural_failures} algorithm(s) did not reach an evaluated baseline calibration.")
        unavailable = int(report.get('baseline_calibration_unavailable_count') or 0)
        if unavailable:
            print(
                f"Baseline-relative behavioural comparison is available for {evaluated}/{report.get('algorithm_count', 0)} algorithms; "
                f"the remaining {unavailable} will be reported as NOT_EVALUABLE if used experimentally."
            )
    elif report.get('batch_type') == 'LLM_RESULTS':
        print(f"Comparison to frozen semantic reference: {report.get('comparison_to_baseline_counts', {})}")
        print(f"Mean experimental semantic behavioural score: {report.get('mean_experimental_behavioural_percentage')}")
        print(f"Mean delta from frozen semantic reference (percentage points): {report.get('mean_delta_from_baseline_percentage_points')}")
        semantic_evaluable = int(report.get('semantic_tests_evaluable') or 0)
        semantic_passed = int(report.get('semantic_tests_passed') or 0)
        semantic_ne = int(report.get('semantic_tests_not_evaluable') or 0)
        if semantic_evaluable or semantic_ne:
            print(f"Task-semantic Common Tests: {semantic_passed}/{semantic_evaluable} passed; {semantic_ne} not evaluable/reference-only")
            print(f"Aggregate task-semantic test accuracy: {report.get('semantic_test_accuracy_percentage')}")
        boundary_evaluable = int(report.get('semantic_boundary_probes_evaluable') or 0)
        boundary_ne = int(report.get('semantic_boundary_probes_not_evaluable') or 0)
        if boundary_evaluable or boundary_ne:
            print(
                "Semantic boundary probes: "
                f"{report.get('semantic_boundary_probes_accepted', 0)} accepted out-of-domain / {boundary_evaluable} evaluable; "
                f"{report.get('semantic_boundary_probes_controlled_rejection', 0)} controlled rejection; "
                f"{report.get('semantic_boundary_probes_incidental_failure', 0)} incidental failure; "
                f"{boundary_ne} not evaluable"
            )
            print(f"Semantic Boundary Variance: {report.get('semantic_boundary_variance_percentage')}")
    common_pack = result.get("common_test_pack") or {}
    if common_pack:
        print(
            "Common Test Pack: "
            f"{'READY' if common_pack.get('complete') else 'INCOMPLETE'} "
            f"({common_pack.get('suite_count', 0)}/50 suites, {common_pack.get('test_count', 0)} tests)"
        )
    print(f"Batch JSON: {result.get('json_path')}")
    print(f"Batch CSV: {result.get('csv_path')}")
    dashboards = result.get('dashboards') or {}
    if dashboards:
        print(f"Dashboard generation: {dashboards.get('status')}")
        if dashboards.get('batch_dashboard'):
            print(f"Batch dashboard: {dashboards.get('batch_dashboard')}")
        if dashboards.get('comparative_dashboard'):
            print(
                f"Comparative dashboard ({dashboards.get('comparative_completed_agent_count', 0)} completed agent(s)): "
                f"{dashboards.get('comparative_dashboard')}"
            )
        if dashboards.get('error'):
            print(f"Dashboard warning: {dashboards.get('error')}")


def _print_llm_run_header(
    selected_file: Path,
    selected_profile: PseudocodeProfile,
    selected_baseline_root: Path,
) -> None:
    pack_status = validate_common_test_pack(DEFAULT_COMMON_TESTS_ROOT)
    print(f"NL-FDEP pipeline version: {PIPELINE_VERSION}")
    print(f"Selected input type: {InputRoute.LLM_RESULTS_FOLDER.value}")
    print(f"Selected file: {selected_file.resolve()}")
    print(f"Selected pseudocode profile: {selected_profile.value}")
    print(f"Selected baseline root: {selected_baseline_root.resolve()}")
    print("Baseline role: PROCEDURAL_READINESS_GATE_ONLY (not supplied to experimental scoring)")
    baseline_state = _current_baseline_state(selected_baseline_root)
    if _baseline_study_ready(baseline_state):
        print("Baseline readiness: FULL_50_OF_50")
    else:
        override = _DEGRADED_BASELINE_SESSION_OVERRIDES.get(_baseline_override_key(selected_baseline_root)) or {}
        unavailable_ids = override.get("unavailable_algorithm_ids", ())
        unavailable_text = ", ".join(f"Algorithm {value}" for value in unavailable_ids) or "unknown"
        print(
            "Baseline readiness: DEGRADED_49_OF_50_OVERRIDE "
            f"(unavailable: {unavailable_text}; explicit session-only acceptance)"
        )
    print(
        f"Packaged Common Tests v{TEST_DESIGN_VERSION}: "
        f"{'READY' if pack_status.complete else 'INCOMPLETE'} "
        f"({pack_status.suite_count}/50 suites, {pack_status.test_count} tests)"
    )


def run_llm_study_session(
    selection_dialog: InputSelectionDialog,
    selected_profile: PseudocodeProfile,
) -> None:
    """Run one or more LLM batches behind one explicit per-process baseline gate."""
    selected_baseline_root = establish_session_baseline(
        selection_dialog,
        selected_profile,
    )
    if selected_baseline_root is None:
        print("Selected operation cancelled because no study-ready baseline benchmark was established.")
        return

    current_llm_results: Path | None = None
    session_llm_results: list[Path] = []
    while True:
        if current_llm_results is None:
            current_llm_results = select_llm_results_directory(
                selection_dialog,
                selected_baseline_root,
            )

            # Re-check the in-memory session gate before every batch.  This does
            # not run the baseline or pass it into experimental scoring.
            current_state = _current_baseline_state(selected_baseline_root)
            if not _baseline_session_ready(selected_baseline_root, current_state):
                problems = _baseline_calibration_problem_details(selected_baseline_root)
                selection_dialog.show_error(
                    "Baseline session is no longer study-ready",
                    "The active session baseline no longer satisfies either the normal 50/50 "
                    "readiness gate or the exact 49/50 state that was explicitly accepted for "
                    "this process.\n\n"
                    f"Current: {current_state['evaluated']}/50 evaluated; "
                    f"{current_state.get('full_score', 0)}/50 scoring 100%.\n\n"
                    f"Calibration problem details:\n{_format_baseline_calibration_problems(problems)}\n\n"
                    "The LLM batch has not started. Restart the runner and establish the baseline "
                    "gate again.",
                )
                return

            _print_llm_run_header(
                current_llm_results,
                selected_profile,
                selected_baseline_root,
            )
            result = run_selected_pipeline(
                route=InputRoute.LLM_RESULTS_FOLDER,
                input_path=current_llm_results,
                pseudocode_profile=selected_profile,
                baseline_root=selected_baseline_root,
            )
            _print_study_batch_result(InputRoute.LLM_RESULTS_FOLDER, result)
            resolved_current = current_llm_results.resolve()
            if all(existing.resolve() != resolved_current for existing in session_llm_results):
                session_llm_results.append(current_llm_results)

        action = selection_dialog.select_post_llm_action()
        if action == PostLLMAction.ANOTHER_LLM_RESULTS_FOLDER:
            current_llm_results = None
            continue
        if action == PostLLMAction.HUMAN_EVALUATION:
            run_human_review_folder(session_llm_results)
            print(
                "Human review session closed for "
                f"{len(session_llm_results)} LLM dataset(s) processed in this runner session."
            )
            # Keep the current batch active so the user can continue reviewing,
            # choose another LLM dataset, or quit after closing the dashboard.
            continue
        if action == PostLLMAction.QUIT:
            print("LLM study session closed.")
            return
        raise ValueError(f"Unsupported post-LLM action: {action}")


def main() -> None:
    """Select a route and run the controlled NL-FDEP workflow.

    Baseline runner state is session-scoped.  Any hint created while establishing an
    LLM readiness gate is deleted after an orderly quit, cancellation, or completed
    non-LLM route.  Unexpected exceptions deliberately leave the hint untouched so a
    subsequent launch can offer it for explicit recovery and revalidation.
    """
    selection_dialog = InputSelectionDialog()
    selected_profile = None

    try:
        selected_route = selection_dialog.select_route()

        if selected_route in {InputRoute.PSEUDOCODE, InputRoute.LLM_RESULTS_FOLDER}:
            selected_profile = selection_dialog.select_pseudocode_profile()
        elif selected_route == InputRoute.BASELINE_BENCHMARK_FOLDER:
            selected_profile = BASELINE_CALIBRATION_PROFILE

        if selected_route == InputRoute.LLM_RESULTS_FOLDER:
            run_llm_study_session(selection_dialog, selected_profile)
            _clear_degraded_baseline_override()
            _clear_baseline_preference()
            return

        selected_file = selection_dialog.select_file(route=selected_route)

    except InputSelectionCancelledError as error:
        print(str(error))
        _clear_baseline_preference()
        return

    pack_status = validate_common_test_pack(DEFAULT_COMMON_TESTS_ROOT)
    print(f"NL-FDEP pipeline version: {PIPELINE_VERSION}")
    print(f"Selected input type: {selected_route.value}")
    print(f"Selected file: {selected_file.resolve()}")
    if selected_profile is not None:
        print(f"Selected pseudocode profile: {selected_profile.value}")
    print(
        f"Packaged Common Tests v{TEST_DESIGN_VERSION}: "
        f"{'READY' if pack_status.complete else 'INCOMPLETE'} "
        f"({pack_status.suite_count}/50 suites, {pack_status.test_count} tests)"
    )

    if selected_route == InputRoute.BASELINE_BENCHMARK_FOLDER:
        print(
            f"Baseline testing and calibration in progress — evaluating 50 algorithms against Common Tests v{TEST_DESIGN_VERSION}…",
            flush=True,
        )

    result = run_selected_pipeline(
        route=selected_route,
        input_path=selected_file,
        pseudocode_profile=selected_profile,
    )

    if selected_route == InputRoute.HUMAN_REVIEW_FOLDER:
        print("Human review session closed.")
    elif selected_route == InputRoute.BASELINE_BENCHMARK_FOLDER:
        _print_study_batch_result(selected_route, result)
    else:
        print_pipeline_report(result=result)

    _clear_baseline_preference()


if __name__ == "__main__":
    main()
