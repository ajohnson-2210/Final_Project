# NL to Flow Diagram Encoder Pipeline v1.3

A dependency-free, object-oriented Python pipeline for AJ_24038155 Dialect v1.0.
The only external program input is AJ pseudocode.

## Pipeline

1. AJ pseudocode input
2. Lexical analysis
3. Recursive-descent parsing
4. AST construction
5. Static semantic validation
6. Machine-readable flow-diagram encoding
7. Interactive AST and flow-diagram visualisation
8. Deterministic Python compilation from `flow_diagram.json`
9. Subprocess-based behavioural testing
10. JSON reporting

## PyCharm

Open `pycharm_runner.py` and press **Run**. Configure these constants at the top
of the file when required:

- `INPUT_FILE`
- `OUTPUT_DIRECTORY`
- `OPEN_VISUALISATIONS`
- `TEST_CASES`

## Outputs

The runner creates:

- `output/ast.json`
- `output/parser_report.json`
- `output/ast_visualisation.html`
- `output/flow_diagram.json`
- `output/flow_diagram.html`
- `output/generated_program.py`
- `output/compilation_report.json`
- `output/test_report.json`
- `output/pipeline_report.json`

## Important design boundary

The AST is an internal intermediate representation. It is generated from
pseudocode and is not accepted as an external pipeline input. The compiler
accepts the machine-readable flow-diagram document produced by the encoder.

## Flow-diagram display

The generated flowchart opens at a readable 115% scale and is centred on the
first program steps. Use **Fit diagram** to display the complete program at once.
Zoom and pan remain available.

## Compilation assurance tests

The integration tests verify that:

- the saved `flow_diagram.json` document is accepted directly by the compiler;
- the compiler produces the exact expected reference Python source;
- the compiled program executes and produces the expected output;
- the visualisation contains the readable initial-view configuration.

Run all tests with:

```bash
python -m unittest discover -s tests -v
```
