# NL-FDEP v4.35 Release Candidate

v4.35 RC advances packaged Common Tests to v1.3 / test-spec schema v1.4 and makes experimental task-semantic scoring runtime-independent of the baseline benchmark.

Key changes:

- 50 suites / 113 retained cases; 75 frozen automated semantic cases.
- explicit static expected semantic values (`STATIC_FROZEN_VALUE`);
- no runtime baseline/reference/oracle execution for experimental expected values;
- declarative, algorithm-agnostic invocation adapters and result observers;
- valid function return values are first-class observations;
- neutral structured-object member aliases for declared tree/list fixtures;
- declared canonical equivalence for empty/not-found states;
- exact frozen matrix fixtures and expectations are internally consistent;
- safely derivable implementation arguments may be declared by the task contract;
- stack and queue state behaviour can be exercised by frozen operation sequences;
- human review remains integrated with the same semantic contract;
- no named model/vendor validation artefacts are distributed in the candidate.

The baseline-calibration route remains available separately and is not used to produce experimental expected results. This build is a release candidate for cross-dataset stress testing and is not the final study freeze.
