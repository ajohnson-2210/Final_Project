import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from pseudocode_profiles import PseudocodeProfile
from pycharm_runner import (
    _baseline_session_ready,
    _clear_degraded_baseline_override,
    _degraded_baseline_override_eligible,
    _register_degraded_baseline_override,
    ensure_baseline_available,
)


READY_PREFLIGHT = {
    "baseline_root_structure_valid": True,
    "issue_count": 0,
    "algorithms": [],
}

DEGRADED_49_STATE = {
    "terminal": 50,
    "evaluated": 49,
    "full_score": 49,
    "pipeline_failure": 1,
    "behavioural_not_evaluated": 0,
    "other_unavailable": 0,
}

BELOW_100_STATE = {
    "terminal": 50,
    "evaluated": 50,
    "full_score": 49,
    "pipeline_failure": 0,
    "behavioural_not_evaluated": 0,
    "other_unavailable": 0,
}

MATPLOTLIB_PROBLEM = {
    "algorithm_id": 50,
    "category": "PIPELINE_FAILURE",
    "reason": "ModuleNotFoundError: No module named 'matplotlib'",
    "processing_status": "FAILURE",
    "calibration_status": "PIPELINE_FAILURE",
    "calibration_score_percentage": None,
}

BELOW_100_PROBLEM = {
    "algorithm_id": 50,
    "category": "CALIBRATION_BELOW_100",
    "reason": "Calibration score is 75% rather than the required 100%.",
    "processing_status": "SUCCESS",
    "calibration_status": "EVALUATED",
    "calibration_score_percentage": 75.0,
}


class _Dialog:
    def __init__(self, answers):
        self.answers = list(answers)
        self.questions = []
        self.errors = []

    def ask_yes_no(self, title, message):
        self.questions.append((title, message))
        if not self.answers:
            raise AssertionError(f"Unexpected question: {title}: {message}")
        return self.answers.pop(0)

    def show_error(self, title, message):
        self.errors.append((title, message))

    def show_info(self, title, message):
        pass

    def select_optional_directory(self, title):
        raise AssertionError("Directory selection was not expected in this test")


class RunnerDegradedBaselineOverrideV435RC7Tests(unittest.TestCase):
    def tearDown(self):
        _clear_degraded_baseline_override()

    def test_only_exact_49_of_50_unavailable_state_is_override_eligible(self):
        self.assertTrue(
            _degraded_baseline_override_eligible(DEGRADED_49_STATE, [MATPLOTLIB_PROBLEM])
        )
        self.assertFalse(
            _degraded_baseline_override_eligible(BELOW_100_STATE, [BELOW_100_PROBLEM])
        )
        self.assertFalse(
            _degraded_baseline_override_eligible(
                {**DEGRADED_49_STATE, "terminal": 49}, [MATPLOTLIB_PROBLEM]
            )
        )
        self.assertFalse(
            _degraded_baseline_override_eligible(
                {**DEGRADED_49_STATE, "evaluated": 48, "full_score": 48},
                [MATPLOTLIB_PROBLEM, {**MATPLOTLIB_PROBLEM, "algorithm_id": 49}],
            )
        )

    def test_49_of_50_failure_shows_reason_and_can_continue_explicitly(self):
        with tempfile.TemporaryDirectory() as temp:
            baseline = Path(temp) / "Baselines"
            baseline.mkdir()
            dialog = _Dialog([True, True])
            calibration_result = {
                "report": {
                    "algorithm_count": 50,
                    "calibration_status_counts": {"CALIBRATED": 49, "PIPELINE_FAILURE": 1},
                    "algorithms": [
                        {
                            "algorithm_id": 50,
                            "status": "FAILURE",
                            "error": "ModuleNotFoundError: No module named 'matplotlib'",
                        }
                    ],
                }
            }

            with patch("pycharm_runner.validate_baseline", return_value=READY_PREFLIGHT), \
                 patch("pycharm_runner._current_baseline_state", side_effect=[DEGRADED_49_STATE, DEGRADED_49_STATE]), \
                 patch("pycharm_runner.run_baseline_folder", return_value=calibration_result), \
                 patch("pycharm_runner._baseline_calibration_problem_details", return_value=[MATPLOTLIB_PROBLEM]), \
                 patch("pycharm_runner._save_baseline_preference") as save:
                result = ensure_baseline_available(
                    dialog,
                    PseudocodeProfile.GENERIC_COMPATIBILITY,
                    baseline_root=baseline,
                    require_full_study_readiness=True,
                )

            self.assertEqual(baseline, result)
            save.assert_called_once_with(baseline)
            self.assertEqual([], dialog.errors)
            self.assertEqual(2, len(dialog.questions))
            title, message = dialog.questions[-1]
            self.assertIn("continue with 49/50", title.lower())
            self.assertIn("Algorithm 50", message)
            self.assertIn("matplotlib", message)
            self.assertIn("DEGRADED_49_OF_50_OVERRIDE", message)

            with patch("pycharm_runner._baseline_calibration_problem_details", return_value=[MATPLOTLIB_PROBLEM]):
                self.assertTrue(_baseline_session_ready(baseline, DEGRADED_49_STATE))

    def test_49_of_50_failure_can_be_declined(self):
        with tempfile.TemporaryDirectory() as temp:
            baseline = Path(temp) / "Baselines"
            baseline.mkdir()
            dialog = _Dialog([True, False])
            calibration_result = {"report": {"algorithm_count": 50, "algorithms": []}}

            with patch("pycharm_runner.validate_baseline", return_value=READY_PREFLIGHT), \
                 patch("pycharm_runner._current_baseline_state", side_effect=[DEGRADED_49_STATE, DEGRADED_49_STATE]), \
                 patch("pycharm_runner.run_baseline_folder", return_value=calibration_result), \
                 patch("pycharm_runner._baseline_calibration_problem_details", return_value=[MATPLOTLIB_PROBLEM]), \
                 patch("pycharm_runner._save_baseline_preference") as save:
                result = ensure_baseline_available(
                    dialog,
                    PseudocodeProfile.GENERIC_COMPATIBILITY,
                    baseline_root=baseline,
                    require_full_study_readiness=True,
                )

            self.assertIsNone(result)
            save.assert_not_called()
            self.assertFalse(_baseline_session_ready(baseline, DEGRADED_49_STATE))

    def test_below_100_calibration_is_not_reclassified_as_unavailable_override(self):
        with tempfile.TemporaryDirectory() as temp:
            baseline = Path(temp) / "Baselines"
            baseline.mkdir()
            dialog = _Dialog([True])
            calibration_result = {"report": {"algorithm_count": 50, "algorithms": []}}

            with patch("pycharm_runner.validate_baseline", return_value=READY_PREFLIGHT), \
                 patch("pycharm_runner._current_baseline_state", side_effect=[BELOW_100_STATE, BELOW_100_STATE]), \
                 patch("pycharm_runner.run_baseline_folder", return_value=calibration_result), \
                 patch("pycharm_runner._baseline_calibration_problem_details", return_value=[BELOW_100_PROBLEM]), \
                 patch("pycharm_runner._save_baseline_preference") as save:
                result = ensure_baseline_available(
                    dialog,
                    PseudocodeProfile.GENERIC_COMPATIBILITY,
                    baseline_root=baseline,
                    require_full_study_readiness=True,
                )

            self.assertIsNone(result)
            save.assert_not_called()
            self.assertEqual(1, len(dialog.questions))
            self.assertTrue(any(title == "Baseline calibration is not study-ready" for title, _ in dialog.errors))
            self.assertIn("75%", dialog.errors[0][1])

    def test_override_is_invalidated_if_the_degraded_state_changes(self):
        with tempfile.TemporaryDirectory() as temp:
            baseline = Path(temp) / "Baselines"
            baseline.mkdir()
            _register_degraded_baseline_override(baseline, DEGRADED_49_STATE, [MATPLOTLIB_PROBLEM])

            changed_problem = {**MATPLOTLIB_PROBLEM, "algorithm_id": 49}
            with patch("pycharm_runner._baseline_calibration_problem_details", return_value=[changed_problem]):
                self.assertFalse(_baseline_session_ready(baseline, DEGRADED_49_STATE))


if __name__ == "__main__":
    unittest.main()
