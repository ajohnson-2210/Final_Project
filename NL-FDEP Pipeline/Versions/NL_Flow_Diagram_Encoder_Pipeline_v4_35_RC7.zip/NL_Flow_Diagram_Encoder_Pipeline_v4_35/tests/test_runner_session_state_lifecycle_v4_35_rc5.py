import unittest
from pathlib import Path
from unittest.mock import Mock, patch

from input_selection import InputRoute, InputSelectionCancelledError
from pseudocode_profiles import PseudocodeProfile
import pycharm_runner


class _Dialog:
    def __init__(self, route=None, selected_file=None, cancel=False):
        self.route = route
        self.selected_file = selected_file
        self.cancel = cancel

    def select_route(self):
        if self.cancel:
            raise InputSelectionCancelledError("Input selection cancelled.")
        return self.route

    def select_pseudocode_profile(self):
        return PseudocodeProfile.GENERIC_COMPATIBILITY

    def select_file(self, route):
        return self.selected_file


class RunnerSessionStateLifecycleV435RC5Tests(unittest.TestCase):
    def test_orderly_llm_session_exit_clears_recovery_hint(self):
        dialog = _Dialog(route=InputRoute.LLM_RESULTS_FOLDER)
        with patch("pycharm_runner.InputSelectionDialog", return_value=dialog), \
             patch("pycharm_runner.run_llm_study_session") as run_session, \
             patch("pycharm_runner._clear_baseline_preference") as clear_hint:
            pycharm_runner.main()

        run_session.assert_called_once_with(dialog, PseudocodeProfile.GENERIC_COMPATIBILITY)
        clear_hint.assert_called_once_with()

    def test_cancelled_runner_exit_clears_recovery_hint(self):
        dialog = _Dialog(cancel=True)
        with patch("pycharm_runner.InputSelectionDialog", return_value=dialog), \
             patch("pycharm_runner._clear_baseline_preference") as clear_hint:
            pycharm_runner.main()

        clear_hint.assert_called_once_with()

    def test_standalone_baseline_route_does_not_persist_for_next_launch(self):
        baseline = Path("Baselines")
        dialog = _Dialog(route=InputRoute.BASELINE_BENCHMARK_FOLDER, selected_file=baseline)
        result = {"report": {"batch_type": "BASELINE"}}
        pack = Mock(complete=True, suite_count=50, test_count=113)

        with patch("pycharm_runner.InputSelectionDialog", return_value=dialog), \
             patch("pycharm_runner.validate_common_test_pack", return_value=pack), \
             patch("pycharm_runner.run_selected_pipeline", return_value=result), \
             patch("pycharm_runner._print_study_batch_result"), \
             patch("pycharm_runner._save_baseline_preference") as save_hint, \
             patch("pycharm_runner._clear_baseline_preference") as clear_hint:
            pycharm_runner.main()

        save_hint.assert_not_called()
        clear_hint.assert_called_once_with()

    def test_unexpected_llm_exception_preserves_recovery_hint(self):
        dialog = _Dialog(route=InputRoute.LLM_RESULTS_FOLDER)
        with patch("pycharm_runner.InputSelectionDialog", return_value=dialog), \
             patch("pycharm_runner.run_llm_study_session", side_effect=RuntimeError("boom")), \
             patch("pycharm_runner._clear_baseline_preference") as clear_hint:
            with self.assertRaisesRegex(RuntimeError, "boom"):
                pycharm_runner.main()

        clear_hint.assert_not_called()


if __name__ == "__main__":
    unittest.main()
