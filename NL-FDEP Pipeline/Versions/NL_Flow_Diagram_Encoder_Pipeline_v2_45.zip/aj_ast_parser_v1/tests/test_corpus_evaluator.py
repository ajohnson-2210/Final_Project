import sys
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from corpus_evaluator import (
    GeminiTextAdapter,
    GroqAdapter,
    HashHeadingAdapter,
    NumberedSectionAdapter,
    QwenAdapter,
)


# The canonical six-model corpus is bundled with the project. Tests must not
# depend on transient notebook/container paths such as /mnt/data/phase9.
DATA = ROOT / 'corpus_hash_format'


class CorpusAdapterTests(unittest.TestCase):
    def test_bundled_hash_corpora_extract_fifty_each(self):
        for filename in (
            'ChatGPT.txt',
            'Claude_Sonnet_4.6.txt',
            'DeepSeek.txt',
            'Groq.txt',
            'Qwen_3.6_Plus.txt',
            'Gemini.txt',
        ):
            text = (DATA / filename).read_text(encoding='utf-8-sig')
            examples = HashHeadingAdapter().extract(text, filename)
            self.assertEqual(len(examples), 50, filename)

    def test_numbered_adapter_extracts_numbered_sections(self):
        text = (
            '1. First task\nBEGIN\nOUTPUT 1\nEND\n\n'
            '2. Second task\ntext\nBEGIN\nOUTPUT 2\nEND\n'
        )
        examples = NumberedSectionAdapter().extract(text, 'Numbered')
        self.assertEqual(len(examples), 2)
        self.assertEqual(examples[0].task_number, 1)
        self.assertEqual(examples[0].title, 'First task')
        self.assertTrue(examples[0].source.startswith('BEGIN'))
        self.assertEqual(examples[1].task_number, 2)
        self.assertNotIn('\ntext\n', f"\n{examples[1].source}\n".lower())

    def test_groq_adapter_extracts_function_sections_without_examples(self):
        text = (
            '1. First task\n'
            'FUNCTION FIRST()\nRETURN 1\nEND FUNCTION\n'
            'Example:\nFIRST()\nreturns 1\n\n'
            '2. Second task\n'
            'FUNCTION SECOND()\nRETURN 2\nEND FUNCTION\n'
            'Example:\nSECOND()\nreturns 2\n'
        )
        examples = GroqAdapter().extract(text, 'Groq')
        self.assertEqual(len(examples), 2)
        self.assertTrue(examples[0].source.startswith('FUNCTION FIRST'))
        self.assertNotIn('Example:', examples[0].source)
        self.assertTrue(examples[1].source.startswith('FUNCTION SECOND'))

    def test_qwen_adapter_extracts_compressed_bodies(self):
        text = (
            '# First task\n'
            'INPUT x\n'
            'x = x + 1\n\n'
            '# Drone Coordination\n'
            'INPUT drones\n'
            'RETURN drones\n'
        )
        examples = QwenAdapter().extract(text, 'Qwen')
        self.assertEqual(len(examples), 2)
        self.assertIn('Drone Coordination', examples[-1].title)
        self.assertTrue(examples[-1].source.startswith('INPUT drones'))

    def test_gemini_txt_adapter_extracts_plaintext_sections(self):
        text = (
            '1. Determine whether two strings are anagrams\n'
            'PlaintextFUNCTION AreAnagrams(a, b)\nRETURN TRUE\nEND FUNCTION\n\n'
            '2. Return a value\n'
            'PlaintextFUNCTION Value()\nRETURN 2\nEND FUNCTION\n'
        )
        examples = GeminiTextAdapter().extract(text, 'Gemini')
        self.assertEqual(len(examples), 2)
        self.assertTrue(examples[0].source.startswith('FUNCTION AreAnagrams'))
        self.assertTrue(examples[1].source.startswith('FUNCTION Value'))


if __name__ == '__main__':
    unittest.main()
