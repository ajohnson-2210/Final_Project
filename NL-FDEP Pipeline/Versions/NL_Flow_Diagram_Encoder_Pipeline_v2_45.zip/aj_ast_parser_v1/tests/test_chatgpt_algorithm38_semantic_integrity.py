from aj_parser import AJParserFacade
from aj_python_compiler import AJPythonCompiler
from flow_diagram import FlowDiagramEncoder
from pseudocode_profiles import PseudocodeProfile, PseudocodeProfileProcessor


def test_chatgpt_algorithm38_operationalises_only_the_abstract_count_prerequisite():
    source = """BEGIN
    INPUT Text

    COUNT frequency of each character

    FOR EACH Character IN Text
        IF Frequency(Character) = 1 THEN
            OUTPUT Character
            STOP
        ENDIF
    ENDFOR

    OUTPUT "None Found"
END
"""
    result = PseudocodeProfileProcessor().process(source, PseudocodeProfile.GENERIC_COMPATIBILITY)

    expected = """Text <- INPUT(STRING(\"Enter Text\"))

Frequency <- EMPTY DICTIONARY
FOR EACH Character IN Text DO
    IF Character IN Frequency THEN
        Frequency[Character] <- Frequency[Character] + 1
    ELSE
        Frequency[Character] <- 1
    ENDIF
ENDFOR
FOR EACH Character IN Text DO
    IF Frequency[Character] == 1 THEN
        OUTPUT Character
        CALL quit()
    ENDIF
ENDFOR

OUTPUT STRING(\"None Found\")"""
    assert result.processed_source == expected

    # The abstract COUNT prerequisite may be operationalised, but the explicit
    # second loop must remain structurally faithful to the model output.
    assert result.processed_source.count("FOR EACH Character IN Text DO") == 2
    assert "IF Frequency[Character] == 1 THEN" in result.processed_source
    assert "OUTPUT Character\n        CALL quit()" in result.processed_source
    assert "OUTPUT STRING(\"None Found\")" in result.processed_source

    # Guard against the rejected one-pass reinterpretation, which would turn
    # the explicit frequency lookup into encounter-state logic.
    assert "IF Frequency[Character] < 1" not in result.processed_source
    assert "ELSE IF Frequency[Character] == 1" not in result.processed_source

    parsed = AJParserFacade().parse(result.processed_source)
    assert parsed.success, parsed.error

    compiled = AJPythonCompiler().compile(FlowDiagramEncoder().encode(parsed.ast))
    assert "Frequency = {}" in compiled.source_code
    assert "if (Frequency[Character] == 1):" in compiled.source_code
    assert "quit()" in compiled.source_code
    assert "count_frequency_of_each_character" not in compiled.source_code
    assert "source_stop" not in compiled.source_code


def test_chatgpt_algorithm38_compiled_python_preserves_two_stage_behaviour(tmp_path):
    import subprocess
    import sys

    source = """BEGIN
    INPUT Text
    COUNT frequency of each character
    FOR EACH Character IN Text
        IF Frequency(Character) = 1 THEN
            OUTPUT Character
            STOP
        ENDIF
    ENDFOR
    OUTPUT "None Found"
END
"""
    result = PseudocodeProfileProcessor().process(source, PseudocodeProfile.GENERIC_COMPATIBILITY)
    parsed = AJParserFacade().parse(result.processed_source)
    assert parsed.success, parsed.error
    compiled = AJPythonCompiler().compile(FlowDiagramEncoder().encode(parsed.ast))

    script = tmp_path / "algorithm38.py"
    script.write_text(compiled.source_code, encoding="utf-8")

    first_unique = subprocess.run(
        [sys.executable, str(script)],
        input="swiss\n",
        text=True,
        capture_output=True,
        check=False,
    )
    assert first_unique.returncode == 0
    assert first_unique.stdout.strip() == "Enter Textw"

    none_unique = subprocess.run(
        [sys.executable, str(script)],
        input="aabbcc\n",
        text=True,
        capture_output=True,
        check=False,
    )
    assert none_unique.returncode == 0
    assert none_unique.stdout.strip() == "Enter TextNone Found"
