# Corpus Semantic-Integrity Re-audit Queue — after ChatGPT Algorithm 39

ChatGPT Algorithms 38 and 39 have now been manually resolved under the refined semantic-integrity policy.

**Remaining flagged examples: 152 / 300**

## ChatGPT — 34
1, 2, 3, 4, 7, 8, 9, 10, 12, 13, 16, 18, 19, 20, 21, 22, 25, 26, 27, 28, 29, 32, 33, 34, 36, 41, 42, 43, 44, 45, 46, 47, 49, 50

## Claude Sonnet 4.6 — 18
8, 9, 12, 13, 17, 19, 20, 25, 27, 28, 38, 39, 41, 44, 45, 46, 49, 50

## DeepSeek — 22
1, 8, 9, 12, 13, 20, 22, 25, 26, 27, 28, 35, 37, 38, 39, 40, 41, 42, 45, 46, 48, 49

## Groq — 14
9, 12, 13, 20, 25, 26, 27, 28, 40, 41, 42, 45, 46, 48

## Qwen 3.6 Plus — 48
1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 36, 37, 38, 39, 40, 41, 42, 44, 45, 46, 47, 48, 49, 50

## Gemini — 16
8, 12, 22, 25, 26, 27, 28, 29, 30, 35, 39, 40, 41, 44, 48, 50
