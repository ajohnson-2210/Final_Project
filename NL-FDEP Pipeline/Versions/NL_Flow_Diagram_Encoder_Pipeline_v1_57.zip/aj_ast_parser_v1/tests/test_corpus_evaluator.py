import sys
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from corpus_evaluator import (
    GeminiTextAdapter,
    GroqAdapter,
    NumberedSectionAdapter,
    QwenAdapter,
)


DATA = Path('/mnt/data/phase9')


class CorpusAdapterTests(unittest.TestCase):
    def test_numbered_adapters_extract_fifty(self):
        for filename in (
            'ChatGPT pseudocode responses.txt',
            'Clude sonnet 4.6 pseudocode responses(1).txt',
            'deepseek pseudocode responses(1).txt',
        ):
            text = (DATA / filename).read_text(encoding='utf-8-sig')
            self.assertEqual(len(NumberedSectionAdapter().extract(text, filename)), 50)

    def test_groq_extracts_fifty(self):
        text = (DATA / 'Groq pseudocode responses(1).txt').read_text(encoding='utf-8-sig')
        self.assertEqual(len(GroqAdapter().extract(text, 'Groq')), 50)

    def test_qwen_extracts_fifty(self):
        text = (DATA / 'Qwen 3.6 plus pseudocode responces(1).txt').read_text(encoding='utf-8-sig')
        examples = QwenAdapter().extract(text, 'Qwen')
        self.assertEqual(len(examples), 50)
        self.assertIn('Drone Coordination', examples[-1].title)
        self.assertTrue(examples[-1].source.startswith('INPUT drones'))

    def test_gemini_txt_extracts_fifty(self):
        text = (DATA / 'Gemini_pseudocode_responses.txt').read_text(encoding='utf-8-sig')
        examples = GeminiTextAdapter().extract(text, 'Gemini')
        self.assertEqual(len(examples), 50)
        self.assertTrue(examples[0].source.startswith('FUNCTION AreAnagrams'))


if __name__ == '__main__':
    unittest.main()
