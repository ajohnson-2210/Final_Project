"""Interactive PyCharm entry point for the two controlled input routes."""

from pathlib import Path

from aj_test_harness import TestCase
from flow_input_pipeline import DrawIOFlowInputPipeline
from input_selection import (
    InputRoute,
    InputSelectionCancelledError,
    InputSelectionDialog,
)
from nl_flow_pipeline import NLFlowDiagramEncoderPipeline
from pseudocode_profiles import PseudocodeProfile


OUTPUT_DIRECTORY = Path("output")
OPEN_VISUALISATIONS = True

TEST_CASES = [
    TestCase(
        name="Pipeline test",
        standard_input=[],
        expected_output=["6", "6"],
        timeout_seconds=3.0,
    )
]


def run_pseudocode_pipeline(
    input_path: Path,
    pseudocode_profile: PseudocodeProfile,
):
    """Runs the canonical pipeline using a selected AJ pseudocode file."""

    pseudocode = input_path.read_text(encoding="utf-8")

    return NLFlowDiagramEncoderPipeline().run(
        pseudocode=pseudocode,
        output_directory=OUTPUT_DIRECTORY,
        test_cases=TEST_CASES,
        open_visualisations=OPEN_VISUALISATIONS,
        pseudocode_profile=pseudocode_profile,
    )


def run_flow_diagram_pipeline(input_path: Path):
    """Runs the controlled draw.io import route."""

    return DrawIOFlowInputPipeline().run(
        input_path=input_path,
        output_directory=OUTPUT_DIRECTORY,
        test_cases=[],
        open_visualisations=OPEN_VISUALISATIONS,
    )


def run_selected_pipeline(
    route: InputRoute,
    input_path: Path,
    pseudocode_profile: PseudocodeProfile | None = None,
):
    """Routes a selected source file to its controlled pipeline."""

    if route == InputRoute.PSEUDOCODE:
        selected_profile = pseudocode_profile

        if selected_profile is None:
            selected_profile = PseudocodeProfile.AJ_DIALECT_STRICT

        return run_pseudocode_pipeline(
            input_path=input_path,
            pseudocode_profile=selected_profile,
        )

    if route == InputRoute.FLOW_DIAGRAM:
        return run_flow_diagram_pipeline(
            input_path=input_path,
        )

    raise ValueError(
        f"Unsupported input route: {route}"
    )


def print_pipeline_report(result) -> None:
    """Prints a concise pipeline report in the PyCharm console."""

    print("NL TO FLOW DIAGRAM ENCODER PIPELINE")
    print("=" * 52)

    for stage in result.stages:
        print(
            f"[{stage.status:7}] "
            f"{stage.name:<28} "
            f"{stage.duration_ms:>9.3f} ms  "
            f"{stage.message}"
        )

    print("\nOUTPUT FILES")

    for output_name, output_path in result.output_files.items():
        print(f"- {output_name}: {output_path}")

    if result.test_report is not None:
        print(
            "\nTests passed: "
            f"{result.test_report.passed_tests}/"
            f"{len(result.test_report.results)}"
        )

    if not result.success:
        print(
            f"\nPipeline failed: "
            f"{result.error or 'One or more tests failed.'}"
        )


def main() -> None:
    """Asks what to import, selects a file and runs the correct pipeline."""

    selection_dialog = InputSelectionDialog()

    selected_profile = None

    try:
        selected_route = selection_dialog.select_route()

        if selected_route == InputRoute.PSEUDOCODE:
            selected_profile = selection_dialog.select_pseudocode_profile()

        selected_file = selection_dialog.select_file(
            route=selected_route,
        )
    except InputSelectionCancelledError as error:
        print(str(error))
        return

    print(f"Selected input type: {selected_route.value}")
    print(f"Selected file: {selected_file.resolve()}")

    if selected_profile is not None:
        print(f"Selected pseudocode profile: {selected_profile.value}")

    result = run_selected_pipeline(
        route=selected_route,
        input_path=selected_file,
        pseudocode_profile=selected_profile,
    )

    print_pipeline_report(
        result=result,
    )


if __name__ == "__main__":
    main()
