import json
import tempfile
import unittest
from pathlib import Path

from aj_test_harness import TestCase
from nl_flow_pipeline import NLFlowDiagramEncoderPipeline
from pseudocode_profiles import (
    GenericPseudocodeLexer,
    PseudocodeProfile,
    PseudocodeProfileProcessor,
)


class PseudocodeProfileTests(unittest.TestCase):

    def setUp(self):
        self.processor = PseudocodeProfileProcessor()

    def test_strict_profile_performs_only_safe_cleanup(self):
        source = "```text\ntotal ← INTEGER(0)   \nOUTPUT total\n```"

        result = self.processor.process(
            source=source,
            profile=PseudocodeProfile.AJ_DIALECT_STRICT,
        )

        self.assertEqual(
            result.processed_source,
            "total <- INTEGER(0)\nOUTPUT total",
        )
        self.assertTrue(result.source_modified)
        self.assertGreaterEqual(result.transformation_count, 2)

    def test_generic_lexer_classifies_supported_statements(self):
        tokens = GenericPseudocodeLexer().tokenise(
            "SET total TO 0\nPRINT total\nEND IF"
        )

        categories = []

        for token in tokens:
            categories.append(token.category)

        self.assertEqual(
            categories,
            ["SET_ASSIGNMENT", "OUTPUT", "END_IF"],
        )

    def test_generic_profile_converts_compatible_syntax(self):
        source = "SET total TO 0\ntotal = total + 3\nPRINT total"

        result = self.processor.process(
            source=source,
            profile=PseudocodeProfile.GENERIC_COMPATIBILITY,
        )

        self.assertEqual(
            result.processed_source,
            "total <- 0\ntotal <- total + 3\nOUTPUT total",
        )
        self.assertEqual(result.transformation_count, 3)

    def test_general_profile_preserves_source_exactly(self):
        source = "set total to 0  \r\nprint total"

        result = self.processor.process(
            source=source,
            profile=PseudocodeProfile.GENERAL_NO_CONVERSION,
        )

        self.assertEqual(result.processed_source, source)
        self.assertFalse(result.source_modified)
        self.assertEqual(result.transformation_count, 0)

    def test_generic_profile_runs_complete_pipeline(self):
        source = "SET total TO 0\ntotal = total + 3\nPRINT total"

        with tempfile.TemporaryDirectory() as directory:
            result = NLFlowDiagramEncoderPipeline().run(
                pseudocode=source,
                output_directory=Path(directory),
                test_cases=[
                    TestCase(
                        name="Generic total",
                        expected_output=["3"],
                    )
                ],
                pseudocode_profile=PseudocodeProfile.GENERIC_COMPATIBILITY,
            )

            report_path = Path(
                result.output_files["pseudocode_processing_report"]
            )
            report = json.loads(
                report_path.read_text(encoding="utf-8")
            )

        self.assertTrue(result.success, result.to_json())
        self.assertEqual(
            result.input_metadata["pseudocode_profile"],
            PseudocodeProfile.GENERIC_COMPATIBILITY.value,
        )
        self.assertEqual(report["transformation_count"], 3)

    def test_general_profile_does_not_repair_generic_syntax(self):
        source = "SET total TO 0\nPRINT total"

        with tempfile.TemporaryDirectory() as directory:
            result = NLFlowDiagramEncoderPipeline().run(
                pseudocode=source,
                output_directory=Path(directory),
                test_cases=[],
                pseudocode_profile=PseudocodeProfile.GENERAL_NO_CONVERSION,
            )

        self.assertFalse(result.success)
        self.assertEqual(
            result.input_metadata["pseudocode_profile"],
            PseudocodeProfile.GENERAL_NO_CONVERSION.value,
        )
        self.assertIn("Expected", result.error)

    def test_general_profile_strips_initial_hash_comment_block(self):
        source = (
            "# Algorithm 1: Sum values\n"
            "This description wraps onto a second line.\n"
            "It can continue without another hash character.\n"
            "\n"
            "total <- INTEGER(0)\n"
            "OUTPUT total"
        )

        result = self.processor.process(
            source=source,
            profile=PseudocodeProfile.GENERAL_NO_CONVERSION,
        )

        self.assertEqual(
            result.processed_source,
            "total <- INTEGER(0)\nOUTPUT total",
        )
        self.assertTrue(result.header_comment_removed)
        self.assertEqual(result.header_lines_removed, 4)
        self.assertEqual(result.transformation_count, 0)

    def test_general_profile_strips_header_after_leading_blank_line(self):
        source = (
            "\n"
            "# Anagram Check\n"
            "\n"
            "INPUT str1, str2 IF length(str1) != length(str2) RETURN FALSE"
        )

        result = self.processor.process(
            source=source,
            profile=PseudocodeProfile.GENERAL_NO_CONVERSION,
        )

        self.assertEqual(
            result.processed_source,
            "INPUT str1, str2 IF length(str1) != length(str2) RETURN FALSE",
        )
        self.assertTrue(result.header_comment_removed)
        self.assertEqual(result.header_lines_removed, 3)
        self.assertEqual(result.transformation_count, 0)

    def test_general_profile_strips_header_with_utf8_bom_and_indentation(self):
        source = (
            "\ufeff   # Anagram Check\n"
            "Wrapped description\n"
            "\n"
            "RETURN TRUE"
        )

        result = self.processor.process(
            source=source,
            profile=PseudocodeProfile.GENERAL_NO_CONVERSION,
        )

        self.assertEqual(result.processed_source, "RETURN TRUE")
        self.assertTrue(result.header_comment_removed)
        self.assertEqual(result.header_lines_removed, 3)

    def test_hash_comment_later_in_source_is_not_automatically_stripped(self):
        source = "total <- INTEGER(0)\n# later comment\nOUTPUT total"

        result = self.processor.process(
            source=source,
            profile=PseudocodeProfile.GENERAL_NO_CONVERSION,
        )

        self.assertEqual(result.processed_source, source)
        self.assertFalse(result.header_comment_removed)
        self.assertEqual(result.header_lines_removed, 0)

    def test_initial_hash_comment_block_runs_complete_pipeline(self):
        source = (
            "# Generated algorithm description\n"
            "This line is part of the wrapped description.\n"
            "\n"
            "total <- INTEGER(0)\n"
            "OUTPUT total"
        )

        with tempfile.TemporaryDirectory() as directory:
            result = NLFlowDiagramEncoderPipeline().run(
                pseudocode=source,
                output_directory=Path(directory),
                test_cases=[
                    TestCase(
                        name="Header stripped total",
                        expected_output=["0"],
                    )
                ],
                pseudocode_profile=PseudocodeProfile.GENERAL_NO_CONVERSION,
            )

            processed_source = Path(
                result.output_files["processed_pseudocode"]
            ).read_text(encoding="utf-8")

        self.assertTrue(result.success, result.to_json())
        self.assertEqual(processed_source, "total <- INTEGER(0)\nOUTPUT total")
        self.assertTrue(result.input_metadata["header_comment_removed"])
        self.assertEqual(result.input_metadata["header_lines_removed"], 3)


if __name__ == "__main__":
    unittest.main()
