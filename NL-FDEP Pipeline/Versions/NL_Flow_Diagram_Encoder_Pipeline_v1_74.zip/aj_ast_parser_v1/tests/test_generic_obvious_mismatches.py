import unittest

from aj_parser import AJParserFacade
from pseudocode_profiles import PseudocodeProfile, PseudocodeProfileProcessor
from flow_diagram import FlowDiagramEncoder
from aj_python_compiler import AJPythonCompiler


class GenericObviousMismatchTests(unittest.TestCase):
    def setUp(self):
        self.processor = PseudocodeProfileProcessor()

    def process(self, source):
        return self.processor.process(source, PseudocodeProfile.GENERIC_COMPATIBILITY)

    def test_raw_output_string_and_sort_characters_parse(self):
        source = """String1 <- INPUT(STRING(\"Enter String1\"))
String2 <- INPUT(STRING(\"Enter String2\"))
IF LENGTH OF String1 != LENGTH OF String2 THEN
    OUTPUT \"Not Anagrams\"
ELSE
    SORT characters of String1
    SORT characters of String2
    IF String1 == String2 THEN
        OUTPUT \"Anagrams\"
    ELSE
        OUTPUT \"Not Anagrams\"
    ENDIF
ENDIF
"""
        result = self.process(source)
        self.assertIn('OUTPUT STRING("Not Anagrams")', result.processed_source)
        self.assertIn('String1 <- CALL sort_characters(String1)', result.processed_source)
        parsed = AJParserFacade().parse(result.processed_source)
        self.assertTrue(parsed.success, parsed.error)

    def test_not_in_operator_parses(self):
        parsed = AJParserFacade().parse("FUNCTION f ACCEPTS(x, seen)\n    IF x NOT IN seen THEN\n        RETURN BOOLEAN(True)\n    ENDIF\n    RETURN BOOLEAN(False)\nENDFUNCTION\n")
        self.assertTrue(parsed.success, parsed.error)

    def test_swap_expands_to_assignments(self):
        result = self.process("SWAP left AND right\n")
        self.assertIn('_swap_temp <- left', result.processed_source)
        self.assertIn('left <- right', result.processed_source)

    def test_swap_indexed_items_expands_and_parses(self):
        source = "WordList <- EMPTY LIST\nj <- 0\nSWAP WordList[j], WordList[j+1]\n"
        result = self.process(source)
        self.assertIn("_swap_temp <- WordList[j]", result.processed_source)
        self.assertIn("WordList[j] <- WordList[j+1]", result.processed_source)
        self.assertIn("WordList[j+1] <- _swap_temp", result.processed_source)
        parsed = AJParserFacade().parse(result.processed_source)
        self.assertTrue(parsed.success, parsed.error)

    def test_reserved_list_identifier_and_exit_for_parse(self):
        source = """List <- INPUT(STRING("Enter List"))
Target <- INPUT(STRING("Enter Target"))
Found <- BOOLEAN(False)
FOR i from 0 to length(List)-1:
    IF List[i] == Target THEN
        OUTPUT TUPLE(STRING("Found at position"), i)
        Found <- BOOLEAN(True)
        EXIT FOR
    ENDIF
ENDFOR
IF Found == BOOLEAN(False) THEN
    OUTPUT STRING("Target not found")
ENDIF
"""
        result = self.process(source)
        self.assertIn("values <- INPUT", result.processed_source)
        self.assertIn("IF values[i] == Target THEN", result.processed_source)
        self.assertIn("BREAK", result.processed_source)
        parsed = AJParserFacade().parse(result.processed_source)
        self.assertTrue(parsed.success, parsed.error)

    def test_case_block_and_part_heading_normalise_and_parse(self):
        source = """Text <- INPUT(STRING("Enter Text"))
A <- 0
E <- 0
FOR EACH Character IN Text DO
    CASE Character OF
        STRING("a"): A <- A + 1
        STRING("e"): E <- E + 1
    ENDCASE
ENDFOR
OUTPUT TUPLE(A, E)
Part 2 - Pseudocode for Tasks 11-20
"""
        result = self.process(source)
        self.assertIn('IF Character == STRING("a") THEN', result.processed_source)
        self.assertIn('ELSE IF Character == STRING("e") THEN', result.processed_source)
        self.assertNotIn("Part 2 -", result.processed_source)
        parsed = AJParserFacade().parse(result.processed_source)
        self.assertTrue(parsed.success, parsed.error)

    def test_add_to_collection_becomes_append_and_parses(self):
        source = """IP_List <- INPUT(STRING("Enter IP_List"))
UniqueIPs <- EMPTY SET
FOR EACH IP IN IP_List DO
    ADD IP TO UniqueIPs
ENDFOR
OUTPUT UniqueIPs
"""
        result = self.process(source)
        self.assertIn("APPEND IP TO UniqueIPs", result.processed_source)
        parsed = AJParserFacade().parse(result.processed_source)
        self.assertTrue(parsed.success, parsed.error)

    def test_downto_range_is_normalised_once(self):
        source = """BEGIN
    INPUT Text

    Reverse ← ""

    FOR i ← LENGTH(Text)-1 DOWNTO 0
        Reverse ← Reverse + Text[i]
    ENDFOR

    OUTPUT Reverse
END
"""
        result = self.process(source)
        expected = """Text <- INPUT(STRING("Enter Text"))

Reverse <- EMPTY STRING

FOR i <- IN RANGE LENGTH OF Text-1 TO 0 STEP -1 DO
    Reverse <- Reverse + Text[i]
ENDFOR

OUTPUT Reverse"""
        self.assertEqual(expected, result.processed_source.strip())
        self.assertNotIn("IN RANGE IN RANGE", result.processed_source)
        parsed = AJParserFacade().parse(result.processed_source)
        self.assertTrue(parsed.success, parsed.error)

    def test_anonymous_dictionary_declaration_parses(self):
        source = """Text <- INPUT(STRING("Enter Text"))
Create Dictionary
OUTPUT Text
"""
        result = self.process(source)
        self.assertIn("Anonymous_Dictionary <- EMPTY DICTIONARY", result.processed_source)
        parsed = AJParserFacade().parse(result.processed_source)
        self.assertTrue(parsed.success, parsed.error)

    def test_all_part_section_labels_are_stripped(self):
        for heading in (
            "Part 1 - Pseudocode for Tasks 1-10",
            "Part 2 - Pseudocode for Tasks 11-20",
            "Part 3 - Pseudocode for Tasks 21-30",
            "Part 10 - Additional Pseudocode",
        ):
            source = f"""Number <- 6
OUTPUT Number
{heading}
"""
            result = self.process(source)
            self.assertNotIn("Part ", result.processed_source)
            parsed = AJParserFacade().parse(result.processed_source)
            self.assertTrue(parsed.success, parsed.error)

    def test_anonymous_queue_uses_append_and_pop_zero_semantics(self):
        source = """Root <- INPUT(STRING("Enter Root"))
CREATE EMPTY QUEUE
ENQUEUE Root
WHILE Queue is not empty DO
    Node <- DEQUEUE Queue
    OUTPUT Node
ENDWHILE
"""
        result = self.process(source)
        self.assertIn("Anonymous_Queue <- EMPTY LIST", result.processed_source)
        self.assertIn("APPEND Root TO Anonymous_Queue", result.processed_source)
        self.assertIn("Node <- REMOVE FIRST ITEM FROM Anonymous_Queue", result.processed_source)
        self.assertNotRegex(result.processed_source, r"\\bQueue\\b")

    def test_inferred_node_queue_traversal_compiles(self):
        source = """BEGIN
    INPUT Root

    CREATE Empty Queue
    ENQUEUE Root

    WHILE Queue is not empty
        Node ← DEQUEUE Queue
        OUTPUT Node.Value

        IF Node.Left exists THEN
            ENQUEUE Node.Left
        ENDIF

        IF Node.Right exists THEN
            ENQUEUE Node.Right
        ENDIF
    ENDWHILE
END
"""
        result = self.process(source)
        self.assertIn('Root_Key <- INPUT(STRING("Enter Root"))', result.processed_source)
        self.assertIn("Root <- CALL lookup_inferred_node(Root_Key)", result.processed_source)
        self.assertIn("Node <- REMOVE FIRST ITEM FROM Anonymous_Queue", result.processed_source)
        self.assertIn("OUTPUT Node.Value", result.processed_source)
        self.assertIn("IF Node.Left != CALL NULL() THEN", result.processed_source)

        parsed = AJParserFacade().parse(result.processed_source)
        self.assertTrue(parsed.success, parsed.error)

        flow = FlowDiagramEncoder().encode(parsed.ast)
        compiled = AJPythonCompiler().compile(flow)
        self.assertTrue(compiled.success)
        self.assertIn("Node = Anonymous_Queue.pop(0)", compiled.source_code)
        self.assertIn("print(Node.value)", compiled.source_code)
        self.assertIn("if (Node.left != None):", compiled.source_code)

    def test_inferred_node_lookup_is_preinitialised_and_does_not_insert_missing_key(self):
        source = """BEGIN
    INPUT Root
    CREATE Empty Queue
    ENQUEUE Root
    WHILE Queue is not empty
        Node ← DEQUEUE Queue
        OUTPUT Node.Value
        IF Node.Left exists THEN
            ENQUEUE Node.Left
        ENDIF
        IF Node.Right exists THEN
            ENQUEUE Node.Right
        ENDIF
    ENDWHILE
END
"""
        result = self.process(source)
        parsed = AJParserFacade().parse(result.processed_source)
        self.assertTrue(parsed.success, parsed.error)
        flow = FlowDiagramEncoder().encode(parsed.ast)
        compiled = AJPythonCompiler().compile(flow)
        self.assertIn("random.sample(range(1, 101), k=10)", compiled.source_code)
        self.assertIn("_inferred_node_lookup = {", compiled.source_code)
        self.assertIn("return None", compiled.source_code)
        self.assertNotIn("_inferred_node_lookup[key] = InferredNode(key)", compiled.source_code)

    def test_inferred_lookup_does_not_output_success_value(self):
        source = """BEGIN
    INPUT Root
    CREATE Empty Queue
    ENQUEUE Root
    WHILE Queue is not empty
        Node ← DEQUEUE Queue
        OUTPUT Node.Value
        IF Node.Left exists THEN
            ENQUEUE Node.Left
        ENDIF
        IF Node.Right exists THEN
            ENQUEUE Node.Right
        ENDIF
    ENDWHILE
END
"""
        result = self.process(source)
        parsed = AJParserFacade().parse(result.processed_source)
        self.assertTrue(parsed.success, parsed.error)

        flow = FlowDiagramEncoder().encode(parsed.ast)
        compiled = AJPythonCompiler().compile(flow)

        self.assertIn("return _inferred_node_lookup[key]", compiled.source_code)
        self.assertNotIn("print(f'{_inferred_node_lookup[key]}')", compiled.source_code)
        self.assertIn("print(Node.value)", compiled.source_code)

    def test_stop_compiles_to_quit(self):
        source = """Number <- 9
WHILE Number > 0 DO
    IF Number == 9 THEN
        OUTPUT Number
        STOP
    ENDIF
    Number <- Number - 1
ENDWHILE
"""
        parsed = AJParserFacade().parse(source)
        self.assertTrue(parsed.success, parsed.error)
        flow = FlowDiagramEncoder().encode(parsed.ast)
        compiled = AJPythonCompiler().compile(flow)
        self.assertTrue(compiled.success)
        self.assertIn("quit()", compiled.source_code)
        self.assertNotIn("break", compiled.source_code)

    def test_array_stack_recovery_compiles_to_push_pop_peek(self):
        source = """CREATE Stack
Top <- -1

CALL PUSH(Item)
    Top <- Top + 1
    Stack[Top] <- Item

CALL POP()
    IF Top == -1 THEN
        OUTPUT STRING("Stack Empty")
    ELSE
        Item <- Stack[Top]
        Top <- Top - 1
        OUTPUT Item
    ENDIF

CALL PEEK()
    IF Top != -1 THEN
        OUTPUT Stack[Top]
    ENDIF
"""
        result = self.process(source)
        self.assertIn("Stack <- EMPTY LIST", result.processed_source)
        self.assertIn("FUNCTION PUSH ACCEPTS(Item)", result.processed_source)
        self.assertIn("Item <- REMOVE LAST ITEM FROM Stack", result.processed_source)
        self.assertIn("IF LENGTH OF Stack > 0 THEN", result.processed_source)

        parsed = AJParserFacade().parse(result.processed_source)
        self.assertTrue(parsed.success, parsed.error)

        flow = FlowDiagramEncoder().encode(parsed.ast)
        compiled = AJPythonCompiler().compile(flow)

        self.assertIn("Stack.append(Item)", compiled.source_code)
        self.assertIn("Item = Stack.pop(-1)", compiled.source_code)
        self.assertIn("if (len(Stack) > 0):", compiled.source_code)
        self.assertIn("print(Stack[(-1)])", compiled.source_code)

    def test_character_frequency_expansion_preserves_text_input(self):
        source = """BEGIN
    INPUT Text
    COUNT frequency of each character
    FOR EACH Character IN Text DO
        IF Frequency(Character) = 1 THEN
            OUTPUT Character
            STOP
        ENDIF
    ENDFOR
    OUTPUT "None Found"
END
"""
        result = self.process(source)
        self.assertIn('Text <- INPUT(STRING("Enter Text"))', result.processed_source)
        self.assertIn("Character_Frequency <- EMPTY DICTIONARY", result.processed_source)
        self.assertIn(
            "Character_Frequency[Character] <- Character_Frequency[Character] + 1",
            result.processed_source,
        )
        self.assertIn("IF Character_Frequency[Character] == 1 THEN", result.processed_source)

        parsed = AJParserFacade().parse(result.processed_source)
        self.assertTrue(parsed.success, parsed.error)

        flow = FlowDiagramEncoder().encode(parsed.ast)
        compiled = AJPythonCompiler().compile(flow)

        self.assertIn("Character_Frequency = {}", compiled.source_code)
        self.assertIn("print(Character)", compiled.source_code)
        self.assertIn("quit()", compiled.source_code)

    def test_linked_cycle_detection_outputs_adjacency(self):
        source = """BEGIN
    INPUT Head
    Slow <- Head
    Fast <- Head
    WHILE Fast != NULL AND Fast.Next != NULL
        Slow <- Slow.Next
        Fast <- Fast.Next.Next
        IF Slow == Fast THEN
            OUTPUT "Cycle Detected"
            STOP
        ENDIF
    ENDWHILE
    OUTPUT "No Cycle"
END
"""
        result = self.process(source)
        self.assertIn("lookup_inferred_linked_node", result.processed_source)
        self.assertIn("Fast.Next.Next", result.processed_source)
        self.assertNotIn("CALL output_adjacency_list(Head)", result.processed_source)

        parsed = AJParserFacade().parse(result.processed_source)
        self.assertTrue(parsed.success, parsed.error)

        flow = FlowDiagramEncoder().encode(parsed.ast)
        compiled = AJPythonCompiler().compile(flow)

        self.assertIn("def output_adjacency_list(head):", compiled.source_code)
        self.assertIn("Fast = Fast.next.next", compiled.source_code)

    def test_two_stack_queue_recovery(self):
        source = """CREATE Stack1
CREATE Stack2

CALL ENQUEUE(Item)
    PUSH Item onto Stack1

CALL DEQUEUE()
    IF Stack2 is empty THEN
        WHILE Stack1 is not empty
            PUSH POP(Stack1) onto Stack2
        ENDWHILE
    ENDIF

    OUTPUT POP(Stack2)
"""
        result = self.process(source)
        self.assertIn("Stack1 <- EMPTY LIST", result.processed_source)
        self.assertIn("Stack2 <- EMPTY LIST", result.processed_source)
        self.assertIn("FUNCTION ENQUEUE ACCEPTS(Item)", result.processed_source)
        self.assertIn("Item <- REMOVE LAST ITEM FROM Stack1", result.processed_source)
        self.assertIn("APPEND Item TO Stack2", result.processed_source)

        parsed = AJParserFacade().parse(result.processed_source)
        self.assertTrue(parsed.success, parsed.error)

        flow = FlowDiagramEncoder().encode(parsed.ast)
        compiled = AJPythonCompiler().compile(flow)

        self.assertIn("Stack1.append(Item)", compiled.source_code)
        self.assertIn("Item = Stack1.pop(-1)", compiled.source_code)
        self.assertIn("Stack2.append(Item)", compiled.source_code)
        self.assertIn("Item = Stack2.pop(-1)", compiled.source_code)

    def test_n_queens_recovery_uses_empty_string_board(self):
        source = """BEGIN
    INPUT N
    CREATE N * N board
    FUNCTION Solve ACCEPTS(Row)
        IF Row = N THEN
            OUTPUT Board
            RETURN
        ENDIF
        FOR Col <- 0 TO N-1
            IF Position(Row, Col) is safe THEN
                PLACE Queen at (Row, Col)
                CALL Solve(Row + 1)
                REMOVE Queen from (Row, Col)
            ENDIF
        ENDFOR
    ENDFUNCTION
    CALL Solve(0)
END
"""
        result = self.process(source)
        self.assertIn("Board <- CALL create_matrix(N, N, EMPTY STRING)", result.processed_source)
        self.assertIn('Board[Row][Col] <- STRING("Q")', result.processed_source)
        self.assertIn("Board[Row][Col] <- EMPTY STRING", result.processed_source)
        self.assertIn("FUNCTION is_safe ACCEPTS(Row, Col)", result.processed_source)

        parsed = AJParserFacade().parse(result.processed_source)
        self.assertTrue(parsed.success, parsed.error)

        flow = FlowDiagramEncoder().encode(parsed.ast)
        compiled = AJPythonCompiler().compile(flow)

        self.assertIn("Board = [['' for _ in range(N)] for _ in range(N)]", compiled.source_code)
        self.assertIn("Board[Row][Col] = 'Q'", compiled.source_code)
        self.assertIn("Board[Row][Col] = ''", compiled.source_code)
        self.assertIn("def is_safe(Row, Col):", compiled.source_code)

    def test_multiline_expression_join_and_matrix_multiplication_recovery(self):
        source = """BEGIN
    INPUT MatrixA
    INPUT MatrixB
    INPUT RowsA
    INPUT ColumnsA
    INPUT ColumnsB

    FOR i <- 0 TO RowsA-1
        FOR j <- 0 TO ColumnsB-1
            Result[i][j] <- 0

            FOR k <- 0 TO ColumnsA-1
                Result[i][j] <- Result[i][j] +
                                MatrixA[i][k] * MatrixB[k][j]
            ENDFOR
        ENDFOR
    ENDFOR

    OUTPUT Result
END
"""
        result = self.process(source)

        self.assertIn(
            "MatrixA <- CALL random_matrix_auto()",
            result.processed_source,
        )
        self.assertIn(
            "MatrixB <- CALL random_compatible_matrix(MatrixA)",
            result.processed_source,
        )
        self.assertIn("RowsA <- LENGTH OF MatrixA", result.processed_source)
        self.assertIn("ColumnsA <- LENGTH OF MatrixA[0]", result.processed_source)
        self.assertIn("ColumnsB <- LENGTH OF MatrixB[0]", result.processed_source)
        self.assertIn(
            "Result <- CALL create_matrix(RowsA, ColumnsB, 0)",
            result.processed_source,
        )
        self.assertIn(
            "Result[i][j] <- Result[i][j] + MatrixA[i][k] * MatrixB[k][j]",
            result.processed_source,
        )

        parsed = AJParserFacade().parse(result.processed_source)
        self.assertTrue(parsed.success, parsed.error)

        flow = FlowDiagramEncoder().encode(parsed.ast)
        compiled = AJPythonCompiler().compile(flow)

        self.assertIn(
            "MatrixA = [[random.randint(0, 9) for _ in range(_matrix_a_columns)] for _ in range(_matrix_a_rows)]",
            compiled.source_code,
        )
        self.assertIn(
            "MatrixB = [[random.randint(0, 9) for _ in range(_matrix_b_columns)] for _ in range(len(MatrixA[0]))]",
            compiled.source_code,
        )
        self.assertIn("RowsA = len(MatrixA)", compiled.source_code)
        self.assertIn("ColumnsA = len(MatrixA[0])", compiled.source_code)
        self.assertIn("ColumnsB = len(MatrixB[0])", compiled.source_code)
        self.assertIn(
            "Result = [[0 for _ in range(ColumnsB)] for _ in range(RowsA)]",
            compiled.source_code,
        )

    def test_maze_pathfinding_recovery_uses_graph_bfs(self):
        source = """BEGIN
    INPUT Maze, Start, Goal
    CREATE Queue
    MARK Start as visited
    ENQUEUE Start
    WHILE Queue is not empty
        Current <- DEQUEUE Queue
        IF Current = Goal THEN
            OUTPUT "Path Found"
            STOP
        ENDIF
        FOR EACH Neighbour of Current
            IF Neighbour not visited THEN
                MARK Neighbour as visited
                ENQUEUE Neighbour
            ENDIF
        ENDFOR
    ENDWHILE
    OUTPUT "No Path Found"
END
"""
        result = self.process(source)

        self.assertIn(
            "FUNCTION find_path ACCEPTS(Maze, Start, Goal)",
            result.processed_source,
        )
        self.assertIn("Visited <- EMPTY SET", result.processed_source)
        self.assertIn("Current <- REMOVE FIRST ITEM FROM Anonymous_Queue", result.processed_source)
        self.assertIn("FOR EACH Neighbour IN Maze[Current] DO", result.processed_source)
        self.assertIn("Maze <- CALL random_graph()", result.processed_source)

        parsed = AJParserFacade().parse(result.processed_source)
        self.assertTrue(parsed.success, parsed.error)

        flow = FlowDiagramEncoder().encode(parsed.ast)
        compiled = AJPythonCompiler().compile(flow)

        self.assertIn("def find_path(Maze, Start, Goal):", compiled.source_code)
        self.assertIn("Current = Anonymous_Queue.pop(0)", compiled.source_code)
        self.assertIn("Visited.add(Start)", compiled.source_code)
        self.assertIn("for Neighbour in Maze[Current]:", compiled.source_code)

    def test_maze_graph_is_undirected_without_invented_path_state(self):
        source = """BEGIN
    INPUT Maze, Start, Goal
    CREATE Queue
    MARK Start as visited
    ENQUEUE Start
    WHILE Queue is not empty
        Current <- DEQUEUE Queue
        IF Current = Goal THEN
            OUTPUT "Path Found"
            STOP
        ENDIF
        FOR EACH Neighbour of Current
            IF Neighbour not visited THEN
                MARK Neighbour as visited
                ENQUEUE Neighbour
            ENDIF
        ENDFOR
    ENDWHILE
    OUTPUT "No Path Found"
END
"""
        result = self.process(source)
        self.assertNotIn('OUTPUT STRING("Path: {Path}")', result.processed_source)

        parsed = AJParserFacade().parse(result.processed_source)
        self.assertTrue(parsed.success, parsed.error)
        flow = FlowDiagramEncoder().encode(parsed.ast)
        compiled = AJPythonCompiler().compile(flow)

        self.assertIn("def _random_undirected_graph():", compiled.source_code)
        self.assertIn("graph[left].append(right)", compiled.source_code)
        self.assertIn("graph[right].append(left)", compiled.source_code)
        self.assertNotIn("Path = Path[::-1]", compiled.source_code)
        self.assertNotIn("print(f'Path: {Path}')", compiled.source_code)

    def test_maze_recovery_does_not_invent_path_state(self):
        source = """BEGIN
    INPUT Maze, Start, Goal
    CREATE Queue
    MARK Start as visited
    ENQUEUE Start
    WHILE Queue is not empty
        Current <- DEQUEUE Queue
        IF Current = Goal THEN
            OUTPUT "Path Found"
            STOP
        ENDIF
        FOR EACH Neighbour of Current
            IF Neighbour not visited THEN
                MARK Neighbour as visited
                ENQUEUE Neighbour
            ENDIF
        ENDFOR
    ENDWHILE
    OUTPUT "No Path Found"
END
"""
        result = self.process(source)

        self.assertNotIn("Previous", result.processed_source)
        self.assertNotIn("Path <-", result.processed_source)
        self.assertNotIn("Walk <-", result.processed_source)

        parsed = AJParserFacade().parse(result.processed_source)
        self.assertTrue(parsed.success, parsed.error)

        flow = FlowDiagramEncoder().encode(parsed.ast)
        compiled = AJPythonCompiler().compile(flow)

        self.assertNotIn("Previous", compiled.source_code)
        self.assertNotIn("Path =", compiled.source_code)
        self.assertIn("print('Path Found')", compiled.source_code)

    def test_sort_characters_to_destination(self):
        source = """FUNCTION isAnagram ACCEPTS(str1, str2)
    IF LENGTH OF str1 != LENGTH OF str2 THEN
        RETURN BOOLEAN(False)
    ENDIF
    sort characters of str1 TO sorted1
    sort characters of str2 TO sorted2
    RETURN sorted1 == sorted2
ENDFUNCTION
"""
        result = self.process(source)
        self.assertIn("sorted1 <- CALL sort_characters(str1)", result.processed_source)
        self.assertIn("sorted2 <- CALL sort_characters(str2)", result.processed_source)

        parsed = AJParserFacade().parse(result.processed_source)
        self.assertTrue(parsed.success, parsed.error)
        flow = FlowDiagramEncoder().encode(parsed.ast)
        compiled = AJPythonCompiler().compile(flow)

        self.assertIn("sorted1 = \'\'.join(sorted(str1))", compiled.source_code)
        self.assertIn("sorted2 = \'\'.join(sorted(str2))", compiled.source_code)

    def test_inline_else_if_and_else_bodies(self):
        source = """FUNCTION intersection ACCEPTS(A, B)
    result <- EMPTY LIST
    i <- 0
    j <- 0
    WHILE i < LENGTH OF A AND j < LENGTH OF B DO
        IF A[i] == B[j] THEN
            APPEND A[i] TO result
            i <- i + 1
            j <- j + 1
        ELSE IF A[i] < B[j] THEN i <- i + 1
        ELSE j <- j + 1
        ENDIF
    ENDWHILE
    RETURN result
ENDFUNCTION
"""
        result = self.process(source)
        self.assertIn("ELSE IF A[i] < B[j] THEN\n            i <- i + 1", result.processed_source)
        self.assertIn("ELSE\n            j <- j + 1", result.processed_source)

        parsed = AJParserFacade().parse(result.processed_source)
        self.assertTrue(parsed.success, parsed.error)
        flow = FlowDiagramEncoder().encode(parsed.ast)
        compiled = AJPythonCompiler().compile(flow)
        self.assertIn("elif (A[i] < B[j]):", compiled.source_code)
        self.assertIn("else:", compiled.source_code)

    def test_inline_if_statement_body(self):
        source = """FUNCTION splitIntoWords ACCEPTS(sentence)
    words <- EMPTY LIST
    currentWord <- EMPTY STRING
    FOR EACH character IN sentence DO
        IF character == STRING(" ") THEN
            IF currentWord != EMPTY STRING THEN APPEND currentWord TO words THEN
            ENDIF
            currentWord <- EMPTY STRING
        ELSE
            currentWord <- currentWord + character
        ENDIF
    ENDFOR
    IF currentWord != EMPTY STRING THEN APPEND currentWord TO words THEN
    ENDIF
    RETURN words
ENDFUNCTION
"""
        result = self.process(source)

        self.assertIn(
            "IF currentWord != EMPTY STRING THEN\n                APPEND currentWord TO words",
            result.processed_source,
        )

        parsed = AJParserFacade().parse(result.processed_source)
        self.assertTrue(parsed.success, parsed.error)

        flow = FlowDiagramEncoder().encode(parsed.ast)
        compiled = AJPythonCompiler().compile(flow)
        self.assertIn("words.append(currentWord)", compiled.source_code)

    def test_endif_before_else_if_is_removed(self):
        source = """FUNCTION scoreToGrade ACCEPTS(score)
    IF score >= 70 THEN
        RETURN STRING("Distinction")
    ENDIF
    ELSE IF score >= 55 THEN RETURN STRING("Merit") THEN
    ELSE IF score >= 40 THEN RETURN STRING("Pass") THEN
    ELSE RETURN STRING("Fail")
ENDFUNCTION
"""
        result = self.process(source)

        self.assertIn('ELSE IF score >= 55 THEN', result.processed_source)
        self.assertNotIn('RETURN STRING("Distinction")\n    ENDIF\n    ELSE IF', result.processed_source)

        parsed = AJParserFacade().parse(result.processed_source)
        self.assertTrue(parsed.success, parsed.error)

        flow = FlowDiagramEncoder().encode(parsed.ast)
        compiled = AJPythonCompiler().compile(flow)
        self.assertIn("elif (score >= 55):", compiled.source_code)
        self.assertIn("elif (score >= 40):", compiled.source_code)
        self.assertIn("else:", compiled.source_code)

    def test_level_order_implied_existing_tree(self):
        source = """FUNCTION levelOrder ACCEPTS(root)
    IF root is NULL THEN
        RETURN EMPTY LIST
    ENDIF
    queue <- [root]
    result <- EMPTY LIST
    WHILE queue is not empty DO
        level <- EMPTY LIST
        nextQueue <- EMPTY LIST
        FOR EACH node IN queue DO
            APPEND node_value TO level
            IF node_left != NULL THEN APPEND node_left TO nextQueue THEN
            ENDIF
            IF node_right != NULL THEN APPEND node_right TO nextQueue THEN
            ENDIF
        ENDFOR
        APPEND level TO result
        queue <- nextQueue
    ENDWHILE
    RETURN result
ENDFUNCTION
"""
        result = self.process(source)
        self.assertIn("root == CALL NULL()", result.processed_source)
        self.assertIn("node.value", result.processed_source)
        self.assertIn("node.left", result.processed_source)
        self.assertIn("node.right", result.processed_source)
        self.assertNotIn("build_example_binary_tree", result.processed_source)

        parsed = AJParserFacade().parse(result.processed_source)
        self.assertTrue(parsed.success, parsed.error)

        flow = FlowDiagramEncoder().encode(parsed.ast)
        compiled = AJPythonCompiler().compile(flow)
        self.assertIn("level.append(node.value)", compiled.source_code)

    def test_random_list_inference_is_narrow(self):
        source = """INPUT CustomerList
FOR EACH Customer IN CustomerList DO
    OUTPUT Customer
ENDFOR
"""
        result = self.process(source)
        self.assertIn('CustomerList <- INPUT(STRING("Enter CustomerList"))', result.processed_source)
        self.assertNotIn("random_list", result.processed_source)

    def test_reverse_indexed_expression(self):
        source = """FUNCTION rotateMatrix ACCEPTS(matrix, N)
    FOR i <- IN RANGE 0 TO N - 1 DO
        FOR j <- IN RANGE i + 1 TO N - 1 DO
            _swap_temp <- matrix[i][j]
            matrix[i][j] <- matrix[j][i]
            matrix[j][i] <- _swap_temp
        ENDFOR
    ENDFOR
    FOR i <- IN RANGE 0 TO N - 1 DO
        REVERSE matrix[i]
    ENDFOR
    RETURN matrix
ENDFUNCTION
"""
        result = self.process(source)
        self.assertIn(
            "matrix[i] <- CALL reverse_value(matrix[i])",
            result.processed_source,
        )

        parsed = AJParserFacade().parse(result.processed_source)
        self.assertTrue(parsed.success, parsed.error)

        flow = FlowDiagramEncoder().encode(parsed.ast)
        compiled = AJPythonCompiler().compile(flow)
        self.assertIn("matrix[i] = matrix[i][::-1]", compiled.source_code)

    def test_sliding_window_deque_shorthand(self):
        source = """FUNCTION slidingWindowMax ACCEPTS(arr, k)
    result <- EMPTY LIST
    deque <- EMPTY LIST   // stores indices
    FOR i <- IN RANGE 0 TO LENGTH OF arr - 1 DO
        WHILE deque not empty AND deque_front < i - k + 1 DO
            REMOVE front of deque
        ENDWHILE
        WHILE deque not empty AND arr[deque_back] < arr[i] DO
            REMOVE back of deque
        ENDWHILE
        APPEND i TO back of deque
        IF i >= k - 1 THEN APPEND arr[deque_front] TO result THEN
        ENDIF
    ENDFOR
    RETURN result
ENDFUNCTION
"""
        result = self.process(source)
        self.assertNotIn("// stores indices", result.processed_source)
        self.assertIn("LENGTH OF deque > 0", result.processed_source)
        self.assertIn("deque[0]", result.processed_source)
        self.assertIn("deque[-1]", result.processed_source)
        self.assertIn("REMOVE FIRST ITEM FROM deque", result.processed_source)
        self.assertIn("REMOVE LAST ITEM FROM deque", result.processed_source)
        self.assertIn("APPEND i TO deque", result.processed_source)

        parsed = AJParserFacade().parse(result.processed_source)
        self.assertTrue(parsed.success, parsed.error)

        flow = FlowDiagramEncoder().encode(parsed.ast)
        compiled = AJPythonCompiler().compile(flow)
        self.assertIn("deque.pop(0)", compiled.source_code)
        self.assertIn("deque.pop()", compiled.source_code)
        self.assertIn("deque.append(i)", compiled.source_code)

    def test_convert_to_set_normalisation(self):
        source = """FUNCTION findCommonElements ACCEPTS(list1, list2)
    set1 <- convert list1 to set
    result <- EMPTY LIST
    FOR EACH item IN list2 DO
        IF item IN set1 AND item NOT IN result THEN
            APPEND item TO result
        ENDIF
    ENDFOR
    RETURN result
ENDFUNCTION
"""
        result = self.process(source)
        self.assertIn(
            "set1 <- CALL to_set(list1)",
            result.processed_source,
        )

        parsed = AJParserFacade().parse(result.processed_source)
        self.assertTrue(parsed.success, parsed.error)

        flow = FlowDiagramEncoder().encode(parsed.ast)
        compiled = AJPythonCompiler().compile(flow)
        self.assertIn("set1 = set(list1)", compiled.source_code)

    def test_lru_cache_uses_ordered_dictionary_semantics(self):
        source = """FUNCTION LRUCache ACCEPTS(capacity)
    cache <- EMPTY DICTIONARY
    FUNCTION get ACCEPTS(key)
        IF key NOT IN cache THEN
            RETURN -1
        ENDIF
        MOVE key to most recently used position
        RETURN cache[key]
    ENDFUNCTION
    FUNCTION put ACCEPTS(key, value)
        IF key IN cache THEN REMOVE key THEN
        ELSE IF LENGTH OF cache == capacity THEN
            REMOVE least recently used (front) item
        ENDIF
        INSERT key:value at most recently used position
    ENDFUNCTION
ENDFUNCTION
"""
        result = self.process(source)
        self.assertIn("CALL move_key_to_back(cache, key)", result.processed_source)
        self.assertIn("CALL remove_key(cache, key)", result.processed_source)
        self.assertIn("CALL remove_first_mapping(cache)", result.processed_source)
        self.assertIn("cache[key] <- value", result.processed_source)
        self.assertNotIn("recentlyUsed", result.processed_source)

        parsed = AJParserFacade().parse(result.processed_source)
        self.assertTrue(parsed.success, parsed.error)

        flow = FlowDiagramEncoder().encode(parsed.ast)
        compiled = AJPythonCompiler().compile(flow)
        self.assertIn("cache.__setitem__(key, cache.pop(key))", compiled.source_code)
        self.assertIn("cache.pop(next(iter(cache)))", compiled.source_code)
        self.assertIn("cache[key] = value", compiled.source_code)

    def test_stack_function_shorthand(self):
        source = """FUNCTION Stack ACCEPTS()
    data <- EMPTY LIST

    FUNCTION push ACCEPTS(item)
        APPEND item TO data
    ENDFUNCTION

    FUNCTION pop ACCEPTS()
        IF data is empty THEN
            RETURN STRING("Underflow")
        ENDIF
        REMOVE and RETURN last item of data
    ENDFUNCTION

    FUNCTION peek ACCEPTS()
        IF data is empty THEN
            RETURN STRING("Empty")
        ENDIF
        RETURN last item of data
    ENDFUNCTION
ENDFUNCTION
"""
        result = self.process(source)

        self.assertIn("IF LENGTH OF data == 0 THEN", result.processed_source)
        self.assertIn("RETURN REMOVE LAST ITEM FROM data", result.processed_source)
        self.assertIn("RETURN data[-1]", result.processed_source)

        parsed = AJParserFacade().parse(result.processed_source)
        self.assertTrue(parsed.success, parsed.error)

        flow = FlowDiagramEncoder().encode(parsed.ast)
        compiled = AJPythonCompiler().compile(flow)

        self.assertIn("return data.pop(-1)", compiled.source_code)
        self.assertIn("return data[(-1)]", compiled.source_code)

    def test_floyd_cycle_implied_linked_list(self):
        source = """FUNCTION hasCycle ACCEPTS(head)
    slow <- head
    fast <- head
    WHILE fast != NULL AND fast_next != NULL DO
        slow <- slow_next
        fast <- fast_next.next
        IF slow == fast THEN
            RETURN BOOLEAN(True)
        ENDIF
    ENDWHILE
    RETURN BOOLEAN(False)
ENDFUNCTION
"""
        result = self.process(source)

        self.assertIn(
            "WHILE fast != CALL NULL() AND fast.next != CALL NULL() DO",
            result.processed_source,
        )
        self.assertIn("slow <- slow.next", result.processed_source)
        self.assertIn("fast <- fast.next.next", result.processed_source)
        self.assertNotIn("InferredNode", result.processed_source)

        parsed = AJParserFacade().parse(result.processed_source)
        self.assertTrue(parsed.success, parsed.error)

        flow = FlowDiagramEncoder().encode(parsed.ast)
        compiled = AJPythonCompiler().compile(flow)

        self.assertIn("slow = slow.next", compiled.source_code)
        self.assertIn("fast = fast.next.next", compiled.source_code)
        self.assertIn("return True", compiled.source_code)
        self.assertIn("return False", compiled.source_code)

    def test_queue_function_two_stacks(self):
        source = """FUNCTION Queue ACCEPTS()
    stack1 <- EMPTY LIST
    stack2 <- EMPTY LIST

    FUNCTION enqueue ACCEPTS(item)
        PUSH item ONTO stack1
    ENDFUNCTION

    FUNCTION dequeue ACCEPTS()
        IF stack2 is empty THEN
            WHILE stack1 is not empty DO
                PUSH CALL POP(stack1) ONTO stack2
            ENDWHILE
        ENDIF
        IF stack2 is empty THEN
            RETURN STRING("Underflow")
        ENDIF
        RETURN CALL POP(stack2)
    ENDFUNCTION
ENDFUNCTION
"""
        result = self.process(source)
        self.assertIn("APPEND item TO stack1", result.processed_source)
        self.assertIn("IF LENGTH OF stack2 == 0 THEN", result.processed_source)
        self.assertIn("WHILE LENGTH OF stack1 > 0 DO", result.processed_source)
        self.assertIn("Item <- REMOVE LAST ITEM FROM stack1", result.processed_source)
        self.assertIn("APPEND Item TO stack2", result.processed_source)
        self.assertIn("RETURN REMOVE LAST ITEM FROM stack2", result.processed_source)
        self.assertIn('RETURN STRING("Underflow")', result.processed_source)

        parsed = AJParserFacade().parse(result.processed_source)
        self.assertTrue(parsed.success, parsed.error)

        flow = FlowDiagramEncoder().encode(parsed.ast)
        compiled = AJPythonCompiler().compile(flow)
        self.assertIn("stack1.append(item)", compiled.source_code)
        self.assertIn("Item = stack1.pop(-1)", compiled.source_code)
        self.assertIn("stack2.append(Item)", compiled.source_code)
        self.assertIn("return stack2.pop(-1)", compiled.source_code)
        self.assertIn("return 'Underflow'", compiled.source_code)

    def test_claude_n_queens_zero_one_board(self):
        source = """FUNCTION solveNQueens ACCEPTS(N)
    board <- N*N grid of 0s
    CALL placeQueens(board, 0, N)
ENDFUNCTION

FUNCTION placeQueens ACCEPTS(board, row, N)
    IF row == N THEN RECORD solution; RETURN THEN
    ENDIF
    FOR col <- IN RANGE 0 TO N - 1 DO
        IF CALL isSafe(board, row, col, N) THEN
            board[row][col] <- 1
            CALL placeQueens(board, row + 1, N)
            board[row][col] <- 0   // backtrack
        ENDIF
    ENDFOR
ENDFUNCTION

FUNCTION isSafe ACCEPTS(board, row, col, N)
    CHECK column, upper-left diagonal, upper-right diagonal for queens
    RETURN BOOLEAN(True) if no conflicts
ENDFUNCTION
"""
        result = self.process(source)

        self.assertIn("board <- CALL create_matrix(N, N, 0)", result.processed_source)
        self.assertIn("RETURN board", result.processed_source)
        self.assertIn("board[row][col] <- 1", result.processed_source)
        self.assertIn("board[row][col] <- 0", result.processed_source)
        self.assertIn("FUNCTION isSafe ACCEPTS(board, row, col, N)", result.processed_source)

        parsed = AJParserFacade().parse(result.processed_source)
        self.assertTrue(parsed.success, parsed.error)

        flow = FlowDiagramEncoder().encode(parsed.ast)
        compiled = AJPythonCompiler().compile(flow)

        self.assertIn("board = [[0 for _ in range(N)] for _ in range(N)]", compiled.source_code)
        self.assertIn("return board", compiled.source_code)
        self.assertIn("board[row][col] = 1", compiled.source_code)
        self.assertIn("board[row][col] = 0", compiled.source_code)
        self.assertIn("def isSafe(board, row, col, N):", compiled.source_code)

    def test_call_append_pair_is_statement(self):
        source = """FUNCTION findPairs ACCEPTS(arr, target)
    seen <- EMPTY SET
    pairs <- EMPTY LIST
    FOR EACH num IN arr DO
        complement <- target - num
        IF complement IN seen THEN
            CALL APPEND (complement, num) TO pairs
        ENDIF
        ADD num TO seen
    ENDFOR
    RETURN pairs
ENDFUNCTION
"""
        result = self.process(source)
        self.assertIn("APPEND TUPLE(complement, num) TO pairs", result.processed_source)
        self.assertNotIn("CALL APPEND", result.processed_source)

        parsed = AJParserFacade().parse(result.processed_source)
        self.assertTrue(parsed.success, parsed.error)

        flow = FlowDiagramEncoder().encode(parsed.ast)
        compiled = AJPythonCompiler().compile(flow)
        self.assertIn("pairs.append((complement, num))", compiled.source_code)
        self.assertIn("seen.add(num)", compiled.source_code)

    def test_matrix_addition_preserves_2d_inputs(self):
        source = """FUNCTION addMatrices ACCEPTS(A, B, rows, cols)
    result <- rows * cols matrix of 0s
    FOR i <- IN RANGE 0 TO rows - 1 DO
        FOR j <- IN RANGE 0 TO cols - 1 DO
            result[i][j] <- A[i][j] + B[i][j]
        ENDFOR
    ENDFOR
    RETURN result
ENDFUNCTION
"""
        result = self.process(source)
        self.assertIn("result <- CALL create_matrix(rows, cols, 0)", result.processed_source)
        self.assertIn("result[i][j] <- A[i][j] + B[i][j]", result.processed_source)

        parsed = AJParserFacade().parse(result.processed_source)
        self.assertTrue(parsed.success, parsed.error)
        flow = FlowDiagramEncoder().encode(parsed.ast)
        compiled = AJPythonCompiler().compile(flow)
        self.assertIn("result = [[0 for _ in range(cols)] for _ in range(rows)]", compiled.source_code)
        self.assertIn("result[i][j] = (A[i][j] + B[i][j])", compiled.source_code)

    def test_claude_matrix_multiplication_preserves_2d_inputs(self):
        source = """FUNCTION multiplyMatrices ACCEPTS(A, B, n, m, p)
    COMMENT A is n*m, B is m*p
    result <- n * p matrix of 0s
    FOR i <- IN RANGE 0 TO n - 1 DO
        FOR j <- IN RANGE 0 TO p - 1 DO
            FOR k <- IN RANGE 0 TO m - 1 DO
                result[i][j] <- result[i][j] + A[i][k] * B[k][j]
            ENDFOR
        ENDFOR
    ENDFOR
    RETURN result
ENDFUNCTION
"""
        result = self.process(source)
        self.assertIn("result <- CALL create_matrix(n, p, 0)", result.processed_source)
        self.assertIn(
            "result[i][j] <- result[i][j] + A[i][k] * B[k][j]",
            result.processed_source,
        )

        parsed = AJParserFacade().parse(result.processed_source)
        self.assertTrue(parsed.success, parsed.error)
        flow = FlowDiagramEncoder().encode(parsed.ast)
        compiled = AJPythonCompiler().compile(flow)
        self.assertIn("result = [[0 for _ in range(p)] for _ in range(n)]", compiled.source_code)
        self.assertIn("A[i][k]", compiled.source_code)
        self.assertIn("B[k][j]", compiled.source_code)

    def test_inventory_update_implied_transaction_properties(self):
        source = """FUNCTION updateInventory ACCEPTS(inventory, transactions)
    FOR EACH transaction IN transactions DO
        item <- transaction_item
        type <- transaction_type
        quantity <- transaction_quantity
        IF item NOT IN inventory THEN inventory[item] <- 0 THEN
        ENDIF
        IF type == STRING("purchase") THEN
            inventory[item] <- inventory[item] - quantity
        ELSE IF type == STRING("delivery") THEN
            inventory[item] <- inventory[item] + quantity
        ENDIF
        IF inventory[item] < 0 THEN ALERT STRING("Insufficient stock for ") + item THEN
        ENDIF
    ENDFOR
    RETURN inventory
ENDFUNCTION
"""
        result = self.process(source)
        self.assertIn("item <- transaction.item", result.processed_source)
        self.assertIn("type <- transaction.type", result.processed_source)
        self.assertIn("quantity <- transaction.quantity", result.processed_source)
        self.assertIn('OUTPUT STRING("Insufficient stock for ") + item', result.processed_source)
        parsed = AJParserFacade().parse(result.processed_source)
        self.assertTrue(parsed.success, parsed.error)
        flow = FlowDiagramEncoder().encode(parsed.ast)
        compiled = AJPythonCompiler().compile(flow)
        self.assertIn("item = transaction.item", compiled.source_code)
        self.assertIn("quantity = transaction.quantity", compiled.source_code)


if __name__ == '__main__':
    unittest.main()
