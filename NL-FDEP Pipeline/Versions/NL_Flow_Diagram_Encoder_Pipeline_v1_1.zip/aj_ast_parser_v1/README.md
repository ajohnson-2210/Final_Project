# NL to Flow Diagram Encoder Pipeline v1.0

A dependency-free, object-oriented Python pipeline for AJ_24038155 Dialect v1.0.
The only external program input is AJ pseudocode.

## Pipeline

1. AJ pseudocode input
2. Lexical analysis
3. Recursive-descent parsing
4. AST construction
5. Static semantic validation
6. Machine-readable flow-diagram encoding
7. Interactive AST and flow-diagram visualisation
8. Deterministic Python compilation from `flow_diagram.json`
9. Subprocess-based behavioural testing
10. JSON reporting

## PyCharm

Open `pycharm_runner.py` and press **Run**. Configure these constants at the top
of the file when required:

- `INPUT_FILE`
- `OUTPUT_DIRECTORY`
- `OPEN_VISUALISATIONS`
- `TEST_CASES`

## Outputs

The runner creates:

- `output/ast.json`
- `output/parser_report.json`
- `output/ast_visualisation.html`
- `output/flow_diagram.json`
- `output/flow_diagram.html`
- `output/generated_program.py`
- `output/compilation_report.json`
- `output/test_report.json`
- `output/pipeline_report.json`

## Important design boundary

The AST is an internal intermediate representation. It is generated from
pseudocode and is not accepted as an external pipeline input. The compiler
accepts the machine-readable flow-diagram document produced by the encoder.

## Tests

```bash
python -m unittest discover -s tests -v
```
