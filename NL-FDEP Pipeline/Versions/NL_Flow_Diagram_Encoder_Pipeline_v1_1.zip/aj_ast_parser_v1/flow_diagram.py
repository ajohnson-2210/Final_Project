"""Machine-readable flow diagram generation from the AJ abstract syntax tree."""

from __future__ import annotations

from dataclasses import dataclass, field, fields
from typing import Any
import json

from aj_parser import (
    ASTNode,
    BlockNode,
    ForEachNode,
    ForRangeNode,
    FunctionNode,
    IfNode,
    ProgramNode,
    TryCatchNode,
    WhileNode,
)


@dataclass
class FlowNode:
    """Represents one executable or structural element in a flow diagram."""

    node_id: str
    node_type: str
    label: str
    line: int
    data: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "node_id": self.node_id,
            "node_type": self.node_type,
            "label": self.label,
            "line": self.line,
            "data": self.data,
        }


@dataclass
class FlowEdge:
    """Represents a directed connection between two flow nodes."""

    source: str
    target: str
    label: str = "NEXT"

    def to_dict(self) -> dict[str, str]:
        return {
            "source": self.source,
            "target": self.target,
            "label": self.label,
        }


@dataclass
class FlowDiagram:
    """Serializable flow diagram and structured program representation."""

    entry_node: str
    exit_node: str
    nodes: dict[str, FlowNode]
    edges: list[FlowEdge]
    structured_program: dict[str, Any]
    format_name: str = "NL-FDEP Flow Diagram"
    version: str = "1.0"

    def to_dict(self) -> dict[str, Any]:
        return {
            "format": self.format_name,
            "version": self.version,
            "entry_node": self.entry_node,
            "exit_node": self.exit_node,
            "nodes": {
                node_id: node.to_dict()
                for node_id, node in self.nodes.items()
            },
            "edges": [edge.to_dict() for edge in self.edges],
            "structured_program": self.structured_program,
        }

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), indent=2, default=str)

    @classmethod
    def from_dict(cls, document: dict[str, Any]) -> "FlowDiagram":
        FlowDiagramValidator().validate(document)

        nodes = {
            node_id: FlowNode(
                node_id=node_data["node_id"],
                node_type=node_data["node_type"],
                label=node_data["label"],
                line=node_data["line"],
                data=node_data.get("data", {}),
            )
            for node_id, node_data in document["nodes"].items()
        }

        edges = [
            FlowEdge(
                source=edge["source"],
                target=edge["target"],
                label=edge.get("label", "NEXT"),
            )
            for edge in document["edges"]
        ]

        return cls(
            entry_node=document["entry_node"],
            exit_node=document["exit_node"],
            nodes=nodes,
            edges=edges,
            structured_program=document["structured_program"],
            format_name=document["format"],
            version=document["version"],
        )

    @classmethod
    def from_json(cls, source: str) -> "FlowDiagram":
        document = json.loads(source)
        return cls.from_dict(document)


class ASTStructureSerializer:
    """Converts AST node objects into a deterministic dictionary structure."""

    def serialize(self, node: ASTNode | None) -> dict[str, Any] | None:
        if node is None:
            return None

        document: dict[str, Any] = {
            "kind": node.kind,
            "line": node.line,
        }

        for field_definition in fields(node):
            field_name = field_definition.name

            if field_name in {"line", "node_id"}:
                continue

            field_value = getattr(node, field_name)
            document[field_name] = self._serialize_value(field_value)

        return document

    def _serialize_value(self, value: Any) -> Any:
        if isinstance(value, ASTNode):
            return self.serialize(value)

        if isinstance(value, list):
            serialized_items: list[Any] = []

            for item in value:
                serialized_items.append(self._serialize_value(item))

            return serialized_items

        return value


class FlowDiagramValidator:
    """Validates the external flow-diagram document before compilation."""

    REQUIRED_FIELDS = {
        "format",
        "version",
        "entry_node",
        "exit_node",
        "nodes",
        "edges",
        "structured_program",
    }

    def validate(self, document: dict[str, Any]) -> None:
        if not isinstance(document, dict):
            raise ValueError("Flow diagram must be a JSON object.")

        missing_fields = self.REQUIRED_FIELDS.difference(document)

        if missing_fields:
            missing_text = ", ".join(sorted(missing_fields))
            raise ValueError(f"Flow diagram is missing fields: {missing_text}.")

        if document["format"] != "NL-FDEP Flow Diagram":
            raise ValueError("Unsupported flow diagram format.")

        if document["version"] != "1.0":
            raise ValueError("Unsupported flow diagram version.")

        nodes = document["nodes"]

        if document["entry_node"] not in nodes:
            raise ValueError("Flow diagram entry node does not exist.")

        if document["exit_node"] not in nodes:
            raise ValueError("Flow diagram exit node does not exist.")

        for edge in document["edges"]:
            if edge["source"] not in nodes:
                raise ValueError(f"Unknown flow edge source: {edge['source']}.")

            if edge["target"] not in nodes:
                raise ValueError(f"Unknown flow edge target: {edge['target']}.")

        program = document["structured_program"]

        if not isinstance(program, dict) or program.get("kind") != "ProgramNode":
            raise ValueError("Flow diagram does not contain a valid structured program.")


class FlowDiagramEncoder:
    """Encodes an AJ AST as a control-flow graph and compiler-ready document."""

    def __init__(self) -> None:
        self.nodes: dict[str, FlowNode] = {}
        self.edges: list[FlowEdge] = []
        self.next_identifier = 1

    def encode(self, program: ProgramNode) -> FlowDiagram:
        self.nodes = {}
        self.edges = []
        self.next_identifier = 1

        start_id = self._add_node("START", "Start", program.line)
        exit_id = self._add_node("END", "End", program.line)

        first_id, final_ids = self._encode_statements(program.body, exit_id)

        if first_id is None:
            self._add_edge(start_id, exit_id)
        else:
            self._add_edge(start_id, first_id)

            for final_id in final_ids:
                self._add_edge(final_id, exit_id)

        structured_program = ASTStructureSerializer().serialize(program)

        if structured_program is None:
            raise ValueError("Unable to serialize the AST program.")

        diagram = FlowDiagram(
            entry_node=start_id,
            exit_node=exit_id,
            nodes=self.nodes,
            edges=self.edges,
            structured_program=structured_program,
        )

        FlowDiagramValidator().validate(diagram.to_dict())

        return diagram

    def _encode_statements(
        self,
        statements: list[ASTNode],
        continuation_id: str | None,
    ) -> tuple[str | None, list[str]]:
        first_id: str | None = None
        previous_final_ids: list[str] = []

        for statement in statements:
            statement_first_id, statement_final_ids = self._encode_statement(
                statement,
                continuation_id,
            )

            if first_id is None:
                first_id = statement_first_id

            for previous_id in previous_final_ids:
                self._add_edge(previous_id, statement_first_id)

            previous_final_ids = statement_final_ids

        return first_id, previous_final_ids

    def _encode_statement(
        self,
        statement: ASTNode,
        continuation_id: str | None,
    ) -> tuple[str, list[str]]:
        if isinstance(statement, IfNode):
            return self._encode_if(statement, continuation_id)

        if isinstance(statement, WhileNode):
            return self._encode_while(statement)

        if isinstance(statement, (ForEachNode, ForRangeNode)):
            return self._encode_for(statement)

        if isinstance(statement, TryCatchNode):
            return self._encode_try_catch(statement)

        if isinstance(statement, FunctionNode):
            return self._encode_function(statement)

        node_type = self._classify_statement(statement)
        label = self._statement_label(statement)
        node_id = self._add_node(
            node_type,
            label,
            statement.line,
            {"ast_kind": statement.kind},
        )

        return node_id, [node_id]

    def _encode_if(
        self,
        statement: IfNode,
        continuation_id: str | None,
    ) -> tuple[str, list[str]]:
        decision_id = self._add_node(
            "DECISION",
            "If condition",
            statement.line,
            {"ast_kind": statement.kind},
        )

        final_ids: list[str] = []
        then_first, then_finals = self._encode_statements(
            statement.then_body.statements,
            continuation_id,
        )

        if then_first is not None:
            self._add_edge(decision_id, then_first, "TRUE")
            final_ids.extend(then_finals)
        else:
            final_ids.append(decision_id)

        false_source_id = decision_id

        for clause in statement.else_if:
            clause_id = self._add_node(
                "DECISION",
                "Else-if condition",
                clause.line,
                {"ast_kind": clause.kind},
            )
            self._add_edge(false_source_id, clause_id, "FALSE")

            clause_first, clause_finals = self._encode_statements(
                clause.body.statements,
                continuation_id,
            )

            if clause_first is not None:
                self._add_edge(clause_id, clause_first, "TRUE")
                final_ids.extend(clause_finals)
            else:
                final_ids.append(clause_id)

            false_source_id = clause_id

        if statement.else_body is not None:
            else_first, else_finals = self._encode_statements(
                statement.else_body.statements,
                continuation_id,
            )

            if else_first is not None:
                self._add_edge(false_source_id, else_first, "FALSE")
                final_ids.extend(else_finals)
            else:
                final_ids.append(false_source_id)
        else:
            final_ids.append(false_source_id)

        return decision_id, final_ids

    def _encode_while(self, statement: WhileNode) -> tuple[str, list[str]]:
        decision_id = self._add_node(
            "LOOP_DECISION",
            "While condition",
            statement.line,
            {"ast_kind": statement.kind},
        )
        body_first, body_finals = self._encode_statements(
            statement.body.statements,
            decision_id,
        )

        if body_first is not None:
            self._add_edge(decision_id, body_first, "TRUE")

            for final_id in body_finals:
                self._add_edge(final_id, decision_id, "LOOP")
        else:
            self._add_edge(decision_id, decision_id, "TRUE")

        return decision_id, [decision_id]

    def _encode_for(
        self,
        statement: ForEachNode | ForRangeNode,
    ) -> tuple[str, list[str]]:
        loop_id = self._add_node(
            "LOOP_DECISION",
            self._statement_label(statement),
            statement.line,
            {"ast_kind": statement.kind},
        )
        body_first, body_finals = self._encode_statements(
            statement.body.statements,
            loop_id,
        )

        if body_first is not None:
            self._add_edge(loop_id, body_first, "ITERATE")

            for final_id in body_finals:
                self._add_edge(final_id, loop_id, "LOOP")

        return loop_id, [loop_id]

    def _encode_try_catch(
        self,
        statement: TryCatchNode,
    ) -> tuple[str, list[str]]:
        try_id = self._add_node(
            "TRY",
            "Try block",
            statement.line,
            {"ast_kind": statement.kind},
        )
        try_first, try_finals = self._encode_statements(
            statement.try_body.statements,
            None,
        )
        catch_first, catch_finals = self._encode_statements(
            statement.catch_body.statements,
            None,
        )

        if try_first is not None:
            self._add_edge(try_id, try_first, "TRY")

        if catch_first is not None:
            self._add_edge(try_id, catch_first, "EXCEPTION")

        final_ids = try_finals + catch_finals

        if not final_ids:
            final_ids = [try_id]

        return try_id, final_ids

    def _encode_function(
        self,
        statement: FunctionNode,
    ) -> tuple[str, list[str]]:
        function_id = self._add_node(
            "FUNCTION",
            f"Function {statement.name}",
            statement.line,
            {"ast_kind": statement.kind, "name": statement.name},
        )
        body_first, body_finals = self._encode_statements(
            statement.body.statements,
            None,
        )

        if body_first is not None:
            self._add_edge(function_id, body_first, "BODY")

        return function_id, body_finals or [function_id]

    def _add_node(
        self,
        node_type: str,
        label: str,
        line: int,
        data: dict[str, Any] | None = None,
    ) -> str:
        node_id = f"F{self.next_identifier}"
        self.next_identifier += 1
        self.nodes[node_id] = FlowNode(
            node_id=node_id,
            node_type=node_type,
            label=label,
            line=line,
            data=data or {},
        )
        return node_id

    def _add_edge(
        self,
        source: str,
        target: str,
        label: str = "NEXT",
    ) -> None:
        self.edges.append(FlowEdge(source, target, label))

    @staticmethod
    def _classify_statement(statement: ASTNode) -> str:
        mapping = {
            "AssignmentNode": "PROCESS",
            "OutputNode": "OUTPUT",
            "InputNode": "INPUT",
            "ReturnNode": "RETURN",
            "CallNode": "CALL",
            "BreakNode": "BREAK",
            "ContinueNode": "CONTINUE",
            "RaiseNode": "RAISE",
            "AppendNode": "PROCESS",
            "RemoveFirstNode": "PROCESS",
            "RemoveLastNode": "PROCESS",
            "CommentNode": "COMMENT",
        }
        return mapping.get(statement.kind, "PROCESS")

    @staticmethod
    def _statement_label(statement: ASTNode) -> str:
        if isinstance(statement, ForEachNode):
            return f"For each {statement.variable.name}"

        if isinstance(statement, ForRangeNode):
            return f"For {statement.variable.name} in range"

        return statement.kind.removesuffix("Node")
