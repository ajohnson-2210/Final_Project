"""Standard-convention flowchart visualisation for machine-readable flow diagrams."""

from __future__ import annotations

from collections import defaultdict, deque
from pathlib import Path
import html
import json
import webbrowser

from flow_diagram import FlowDiagram, FlowEdge, FlowNode


class FlowDiagramVisualizer:
    """Creates an interactive SVG flowchart using conventional flowchart symbols.

    The visual notation follows the convention demonstrated by the supplied
    Tic-Tac-Toe draw.io example: terminators for start/end, diamonds for
    decisions, process rectangles, input/output parallelograms, orthogonal
    arrow connectors, and visible branch labels.
    """

    NODE_WIDTH = 230
    NODE_HEIGHT = 64
    DECISION_WIDTH = 230
    DECISION_HEIGHT = 112
    HORIZONTAL_GAP = 120
    VERTICAL_GAP = 85
    MARGIN = 90

    DECISION_TYPES = {"DECISION", "LOOP_DECISION", "CATCH_DECISION"}
    INPUT_OUTPUT_TYPES = {"INPUT", "OUTPUT"}
    TERMINATOR_TYPES = {"START", "END"}
    SUBROUTINE_TYPES = {"FUNCTION", "CALL"}
    BACK_EDGE_LABELS = {"LOOP", "REPEAT", "BACK"}

    def generate(
        self,
        flow_diagram: FlowDiagram,
        output_path: str | Path,
        open_browser: bool = False,
    ) -> Path:
        destination = Path(output_path).resolve()
        positions = self._calculate_positions(flow_diagram)
        width, height = self._calculate_canvas_size(positions)
        svg_edges = self._render_edges(flow_diagram, positions)
        svg_nodes = self._render_nodes(flow_diagram, positions)
        diagram_json = json.dumps(flow_diagram.to_dict())

        document = f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>NL-FDEP Flow Diagram</title>
<style>
:root {{ color-scheme: light; }}
* {{ box-sizing: border-box; }}
body {{ margin: 0; font-family: Arial, Helvetica, sans-serif; background: #f4f5f7; color: #16191f; }}
header {{ position: sticky; top: 0; z-index: 10; padding: 14px 18px; background: white; border-bottom: 1px solid #c9cdd3; }}
header h1 {{ margin: 0 0 4px; font-size: 20px; }}
header p {{ margin: 0; color: #555d69; font-size: 13px; }}
.controls {{ display: flex; flex-wrap: wrap; gap: 8px; margin-top: 10px; }}
.controls input {{ min-width: 220px; flex: 1; padding: 8px 10px; border: 1px solid #9da4ae; border-radius: 5px; }}
.controls button {{ padding: 8px 12px; border: 1px solid #8f97a3; border-radius: 5px; background: white; cursor: pointer; }}
.viewport {{ overflow: hidden; width: 100%; height: calc(100vh - 108px); background: white; cursor: grab; }}
.viewport.dragging {{ cursor: grabbing; }}
svg {{ width: 100%; height: 100%; user-select: none; }}
.flow-node {{ cursor: pointer; }}
.flow-node .shape {{ fill: white; stroke: #20242a; stroke-width: 1.6; vector-effect: non-scaling-stroke; }}
.flow-node text {{ fill: #111418; font-size: 13px; text-anchor: middle; dominant-baseline: middle; pointer-events: none; }}
.flow-node .metadata {{ fill: #606874; font-size: 10px; }}
.flow-node.match .shape {{ stroke: #d18b00; stroke-width: 4; }}
.flow-node.selected .shape {{ stroke: #1769aa; stroke-width: 4; }}
.flow-edge {{ fill: none; stroke: #252a31; stroke-width: 1.45; vector-effect: non-scaling-stroke; marker-end: url(#arrowhead); }}
.edge-label rect {{ fill: white; stroke: none; }}
.edge-label text {{ fill: #20242a; font-size: 11px; text-anchor: middle; dominant-baseline: middle; }}
.legend {{ position: fixed; right: 14px; bottom: 14px; padding: 9px 11px; background: rgba(255,255,255,.94); border: 1px solid #c9cdd3; border-radius: 6px; font-size: 11px; line-height: 1.6; }}
</style>
</head>
<body>
<header>
<h1>NL to Flow Diagram Encoder Pipeline</h1>
<p>Standard flowchart notation generated from AJ pseudocode.</p>
<div class="controls">
<input id="search" placeholder="Search step, type, line, or node ID">
<button id="zoom-in" type="button">Zoom in</button>
<button id="zoom-out" type="button">Zoom out</button>
<button id="fit" type="button">Fit diagram</button>
</div>
</header>
<div id="viewport" class="viewport">
<svg id="diagram" viewBox="0 0 {width} {height}" role="img" aria-label="Generated program flow diagram">
<defs>
<marker id="arrowhead" markerWidth="9" markerHeight="7" refX="8" refY="3.5" orient="auto" markerUnits="strokeWidth">
<path d="M 0 0 L 9 3.5 L 0 7 z" fill="#252a31"></path>
</marker>
</defs>
<g id="canvas">{svg_edges}{svg_nodes}</g>
</svg>
</div>
<div class="legend">Oval: Start/End<br>Diamond: Decision<br>Parallelogram: Input/Output<br>Rectangle: Process<br>Double rectangle: Function/Call</div>
<script>
const diagramData = {diagram_json};
const svg = document.getElementById('diagram');
const canvas = document.getElementById('canvas');
const viewport = document.getElementById('viewport');
let scale = 1;
let translateX = 0;
let translateY = 0;
let dragging = false;
let startX = 0;
let startY = 0;

function applyTransform() {{
    canvas.setAttribute('transform', `translate(${{translateX}} ${{translateY}}) scale(${{scale}})`);
}}

function fitDiagram() {{
    const box = canvas.getBBox();
    const visibleWidth = viewport.clientWidth;
    const visibleHeight = viewport.clientHeight;
    scale = Math.min(visibleWidth / (box.width + 80), visibleHeight / (box.height + 80), 1.3);
    translateX = (visibleWidth - box.width * scale) / 2 - box.x * scale;
    translateY = (visibleHeight - box.height * scale) / 2 - box.y * scale;
    applyTransform();
}}

document.getElementById('zoom-in').addEventListener('click', () => {{ scale *= 1.15; applyTransform(); }});
document.getElementById('zoom-out').addEventListener('click', () => {{ scale /= 1.15; applyTransform(); }});
document.getElementById('fit').addEventListener('click', fitDiagram);

document.getElementById('search').addEventListener('input', event => {{
    const query = event.target.value.trim().toLowerCase();
    document.querySelectorAll('.flow-node').forEach(node => {{
        node.classList.toggle('match', query.length > 0 && node.textContent.toLowerCase().includes(query));
    }});
}});

document.querySelectorAll('.flow-node').forEach(node => {{
    node.addEventListener('click', () => node.classList.toggle('selected'));
}});

viewport.addEventListener('mousedown', event => {{
    dragging = true;
    startX = event.clientX - translateX;
    startY = event.clientY - translateY;
    viewport.classList.add('dragging');
}});
window.addEventListener('mousemove', event => {{
    if (!dragging) return;
    translateX = event.clientX - startX;
    translateY = event.clientY - startY;
    applyTransform();
}});
window.addEventListener('mouseup', () => {{ dragging = false; viewport.classList.remove('dragging'); }});
viewport.addEventListener('wheel', event => {{
    event.preventDefault();
    const factor = event.deltaY < 0 ? 1.1 : 0.9;
    scale *= factor;
    applyTransform();
}}, {{ passive: false }});
window.addEventListener('load', fitDiagram);
window.addEventListener('resize', fitDiagram);
</script>
</body>
</html>"""

        destination.write_text(document, encoding="utf-8")

        if open_browser:
            webbrowser.open(destination.as_uri())

        return destination

    def _calculate_positions(self, flow_diagram: FlowDiagram) -> dict[str, tuple[float, float]]:
        ranks: dict[str, int] = {flow_diagram.entry_node: 0}
        outgoing: dict[str, list[FlowEdge]] = defaultdict(list)

        for edge in flow_diagram.edges:
            outgoing[edge.source].append(edge)

        queue: deque[str] = deque([flow_diagram.entry_node])
        visit_count: dict[str, int] = defaultdict(int)

        while queue:
            source = queue.popleft()
            source_rank = ranks.get(source, 0)

            for edge in outgoing[source]:
                if edge.label.upper() in self.BACK_EDGE_LABELS:
                    continue

                proposed_rank = source_rank + 1
                current_rank = ranks.get(edge.target, -1)

                if proposed_rank > current_rank:
                    ranks[edge.target] = proposed_rank
                    visit_count[edge.target] += 1

                    if visit_count[edge.target] <= len(flow_diagram.nodes):
                        queue.append(edge.target)

        next_rank = max(ranks.values(), default=0) + 1

        for node_id in flow_diagram.nodes:
            if node_id not in ranks:
                ranks[node_id] = next_rank
                next_rank += 1

        ranked_nodes: dict[int, list[str]] = defaultdict(list)

        for node_id, rank in ranks.items():
            ranked_nodes[rank].append(node_id)

        positions: dict[str, tuple[float, float]] = {}
        widest_count = max((len(items) for items in ranked_nodes.values()), default=1)
        canvas_center = self.MARGIN + ((widest_count - 1) * (self.NODE_WIDTH + self.HORIZONTAL_GAP) + self.NODE_WIDTH) / 2

        for rank in sorted(ranked_nodes):
            node_ids = sorted(ranked_nodes[rank], key=self._node_sort_key)
            row_width = (len(node_ids) - 1) * (self.NODE_WIDTH + self.HORIZONTAL_GAP) + self.NODE_WIDTH
            start_x = canvas_center - row_width / 2
            y = self.MARGIN + rank * (self.DECISION_HEIGHT + self.VERTICAL_GAP)

            for index, node_id in enumerate(node_ids):
                x = start_x + index * (self.NODE_WIDTH + self.HORIZONTAL_GAP)
                positions[node_id] = (x, y)

        return positions

    def _node_sort_key(self, node_id: str) -> tuple[int, str]:
        digits = "".join(character for character in node_id if character.isdigit())
        return (int(digits) if digits else 0, node_id)

    def _calculate_canvas_size(self, positions: dict[str, tuple[float, float]]) -> tuple[int, int]:
        maximum_x = max((x for x, _ in positions.values()), default=0)
        maximum_y = max((y for _, y in positions.values()), default=0)
        width = int(maximum_x + self.NODE_WIDTH + self.MARGIN)
        height = int(maximum_y + self.DECISION_HEIGHT + self.MARGIN)
        return max(width, 700), max(height, 500)

    def _render_nodes(self, flow_diagram: FlowDiagram, positions: dict[str, tuple[float, float]]) -> str:
        fragments: list[str] = []

        for node_id, node in flow_diagram.nodes.items():
            x, y = positions[node_id]
            fragments.append(self._render_node(node, x, y))

        return "".join(fragments)

    def _render_node(self, node: FlowNode, x: float, y: float) -> str:
        node_type = node.node_type.upper()
        label_lines = self._wrap_label(node.label, 30)
        safe_id = html.escape(node.node_id)
        title = html.escape(f"{node.node_type} | Line {node.line} | {node.node_id}")
        text = self._render_multiline_text(label_lines, x + self.NODE_WIDTH / 2, y + self._node_height(node) / 2 - 7)
        metadata_y = y + self._node_height(node) - 13
        metadata = html.escape(f"Line {node.line} · {node.node_id}")

        if node_type in self.TERMINATOR_TYPES:
            shape = (
                f'<rect class="shape" x="{x}" y="{y}" width="{self.NODE_WIDTH}" '
                f'height="{self.NODE_HEIGHT}" rx="32" ry="32"></rect>'
            )
        elif node_type in self.DECISION_TYPES:
            center_x = x + self.DECISION_WIDTH / 2
            center_y = y + self.DECISION_HEIGHT / 2
            points = (
                f"{center_x},{y} {x + self.DECISION_WIDTH},{center_y} "
                f"{center_x},{y + self.DECISION_HEIGHT} {x},{center_y}"
            )
            shape = f'<polygon class="shape" points="{points}"></polygon>'
        elif node_type in self.INPUT_OUTPUT_TYPES:
            inset = 24
            points = (
                f"{x + inset},{y} {x + self.NODE_WIDTH},{y} "
                f"{x + self.NODE_WIDTH - inset},{y + self.NODE_HEIGHT} {x},{y + self.NODE_HEIGHT}"
            )
            shape = f'<polygon class="shape" points="{points}"></polygon>'
        elif node_type in self.SUBROUTINE_TYPES:
            shape = (
                f'<rect class="shape" x="{x}" y="{y}" width="{self.NODE_WIDTH}" height="{self.NODE_HEIGHT}"></rect>'
                f'<line class="shape" x1="{x + 12}" y1="{y}" x2="{x + 12}" y2="{y + self.NODE_HEIGHT}"></line>'
                f'<line class="shape" x1="{x + self.NODE_WIDTH - 12}" y1="{y}" x2="{x + self.NODE_WIDTH - 12}" y2="{y + self.NODE_HEIGHT}"></line>'
            )
        else:
            shape = (
                f'<rect class="shape" x="{x}" y="{y}" width="{self.NODE_WIDTH}" '
                f'height="{self.NODE_HEIGHT}" rx="4" ry="4"></rect>'
            )

        return (
            f'<g class="flow-node" data-node-id="{safe_id}"><title>{title}</title>'
            f'{shape}{text}<text class="metadata" x="{x + self.NODE_WIDTH / 2}" y="{metadata_y}">{metadata}</text></g>'
        )

    def _render_edges(self, flow_diagram: FlowDiagram, positions: dict[str, tuple[float, float]]) -> str:
        fragments: list[str] = []

        for edge in flow_diagram.edges:
            source = flow_diagram.nodes[edge.source]
            target = flow_diagram.nodes[edge.target]
            sx, sy = positions[edge.source]
            tx, ty = positions[edge.target]
            source_width = self._node_width(source)
            source_height = self._node_height(source)
            target_width = self._node_width(target)
            target_height = self._node_height(target)
            label = self._display_edge_label(edge.label)

            if ty > sy:
                start_x = sx + source_width / 2
                start_y = sy + source_height
                end_x = tx + target_width / 2
                end_y = ty
                middle_y = (start_y + end_y) / 2
                path = f"M {start_x} {start_y} L {start_x} {middle_y} L {end_x} {middle_y} L {end_x} {end_y}"
                label_x = (start_x + end_x) / 2
                label_y = middle_y - 9
            else:
                start_x = sx
                start_y = sy + source_height / 2
                end_x = tx
                end_y = ty + target_height / 2
                loop_x = min(start_x, end_x) - 55
                path = f"M {start_x} {start_y} L {loop_x} {start_y} L {loop_x} {end_y} L {end_x} {end_y}"
                label_x = loop_x
                label_y = (start_y + end_y) / 2 - 9

            fragments.append(f'<path class="flow-edge" d="{path}"></path>')

            if label:
                safe_label = html.escape(label)
                label_width = max(30, len(label) * 7 + 12)
                fragments.append(
                    f'<g class="edge-label"><rect x="{label_x - label_width / 2}" y="{label_y - 9}" '
                    f'width="{label_width}" height="18" rx="3"></rect>'
                    f'<text x="{label_x}" y="{label_y}">{safe_label}</text></g>'
                )

        return "".join(fragments)

    def _node_width(self, node: FlowNode) -> int:
        if node.node_type.upper() in self.DECISION_TYPES:
            return self.DECISION_WIDTH
        return self.NODE_WIDTH

    def _node_height(self, node: FlowNode) -> int:
        if node.node_type.upper() in self.DECISION_TYPES:
            return self.DECISION_HEIGHT
        return self.NODE_HEIGHT

    def _display_edge_label(self, label: str) -> str:
        normalized = label.upper()
        translations = {
            "TRUE": "Yes",
            "FALSE": "No",
            "ITERATE": "Yes",
            "BODY": "",
            "NEXT": "",
            "LOOP": "Repeat",
            "CATCH": "Exception",
        }
        return translations.get(normalized, label.title())

    def _wrap_label(self, label: str, width: int) -> list[str]:
        words = label.split()
        lines: list[str] = []
        current = ""

        for word in words:
            candidate = word if not current else f"{current} {word}"

            if len(candidate) <= width:
                current = candidate
            else:
                if current:
                    lines.append(current)
                current = word

        if current:
            lines.append(current)

        return lines[:3] or [""]

    def _render_multiline_text(self, lines: list[str], x: float, center_y: float) -> str:
        line_height = 16
        first_y = center_y - ((len(lines) - 1) * line_height / 2)
        fragments = [f'<text x="{x}" y="{first_y}">']

        for index, line in enumerate(lines):
            dy = 0 if index == 0 else line_height
            fragments.append(f'<tspan x="{x}" dy="{dy}">{html.escape(line)}</tspan>')

        fragments.append("</text>")
        return "".join(fragments)
