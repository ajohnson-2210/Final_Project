import json
import tempfile
import unittest
from pathlib import Path

from aj_parser import AJParserFacade
from aj_python_compiler import AJPythonCompiler
from aj_test_harness import AJTestHarness, TestCase
from flow_diagram import FlowDiagramEncoder
from nl_flow_pipeline import NLFlowDiagramEncoderPipeline


SAMPLE = """
total <- INTEGER(0)
FOR number <- IN RANGE INTEGER(1) TO INTEGER(4) DO
    total <- total + number
ENDFOR
OUTPUT total
""".strip()


class CompletePipelineTests(unittest.TestCase):

    def test_pseudocode_generates_flow_diagram(self):
        parse_result = AJParserFacade().parse(SAMPLE)
        self.assertTrue(parse_result.success, parse_result.report.pretty())

        flow_diagram = FlowDiagramEncoder().encode(parse_result.ast)
        document = flow_diagram.to_dict()

        self.assertEqual(document["format"], "NL-FDEP Flow Diagram")
        self.assertGreater(len(document["nodes"]), 3)
        self.assertEqual(document["structured_program"]["kind"], "ProgramNode")

    def test_flow_diagram_compiles_to_python(self):
        parse_result = AJParserFacade().parse(SAMPLE)
        flow_diagram = FlowDiagramEncoder().encode(parse_result.ast)
        compilation = AJPythonCompiler().compile(flow_diagram)

        self.assertTrue(compilation.success)
        self.assertIn("for number in range", compilation.source_code)
        self.assertIn("print(total)", compilation.source_code)

    def test_generated_python_passes_harness(self):
        parse_result = AJParserFacade().parse(SAMPLE)
        flow_diagram = FlowDiagramEncoder().encode(parse_result.ast)
        compilation = AJPythonCompiler().compile(flow_diagram)

        with tempfile.TemporaryDirectory() as temporary_directory:
            program_path = Path(temporary_directory) / "generated_program.py"
            program_path.write_text(compilation.source_code, encoding="utf-8")
            report = AJTestHarness().run(
                program_path,
                [TestCase("Range total", expected_output=["10"])],
            )

        self.assertTrue(report.success, report.to_json())

    def test_complete_pipeline_outputs_expected_files(self):
        with tempfile.TemporaryDirectory() as temporary_directory:
            result = NLFlowDiagramEncoderPipeline().run(
                pseudocode=SAMPLE,
                output_directory=Path(temporary_directory),
                test_cases=[TestCase("Range total", expected_output=["10"])],
                open_visualisations=False,
            )

            self.assertTrue(result.success, result.to_json())
            self.assertTrue(Path(result.output_files["flow_diagram"]).exists())
            self.assertTrue(Path(result.output_files["generated_python"]).exists())
            self.assertTrue(Path(result.output_files["test_report"]).exists())

            flow_document = json.loads(
                Path(result.output_files["flow_diagram"]).read_text(
                    encoding="utf-8"
                )
            )
            self.assertEqual(flow_document["version"], "1.0")


if __name__ == "__main__":
    unittest.main()
