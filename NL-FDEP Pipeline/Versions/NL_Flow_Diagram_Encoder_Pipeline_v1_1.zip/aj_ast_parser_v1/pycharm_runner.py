"""PyCharm entry point for the complete pseudocode-only NL-FDEP pipeline."""

from pathlib import Path

from aj_test_harness import TestCase
from nl_flow_pipeline import NLFlowDiagramEncoderPipeline


INPUT_FILE: Path | None = None
OUTPUT_DIRECTORY = Path("output")
OPEN_VISUALISATIONS = True

SAMPLE_PSEUDOCODE = """
FUNCTION sum_even ACCEPTS(numbers AS LIST)
    total <- INTEGER(0)

    FOR EACH number IN numbers DO
        IF number MODULUS 2 == 0 THEN
            total <- total + number
        ENDIF
    ENDFOR

    OUTPUT total
    RETURN total
ENDFUNCTION

OUTPUT CALL sum_even(LIST[INTEGER(1), INTEGER(2), INTEGER(3), INTEGER(4)])
""".strip()

TEST_CASES = [
    TestCase(
        name="Sum even numbers",
        standard_input=[],
        expected_output=["6", "6"],
        timeout_seconds=3.0,
    )
]


def load_pseudocode() -> str:
    """Loads pseudocode from a configured file or the embedded example."""

    if INPUT_FILE is None:
        return SAMPLE_PSEUDOCODE

    if not INPUT_FILE.exists():
        raise FileNotFoundError(
            f"Pseudocode file not found: {INPUT_FILE.resolve()}"
        )

    return INPUT_FILE.read_text(encoding="utf-8")


def main() -> None:
    """Runs the complete pipeline and prints a dissertation-friendly report."""

    pseudocode = load_pseudocode()
    pipeline = NLFlowDiagramEncoderPipeline()
    result = pipeline.run(
        pseudocode=pseudocode,
        output_directory=OUTPUT_DIRECTORY,
        test_cases=TEST_CASES,
        open_visualisations=OPEN_VISUALISATIONS,
    )

    print("NL TO FLOW DIAGRAM ENCODER PIPELINE")
    print("=" * 52)

    for stage in result.stages:
        print(
            f"[{stage.status:7}] "
            f"{stage.name:<28} "
            f"{stage.duration_ms:>9.3f} ms  "
            f"{stage.message}"
        )

    print("\nOUTPUT FILES")

    for output_name, output_path in result.output_files.items():
        print(f"- {output_name}: {output_path}")

    if result.test_report is not None:
        print(
            "\nTests passed: "
            f"{result.test_report.passed_tests}/"
            f"{len(result.test_report.results)}"
        )

    if not result.success:
        print(f"\nPipeline failed: {result.error or 'One or more tests failed.'}")


if __name__ == "__main__":
    main()
