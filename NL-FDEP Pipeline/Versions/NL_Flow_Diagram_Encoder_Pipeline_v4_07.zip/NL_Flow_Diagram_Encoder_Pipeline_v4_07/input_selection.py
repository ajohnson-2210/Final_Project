"""Interactive input-route and file selection for the PyCharm application."""

from __future__ import annotations

from enum import Enum
from pathlib import Path
from tkinter import Button, Label, Tk, filedialog

from pseudocode_profiles import PseudocodeProfile


class InputRoute(str, Enum):
    """Supported controlled input routes."""

    PSEUDOCODE = "PSEUDOCODE"
    FLOW_DIAGRAM = "FLOW_DIAGRAM"
    LLM_RESULTS_FOLDER = "LLM_RESULTS_FOLDER"
    BASELINE_BENCHMARK_FOLDER = "BASELINE_BENCHMARK_FOLDER"


class InputSelectionCancelledError(Exception):
    """Raised when the user closes or cancels an input-selection dialog."""


class InputSelectionDialog:
    """Displays route-selection and file-selection windows."""

    def select_route(self) -> InputRoute:
        """Asks the user which type of source file they want to import."""

        selected_route: list[InputRoute] = []

        selection_window = Tk()
        selection_window.title("NL to Flow Diagram Encoder Pipeline")
        selection_window.resizable(False, False)
        selection_window.attributes("-topmost", True)

        instruction_label = Label(
            selection_window,
            text="What would you like to import?",
            padx=30,
            pady=18,
        )
        instruction_label.pack()

        pseudocode_button = Button(
            selection_window,
            text="Pseudocode file",
            width=28,
            command=lambda: self._select_and_close(
                selected_route=selected_route,
                route=InputRoute.PSEUDOCODE,
                window=selection_window,
            ),
        )
        pseudocode_button.pack(padx=30, pady=6)

        flow_diagram_button = Button(
            selection_window,
            text="Flow diagram file",
            width=28,
            command=lambda: self._select_and_close(
                selected_route=selected_route,
                route=InputRoute.FLOW_DIAGRAM,
                window=selection_window,
            ),
        )
        flow_diagram_button.pack(padx=30, pady=6)

        llm_folder_button = Button(
            selection_window,
            text="LLM results folder",
            width=28,
            command=lambda: self._select_and_close(
                selected_route=selected_route,
                route=InputRoute.LLM_RESULTS_FOLDER,
                window=selection_window,
            ),
        )
        llm_folder_button.pack(padx=30, pady=6)

        baseline_button = Button(
            selection_window,
            text="Baseline benchmark folder",
            width=28,
            command=lambda: self._select_and_close(
                selected_route=selected_route,
                route=InputRoute.BASELINE_BENCHMARK_FOLDER,
                window=selection_window,
            ),
        )
        baseline_button.pack(padx=30, pady=(6, 20))

        selection_window.protocol(
            "WM_DELETE_WINDOW",
            selection_window.destroy,
        )
        selection_window.mainloop()

        if not selected_route:
            raise InputSelectionCancelledError(
                "Input type selection was cancelled."
            )

        return selected_route[0]


    def select_pseudocode_profile(self) -> PseudocodeProfile:
        """Asks how a selected pseudocode file should be processed."""

        selected_profile: list[PseudocodeProfile] = []

        profile_window = Tk()
        profile_window.title("Pseudocode processing profile")
        profile_window.resizable(False, False)
        profile_window.attributes("-topmost", True)

        instruction_label = Label(
            profile_window,
            text="How should the pseudocode be processed?",
            padx=30,
            pady=18,
        )
        instruction_label.pack()

        profile_options = [
            (
                "AJ Dialect — strict",
                PseudocodeProfile.AJ_DIALECT_STRICT,
            ),
            (
                "Generic — convert compatible syntax",
                PseudocodeProfile.GENERIC_COMPATIBILITY,
            ),
            (
                "General — parse without conversion",
                PseudocodeProfile.GENERAL_NO_CONVERSION,
            ),
        ]

        for button_text, profile in profile_options:
            profile_button = Button(
                profile_window,
                text=button_text,
                width=38,
                command=lambda selected_profile_value=profile: self._select_profile_and_close(
                    selected_profiles=selected_profile,
                    profile=selected_profile_value,
                    window=profile_window,
                ),
            )
            profile_button.pack(
                padx=30,
                pady=6,
            )

        cancel_button = Button(
            profile_window,
            text="Cancel",
            width=38,
            command=profile_window.destroy,
        )
        cancel_button.pack(
            padx=30,
            pady=(6, 20),
        )

        profile_window.protocol(
            "WM_DELETE_WINDOW",
            profile_window.destroy,
        )
        profile_window.mainloop()

        if not selected_profile:
            raise InputSelectionCancelledError(
                "Pseudocode profile selection was cancelled."
            )

        return selected_profile[0]

    def select_file(self, route: InputRoute) -> Path:
        """Displays a file chooser configured for the selected route."""

        file_window = Tk()
        file_window.withdraw()
        file_window.attributes("-topmost", True)

        if route in {InputRoute.LLM_RESULTS_FOLDER, InputRoute.BASELINE_BENCHMARK_FOLDER}:
            selected_path = filedialog.askdirectory(
                title=self._file_dialog_title(route),
            )
        else:
            selected_path = filedialog.askopenfilename(
                title=self._file_dialog_title(route),
                filetypes=self._file_types(route),
            )

        file_window.destroy()

        if not selected_path:
            raise InputSelectionCancelledError(
                "Input file selection was cancelled."
            )

        return Path(selected_path)

    def select_optional_directory(self, title: str) -> Path | None:
        """Displays an optional directory chooser; cancelling returns None."""

        folder_window = Tk()
        folder_window.withdraw()
        folder_window.attributes("-topmost", True)
        selected_path = filedialog.askdirectory(title=title)
        folder_window.destroy()
        return Path(selected_path) if selected_path else None

    def _select_and_close(
        self,
        selected_route: list[InputRoute],
        route: InputRoute,
        window: Tk,
    ) -> None:
        """Stores the selected route and closes the route-selection window."""

        selected_route.append(route)
        window.destroy()


    def _select_profile_and_close(
        self,
        selected_profiles: list[PseudocodeProfile],
        profile: PseudocodeProfile,
        window: Tk,
    ) -> None:
        """Stores the selected pseudocode profile and closes the window."""

        selected_profiles.append(
            profile
        )
        window.destroy()

    def _file_dialog_title(self, route: InputRoute) -> str:
        """Returns the file-dialog title for a selected route."""

        if route == InputRoute.FLOW_DIAGRAM:
            return "Select a controlled draw.io flow diagram"
        if route == InputRoute.LLM_RESULTS_FOLDER:
            return "Select an LLM results folder containing Algorithm - n folders"
        if route == InputRoute.BASELINE_BENCHMARK_FOLDER:
            return "Select the Baseline folder containing pseudocode and python folders"

        return "Select AJ pseudocode"

    def _file_types(self, route: InputRoute) -> list[tuple[str, str]]:
        """Returns accepted file filters for a selected route."""

        if route == InputRoute.FLOW_DIAGRAM:
            return [
                ("draw.io files", "*.drawio *.xml *.svg"),
                ("All files", "*.*"),
            ]

        return [
            ("AJ pseudocode", "*.aj *.txt"),
            ("All files", "*.*"),
        ]
