"""Command-line interface for NL-FDEP study batch processing and adjudication."""

from __future__ import annotations

from pathlib import Path
import argparse
import json

from adjudication import adjudicate_files
from pseudocode_profiles import PseudocodeProfile
from study_analysis import aggregate_algorithm_folders, aggregate_study_root
from study_batch import StudyBatchProcessor


def _profile(value: str) -> PseudocodeProfile:
    aliases = {
        "strict": PseudocodeProfile.AJ_DIALECT_STRICT,
        "generic": PseudocodeProfile.GENERIC_COMPATIBILITY,
        "general": PseudocodeProfile.GENERAL_NO_CONVERSION,
    }
    try:
        return aliases[value.lower()]
    except KeyError as exc:
        raise argparse.ArgumentTypeError("profile must be strict, generic, or general") from exc


def main() -> int:
    parser = argparse.ArgumentParser(description="NL-FDEP v4.07 study tooling")
    sub = parser.add_subparsers(dest="command", required=True)

    llm = sub.add_parser("process-llm", help="Process an LLM results folder")
    llm.add_argument("results", type=Path)
    llm.add_argument("--profile", type=_profile, default=PseudocodeProfile.GENERIC_COMPATIBILITY)
    llm.add_argument("--baseline-root", type=Path)

    baseline = sub.add_parser("process-baseline", help="Process a Baseline folder")
    baseline.add_argument("baseline", type=Path)
    baseline.add_argument("--profile", type=_profile, default=PseudocodeProfile.GENERIC_COMPATIBILITY)

    aggregate = sub.add_parser("aggregate", help="Rebuild CSV/JSON analysis tables")
    aggregate.add_argument("algorithm_parent", type=Path)
    aggregate.add_argument("--output", type=Path)

    whole = sub.add_parser("aggregate-study", help="Aggregate Baseline plus all model result folders")
    whole.add_argument("study_root", type=Path)
    whole.add_argument("--output", type=Path)

    adjudicate = sub.add_parser("adjudicate", help="Apply completed human_review.json files")
    adjudicate.add_argument("algorithm_parent", type=Path)

    args = parser.parse_args()
    if args.command == "process-llm":
        result = StudyBatchProcessor().process_llm_results(
            args.results,
            profile=args.profile,
            baseline_root=args.baseline_root,
        )
    elif args.command == "process-baseline":
        result = StudyBatchProcessor().process_baseline(args.baseline, profile=args.profile)
    elif args.command == "aggregate":
        result = aggregate_algorithm_folders(args.algorithm_parent, args.output)
    elif args.command == "aggregate-study":
        result = aggregate_study_root(args.study_root, args.output)
    else:
        updated = []
        for scoring_dir in sorted(args.algorithm_parent.glob("Algorithm - */pipeline_artifacts/scoring")):
            path = adjudicate_files(scoring_dir)
            if path:
                updated.append(str(path.resolve()))
        analysis = aggregate_algorithm_folders(args.algorithm_parent)
        result = {"adjudicated": updated, "analysis_outputs": analysis}

    print(json.dumps(result, indent=2, default=str))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
