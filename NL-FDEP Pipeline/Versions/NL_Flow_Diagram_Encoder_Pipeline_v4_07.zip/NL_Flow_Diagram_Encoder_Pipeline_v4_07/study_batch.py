"""Batch orchestration for model-result and baseline study folders."""

from __future__ import annotations

from collections import Counter
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
import csv
import json
import re

from adjudication import adjudicate_files
from baseline_benchmark import (
    build_baseline_comparison,
    load_test_spec,
    test_cases_from_spec,
)
from human_review import HumanReviewQuestionnaireGenerator
from nl_flow_pipeline import NLFlowDiagramEncoderPipeline
from pseudocode_profiles import PseudocodeProfile
from scoring_engine import StudyScoringEngine
from study_rubric import LANGUAGE_VERSION, PIPELINE_VERSION, RUBRIC_VERSION
from study_analysis import aggregate_algorithm_folders

ALGORITHM_FOLDER_RE = re.compile(r"^Algorithm\s*-\s*(\d+)$", re.IGNORECASE)


@dataclass
class AlgorithmRunRecord:
    algorithm_id: int
    dataset: str
    source_file: str | None
    artifact_directory: str
    status: str
    pipeline_success: bool
    error: str | None = None
    reference_python: str | None = None
    tests_file: str | None = None
    score_file: str | None = None
    questionnaire_file: str | None = None


class StudyFolderError(ValueError):
    pass


def discover_algorithm_folders(parent: Path) -> list[tuple[int, Path]]:
    parent = Path(parent)
    if not parent.is_dir():
        raise StudyFolderError(f"Study folder does not exist: {parent}")
    found: list[tuple[int, Path]] = []
    for child in parent.iterdir():
        if not child.is_dir():
            continue
        match = ALGORITHM_FOLDER_RE.match(child.name)
        if match:
            found.append((int(match.group(1)), child))
    return sorted(found, key=lambda item: item[0])


def expected_pseudocode_file(folder: Path, algorithm_id: int) -> Path:
    expected_name = f"Algorithm {algorithm_id} Pseudocode.txt"
    exact = folder / expected_name
    if exact.exists():
        return exact
    # Case-insensitive fallback preserves the required naming convention while being OS-portable.
    matches = [
        path for path in folder.iterdir()
        if path.is_file() and path.name.casefold() == expected_name.casefold()
    ]
    if len(matches) == 1:
        return matches[0]
    raise StudyFolderError(
        f"Expected '{expected_name}' inside '{folder.name}'."
    )


def _find_reference_python(folder: Path, algorithm_id: int) -> Path | None:
    expected = folder / f"Algorithm {algorithm_id} Python.py"
    if expected.exists():
        return expected
    casefold_name = expected.name.casefold()
    candidates = [p for p in folder.glob("*.py") if p.name.casefold() == casefold_name]
    if len(candidates) == 1:
        return candidates[0]
    candidates = list(folder.glob("*.py"))
    return candidates[0] if len(candidates) == 1 else None


def _find_tests_file(*folders: Path, algorithm_id: int) -> Path | None:
    expected_name = f"Algorithm {algorithm_id} Tests.json"
    for folder in folders:
        if folder is None or not folder.exists():
            continue
        exact = folder / expected_name
        if exact.exists():
            return exact
        matches = [
            path for path in folder.glob("*.json")
            if path.name.casefold() == expected_name.casefold()
        ]
        if len(matches) == 1:
            return matches[0]
    return None


def _write_manifest(
    artifact_directory: Path,
    *,
    algorithm_id: int,
    dataset: str,
    source_type: str,
    source_file: Path,
    profile: PseudocodeProfile,
    is_baseline: bool,
    reference_python: Path | None = None,
    tests_file: Path | None = None,
    processing_status: str = "PENDING",
) -> Path:
    artifact_directory.mkdir(parents=True, exist_ok=True)
    manifest = {
        "manifest_schema_version": "1.0",
        "algorithm_id": algorithm_id,
        "dataset": dataset,
        "source_type": source_type,
        "source_file": source_file.name,
        "source_file_resolved": str(source_file.resolve()),
        "artifact_directory": str(artifact_directory.resolve()),
        "pipeline_version": PIPELINE_VERSION,
        "language_version": LANGUAGE_VERSION,
        "rubric_version": RUBRIC_VERSION,
        "pseudocode_profile": profile.value,
        "is_baseline": is_baseline,
        "reference_python": str(reference_python.resolve()) if reference_python else None,
        "tests_file": str(tests_file.resolve()) if tests_file else None,
        "processing_status": processing_status,
        "updated_at_utc": datetime.now(timezone.utc).isoformat(),
    }
    path = artifact_directory / "manifest.json"
    path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return path


def _read_json(path: Path) -> dict[str, Any] | None:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else None
    except (OSError, json.JSONDecodeError):
        return None


def _write_batch_failure(artifact_directory: Path, algorithm_id: int, dataset: str, error: Exception) -> Path:
    artifact_directory.mkdir(parents=True, exist_ok=True)
    path = artifact_directory / "batch_failure.json"
    path.write_text(json.dumps({
        "algorithm_id": algorithm_id,
        "dataset": dataset,
        "status": "FAILURE",
        "error": str(error),
        "recorded_at_utc": datetime.now(timezone.utc).isoformat(),
    }, indent=2), encoding="utf-8")
    return path


class StudyBatchProcessor:
    """Processes existing study folders without altering source response files."""

    def __init__(self) -> None:
        self.pipeline = NLFlowDiagramEncoderPipeline()
        self.scorer = StudyScoringEngine()
        self.questionnaire = HumanReviewQuestionnaireGenerator()

    def process_llm_results(
        self,
        results_directory: Path,
        profile: PseudocodeProfile = PseudocodeProfile.GENERIC_COMPATIBILITY,
        baseline_root: Path | None = None,
        open_visualisations: bool = False,
    ) -> dict[str, Any]:
        results_directory = Path(results_directory)
        dataset = results_directory.parent.name if results_directory.name.casefold() == "results" else results_directory.name
        records: list[AlgorithmRunRecord] = []
        for algorithm_id, algorithm_folder in discover_algorithm_folders(results_directory):
            artifact_directory = algorithm_folder / "pipeline_artifacts"
            try:
                source_file = expected_pseudocode_file(algorithm_folder, algorithm_id)
                tests_file = None
                baseline_reference_python = None
                if baseline_root is not None:
                    base_python_folder = Path(baseline_root) / "python" / f"Algorithm - {algorithm_id}"
                    base_pseudo_folder = Path(baseline_root) / "pseudocode" / f"Algorithm - {algorithm_id}"
                    tests_file = _find_tests_file(base_python_folder, base_pseudo_folder, algorithm_id=algorithm_id)
                    if base_python_folder.is_dir():
                        baseline_reference_python = _find_reference_python(base_python_folder, algorithm_id)
                if tests_file is None:
                    tests_file = _find_tests_file(algorithm_folder, algorithm_id=algorithm_id)
                test_specs = load_test_spec(tests_file) if tests_file else []
                test_cases, _ = test_cases_from_spec(test_specs, reference_python=baseline_reference_python)
                _write_manifest(
                    artifact_directory,
                    algorithm_id=algorithm_id,
                    dataset=dataset,
                    source_type="LLM_PSEUDOCODE",
                    source_file=source_file,
                    profile=profile,
                    is_baseline=False,
                    reference_python=baseline_reference_python,
                    tests_file=tests_file,
                )
                result = self.pipeline.run(
                    pseudocode=source_file.read_text(encoding="utf-8"),
                    output_directory=artifact_directory,
                    test_cases=test_cases,
                    open_visualisations=open_visualisations,
                    pseudocode_profile=profile,
                )
                metadata = {
                    "algorithm_id": algorithm_id,
                    "dataset": dataset,
                    "source_type": "llm_pseudocode",
                    "source_file": source_file.name,
                    "source_file_resolved": str(source_file.resolve()),
                    "is_baseline": False,
                    "baseline_algorithm_id": algorithm_id,
                    "baseline_reference_python": str(baseline_reference_python.resolve()) if baseline_reference_python else None,
                }
                score_paths = self.scorer.write_outputs(
                    artifact_directory,
                    metadata,
                    benchmark={
                        "is_baseline": False,
                        "baseline_algorithm_id": algorithm_id,
                        "reference_python": str(baseline_reference_python.resolve()) if baseline_reference_python else None,
                        "tests_file": str(tests_file.resolve()) if tests_file else None,
                        "oracle_source": "BASELINE_REFERENCE_PYTHON" if baseline_reference_python and tests_file else ("EXPLICIT_TEST_EXPECTATIONS" if tests_file else None),
                    },
                )
                questionnaire_paths = self.questionnaire.write(
                    artifact_directory / "scoring",
                    _read_json(score_paths["automated_score"]) or {},
                )
                adjudicate_files(artifact_directory / "scoring")
                _write_manifest(
                    artifact_directory,
                    algorithm_id=algorithm_id,
                    dataset=dataset,
                    source_type="LLM_PSEUDOCODE",
                    source_file=source_file,
                    profile=profile,
                    is_baseline=False,
                    reference_python=baseline_reference_python,
                    tests_file=tests_file,
                    processing_status=result.status,
                )
                records.append(AlgorithmRunRecord(
                    algorithm_id=algorithm_id,
                    dataset=dataset,
                    source_file=str(source_file.resolve()),
                    artifact_directory=str(artifact_directory.resolve()),
                    status=result.status,
                    pipeline_success=result.success,
                    error=result.error,
                    tests_file=str(tests_file.resolve()) if tests_file else None,
                    score_file=str(score_paths["automated_score"].resolve()),
                    questionnaire_file=str(questionnaire_paths["questionnaire_html"].resolve()),
                ))
            except Exception as error:
                _write_batch_failure(artifact_directory, algorithm_id, dataset, error)
                records.append(AlgorithmRunRecord(
                    algorithm_id=algorithm_id,
                    dataset=dataset,
                    source_file=None,
                    artifact_directory=str(artifact_directory.resolve()),
                    status="FAILURE",
                    pipeline_success=False,
                    error=str(error),
                ))
        batch = self._write_batch_reports(results_directory / "study_analysis", dataset, records, "LLM_RESULTS")
        batch["analysis_outputs"] = aggregate_algorithm_folders(results_directory, results_directory / "study_analysis")
        return batch

    def process_baseline(
        self,
        baseline_root: Path,
        profile: PseudocodeProfile = PseudocodeProfile.GENERIC_COMPATIBILITY,
        open_visualisations: bool = False,
    ) -> dict[str, Any]:
        baseline_root = Path(baseline_root)
        pseudocode_root = baseline_root / "pseudocode"
        python_root = baseline_root / "python"
        if not pseudocode_root.is_dir() or not python_root.is_dir():
            raise StudyFolderError(
                "Baseline root must contain 'pseudocode' and 'python' folders."
            )
        records: list[AlgorithmRunRecord] = []
        for algorithm_id, pseudo_folder in discover_algorithm_folders(pseudocode_root):
            artifact_directory = pseudo_folder / "pipeline_artifacts"
            try:
                source_file = expected_pseudocode_file(pseudo_folder, algorithm_id)
                reference_folder = python_root / f"Algorithm - {algorithm_id}"
                reference_python = _find_reference_python(reference_folder, algorithm_id) if reference_folder.is_dir() else None
                tests_file = _find_tests_file(reference_folder, pseudo_folder, algorithm_id=algorithm_id)
                test_specs = load_test_spec(tests_file) if tests_file else []
                test_cases, oracle_records = test_cases_from_spec(test_specs, reference_python=reference_python)
                _write_manifest(
                    artifact_directory,
                    algorithm_id=algorithm_id,
                    dataset="Baseline",
                    source_type="BASELINE_PSEUDOCODE",
                    source_file=source_file,
                    profile=profile,
                    is_baseline=True,
                    reference_python=reference_python,
                    tests_file=tests_file,
                )
                result = self.pipeline.run(
                    pseudocode=source_file.read_text(encoding="utf-8"),
                    output_directory=artifact_directory,
                    test_cases=test_cases,
                    open_visualisations=open_visualisations,
                    pseudocode_profile=profile,
                )
                generated_test_report = (
                    _read_json(artifact_directory / "test_report.json")
                    if (artifact_directory / "test_report.json").exists()
                    else None
                )
                benchmark = build_baseline_comparison(
                    generated_test_report,
                    reference_python,
                    tests_file,
                    oracle_records,
                    generated_python=(artifact_directory / "generated_program.py"),
                )
                comparison_path = artifact_directory / "baseline_python_comparison.json"
                comparison_path.write_text(json.dumps(benchmark, indent=2), encoding="utf-8")
                metadata = {
                    "algorithm_id": algorithm_id,
                    "dataset": "Baseline",
                    "source_type": "baseline_pseudocode",
                    "source_file": source_file.name,
                    "source_file_resolved": str(source_file.resolve()),
                    "is_baseline": True,
                }
                score_paths = self.scorer.write_outputs(artifact_directory, metadata, benchmark=benchmark)
                questionnaire_paths = self.questionnaire.write(
                    artifact_directory / "scoring",
                    _read_json(score_paths["automated_score"]) or {},
                )
                adjudicate_files(artifact_directory / "scoring")
                _write_manifest(
                    artifact_directory,
                    algorithm_id=algorithm_id,
                    dataset="Baseline",
                    source_type="BASELINE_PSEUDOCODE",
                    source_file=source_file,
                    profile=profile,
                    is_baseline=True,
                    reference_python=reference_python,
                    tests_file=tests_file,
                    processing_status=result.status,
                )
                records.append(AlgorithmRunRecord(
                    algorithm_id=algorithm_id,
                    dataset="Baseline",
                    source_file=str(source_file.resolve()),
                    artifact_directory=str(artifact_directory.resolve()),
                    status=result.status,
                    pipeline_success=result.success,
                    error=result.error,
                    reference_python=str(reference_python.resolve()) if reference_python else None,
                    tests_file=str(tests_file.resolve()) if tests_file else None,
                    score_file=str(score_paths["automated_score"].resolve()),
                    questionnaire_file=str(questionnaire_paths["questionnaire_html"].resolve()),
                ))
            except Exception as error:
                _write_batch_failure(artifact_directory, algorithm_id, "Baseline", error)
                records.append(AlgorithmRunRecord(
                    algorithm_id=algorithm_id,
                    dataset="Baseline",
                    source_file=None,
                    artifact_directory=str(artifact_directory.resolve()),
                    status="FAILURE",
                    pipeline_success=False,
                    error=str(error),
                ))
        batch = self._write_batch_reports(baseline_root / "study_analysis", "Baseline", records, "BASELINE")
        batch["analysis_outputs"] = aggregate_algorithm_folders(pseudocode_root, baseline_root / "study_analysis")
        return batch

    @staticmethod
    def _write_batch_reports(
        analysis_directory: Path,
        dataset: str,
        records: list[AlgorithmRunRecord],
        batch_type: str,
    ) -> dict[str, Any]:
        analysis_directory.mkdir(parents=True, exist_ok=True)
        report = {
            "batch_schema_version": "1.0",
            "pipeline_version": PIPELINE_VERSION,
            "rubric_version": RUBRIC_VERSION,
            "batch_type": batch_type,
            "dataset": dataset,
            "generated_at_utc": datetime.now(timezone.utc).isoformat(),
            "algorithm_count": len(records),
            "status_counts": dict(sorted(Counter(r.status for r in records).items())),
            "algorithms": [asdict(record) for record in records],
        }
        json_path = analysis_directory / "batch_report.json"
        json_path.write_text(json.dumps(report, indent=2), encoding="utf-8")
        csv_path = analysis_directory / "batch_report.csv"
        fieldnames = list(asdict(records[0]).keys()) if records else [
            "algorithm_id", "dataset", "source_file", "artifact_directory", "status",
            "pipeline_success", "error", "reference_python", "tests_file", "score_file", "questionnaire_file",
        ]
        with csv_path.open("w", encoding="utf-8", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=fieldnames)
            writer.writeheader()
            for record in records:
                writer.writerow(asdict(record))
        return {
            "report": report,
            "json_path": str(json_path.resolve()),
            "csv_path": str(csv_path.resolve()),
        }
