import unittest

from aj_parser import AJParserFacade
from pseudocode_profiles import PseudocodeProfile, PseudocodeProfileProcessor
from flow_diagram import FlowDiagramEncoder
from aj_python_compiler import AJPythonCompiler


class GenericObviousMismatchTests(unittest.TestCase):
    def setUp(self):
        self.processor = PseudocodeProfileProcessor()

    def process(self, source):
        return self.processor.process(source, PseudocodeProfile.GENERIC_COMPATIBILITY)

    def test_raw_output_string_and_sort_characters_parse(self):
        source = """String1 <- INPUT(STRING(\"Enter String1\"))
String2 <- INPUT(STRING(\"Enter String2\"))
IF LENGTH OF String1 != LENGTH OF String2 THEN
    OUTPUT \"Not Anagrams\"
ELSE
    SORT characters of String1
    SORT characters of String2
    IF String1 == String2 THEN
        OUTPUT \"Anagrams\"
    ELSE
        OUTPUT \"Not Anagrams\"
    ENDIF
ENDIF
"""
        result = self.process(source)
        self.assertIn('OUTPUT STRING("Not Anagrams")', result.processed_source)
        self.assertIn('String1 <- CALL sort_characters(String1)', result.processed_source)
        parsed = AJParserFacade().parse(result.processed_source)
        self.assertTrue(parsed.success, parsed.error)

    def test_not_in_operator_parses(self):
        parsed = AJParserFacade().parse("FUNCTION f ACCEPTS(x, seen)\n    IF x NOT IN seen THEN\n        RETURN BOOLEAN(True)\n    ENDIF\n    RETURN BOOLEAN(False)\nENDFUNCTION\n")
        self.assertTrue(parsed.success, parsed.error)

    def test_swap_expands_to_assignments(self):
        result = self.process("SWAP left AND right\n")
        self.assertIn('_swap_temp <- left', result.processed_source)
        self.assertIn('left <- right', result.processed_source)

    def test_swap_indexed_items_expands_and_parses(self):
        source = "WordList <- EMPTY LIST\nj <- 0\nSWAP WordList[j], WordList[j+1]\n"
        result = self.process(source)
        self.assertIn("_swap_temp <- WordList[j]", result.processed_source)
        self.assertIn("WordList[j] <- WordList[j+1]", result.processed_source)
        self.assertIn("WordList[j+1] <- _swap_temp", result.processed_source)
        parsed = AJParserFacade().parse(result.processed_source)
        self.assertTrue(parsed.success, parsed.error)

    def test_reserved_list_identifier_and_exit_for_parse(self):
        source = """List <- INPUT(STRING("Enter List"))
Target <- INPUT(STRING("Enter Target"))
Found <- BOOLEAN(False)
FOR i from 0 to length(List)-1:
    IF List[i] == Target THEN
        OUTPUT TUPLE(STRING("Found at position"), i)
        Found <- BOOLEAN(True)
        EXIT FOR
    ENDIF
ENDFOR
IF Found == BOOLEAN(False) THEN
    OUTPUT STRING("Target not found")
ENDIF
"""
        result = self.process(source)
        self.assertIn("values <- INPUT", result.processed_source)
        self.assertIn("IF values[i] == Target THEN", result.processed_source)
        self.assertIn("BREAK", result.processed_source)
        parsed = AJParserFacade().parse(result.processed_source)
        self.assertTrue(parsed.success, parsed.error)

    def test_case_block_and_part_heading_normalise_and_parse(self):
        source = """Text <- INPUT(STRING("Enter Text"))
A <- 0
E <- 0
FOR EACH Character IN Text DO
    CASE Character OF
        STRING("a"): A <- A + 1
        STRING("e"): E <- E + 1
    ENDCASE
ENDFOR
OUTPUT TUPLE(A, E)
Part 2 - Pseudocode for Tasks 11-20
"""
        result = self.process(source)
        self.assertIn('IF Character == STRING("a") THEN', result.processed_source)
        self.assertIn('ELSE IF Character == STRING("e") THEN', result.processed_source)
        self.assertNotIn("Part 2 -", result.processed_source)
        parsed = AJParserFacade().parse(result.processed_source)
        self.assertTrue(parsed.success, parsed.error)

    def test_add_to_collection_becomes_append_and_parses(self):
        source = """IP_List <- INPUT(STRING("Enter IP_List"))
UniqueIPs <- EMPTY SET
FOR EACH IP IN IP_List DO
    ADD IP TO UniqueIPs
ENDFOR
OUTPUT UniqueIPs
"""
        result = self.process(source)
        self.assertIn("APPEND IP TO UniqueIPs", result.processed_source)
        parsed = AJParserFacade().parse(result.processed_source)
        self.assertTrue(parsed.success, parsed.error)

    def test_downto_range_is_normalised_once(self):
        source = """BEGIN
    INPUT Text

    Reverse ← ""

    FOR i ← LENGTH(Text)-1 DOWNTO 0
        Reverse ← Reverse + Text[i]
    ENDFOR

    OUTPUT Reverse
END
"""
        result = self.process(source)
        expected = """Text <- INPUT(STRING("Enter Text"))

Reverse <- EMPTY STRING

FOR i <- IN RANGE LENGTH OF Text-1 TO 0 STEP -1 DO
    Reverse <- Reverse + Text[i]
ENDFOR

OUTPUT Reverse"""
        self.assertEqual(expected, result.processed_source.strip())
        self.assertNotIn("IN RANGE IN RANGE", result.processed_source)
        parsed = AJParserFacade().parse(result.processed_source)
        self.assertTrue(parsed.success, parsed.error)

    def test_anonymous_dictionary_declaration_parses(self):
        source = """Text <- INPUT(STRING("Enter Text"))
Create Dictionary
OUTPUT Text
"""
        result = self.process(source)
        self.assertIn("Anonymous_Dictionary <- EMPTY DICTIONARY", result.processed_source)
        parsed = AJParserFacade().parse(result.processed_source)
        self.assertTrue(parsed.success, parsed.error)

    def test_all_part_section_labels_are_stripped(self):
        for heading in (
            "Part 1 - Pseudocode for Tasks 1-10",
            "Part 2 - Pseudocode for Tasks 11-20",
            "Part 3 - Pseudocode for Tasks 21-30",
            "Part 10 - Additional Pseudocode",
        ):
            source = f"""Number <- 6
OUTPUT Number
{heading}
"""
            result = self.process(source)
            self.assertNotIn("Part ", result.processed_source)
            parsed = AJParserFacade().parse(result.processed_source)
            self.assertTrue(parsed.success, parsed.error)

    def test_anonymous_queue_uses_append_and_pop_zero_semantics(self):
        source = """Root <- INPUT(STRING("Enter Root"))
CREATE EMPTY QUEUE
ENQUEUE Root
WHILE Queue is not empty DO
    Node <- DEQUEUE Queue
    OUTPUT Node
ENDWHILE
"""
        result = self.process(source)
        self.assertIn("Anonymous_Queue <- EMPTY LIST", result.processed_source)
        self.assertIn("APPEND Root TO Anonymous_Queue", result.processed_source)
        self.assertIn("Node <- REMOVE FIRST ITEM FROM Anonymous_Queue", result.processed_source)
        self.assertNotRegex(result.processed_source, r"\\bQueue\\b")

    def test_inferred_node_queue_traversal_compiles(self):
        source = """BEGIN
    INPUT Root

    CREATE Empty Queue
    ENQUEUE Root

    WHILE Queue is not empty
        Node ← DEQUEUE Queue
        OUTPUT Node.Value

        IF Node.Left exists THEN
            ENQUEUE Node.Left
        ENDIF

        IF Node.Right exists THEN
            ENQUEUE Node.Right
        ENDIF
    ENDWHILE
END
"""
        result = self.process(source)
        self.assertIn('Root_Key <- INPUT(STRING("Enter Root"))', result.processed_source)
        self.assertIn("Root <- CALL lookup_inferred_node(Root_Key)", result.processed_source)
        self.assertIn("Node <- REMOVE FIRST ITEM FROM Anonymous_Queue", result.processed_source)
        self.assertIn("OUTPUT Node.Value", result.processed_source)
        self.assertIn("IF Node.Left != CALL NULL() THEN", result.processed_source)

        parsed = AJParserFacade().parse(result.processed_source)
        self.assertTrue(parsed.success, parsed.error)

        flow = FlowDiagramEncoder().encode(parsed.ast)
        compiled = AJPythonCompiler().compile(flow)
        self.assertTrue(compiled.success)
        self.assertIn("class InferredNode:", compiled.source_code)
        self.assertIn("Node = Anonymous_Queue.pop(0)", compiled.source_code)
        self.assertIn("print(Node.value)", compiled.source_code)
        self.assertIn("if (Node.left != None):", compiled.source_code)

    def test_inferred_node_lookup_is_preinitialised_and_does_not_insert_missing_key(self):
        source = """BEGIN
    INPUT Root
    CREATE Empty Queue
    ENQUEUE Root
    WHILE Queue is not empty
        Node ← DEQUEUE Queue
        OUTPUT Node.Value
        IF Node.Left exists THEN
            ENQUEUE Node.Left
        ENDIF
        IF Node.Right exists THEN
            ENQUEUE Node.Right
        ENDIF
    ENDWHILE
END
"""
        result = self.process(source)
        parsed = AJParserFacade().parse(result.processed_source)
        self.assertTrue(parsed.success, parsed.error)
        flow = FlowDiagramEncoder().encode(parsed.ast)
        compiled = AJPythonCompiler().compile(flow)
        self.assertIn("random.sample(range(1, 101), k=10)", compiled.source_code)
        self.assertIn("_inferred_node_lookup = {", compiled.source_code)
        self.assertIn("return None", compiled.source_code)
        self.assertNotIn("_inferred_node_lookup[key] = InferredNode(key)", compiled.source_code)

    def test_inferred_lookup_does_not_output_success_value(self):
        source = """BEGIN
    INPUT Root
    CREATE Empty Queue
    ENQUEUE Root
    WHILE Queue is not empty
        Node ← DEQUEUE Queue
        OUTPUT Node.Value
        IF Node.Left exists THEN
            ENQUEUE Node.Left
        ENDIF
        IF Node.Right exists THEN
            ENQUEUE Node.Right
        ENDIF
    ENDWHILE
END
"""
        result = self.process(source)
        parsed = AJParserFacade().parse(result.processed_source)
        self.assertTrue(parsed.success, parsed.error)

        flow = FlowDiagramEncoder().encode(parsed.ast)
        compiled = AJPythonCompiler().compile(flow)

        self.assertIn("return _inferred_node_lookup[key]", compiled.source_code)
        self.assertNotIn("print(f'{_inferred_node_lookup[key]}')", compiled.source_code)
        self.assertIn("print(Node.value)", compiled.source_code)

    def test_stop_compiles_to_quit(self):
        source = """Number <- 9
WHILE Number > 0 DO
    IF Number == 9 THEN
        OUTPUT Number
        STOP
    ENDIF
    Number <- Number - 1
ENDWHILE
"""
        parsed = AJParserFacade().parse(source)
        self.assertTrue(parsed.success, parsed.error)
        flow = FlowDiagramEncoder().encode(parsed.ast)
        compiled = AJPythonCompiler().compile(flow)
        self.assertTrue(compiled.success)
        self.assertIn("quit()", compiled.source_code)
        self.assertNotIn("break", compiled.source_code)


if __name__ == '__main__':
    unittest.main()
