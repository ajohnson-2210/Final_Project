# NL-FDEP v4.35 Release Candidate 3

v4.35 RC3 retains Common Tests v1.3 / test-spec schema v1.4 and the model-neutral, static semantic evaluation introduced in the v4.35 candidate. RC3 changes only the interactive study-readiness workflow and associated tests/documentation.

## Procedural baseline-readiness gate

`LLM_RESULTS_FOLDER` is once again a baseline-gated runner route. Before the experimental dataset can be selected, the runner must establish a current trusted benchmark satisfying all of the following:

- 50/50 current terminal baseline calibration runs;
- 50/50 behaviourally evaluated calibrations;
- 50/50 calibration scores equal to 100%;
- valid baseline structure against the packaged Common Tests v1.3 resource.

If no saved baseline is available, the runner offers the baseline chooser. If calibration is missing or stale, it offers calibration and resumes the original LLM operation only after the requirement is met. A moved or structurally invalid saved path is cleared and replaced through the normal chooser. A calibration that remains incomplete or below 100% is rejected and the LLM operation does not start.

The last study-ready baseline path is stored outside the release tree in the existing per-user runner state file and is revalidated on every dependent run.

## Academic-integrity separation

The baseline is a **procedural readiness prerequisite only**. Its path is retained by the interactive runner for validation and folder-selection safety but is not passed to `run_llm_results_folder()` or the experimental scorer. Experimental semantic scoring continues to use only static frozen Common Tests v1.3 expectations. No baseline Python, reference implementation, or executable oracle is used to generate an expected value from an LLM input at runtime.

## RC3 regression coverage

RC3 adds regression tests proving that:

- the LLM route is baseline-gated;
- a missing baseline can be provided, calibrated, and then used to resume the LLM workflow;
- fewer than 50/50 100% calibration outcomes blocks the LLM operation;
- a persisted ready baseline is reused without an unnecessary chooser;
- the baseline path is not forwarded into the experimental scoring call;
- static frozen expectations, algorithm-agnostic semantic observation, and model-neutral release integrity remain unchanged.

This build remains a release candidate for cross-dataset stress testing and is not the final study freeze.
