"""Controlled pseudocode processing profiles for the input pipeline."""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from enum import Enum
import json
import re


class PseudocodeProfile(str, Enum):
    """Available pseudocode processing profiles."""

    AJ_DIALECT_STRICT = "AJ_DIALECT_STRICT"
    GENERIC_COMPATIBILITY = "GENERIC_COMPATIBILITY"
    GENERAL_NO_CONVERSION = "GENERAL_NO_CONVERSION"


@dataclass
class SourceTransformation:
    """Records one deliberate source transformation."""

    line: int | None
    rule: str
    source: str
    target: str


@dataclass
class PseudocodeProcessingResult:
    """Contains processed source and an auditable transformation report."""

    profile: PseudocodeProfile
    original_source: str
    processed_source: str
    transformations: list[SourceTransformation] = field(default_factory=list)
    header_comment_removed: bool = False
    header_lines_removed: int = 0

    @property
    def source_modified(self) -> bool:
        """Returns whether the selected profile changed the supplied source."""

        return self.original_source != self.processed_source

    @property
    def transformation_count(self) -> int:
        """Returns the number of logged transformations."""

        return len(self.transformations)

    def to_dict(self) -> dict:
        """Returns a serialisable processing report."""

        transformations = []

        for transformation in self.transformations:
            transformations.append(
                asdict(transformation)
            )

        return {
            "profile": self.profile.value,
            "source_modified": self.source_modified,
            "transformation_count": self.transformation_count,
            "transformations": transformations,
            "header_comment_removed": self.header_comment_removed,
            "header_lines_removed": self.header_lines_removed,
        }

    def to_json(self) -> str:
        """Returns the processing report as formatted JSON."""

        return json.dumps(
            self.to_dict(),
            indent=2,
        )


class InitialHashCommentStripper:
    """Removes an optional leading hash-comment metadata block before parsing."""

    PSEUDOCODE_START_PATTERN = re.compile(
        r"^(?:"
        r"INPUT\b|OUTPUT\b|FUNCTION\b|CLASS\b|IF\b|WHILE\b|FOR\b|"
        r"RETURN\b|CALL\b|TRY\b|RAISE\b|COMMENT\b|BREAK\b|"
        r"[A-Za-z_][A-Za-z0-9_]*(?:\[[^\]]+\])?\s*(?:<-|=)"
        r")",
        re.IGNORECASE,
    )

    def strip(self, source: str) -> tuple[str, bool, int]:
        """Removes a leading hash-comment metadata block before pseudocode begins."""

        source_lines = source.splitlines(keepends=True)

        if not source_lines:
            return source, False, 0

        header_start_index = 0

        while header_start_index < len(source_lines):
            candidate_line = source_lines[header_start_index]
            candidate_line = candidate_line.lstrip("\ufeff \t\r\n")

            if candidate_line != "":
                break

            header_start_index += 1

        if header_start_index >= len(source_lines):
            return source, False, 0

        first_content_line = source_lines[header_start_index]
        first_content_line = first_content_line.lstrip("\ufeff \t")

        if not first_content_line.startswith("#"):
            return source, False, 0

        first_pseudocode_index = None

        for index in range(header_start_index + 1, len(source_lines)):
            candidate = source_lines[index]
            stripped_candidate = candidate.strip()

            if stripped_candidate == "":
                first_pseudocode_index = index + 1

                while first_pseudocode_index < len(source_lines):
                    if source_lines[first_pseudocode_index].strip() != "":
                        break

                    first_pseudocode_index += 1

                break

            if self._looks_like_pseudocode(stripped_candidate):
                first_pseudocode_index = index
                break

        if first_pseudocode_index is None:
            first_pseudocode_index = header_start_index + 1

        processed_source = "".join(
            source_lines[first_pseudocode_index:]
        )

        return processed_source, True, first_pseudocode_index

    def _looks_like_pseudocode(self, line: str) -> bool:
        """Returns whether a line clearly begins with executable pseudocode."""

        return bool(
            self.PSEUDOCODE_START_PATTERN.match(
                line
            )
        )


@dataclass(frozen=True)
class CharacterNormalisationRule:
    """Defines one auditable Generic compatibility character rule."""

    rule_id: str
    source: str
    target: str
    description: str


class GenericCharacterNormaliser:
    """Normalises characters observed across the six-model pseudocode corpus."""

    RULES = (
        CharacterNormalisationRule("GC001", "≠", "!=", "Unicode not-equal operator"),
        CharacterNormalisationRule("GC002", "≤", "<=", "Unicode less-than-or-equal operator"),
        CharacterNormalisationRule("GC003", "≥", ">=", "Unicode greater-than-or-equal operator"),
        CharacterNormalisationRule("GC004", "←", "<-", "Unicode assignment arrow"),
        CharacterNormalisationRule("GC005", "×", "*", "Unicode multiplication operator"),
        CharacterNormalisationRule("GC006", "∞", "INFINITY", "Unicode infinity symbol"),
        CharacterNormalisationRule("GC007", "→", "TO", "Unicode right arrow"),
        CharacterNormalisationRule("GC008", "“", '"', "Opening smart double quote"),
        CharacterNormalisationRule("GC009", "”", '"', "Closing smart double quote"),
        CharacterNormalisationRule("GC010", "‘", "'", "Opening smart single quote"),
        CharacterNormalisationRule("GC011", "’", "'", "Closing smart single quote"),
        CharacterNormalisationRule("GC012", "–", "-", "Unicode en dash"),
        CharacterNormalisationRule("GC013", "\u2005", " ", "Unicode four-per-em space"),
        CharacterNormalisationRule("GC014", "\u00a0", " ", "Non-breaking space"),
        CharacterNormalisationRule("GC015", "\u200b", "", "Zero-width space"),
        CharacterNormalisationRule("GC016", "\ufeff", "", "UTF-8 BOM / zero-width no-break space"),
    )

    def process(self, source: str) -> tuple[str, list[SourceTransformation]]:
        """Applies corpus-derived character rules and records every changed line."""

        source_lines = source.splitlines(keepends=True)
        transformations = []
        processed_lines = []

        for line_number, source_line in enumerate(source_lines, start=1):
            transformed_line = source_line

            for rule in self.RULES:
                if rule.source not in transformed_line:
                    continue

                before = transformed_line
                transformed_line = transformed_line.replace(
                    rule.source,
                    rule.target,
                )

                transformations.append(
                    SourceTransformation(
                        line=line_number,
                        rule=rule.rule_id,
                        source=before.rstrip("\r\n"),
                        target=transformed_line.rstrip("\r\n"),
                    )
                )

            degree_before = transformed_line
            transformed_line = re.sub(
                r"(?<=\d)°",
                " DEG",
                transformed_line,
            )

            if transformed_line != degree_before:
                transformations.append(
                    SourceTransformation(
                        line=line_number,
                        rule="GC017",
                        source=degree_before.rstrip("\r\n"),
                        target=transformed_line.rstrip("\r\n"),
                    )
                )

            processed_lines.append(
                transformed_line
            )

        return "".join(processed_lines), transformations


@dataclass(frozen=True)
class OperatorNormalisationRule:
    """Defines one auditable Generic compatibility operator rule."""

    rule_id: str
    source: str
    target: str
    description: str


class GenericOperatorNormaliser:
    """Normalises operator forms observed across the six-model corpus."""

    COMPOUND_RULES = (
        OperatorNormalisationRule("GC018", "+=", "<-", "Compound addition assignment"),
        OperatorNormalisationRule("GC019", "-=", "<-", "Compound subtraction assignment"),
        OperatorNormalisationRule("GC020", "*=", "<-", "Compound multiplication assignment"),
        OperatorNormalisationRule("GC021", "/=", "<-", "Compound division assignment"),
        OperatorNormalisationRule("GC022", "%=", "<-", "Compound modulus assignment"),
    )

    def process(self, source: str) -> tuple[str, list[SourceTransformation]]:
        """Applies context-aware operator rules and records each changed line."""

        transformations = []
        processed_lines = []

        for line_number, source_line in enumerate(source.splitlines(keepends=True), start=1):
            transformed_line = source_line

            transformed_line, line_transformations = self._normalise_line(
                transformed_line,
                line_number,
            )
            transformations.extend(line_transformations)
            processed_lines.append(transformed_line)

        return "".join(processed_lines), transformations

    def _normalise_line(
        self,
        line: str,
        line_number: int,
    ) -> tuple[str, list[SourceTransformation]]:
        """Normalises one line without confusing comparison and assignment equals."""

        transformations = []
        transformed = line

        for rule in self.COMPOUND_RULES:
            pattern = re.compile(
                rf"(?P<target>[A-Za-z_][A-Za-z0-9_]*(?:\[[^\]]+\])?(?:\.[A-Za-z_][A-Za-z0-9_]*)*)\s*{re.escape(rule.source)}\s*(?P<value>[^,;\n]+)"
            )

            def replace_compound(match):
                target = match.group("target")
                value = match.group("value").strip()
                operator = rule.source[0]
                return f"{target} <- {target} {operator} {value}"

            before = transformed
            transformed = pattern.sub(replace_compound, transformed)
            self._record_if_changed(
                transformations, line_number, rule.rule_id, before, transformed
            )

        for rule_id, suffix, operator in (
            ("GC023", "++", "+"),
            ("GC024", "--", "-"),
        ):
            pattern = re.compile(
                rf"(?P<target>[A-Za-z_][A-Za-z0-9_]*(?:\[[^\]]+\])?(?:\.[A-Za-z_][A-Za-z0-9_]*)*)\s*{re.escape(suffix)}"
            )

            def replace_step(match, op=operator):
                target = match.group("target")
                return f"{target} <- {target} {op} 1"

            before = transformed
            transformed = pattern.sub(replace_step, transformed)
            self._record_if_changed(
                transformations, line_number, rule_id, before, transformed
            )

        before = transformed
        transformed = self._normalise_condition_equals(transformed)
        self._record_if_changed(
            transformations, line_number, "GC025", before, transformed
        )

        before = transformed
        transformed = self._normalise_assignment_equals(transformed)
        self._record_if_changed(
            transformations, line_number, "GC026", before, transformed
        )

        return transformed, transformations

    def _normalise_condition_equals(self, line: str) -> str:
        """Converts single equals to equality only in explicit condition clauses."""

        line_ending = ""

        if line.endswith("\r\n"):
            line_ending = "\r\n"
            content = line[:-2]
        elif line.endswith("\n") or line.endswith("\r"):
            line_ending = line[-1]
            content = line[:-1]
        else:
            content = line

        condition_match = re.match(
            r"^(?P<prefix>\s*(?:IF|ELSE\s+IF|WHILE)\s+)(?P<body>.*)$",
            content,
            re.IGNORECASE,
        )

        if condition_match is None:
            return line

        prefix = condition_match.group("prefix")
        body = condition_match.group("body")

        boundary_match = re.search(
            r"\s+THEN\b|:",
            body,
            re.IGNORECASE,
        )

        if boundary_match is None:
            condition_text = body
            suffix = ""
        else:
            condition_text = body[:boundary_match.start()]
            suffix = body[boundary_match.start():]

        condition_text = re.sub(
            r"(?<![<>=!])=(?!=)",
            "==",
            condition_text,
        )
        return f"{prefix}{condition_text}{suffix}{line_ending}"

    def _normalise_assignment_equals(self, line: str) -> str:
        """Converts a leading lvalue assignment equals to AJ assignment syntax."""

        return re.sub(
            r"^(?P<indent>\s*)(?P<target>[A-Za-z_][A-Za-z0-9_]*(?:\[[^\]]+\])?(?:\.[A-Za-z_][A-Za-z0-9_]*)*)\s*(?<![<>=!])=(?!=)\s*",
            lambda match: f"{match.group('indent')}{match.group('target')} <- ",
            line,
            count=1,
        )

    def _record_if_changed(
        self,
        transformations: list[SourceTransformation],
        line_number: int,
        rule_id: str,
        before: str,
        after: str,
    ) -> None:
        """Adds one transformation record when a rule changes a line."""

        if before == after:
            return

        transformations.append(
            SourceTransformation(
                line=line_number,
                rule=rule_id,
                source=before.rstrip("\r\n"),
                target=after.rstrip("\r\n"),
            )
        )


@dataclass
class GenericLineToken:
    """Represents one classified line of generic pseudocode."""

    line_number: int
    indentation: str
    content: str
    category: str


class GenericPseudocodeLexer:
    """Classifies common generic pseudocode statements without parsing them."""

    def tokenise(self, source: str) -> list[GenericLineToken]:
        """Converts generic pseudocode into classified line tokens."""

        tokens = []
        source_lines = source.splitlines()

        for line_number, source_line in enumerate(source_lines, start=1):
            indentation = source_line[: len(source_line) - len(source_line.lstrip())]
            content = source_line.strip()
            category = self._classify_line(
                content=content,
            )

            line_token = GenericLineToken(
                line_number=line_number,
                indentation=indentation,
                content=content,
                category=category,
            )

            tokens.append(
                line_token
            )

        return tokens

    def _classify_line(self, content: str) -> str:
        """Returns the recognised category for one source line."""

        upper_content = content.upper()

        if not content:
            return "BLANK"

        if re.match(r"^SET\s+.+?\s+TO\s+.+$", content, re.IGNORECASE):
            return "SET_ASSIGNMENT"

        if re.match(r"^(PRINT|DISPLAY)\s+.+$", content, re.IGNORECASE):
            return "OUTPUT"

        if upper_content == "END IF":
            return "END_IF"

        if upper_content == "END WHILE":
            return "END_WHILE"

        if re.match(r"^NEXT(?:\s+\w+)?$", content, re.IGNORECASE):
            return "NEXT"

        if re.match(r"^IF\s+.+$", content, re.IGNORECASE):
            return "IF"

        if re.match(r"^WHILE\s+.+$", content, re.IGNORECASE):
            return "WHILE"

        if re.match(r"^FOR\s+EACH\s+\w+\s+IN\s+.+$", content, re.IGNORECASE):
            return "FOR_EACH"

        if self._is_simple_assignment(content):
            return "EQUALS_ASSIGNMENT"

        return "UNCHANGED"

    def _is_simple_assignment(self, content: str) -> bool:
        """Identifies assignment equals without confusing comparison operators."""

        assignment_pattern = r"^[A-Za-z_][A-Za-z0-9_]*(?:\[[^\]]+\])?\s*=\s*.+$"

        if not re.match(assignment_pattern, content):
            return False

        comparison_operators = [
            "==",
            "!=",
            "<=",
            ">=",
        ]

        for comparison_operator in comparison_operators:
            if comparison_operator in content:
                return False

        return True


class StrictPseudocodeProcessor:
    """Performs only non-semantic AJ Dialect source cleanup."""

    def process(self, source: str) -> PseudocodeProcessingResult:
        """Processes source using strict, auditable cleanup rules."""

        processed_source = source
        transformations = []

        normalised_line_endings = processed_source.replace("\r\n", "\n").replace("\r", "\n")

        if normalised_line_endings != processed_source:
            transformations.append(
                SourceTransformation(
                    line=None,
                    rule="NORMALISE_LINE_ENDINGS",
                    source="Mixed platform line endings",
                    target="Unix line endings",
                )
            )

            processed_source = normalised_line_endings

        processed_source, fence_transformations = self._remove_markdown_fences(
            source=processed_source,
        )
        transformations.extend(
            fence_transformations
        )

        source_lines = processed_source.splitlines()
        normalised_lines = []

        for line_number, source_line in enumerate(source_lines, start=1):
            transformed_line = source_line.rstrip()

            if transformed_line != source_line:
                transformations.append(
                    SourceTransformation(
                        line=line_number,
                        rule="REMOVE_TRAILING_WHITESPACE",
                        source=source_line,
                        target=transformed_line,
                    )
                )

            arrow_normalised_line = transformed_line.replace("←", "<-")

            if arrow_normalised_line != transformed_line:
                transformations.append(
                    SourceTransformation(
                        line=line_number,
                        rule="NORMALISE_ASSIGNMENT_ARROW",
                        source=transformed_line,
                        target=arrow_normalised_line,
                    )
                )

            normalised_lines.append(
                arrow_normalised_line
            )

        processed_source = "\n".join(normalised_lines)

        return PseudocodeProcessingResult(
            profile=PseudocodeProfile.AJ_DIALECT_STRICT,
            original_source=source,
            processed_source=processed_source,
            transformations=transformations,
        )

    def _remove_markdown_fences(
        self,
        source: str,
    ) -> tuple[str, list[SourceTransformation]]:
        """Removes a surrounding Markdown code fence when present."""

        source_lines = source.splitlines()
        transformations = []

        if len(source_lines) < 2:
            return source, transformations

        first_line = source_lines[0].strip()
        final_line = source_lines[-1].strip()

        if first_line.startswith("```") and final_line == "```":
            transformed_source = "\n".join(source_lines[1:-1])

            transformations.append(
                SourceTransformation(
                    line=None,
                    rule="REMOVE_MARKDOWN_CODE_FENCE",
                    source=f"{first_line} ... {final_line}",
                    target="Code-fence contents",
                )
            )

            return transformed_source, transformations

        return source, transformations


class GenericPseudocodeProcessor:
    """Converts recognised generic structured pseudocode into AJ Dialect syntax."""

    def __init__(self) -> None:
        self.character_normaliser = GenericCharacterNormaliser()
        self.operator_normaliser = GenericOperatorNormaliser()
        self.lexer = GenericPseudocodeLexer()
        self.strict_processor = StrictPseudocodeProcessor()

    def process(self, source: str) -> PseudocodeProcessingResult:
        """Applies compatibility conversions and records every changed line."""

        character_source, character_transformations = self.character_normaliser.process(
            source=source,
        )
        operator_source, operator_transformations = self.operator_normaliser.process(
            source=character_source,
        )
        strict_result = self.strict_processor.process(
            source=operator_source,
        )
        generic_tokens = self.lexer.tokenise(
            source=strict_result.processed_source,
        )
        processed_lines = []
        transformations = list(character_transformations)
        transformations.extend(
            operator_transformations
        )
        transformations.extend(
            strict_result.transformations
        )

        for line_token in generic_tokens:
            transformed_content = self._convert_token(
                line_token=line_token,
            )
            transformed_content = self._convert_operators(
                content=transformed_content,
            )
            transformed_line = f"{line_token.indentation}{transformed_content}"
            source_line = f"{line_token.indentation}{line_token.content}"

            if transformed_line != source_line:
                transformations.append(
                    SourceTransformation(
                        line=line_token.line_number,
                        rule=f"GENERIC_{line_token.category}",
                        source=source_line,
                        target=transformed_line,
                    )
                )

            processed_lines.append(
                transformed_line
            )

        processed_source = "\n".join(processed_lines)

        return PseudocodeProcessingResult(
            profile=PseudocodeProfile.GENERIC_COMPATIBILITY,
            original_source=source,
            processed_source=processed_source,
            transformations=transformations,
        )

    def _convert_token(self, line_token: GenericLineToken) -> str:
        """Converts one classified generic line into AJ Dialect syntax."""

        content = line_token.content

        if line_token.category == "SET_ASSIGNMENT":
            match = re.match(
                r"^SET\s+(.+?)\s+TO\s+(.+)$",
                content,
                re.IGNORECASE,
            )

            if match is not None:
                target = match.group(1).strip()
                value = match.group(2).strip()
                return f"{target} <- {value}"

        if line_token.category == "OUTPUT":
            match = re.match(
                r"^(?:PRINT|DISPLAY)\s+(.+)$",
                content,
                re.IGNORECASE,
            )

            if match is not None:
                output_expression = match.group(1).strip()
                return f"OUTPUT {output_expression}"

        if line_token.category == "END_IF":
            return "ENDIF"

        if line_token.category == "END_WHILE":
            return "ENDWHILE"

        if line_token.category == "NEXT":
            return "ENDFOR"

        if line_token.category == "IF":
            if not re.search(r"\sTHEN$", content, re.IGNORECASE):
                return f"{content} THEN"

        if line_token.category == "WHILE":
            if not re.search(r"\sDO$", content, re.IGNORECASE):
                return f"{content} DO"

        if line_token.category == "FOR_EACH":
            if not re.search(r"\sDO$", content, re.IGNORECASE):
                return f"{content} DO"

        if line_token.category == "EQUALS_ASSIGNMENT":
            return re.sub(
                r"\s*=\s*",
                " <- ",
                content,
                count=1,
            )

        return content

    def _convert_operators(self, content: str) -> str:
        """Converts supported generic arithmetic operator words."""

        converted_content = re.sub(
            r"\bMOD\b",
            "MODULUS",
            content,
            flags=re.IGNORECASE,
        )
        converted_content = re.sub(
            r"\bDIV\b",
            "INTEGER DIVISION",
            converted_content,
            flags=re.IGNORECASE,
        )

        return converted_content


class GeneralPseudocodeProcessor:
    """Passes supplied pseudocode to the parser without source conversion."""

    def process(self, source: str) -> PseudocodeProcessingResult:
        """Returns the original source unchanged."""

        return PseudocodeProcessingResult(
            profile=PseudocodeProfile.GENERAL_NO_CONVERSION,
            original_source=source,
            processed_source=source,
            transformations=[],
        )


class PseudocodeProfileProcessor:
    """Selects the correct processor for a requested pseudocode profile."""

    def __init__(self) -> None:
        self.strict_processor = StrictPseudocodeProcessor()
        self.generic_processor = GenericPseudocodeProcessor()
        self.general_processor = GeneralPseudocodeProcessor()
        self.header_comment_stripper = InitialHashCommentStripper()

    def process(
        self,
        source: str,
        profile: PseudocodeProfile,
    ) -> PseudocodeProcessingResult:
        """Strips an optional file header and applies the selected profile."""

        profile_source, header_removed, header_lines_removed = (
            self.header_comment_stripper.strip(
                source=source,
            )
        )

        if profile == PseudocodeProfile.AJ_DIALECT_STRICT:
            result = self.strict_processor.process(
                source=profile_source,
            )

        elif profile == PseudocodeProfile.GENERIC_COMPATIBILITY:
            result = self.generic_processor.process(
                source=profile_source,
            )

        elif profile == PseudocodeProfile.GENERAL_NO_CONVERSION:
            result = self.general_processor.process(
                source=profile_source,
            )

        else:
            raise ValueError(
                f"Unsupported pseudocode profile: {profile}"
            )

        result.original_source = source
        result.header_comment_removed = header_removed
        result.header_lines_removed = header_lines_removed

        return result
