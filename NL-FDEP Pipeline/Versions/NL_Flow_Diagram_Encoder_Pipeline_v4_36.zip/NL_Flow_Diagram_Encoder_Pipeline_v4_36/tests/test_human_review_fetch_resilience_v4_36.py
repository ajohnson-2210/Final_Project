import inspect
import unittest

from human_review import _html_document
import study_review


class HumanReviewFetchResilienceTests(unittest.TestCase):
    def _template(self):
        return {
            "algorithm": {"algorithm_id": 27, "dataset": "Agent", "is_baseline": False},
            "instructions": "Independent review.",
            "reviewer": {"reviewer_id": "REV001", "reviewer_name": "Reviewer One"},
            "source_sufficiency": {},
            "behavioural_evidence_adequacy": {},
            "task_semantic_evaluation": None,
            "benchmark_validation": None,
            "criteria": [],
            "overall_review": {},
        }

    def test_server_backed_questionnaire_preserves_review_if_fetch_service_is_unavailable(self):
        html = _html_document(self._template(), save_endpoint="/save/token")
        self.assertIn("function downloadReviewBackup(review)", html)
        self.assertIn("downloadReviewBackup(review);showStatus(false,'Direct save service is unavailable.", html)
        self.assertNotIn("Review could not be saved: '+err", html)
        self.assertIn("cache:'no-store'", html)

    def test_window_manager_close_does_not_stop_open_questionnaire_service(self):
        source = inspect.getsource(study_review.launch_review_dashboard)
        self.assertIn("if service.contexts:\n            root.iconify()\n            return", source)
        self.assertIn('text="End Review Session"', source)
        self.assertIn("end_session_button.config(command=end_review_session)", source)


if __name__ == "__main__":
    unittest.main()
