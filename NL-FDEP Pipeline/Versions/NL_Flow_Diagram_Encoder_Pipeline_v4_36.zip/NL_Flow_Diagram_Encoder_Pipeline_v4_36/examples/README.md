# Examples — NL-FDEP v4.36

The examples in this folder were reviewed/regenerated against the v4.36 build.

- `example.aj` is a strict AJ_24038155 Dialect v1.5 pseudocode example.
- `example_ast.json`, `example_report.json`, `ast_visualisation.html`, `example_flow_diagram.json`, `example_flow_diagram.html`, `example_flow_diagram.drawio`, `example_generated_program.py`, `example_compilation_report.json`, `example_pseudocode_processing_report.json`, and `example_pipeline_report.json` are current artefacts generated from `example.aj`.
- `example_run.txt` is a human-readable summary of that full-pipeline run. Timings are illustrative and environment-dependent.
- `ast_output.json`, `parser_report.json`, and `pycharm_example_output.txt` are the current parser-only `sum_even` demonstration.
- `tic_tac_toe.drawio` is a DrawIO-input example verified against the current DrawIO input route.
- `study_tests_template.json` demonstrates the active Common Tests v1.4.2 / test-spec schema v1.6 structure. It uses static pre-experiment expectations and explicitly prohibits a runtime oracle. Placeholder values must be replaced before use in a frozen study pack.

The examples are demonstrations only; the authoritative study resources are under `study data/common tests v1.4.2`.
