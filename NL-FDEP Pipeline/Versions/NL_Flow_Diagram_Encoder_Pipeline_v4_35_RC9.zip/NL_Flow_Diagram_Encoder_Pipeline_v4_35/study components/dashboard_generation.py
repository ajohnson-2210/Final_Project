"""Automatic self-contained HTML dashboards for NL-FDEP study batches.

The dashboards are a presentation layer only. They read already-written study
artefacts and never participate in scoring, expected-value generation, baseline
calibration, or rubric adjudication.
"""
from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from typing import Any
import html
import json

DASHBOARD_SCHEMA_VERSION = "1.0"
COLOUR_STOPS = [
    (0, "#2f6db3"),
    (25, "#6ec5ff"),
    (50, "#ffc145"),
    (75, "#9be564"),
    (100, "#2ca25f"),
]


def _read_json(path: Path) -> Any:
    try:
        return json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None


def _read_text(path: Path) -> str | None:
    try:
        return Path(path).read_text(encoding="utf-8")
    except OSError:
        return None


def _results_child(parent: Path) -> Path | None:
    """Return a child named results, case-insensitively."""
    if not parent.is_dir():
        return None
    for child in parent.iterdir():
        if child.is_dir() and child.name.casefold() == "results":
            return child
    return None


def _algorithm_folder(parent: Path, algorithm_id: int) -> Path | None:
    wanted = f"algorithm - {algorithm_id}"
    if not parent.is_dir():
        return None
    for child in parent.iterdir():
        if child.is_dir() and child.name.casefold() == wanted:
            return child
    return None


def _source_pseudocode(folder: Path | None, algorithm_id: int) -> str | None:
    if folder is None:
        return None
    exact = folder / f"Algorithm {algorithm_id} Pseudocode.txt"
    if exact.is_file():
        return _read_text(exact)
    target = f"algorithm {algorithm_id} pseudocode.txt"
    for child in folder.iterdir():
        if child.is_file() and " ".join(child.name.split()).casefold() == target:
            return _read_text(child)
    return None


def _generated_python(folder: Path | None) -> tuple[str | None, str | None]:
    if folder is None:
        return None, None
    path = folder / "pipeline_artifacts" / "generated_program.py"
    if not path.is_file():
        return None, None
    return _read_text(path), str(path.resolve())


def _safe_json_for_script(value: Any) -> str:
    # Prevent source text containing </script> from terminating the data script.
    return json.dumps(value, ensure_ascii=False, separators=(",", ":")).replace("</", "<\\/")


def _number(value: Any) -> float | None:
    try:
        if value is None or value == "":
            return None
        return float(value)
    except (TypeError, ValueError):
        return None


def _mean(values: list[Any]) -> float | None:
    nums = [_number(v) for v in values]
    nums = [v for v in nums if v is not None]
    return round(sum(nums) / len(nums), 2) if nums else None


def _combined_behavioural(report: dict[str, Any]) -> float | None:
    a = _number(report.get("mean_experimental_behavioural_percentage"))
    b = _number(report.get("semantic_test_accuracy_percentage"))
    if a is None or b is None:
        return None
    return round((a + b) / 2.0, 2)


def _row_map(analysis_directory: Path) -> dict[int, dict[str, Any]]:
    rows = _read_json(analysis_directory / "algorithm_scores.json")
    out: dict[int, dict[str, Any]] = {}
    if not isinstance(rows, list):
        return out
    for row in rows:
        if not isinstance(row, dict):
            continue
        try:
            aid = int(row.get("Algorithm"))
        except (TypeError, ValueError):
            continue
        out[aid] = row
    return out


def _batch_records(report: dict[str, Any]) -> dict[int, dict[str, Any]]:
    out: dict[int, dict[str, Any]] = {}
    for record in report.get("algorithms", []) or []:
        if not isinstance(record, dict):
            continue
        try:
            aid = int(record.get("algorithm_id"))
        except (TypeError, ValueError):
            continue
        out[aid] = record
    return out


def _batch_dashboard_data(batch_root: Path, analysis_directory: Path) -> dict[str, Any]:
    report = _read_json(analysis_directory / "batch_report.json") or {}
    rows = _row_map(analysis_directory)
    records = _batch_records(report)
    is_baseline = str(report.get("batch_type") or "").upper() == "BASELINE"
    dataset = str(report.get("dataset") or batch_root.name)
    algorithms = []
    for aid in range(1, 51):
        row = rows.get(aid, {})
        record = records.get(aid, {})
        folder = _algorithm_folder(batch_root, aid)
        pseudo = _source_pseudocode(folder, aid)
        generated, generated_path = _generated_python(folder)
        score = (
            row.get("BaselineCalibrationPercent")
            if is_baseline
            else row.get("ExperimentalBehaviouralPercent")
        )
        if score is None:
            score = record.get("baseline_calibration_percentage" if is_baseline else "experimental_behavioural_percentage")
        algorithms.append({
            "algorithm": aid,
            "score": _number(score),
            "comparison": row.get("ComparisonToBaseline") or record.get("comparison_to_baseline") or ("CALIBRATION" if is_baseline else "NOT_EVALUABLE"),
            "pipelineStatus": row.get("PipelineStatus") or record.get("status") or "NOT_RUN",
            "pipelineSuccess": row.get("PipelineSuccess") if row.get("PipelineSuccess") is not None else record.get("pipeline_success"),
            "batchAction": row.get("BatchAction") or record.get("action"),
            "batchError": row.get("BatchError") or record.get("error"),
            "canonicalisation": _number(row.get("CanonicalisationPercent")),
            "ast": _number(row.get("ASTPercent")),
            "flow": _number(row.get("FlowPercent")),
            "python": _number(row.get("PythonPercent")),
            "testAccuracy": _number(row.get("TestAccuracyPercent")),
            "automatedRubric": _number(row.get("AutomatedRubricPercent")),
            "humanRubric": _number(row.get("HumanRubricPercent")),
            "combinedRubric": _number(row.get("CombinedRubricPercent")),
            "combinedRubricAvailable": bool(row.get("CombinedRubricAvailable")),
            "boundaryVariance": _number(row.get("SemanticBoundaryVariancePercent")),
            "boundaryEvaluable": row.get("SemanticBoundaryProbesEvaluable") if row else record.get("semantic_boundary_probes_evaluable"),
            "boundaryAccepted": row.get("SemanticBoundaryAccepted") if row else record.get("semantic_boundary_probes_accepted"),
            "boundaryControlled": row.get("SemanticBoundaryControlledRejection") if row else record.get("semantic_boundary_probes_controlled_rejection"),
            "boundaryIncidental": row.get("SemanticBoundaryIncidentalFailure") if row else record.get("semantic_boundary_probes_incidental_failure"),
            "behaviouralEvidenceAdequacy": row.get("BehaviouralEvidenceAdequacy"),
            "g2Summary": row.get("G2Summary"),
            "g2Strengths": row.get("G2Strengths"),
            "g2Limitations": row.get("G2Limitations"),
            "failureTaxonomy": row.get("FailureTaxonomy"),
            "firstSemanticLossStage": row.get("FirstSemanticLossStage"),
            "firstSemanticLossCriterion": row.get("FirstSemanticLossCriterion"),
            "cyclomaticComplexity": row.get("CyclomaticComplexity"),
            "decisionCount": row.get("DecisionCount"),
            "loopCount": row.get("LoopCount"),
            "maximumLoopNesting": row.get("MaximumLoopNesting"),
            "pseudocode": pseudo,
            "generatedPython": generated,
            "generatedPythonPath": generated_path,
        })
    return {
        "schemaVersion": DASHBOARD_SCHEMA_VERSION,
        "generatedAtUtc": datetime.now(timezone.utc).isoformat(),
        "dataset": dataset,
        "batchType": report.get("batch_type"),
        "isBaseline": is_baseline,
        "report": {
            "algorithmCount": report.get("algorithm_count"),
            "meanBehavioural": report.get("mean_experimental_behavioural_percentage"),
            "commonTestAccuracy": report.get("semantic_test_accuracy_percentage"),
            "combinedBehavioural": _combined_behavioural(report),
            "boundaryVariance": report.get("semantic_boundary_variance_percentage"),
            "meanBoundaryVariance": report.get("mean_algorithm_semantic_boundary_variance_percentage"),
            "meanBaselineCalibration": report.get("mean_baseline_calibration_percentage"),
            "semanticTestsEvaluable": report.get("semantic_tests_evaluable"),
            "semanticTestsPassed": report.get("semantic_tests_passed"),
            "semanticTestsNotEvaluable": report.get("semantic_tests_not_evaluable"),
            "pipelineStatusCounts": report.get("pipeline_status_counts") or report.get("status_counts") or {},
            "comparisonCounts": report.get("comparison_to_baseline_counts") or {},
            "boundaryEvaluable": report.get("semantic_boundary_probes_evaluable"),
            "boundaryAccepted": report.get("semantic_boundary_probes_accepted"),
            "boundaryControlled": report.get("semantic_boundary_probes_controlled_rejection"),
            "boundaryIncidental": report.get("semantic_boundary_probes_incidental_failure"),
            "boundaryNotEvaluable": report.get("semantic_boundary_probes_not_evaluable"),
            "meanAutomatedRubric": _mean([r.get("AutomatedRubricPercent") for r in rows.values()]),
            "meanHumanRubric": _mean([r.get("HumanRubricPercent") for r in rows.values()]),
            "meanCombinedRubric": _mean([r.get("CombinedRubricPercent") for r in rows.values() if r.get("CombinedRubricAvailable")]),
        },
        "algorithms": algorithms,
    }


_COMMON_CSS = r"""
:root{--bg:#f7f9fc;--panel:#fff;--text:#172033;--muted:#667085;--border:#d9e0ea;--shadow:0 12px 30px rgba(16,24,40,.08);--accent:#315efb}
*{box-sizing:border-box}body{margin:0;font-family:Inter,ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;background:var(--bg);color:var(--text)}
.page{max-width:1700px;margin:0 auto;padding:24px}.panel{background:var(--panel);border:1px solid var(--border);border-radius:16px;box-shadow:var(--shadow)}
h1{margin:0 0 6px;font-size:clamp(1.65rem,2.8vw,2.45rem);letter-spacing:-.03em}.sub{margin:0 0 18px;color:var(--muted);line-height:1.5}
.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(155px,1fr));gap:12px;margin:0 0 18px}.card{padding:13px 15px}.card .k{font-size:.75rem;color:var(--muted)}.card .v{font-weight:800;font-size:1.28rem;margin-top:3px}
.toolbar{display:flex;flex-wrap:wrap;gap:10px;align-items:center;padding:12px 14px;margin-bottom:16px}button,select{font:inherit;border:1px solid var(--border);background:#fff;padding:7px 9px;border-radius:9px;color:var(--text)}button{cursor:pointer;font-weight:700}
.legend{display:flex;flex-wrap:wrap;gap:10px;align-items:center;font-size:.78rem;color:#52606f;margin:10px 0}.sw{width:15px;height:15px;border:1px solid rgba(0,0,0,.15);border-radius:3px;display:inline-block;vertical-align:middle;margin-right:4px}
.heat-wrap{padding:14px}.alg-head,.heat-row{display:grid;grid-template-columns:repeat(50,minmax(0,1fr));gap:2px}.alg-head div{text-align:center;font-size:8px;color:var(--muted);overflow:hidden}.cell{aspect-ratio:1/1;min-height:17px;border:1px solid rgba(0,0,0,.10);border-radius:3px;cursor:pointer;position:relative;display:flex;align-items:center;justify-content:center;font-size:8px;font-weight:800;overflow:hidden}.cell:hover,.cell.sel{outline:2px solid #172033;z-index:2}.cell.dim{opacity:.18}.sep{box-shadow:2px 0 0 #7f8b9e}
.grid2{display:grid;grid-template-columns:minmax(0,1fr) 390px;gap:16px;align-items:start}.detail{padding:16px;position:sticky;top:12px;max-height:calc(100vh - 24px);overflow:auto}.detail h2{margin:0 0 4px}.muted{color:var(--muted)}
.sec{border-top:1px solid var(--border);margin-top:12px;padding-top:12px}.sec h3{margin:0 0 8px;font-size:.9rem}.kvgrid{display:grid;grid-template-columns:1fr 1fr;gap:8px 12px}.kv .k{font-size:.7rem;color:var(--muted)}.kv .v{font-size:.86rem;font-weight:700;overflow-wrap:anywhere}
.codebox{border:1px solid var(--border);border-radius:10px;overflow:hidden;margin-top:8px}.codehead{display:flex;justify-content:space-between;align-items:center;padding:7px 9px;background:#f4f6f9;font-size:.76rem;font-weight:700}.codebox pre{margin:0;padding:10px;max-height:280px;overflow:auto;background:#101828;color:#f2f4f7;font-size:.76rem;line-height:1.45;white-space:pre}
.tablewrap{overflow:auto}.rank{width:100%;border-collapse:collapse;font-size:.84rem}.rank th,.rank td{padding:8px 9px;border-bottom:1px solid var(--border);text-align:left}.rank th{color:var(--muted);font-size:.72rem;text-transform:uppercase;letter-spacing:.04em}.rank td.num{text-align:right;font-variant-numeric:tabular-nums}
.bar{height:9px;background:#e9eef5;border-radius:999px;overflow:hidden;min-width:90px}.bar>i{display:block;height:100%;background:#667085;border-radius:999px}
.badge{display:inline-block;border:1px solid var(--border);border-radius:999px;padding:3px 7px;font-size:.7rem;background:#fff}.warn{background:#fff7e6}.ok{background:#ecfdf3}.fail{background:#fff1f0}
@media(max-width:1050px){.grid2{grid-template-columns:1fr}.detail{position:static;max-height:none}.page{padding:14px}.cell{min-height:13px;font-size:0}.alg-head div{font-size:0}.alg-head div:nth-child(5n){font-size:7px}.kvgrid{grid-template-columns:1fr}}
"""


def _batch_html(data: dict[str, Any]) -> str:
    data_json = _safe_json_for_script(data)
    title = html.escape(f"NL-FDEP — {data['dataset']} Batch Dashboard")
    return f'''<!doctype html><html lang="en-GB"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{title}</title><style>{_COMMON_CSS}</style></head>
<body><div class="page"><h1>{title}</h1><p class="sub">Automatically generated from the completed NL-FDEP batch artefacts. Dashboard presentation does not participate in scoring.</p>
<div id="cards" class="cards"></div><div class="toolbar panel"><strong>Algorithm view</strong><select id="filter"><option value="all">All algorithms</option><option value="at">At reference</option><option value="below">Below reference</option><option value="ne">Not evaluable</option><option value="fail">Pipeline failures</option><option value="boundary">Boundary probes evaluable</option></select><select id="labels"><option value="score">Cell text: score</option><option value="id">Cell text: algorithm</option><option value="none">Cell text: none</option></select><button id="clear">Clear selection</button></div>
<div class="grid2"><div><div class="panel heat-wrap"><div style="display:flex;justify-content:space-between;gap:12px;align-items:end;flex-wrap:wrap"><div><strong id="heatTitle">50-algorithm behavioural heat map</strong><div class="muted" style="font-size:.8rem;margin-top:3px">All 50 algorithms remain visible. White = not evaluable / no behavioural score.</div></div></div><div class="alg-head" id="head"></div><div class="heat-row" id="heat"></div><div class="legend"><strong>Behavioural score:</strong><span><i class="sw" style="background:#2f6db3"></i>0</span><span><i class="sw" style="background:#6ec5ff"></i>25</span><span><i class="sw" style="background:#ffc145"></i>50</span><span><i class="sw" style="background:#9be564"></i>75</span><span><i class="sw" style="background:#2ca25f"></i>100</span><span><i class="sw" style="background:#fff"></i>Not evaluable</span></div></div>
<div class="panel" style="margin-top:16px;padding:14px"><h2 style="margin-top:0;font-size:1.05rem">Algorithm table</h2><div class="tablewrap"><table class="rank"><thead><tr><th>Alg.</th><th>Behavioural</th><th>Reference</th><th>Pipeline</th><th>SBV</th><th>Automated rubric</th><th>Combined rubric</th></tr></thead><tbody id="tbody"></tbody></table></div></div></div>
<div class="panel detail" id="detail"><h2>Algorithm inspection</h2><p class="muted">Select a heat-map cell or table row.</p></div></div></div>
<script>const DATA={data_json};
const A=DATA.algorithms;let selected=null;const $=s=>document.querySelector(s);const esc=v=>String(v??'').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;').replaceAll("'",'&#039;');
const pct=v=>v==null||Number.isNaN(+v)?'—':(+v).toFixed(2)+'%';const pretty=v=>v==null||v===''?'—':String(v).replaceAll('_',' ');
function colour(v){{if(v==null)return '#fff';const stops=[[0,[47,109,179]],[25,[110,197,255]],[50,[255,193,69]],[75,[155,229,100]],[100,[44,162,95]]];v=Math.max(0,Math.min(100,+v));for(let i=1;i<stops.length;i++){{if(v<=stops[i][0]){{const [x0,c0]=stops[i-1],[x1,c1]=stops[i],t=(v-x0)/(x1-x0);const c=c0.map((q,j)=>Math.round(q+(c1[j]-q)*t));return `rgb(${{c[0]}},${{c[1]}},${{c[2]}})`;}}}}return '#2ca25f';}}
function card(k,v){{return `<div class="panel card"><div class="k">${{esc(k)}}</div><div class="v">${{esc(v)}}</div></div>`;}}
function renderCards(){{const r=DATA.report,isB=DATA.isBaseline;const parts=[card('Dataset',DATA.dataset),card('Algorithms',r.algorithmCount??50)];if(isB)parts.push(card('Mean baseline calibration',pct(r.meanBaselineCalibration)));else{{parts.push(card('Mean semantic behavioural',pct(r.meanBehavioural)),card('Common Test accuracy',pct(r.commonTestAccuracy)),card('Combined Behavioural Measure',pct(r.combinedBehavioural)),card('Semantic Boundary Variance',pct(r.boundaryVariance)));}}if(r.meanCombinedRubric!=null)parts.push(card('Mean Combined Rubric',pct(r.meanCombinedRubric)));$('#cards').innerHTML=parts.join('');$('#heatTitle').textContent=isB?'50-algorithm baseline calibration heat map':'50-algorithm behavioural heat map';}}
function match(r,m){{if(m==='all')return true;if(m==='at')return r.comparison==='AT_REFERENCE';if(m==='below')return r.comparison==='BELOW_REFERENCE';if(m==='ne')return r.score==null;if(m==='fail')return r.pipelineStatus==='FAILURE';if(m==='boundary')return +(r.boundaryEvaluable||0)>0;return true;}}
function renderHeat(){{const mode=$('#filter').value,lm=$('#labels').value;$('#head').innerHTML=A.map(r=>`<div>${{r.algorithm}}</div>`).join('');$('#heat').innerHTML=A.map(r=>{{const lab=lm==='score'?(r.score==null?'':Math.round(r.score)):lm==='id'?r.algorithm:'';const text=r.score!=null&&r.score<42?'#fff':'#172033';return `<div class="cell ${{r.algorithm%5===0?'sep ':''}}${{selected===r.algorithm?'sel ':''}}${{match(r,mode)?'':'dim'}}" data-id="${{r.algorithm}}" title="Algorithm ${{r.algorithm}} — ${{pct(r.score)}}" style="background:${{colour(r.score)}};color:${{text}}">${{lab}}</div>`;}}).join('');document.querySelectorAll('.cell').forEach(x=>x.onclick=()=>selectAlg(+x.dataset.id));}}
function renderTable(){{const mode=$('#filter').value;$('#tbody').innerHTML=A.map(r=>`<tr data-id="${{r.algorithm}}" style="${{match(r,mode)?'':'opacity:.25'}};cursor:pointer"><td>${{r.algorithm}}</td><td class="num">${{pct(r.score)}}</td><td>${{pretty(r.comparison)}}</td><td>${{pretty(r.pipelineStatus)}}</td><td class="num">${{pct(r.boundaryVariance)}}</td><td class="num">${{pct(r.automatedRubric)}}</td><td class="num">${{r.combinedRubricAvailable?pct(r.combinedRubric):'—'}}</td></tr>`).join('');document.querySelectorAll('#tbody tr').forEach(x=>x.onclick=()=>selectAlg(+x.dataset.id));}}
function kv(k,v){{return `<div class="kv"><div class="k">${{esc(k)}}</div><div class="v">${{esc(v??'—')}}</div></div>`;}}
window.copyCode=async function(btn){{const code=btn.closest('.codebox').querySelector('code').innerText,old=btn.textContent;const done=t=>{{btn.textContent=t;setTimeout(()=>btn.textContent=old,1300)}};if(navigator.clipboard&&navigator.clipboard.writeText){{try{{await navigator.clipboard.writeText(code);done('Copied');return}}catch(e){{}}}}try{{const t=document.createElement('textarea');t.value=code;t.style.position='fixed';t.style.opacity='.01';document.body.appendChild(t);t.focus();t.select();const ok=document.execCommand&&document.execCommand('copy');t.remove();if(ok){{done('Copied');return}}}}catch(e){{}}const el=btn.closest('.codebox').querySelector('code'),s=window.getSelection(),range=document.createRange();range.selectNodeContents(el);s.removeAllRanges();s.addRange(range);done('Selected — Ctrl+C');}};
function codebox(title,code,path){{if(!code)return `<div class="muted">No ${{esc(title.toLowerCase())}} artefact is available.</div>`;return `<div class="codebox"><div class="codehead"><span>${{esc(title)}}${{path?` <span class="muted">· ${{esc(path)}}</span>`:''}}</span><button onclick="copyCode(this)">Copy</button></div><pre><code>${{esc(code)}}</code></pre></div>`;}}
function selectAlg(id){{selected=id;const r=A.find(x=>x.algorithm===id);renderHeat();if(!r)return;$('#detail').innerHTML=`<h2>Algorithm ${{id}}</h2><p class="muted">${{esc(DATA.dataset)}} · ${{pretty(r.pipelineStatus)}}</p><div class="sec"><h3>Behavioural result</h3><div class="kvgrid">${{kv('Behavioural score',pct(r.score))}}${{kv('Reference comparison',pretty(r.comparison))}}${{kv('Semantic Boundary Variance',pct(r.boundaryVariance))}}${{kv('Boundary probes evaluable',r.boundaryEvaluable)}}${{kv('Out-of-domain accepted',r.boundaryAccepted)}}${{kv('Controlled rejection',r.boundaryControlled)}}${{kv('Incidental failure',r.boundaryIncidental)}}${{kv('Evidence adequacy',pretty(r.behaviouralEvidenceAdequacy))}}</div></div><div class="sec"><h3>Assessed pseudocode</h3>${{codebox('Pseudocode',r.pseudocode,null)}}</div><div class="sec"><h3>Generated Python</h3>${{codebox('Python produced by NL-FDEP',r.generatedPython,r.generatedPythonPath)}}</div><div class="sec"><h3>Transformation stages</h3><div class="kvgrid">${{kv('Canonicalisation',pct(r.canonicalisation))}}${{kv('AST',pct(r.ast))}}${{kv('Flow',pct(r.flow))}}${{kv('Python',pct(r.python))}}${{kv('Test accuracy',pct(r.testAccuracy))}}${{kv('Automated rubric',pct(r.automatedRubric))}}${{kv('Human rubric',pct(r.humanRubric))}}${{kv('Combined rubric',r.combinedRubricAvailable?pct(r.combinedRubric):'—')}}</div></div><div class="sec"><h3>Pipeline / semantic loss</h3><div class="kvgrid">${{kv('Failure taxonomy',pretty(r.failureTaxonomy))}}${{kv('First loss stage',pretty(r.firstSemanticLossStage))}}${{kv('First loss criterion',pretty(r.firstSemanticLossCriterion))}}${{kv('Batch error',r.batchError)}}</div></div><div class="sec"><h3>Complexity</h3><div class="kvgrid">${{kv('Cyclomatic complexity',r.cyclomaticComplexity)}}${{kv('Decisions',r.decisionCount)}}${{kv('Loops',r.loopCount)}}${{kv('Maximum loop nesting',r.maximumLoopNesting)}}</div></div><div class="sec"><h3>Behavioural evidence</h3><p style="font-size:.82rem;line-height:1.5">${{esc(r.g2Summary||'—')}}</p><p class="muted" style="font-size:.78rem"><strong>Strengths:</strong> ${{esc(r.g2Strengths||'—')}}</p><p class="muted" style="font-size:.78rem"><strong>Limitations:</strong> ${{esc(r.g2Limitations||'—')}}</p></div>`;}}
$('#filter').onchange=()=>{{renderHeat();renderTable()}};$('#labels').onchange=renderHeat;$('#clear').onclick=()=>{{selected=null;renderHeat();$('#detail').innerHTML='<h2>Algorithm inspection</h2><p class="muted">Select a heat-map cell or table row.</p>'}};renderCards();renderHeat();renderTable();
</script></body></html>'''


def generate_batch_dashboard(batch_root: Path, analysis_directory: Path | None = None) -> dict[str, Any]:
    batch_root = Path(batch_root)
    analysis_directory = Path(analysis_directory) if analysis_directory else batch_root / "study_analysis"
    dashboard_dir = analysis_directory / "dashboards"
    dashboard_dir.mkdir(parents=True, exist_ok=True)
    data = _batch_dashboard_data(batch_root, analysis_directory)
    out = dashboard_dir / "NL_FDEP_batch_dashboard.html"
    out.write_text(_batch_html(data), encoding="utf-8")
    return {
        "status": "GENERATED",
        "dashboard_schema_version": DASHBOARD_SCHEMA_VERSION,
        "dataset": data.get("dataset"),
        "batch_dashboard": str(out.resolve()),
    }


def _discover_completed_llm_batches(study_root: Path) -> list[tuple[Path, Path, dict[str, Any], dict[int, dict[str, Any]]]]:
    found = []
    if not study_root.is_dir():
        return found
    for child in sorted(study_root.iterdir(), key=lambda p: p.name.casefold()):
        if not child.is_dir() or child.name.casefold() == "baseline":
            continue
        results = _results_child(child)
        if results is None:
            continue
        analysis = results / "study_analysis"
        report = _read_json(analysis / "batch_report.json")
        if not isinstance(report, dict) or str(report.get("batch_type") or "").upper() != "LLM_RESULTS":
            continue
        found.append((results, analysis, report, _row_map(analysis)))
    return found


def _study_dashboard_data(study_root: Path) -> dict[str, Any]:
    batches = _discover_completed_llm_batches(study_root)
    agents = []
    records = []
    for results, analysis, report, rows in batches:
        dataset = str(report.get("dataset") or results.parent.name)
        combined = _combined_behavioural(report)
        agents.append({
            "dataset": dataset,
            "meanBehavioural": _number(report.get("mean_experimental_behavioural_percentage")),
            "commonTestAccuracy": _number(report.get("semantic_test_accuracy_percentage")),
            "combinedBehavioural": combined,
            "boundaryVariance": _number(report.get("semantic_boundary_variance_percentage")),
            "meanAutomatedRubric": _mean([r.get("AutomatedRubricPercent") for r in rows.values()]),
            "meanHumanRubric": _mean([r.get("HumanRubricPercent") for r in rows.values()]),
            "meanCombinedRubric": _mean([r.get("CombinedRubricPercent") for r in rows.values() if r.get("CombinedRubricAvailable")]),
            "pipelineStatusCounts": report.get("pipeline_status_counts") or report.get("status_counts") or {},
            "comparisonCounts": report.get("comparison_to_baseline_counts") or {},
            "semanticTestsEvaluable": report.get("semantic_tests_evaluable"),
            "semanticTestsPassed": report.get("semantic_tests_passed"),
        })
        batch_records = _batch_records(report)
        for aid in range(1, 51):
            row = rows.get(aid, {})
            rec = batch_records.get(aid, {})
            records.append({
                "dataset": dataset,
                "algorithm": aid,
                "score": _number(row.get("ExperimentalBehaviouralPercent") if row else rec.get("experimental_behavioural_percentage")),
                "comparison": row.get("ComparisonToBaseline") if row else rec.get("comparison_to_baseline"),
                "pipelineStatus": row.get("PipelineStatus") if row else rec.get("status"),
                "boundaryVariance": _number(row.get("SemanticBoundaryVariancePercent") if row else rec.get("semantic_boundary_variance_percentage")),
                "automatedRubric": _number(row.get("AutomatedRubricPercent")),
                "humanRubric": _number(row.get("HumanRubricPercent")),
                "combinedRubric": _number(row.get("CombinedRubricPercent")),
                "combinedRubricAvailable": bool(row.get("CombinedRubricAvailable")),
            })
    agents.sort(key=lambda x: (-(x.get("combinedBehavioural") if x.get("combinedBehavioural") is not None else -1), x["dataset"].casefold()))
    order = [a["dataset"] for a in agents]
    return {
        "schemaVersion": DASHBOARD_SCHEMA_VERSION,
        "generatedAtUtc": datetime.now(timezone.utc).isoformat(),
        "studyRoot": str(study_root.resolve()),
        "agents": agents,
        "agentOrder": order,
        "records": records,
    }


def _study_html(data: dict[str, Any]) -> str:
    j = _safe_json_for_script(data)
    return f'''<!doctype html><html lang="en-GB"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>NL-FDEP Comparative Study Dashboard</title><style>{_COMMON_CSS}.studyrow{{display:grid;grid-template-columns:230px minmax(0,1fr);gap:10px;align-items:center;margin:4px 0}}.agentname{{font-size:.8rem;font-weight:750;overflow-wrap:anywhere}}@media(max-width:800px){{.studyrow{{grid-template-columns:130px minmax(0,1fr)}}}}</style></head><body><div class="page"><h1>NL-FDEP Comparative Study Dashboard</h1><p class="sub">Automatically regenerated after an experimental batch completes. Baseline results are not included as an experimental agent row.</p><div id="cards" class="cards"></div>
<div class="panel heat-wrap"><h2 style="margin:0 0 4px;font-size:1.05rem">Comparative 50-algorithm behavioural heat map</h2><p class="muted" style="font-size:.8rem;margin-top:0">All 50 algorithms remain visible for every completed agent. White = not evaluable / no behavioural score.</p><div id="heatRows"></div><div class="legend"><strong>Behavioural score:</strong><span><i class="sw" style="background:#2f6db3"></i>0</span><span><i class="sw" style="background:#6ec5ff"></i>25</span><span><i class="sw" style="background:#ffc145"></i>50</span><span><i class="sw" style="background:#9be564"></i>75</span><span><i class="sw" style="background:#2ca25f"></i>100</span><span><i class="sw" style="background:#fff"></i>Not evaluable</span></div></div>
<div class="panel" style="margin-top:16px;padding:14px"><h2 style="margin-top:0;font-size:1.05rem">Behavioural ranking</h2><div class="tablewrap"><table class="rank"><thead><tr><th>Rank</th><th>AI agent</th><th>Mean semantic behavioural</th><th>Common Test accuracy</th><th>Combined Behavioural Measure</th><th>Semantic Boundary Variance</th><th>Mean Combined Rubric</th></tr></thead><tbody id="rank"></tbody></table></div></div>
</div><script>const DATA={j};const $=s=>document.querySelector(s);const esc=v=>String(v??'').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;').replaceAll("'",'&#039;');const pct=v=>v==null||Number.isNaN(+v)?'—':(+v).toFixed(2)+'%';
function colour(v){{if(v==null)return '#fff';const s=[[0,[47,109,179]],[25,[110,197,255]],[50,[255,193,69]],[75,[155,229,100]],[100,[44,162,95]]];v=Math.max(0,Math.min(100,+v));for(let i=1;i<s.length;i++)if(v<=s[i][0]){{const [x0,c0]=s[i-1],[x1,c1]=s[i],t=(v-x0)/(x1-x0),c=c0.map((q,j)=>Math.round(q+(c1[j]-q)*t));return `rgb(${{c[0]}},${{c[1]}},${{c[2]}})`}}return '#2ca25f'}}
const total=DATA.agents.length*50,evals=DATA.records.filter(r=>r.score!=null).length,at=DATA.records.filter(r=>r.comparison==='AT_REFERENCE').length,below=DATA.records.filter(r=>r.comparison==='BELOW_REFERENCE').length;$('#cards').innerHTML=`<div class="panel card"><div class="k">Completed agents</div><div class="v">${{DATA.agents.length}}</div></div><div class="panel card"><div class="k">Algorithm instances</div><div class="v">${{total}}</div></div><div class="panel card"><div class="k">Behaviourally evaluable</div><div class="v">${{evals}}</div></div><div class="panel card"><div class="k">At reference</div><div class="v">${{at}}</div></div><div class="panel card"><div class="k">Below reference</div><div class="v">${{below}}</div></div>`;
const grouped=new Map(DATA.agentOrder.map(n=>[n,DATA.records.filter(r=>r.dataset===n)]));$('#heatRows').innerHTML=DATA.agentOrder.map(name=>`<div class="studyrow"><div class="agentname">${{esc(name)}}</div><div class="heat-row">${{grouped.get(name).map(r=>`<div class="cell ${{r.algorithm%5===0?'sep':''}}" title="${{esc(name)}} · Algorithm ${{r.algorithm}} · ${{pct(r.score)}}" style="background:${{colour(r.score)}}"></div>`).join('')}}</div></div>`).join('');
$('#rank').innerHTML=DATA.agents.map((a,i)=>`<tr><td>${{i+1}}</td><td><strong>${{esc(a.dataset)}}</strong></td><td class="num">${{pct(a.meanBehavioural)}}</td><td class="num">${{pct(a.commonTestAccuracy)}}</td><td class="num"><strong>${{pct(a.combinedBehavioural)}}</strong></td><td class="num">${{pct(a.boundaryVariance)}}</td><td class="num">${{pct(a.meanCombinedRubric)}}</td></tr>`).join('');</script></body></html>'''


def generate_study_dashboard(study_root: Path, output_directory: Path | None = None) -> dict[str, Any]:
    study_root = Path(study_root)
    data = _study_dashboard_data(study_root)
    output_directory = Path(output_directory) if output_directory else study_root / "analysis" / "dashboards"
    output_directory.mkdir(parents=True, exist_ok=True)
    out = output_directory / "NL_FDEP_comparative_dashboard.html"
    out.write_text(_study_html(data), encoding="utf-8")
    return {
        "status": "GENERATED",
        "dashboard_schema_version": DASHBOARD_SCHEMA_VERSION,
        "completed_agent_count": len(data.get("agents") or []),
        "comparative_dashboard": str(out.resolve()),
    }


def infer_study_root(batch_root: Path, batch_type: str | None) -> Path | None:
    batch_root = Path(batch_root)
    if str(batch_type or "").upper() == "LLM_RESULTS":
        if batch_root.name.casefold() == "results":
            return batch_root.parent.parent
        return batch_root.parent
    if str(batch_type or "").upper() == "BASELINE":
        # Baseline dashboard generation is called with Baseline/pseudocode so
        # the algorithm folders can be inspected directly.
        if batch_root.name.casefold() == "pseudocode" and batch_root.parent.name.casefold() == "baseline":
            return batch_root.parent.parent
        return batch_root.parent
    return None


def generate_dashboards_for_completed_batch(batch_root: Path, analysis_directory: Path | None = None, batch_type: str | None = None) -> dict[str, Any]:
    """Best-effort dashboard generation after batch evidence is finalised.

    Dashboard failure is deliberately non-fatal: scoring artefacts are already
    complete and remain authoritative. A status file records any presentation
    layer failure for the operator.
    """
    batch_root = Path(batch_root)
    analysis_directory = Path(analysis_directory) if analysis_directory else batch_root / "study_analysis"
    status_path = analysis_directory / "dashboard_generation.json"
    payload: dict[str, Any] = {
        "dashboard_schema_version": DASHBOARD_SCHEMA_VERSION,
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "batch_type": batch_type,
        "status": "FAILED",
        "batch_dashboard": None,
        "comparative_dashboard": None,
        "comparative_completed_agent_count": None,
        "error": None,
    }
    try:
        batch = generate_batch_dashboard(batch_root, analysis_directory)
        payload["batch_dashboard"] = batch.get("batch_dashboard")
        study_root = infer_study_root(batch_root, batch_type)
        if study_root is not None and study_root.is_dir():
            study = generate_study_dashboard(study_root)
            payload["comparative_dashboard"] = study.get("comparative_dashboard")
            payload["comparative_completed_agent_count"] = study.get("completed_agent_count")
        payload["status"] = "GENERATED"
    except Exception as exc:  # Presentation-layer failure must not invalidate the study batch.
        payload["error"] = f"{type(exc).__name__}: {exc}"
    analysis_directory.mkdir(parents=True, exist_ok=True)
    status_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    payload["status_file"] = str(status_path.resolve())
    return payload
