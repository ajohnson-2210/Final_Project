from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from dashboard_generation import generate_dashboards_for_completed_batch
from pseudocode_profiles import PseudocodeProfile
from study_batch import StudyBatchProcessor


SAMPLE = """\
BEGIN
    INPUT String1, String2
    IF LENGTH(String1) != LENGTH(String2) THEN
        OUTPUT "Not Anagrams"
    ELSE
        SORT characters of String1
        SORT characters of String2
        IF String1 = String2 THEN
            OUTPUT "Anagrams"
        ELSE
            OUTPUT "Not Anagrams"
        ENDIF
    ENDIF
END
"""


class AutomaticDashboardRC9Tests(unittest.TestCase):
    def test_completed_llm_batch_automatically_generates_batch_and_comparative_dashboards(self):
        with tempfile.TemporaryDirectory() as td:
            study = Path(td)
            results = study / "Agent A" / "Results"
            folder = results / "Algorithm - 1"
            folder.mkdir(parents=True)
            (folder / "Algorithm 1 Pseudocode.txt").write_text(SAMPLE, encoding="utf-8")

            result = StudyBatchProcessor().process_llm_results(
                results,
                profile=PseudocodeProfile.GENERIC_COMPATIBILITY,
            )

            dashboards = result["dashboards"]
            self.assertEqual("GENERATED", dashboards["status"])
            self.assertEqual(1, dashboards["comparative_completed_agent_count"])
            batch_path = Path(dashboards["batch_dashboard"])
            comparative_path = Path(dashboards["comparative_dashboard"])
            self.assertTrue(batch_path.is_file())
            self.assertTrue(comparative_path.is_file())
            self.assertTrue((results / "study_analysis" / "dashboard_generation.json").is_file())

            batch_html = batch_path.read_text(encoding="utf-8")
            self.assertIn("Combined Behavioural Measure", batch_html)
            self.assertIn("Semantic Boundary Variance", batch_html)
            self.assertIn("window.copyCode", batch_html)
            self.assertIn("All 50 algorithms remain visible", batch_html)

            history = Path(result["history_directory"])
            self.assertTrue((history / "dashboard_generation.json").is_file())
            self.assertTrue((history / "dashboards" / "NL_FDEP_batch_dashboard.html").is_file())

    def test_dashboard_failure_is_non_fatal_and_is_recorded(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td) / "Agent A" / "Results"
            analysis = root / "study_analysis"
            analysis.mkdir(parents=True)
            (analysis / "batch_report.json").write_text(
                json.dumps({"batch_type": "LLM_RESULTS", "dataset": "Agent A", "algorithms": []}),
                encoding="utf-8",
            )
            with patch("dashboard_generation.generate_batch_dashboard", side_effect=RuntimeError("dashboard boom")):
                status = generate_dashboards_for_completed_batch(root, analysis, "LLM_RESULTS")
            self.assertEqual("FAILED", status["status"])
            self.assertIn("dashboard boom", status["error"])
            recorded = json.loads((analysis / "dashboard_generation.json").read_text(encoding="utf-8"))
            self.assertEqual("FAILED", recorded["status"])

    def test_comparative_dashboard_discovers_case_insensitive_results_siblings(self):
        with tempfile.TemporaryDirectory() as td:
            study = Path(td)
            for name, folder_name, mean_b, acc in (
                ("Agent A", "Results", 80.0, 90.0),
                ("Agent B", "results", 70.0, 80.0),
            ):
                analysis = study / name / folder_name / "study_analysis"
                analysis.mkdir(parents=True)
                (analysis / "batch_report.json").write_text(json.dumps({
                    "batch_type": "LLM_RESULTS",
                    "dataset": name,
                    "algorithm_count": 50,
                    "mean_experimental_behavioural_percentage": mean_b,
                    "semantic_test_accuracy_percentage": acc,
                    "algorithms": [],
                }), encoding="utf-8")
                (analysis / "algorithm_scores.json").write_text("[]", encoding="utf-8")

            root = study / "Agent B" / "results"
            status = generate_dashboards_for_completed_batch(root, root / "study_analysis", "LLM_RESULTS")
            self.assertEqual(2, status["comparative_completed_agent_count"])
            text = Path(status["comparative_dashboard"]).read_text(encoding="utf-8")
            self.assertIn("Agent A", text)
            self.assertIn("Agent B", text)
            # Combined behavioural measures are 85.00 and 75.00, so A ranks first.
            self.assertLess(text.find('Agent A'), text.find('Agent B'))


if __name__ == "__main__":
    unittest.main()
