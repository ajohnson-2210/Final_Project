# v2.56 — ChatGPT Algorithm 8 bubble-sort semantic-integrity audit

## Decision

ChatGPT Algorithm 8 is **PASS AFTER REPRESENTATIONAL CORRECTION**.

The source explicitly supplies a bubble-sort procedure over `WordList`. No sorting algorithm is reconstructed or replaced.

## Corrections

1. **Inclusive source bounds preserved in end-exclusive AJ ranges**
   - Source outer bound: `0 TO LENGTH(WordList)-2`
   - Canonical AJ: `0 TO (LENGTH OF WordList - 2) + 1`
   - Python: `range(0, len(WordList) - 1)`
   - Source inner bound: `0 TO LENGTH(WordList)-2-i`
   - Canonical AJ: `0 TO (LENGTH OF WordList - 2 - i) + 1`
   - Python: `range(0, len(WordList) - 1 - i)`

2. **SWAP preserved as a source-level primitive**
   - Source: `SWAP WordList[j], WordList[j+1]`
   - Canonical AJ: `CALL swap(WordList, j, j + 1)`
   - Python compiler lowering introduces the temporary only at implementation time:
     - `temp = WordList[j]`
     - `WordList[j] = WordList[j + 1]`
     - `WordList[j + 1] = temp`

3. The generic `SWAP(a, b)` shorthand normaliser no longer rewrites an already explicit `CALL swap(...)`.

## Canonical AJ

```text
FUNCTION unnamed_function ACCEPTS(WordList)
    FOR i <- IN RANGE 0 TO (LENGTH OF WordList - 2) + 1 DO
        FOR j <- IN RANGE 0 TO (LENGTH OF WordList - 2 - i) + 1 DO
            IF WordList[j] > WordList[j + 1] THEN
                CALL swap(WordList, j, j + 1)
            ENDIF
        ENDFOR
    ENDFOR

    OUTPUT WordList
ENDFUNCTION
```

## Python target

```python
def unnamed_function(WordList):
    for i in range(0, len(WordList) - 1):
        for j in range(0, len(WordList) - 1 - i):
            if WordList[j] > WordList[j + 1]:
                temp = WordList[j]
                WordList[j] = WordList[j + 1]
                WordList[j + 1] = temp

    print(WordList)
```

## Classification

- algorithmic_intent: EXPLICIT
- procedural_completeness: COMPLETE
- range_semantics_correction: REQUIRED
- explicit_abstract_primitive: SWAP
- algorithmic_reconstruction: NO
- semantic_core_preserved: YES

## Validation

- Regression suite: 206 passed, 0 failed, 3 pre-existing collection warnings
- Corpus: 182 / 300 (60.7%)
- ChatGPT: 38 / 50
- Parse-classification change: 0
