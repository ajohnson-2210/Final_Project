# v2.55 — ChatGPT Algorithm 7 explicit-space split semantic-integrity audit

## Decision

**PASS AFTER REPRESENTATIONAL CORRECTION**

The source explicitly states `SPLIT Sentence BY spaces`. Python's parameterless `.split()` is broader than that instruction because it treats arbitrary whitespace as separators. GC106 therefore preserves the literal separator semantics through a dedicated canonical helper:

```text
Words <- CALL split_on_space(Sentence)
```

which compiles to:

```python
Words = str(Sentence).split(" ")
```

## Semantic boundary

This is a representational correction, not an algorithmic reconstruction. The canonicaliser does not invent tokenisation rules beyond the source-provided space delimiter. The older `split_words(...) -> str(x).split()` helper remains available for sources that actually request generic word/whitespace splitting.

## Validation

- Regression suite: **205 passed**, **0 failed**, 3 pre-existing warnings
- Corpus: **182/300 (60.7%)**
- ChatGPT: **38/50**
- Parse-classification delta from v2.54: **0**

AJ_24038155 Dialect v1.0 is unchanged.
