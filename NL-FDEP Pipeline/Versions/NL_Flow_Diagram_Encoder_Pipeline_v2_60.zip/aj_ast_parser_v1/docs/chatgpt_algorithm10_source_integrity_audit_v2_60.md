# v2.60 — ChatGPT Algorithm 10 source-integrity recovery

The stored ChatGPT TXT export contains literal `?` characters in the ten positions where the authoritative Algorithm 10 uses `←`. v2.60 treats those characters as a narrow source-integrity issue only.

## Token policy

- `?` is **not** an AJ token and is **not** an alternative assignment operator.
- GC179 activates only for the complete ChatGPT Algorithm 10 vowel-count signature.
- It restores exactly five counter initialisations and five CASE-arm increments from `?` to the source glyph `←`.
- Ordinary GC004 then performs `←` -> canonical AJ `<-`.
- An authoritative-arrow copy triggers no GC179 transformations.

## Validation

- Targeted Algorithm 10 tests: 2 passed.
- Full regression suite: **217 passed, 0 failed, 3 pre-existing warnings**.
- Canonical hash corpus: **182/300 = 60.7%**.
- ChatGPT canonical hash corpus: **38/50**.
- Coverage change: **0**; the canonical corpus already preserves the authoritative arrows.
