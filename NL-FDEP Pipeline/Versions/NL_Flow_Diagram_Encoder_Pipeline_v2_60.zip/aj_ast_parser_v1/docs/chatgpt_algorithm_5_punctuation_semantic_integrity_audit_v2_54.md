# v2.54 — ChatGPT Algorithm 5 punctuation semantic-integrity audit

## Decision

**EXPECTED_FAIL / INSUFFICIENT_PREDICATE_SEMANTICS**

The source supplies the filtering loop but does not define what counts as punctuation. The compatibility layer therefore preserves `Character is NOT punctuation` unresolved instead of renaming the missing semantics as `CALL is_punctuation(Character)`.

## Guard scope

The guard is deliberately narrow to the ChatGPT Algorithm 5 source form and runs before GC104 and neutral-wrapper recovery. GC104 is not globally retired because other models' punctuation cases still require manual semantic-integrity review.

## Forbidden inventions

- `is_punctuation(...)` helper semantics
- `string.punctuation`
- regex-based punctuation rules
- Unicode-category punctuation rules

## Validation

- Regression suite: **203 passed**, **0 failed**, 3 pre-existing warnings
- Corpus: **182/300 (60.7%)**
- ChatGPT: **38/50**
- Delta from v2.53: **-1**, exactly Algorithm 5; other model counts unchanged

AJ_24038155 Dialect v1.0 is unchanged.
