# v2.58 — ChatGPT Algorithm 9 range semantic-integrity audit

## Decision

Algorithm 9 is a complete explicit first-match linear search. The canonicaliser must preserve that procedure and must not reconstruct a different search algorithm.

The authoritative source uses the inclusive loop bound:

```text
FOR i ← 0 TO LENGTH(List)-1
```

AJ_24038155 Dialect v1.0 RANGE endpoints are end-exclusive. Therefore canonical AJ records the endpoint-preservation adjustment explicitly:

```text
FOR i <- IN RANGE 0 TO (LENGTH OF __reserved_keyword__List - 1) + 1 DO
```

The Python compiler may simplify only the canonicaliser-introduced length-derived `+ 1`, yielding:

```python
for i in range(0, len(__reserved_keyword__List)):
```

`EXIT FOR` is represented as `BREAK`. The existing comma-separated OUTPUT representation is intentionally unchanged in this version and remains a separate audit topic.

## Canonical assignment-token invariant

The authoritative source's `←` is directly normalised to AJ `<-`. The stored ChatGPT TXT export is known to be lossy and may contain `?` at those positions. GC175 accepts `?` only inside this narrow legacy source-recovery signature so the stored research corpus remains reproducible. It never emits `?`; strict AJ still rejects bare `?`, and `?` is not an alternative assignment token.

## Canonical AJ

```text
FUNCTION unnamed_function ACCEPTS(__reserved_keyword__List, Target)
    Found <- BOOLEAN(False)

    FOR i <- IN RANGE 0 TO (LENGTH OF __reserved_keyword__List - 1) + 1 DO
        IF __reserved_keyword__List[i] == Target THEN
            OUTPUT TUPLE(STRING("Found at position"), i)
            Found <- BOOLEAN(True)
            BREAK
        ENDIF
    ENDFOR

    IF Found == BOOLEAN(False) THEN
        OUTPUT STRING("Target not found")
    ENDIF
ENDFUNCTION
```

## Validation

- Regression suite: 210 passed, 0 failed, 3 pre-existing warnings.
- Canonical 300-item hash corpus: 182/300 parsed (60.7%).
- ChatGPT: 38/50 parsed.
- Coverage change: none.
- Execution regression confirms a target located at the final list index is found.
