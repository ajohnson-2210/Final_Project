# v2.53 — Algorithm 3 and direct INPUT-to-wrapper audit hygiene

## Decision

ChatGPT Algorithm 3 remains a semantic **PASS**. Its leap-year decision structure is explicit and requires no algorithmic reconstruction.

The retrospective correction is audit hygiene: when a top-level unnamed algorithm is represented as `FUNCTION unnamed_function ACCEPTS(...)`, bare source `INPUT` declarations now bind directly to the wrapper parameters. The pipeline no longer creates an intermediate `INPUT(STRING(...))` form that is immediately discarded.

## Generic rule

`GC173 — DIRECT_INPUT_TO_NEUTRAL_WRAPPER`

- Applies to unnamed top-level programs with bare `INPUT` declarations and observable `OUTPUT` or `RETURN`.
- Does not apply when the source already declares a `FUNCTION` or `PROCEDURE`.
- Approved expected-fail guards run earlier and remain unresolved.
- Does not invent a semantic wrapper name; the generated name is always `unnamed_function`.

## Corpus-wide scan

Before v2.53, 77 corpus entries exhibited the exact transient pattern:

`INPUT x -> x <- INPUT(STRING(...)) -> FUNCTION unnamed_function ACCEPTS(x)`

- ChatGPT: 33
- Qwen 3.6 Plus: 44
- Claude Sonnet 4.6: 0
- DeepSeek: 0
- Gemini: 0
- Groq: 0

After v2.53, the remaining count is **0**.

GC173 applies to 79 corpus entries in total (35 ChatGPT, 44 Qwen). The two additional ChatGPT entries are Algorithms 13 and 25, which now follow the already-approved default wrapper policy rather than retaining an interactive-input representation.

No source-declared `FUNCTION` or `PROCEDURE` was wrapped or renamed by GC173.

## Validation

- Pytest: 201 passed, 0 failed, 3 pre-existing collection warnings.
- Corpus: 183/300 parsed (61.0%).
- ChatGPT: 39/50 parsed.
- Parse classification changes: 0.
