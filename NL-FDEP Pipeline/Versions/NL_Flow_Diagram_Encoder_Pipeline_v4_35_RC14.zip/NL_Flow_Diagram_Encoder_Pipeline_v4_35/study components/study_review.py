"""Integrated questionnaire-driven human-review session and Tk dashboard.

The dashboard is intentionally LLM-only. Baseline algorithms are calibration
artefacts and are excluded from human-review discovery.
"""
from __future__ import annotations

from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable
import json
import os
import webbrowser

from adjudication import adjudicate_files


_SCORE_LABELS = ("2", "1", "0", "NA")
_AGREEMENT_VALUES = ("AGREE", "PARTIALLY_AGREE", "DISAGREE")


REVIEW_STATE_SCHEMA_VERSION = "1.0"
REVIEW_STATE_PURPOSE = "HUMAN_REVIEW_PREVIOUS_STUDY_HINT"
REVIEW_STATE_FILE_ENV = "NL_FDEP_HUMAN_REVIEW_STATE_FILE"


def _review_state_path() -> Path:
    """Return the durable, non-scoring Human Review discovery-state path."""
    override = os.environ.get(REVIEW_STATE_FILE_ENV)
    if override:
        return Path(override).expanduser()

    local_app_data = os.environ.get("LOCALAPPDATA")
    if local_app_data:
        return Path(local_app_data) / "NL-FDEP" / "human_review_state.json"

    xdg_config_home = os.environ.get("XDG_CONFIG_HOME")
    if xdg_config_home:
        return Path(xdg_config_home) / "NL-FDEP" / "human_review_state.json"

    return Path.home() / ".config" / "NL-FDEP" / "human_review_state.json"


def _study_parent_for_review_root(value: Path) -> Path | None:
    """Return the parent directory whose children are experimental dataset folders."""
    normalised = normalise_review_root(Path(value))
    if normalised is None:
        return None
    outer = normalised.parent if normalised.name.casefold() == "results" else normalised
    return outer.parent.resolve()


def remember_review_study(value: Path) -> Path | None:
    """Persist a harmless cross-session pointer used only for Human Review discovery.

    The file stores no baseline path, calibration state, score or review answer. It
    merely remembers the study parent so a later Human Review session can rebuild
    the experimental dataset selector from artefacts already present on disk.
    """
    study_parent = _study_parent_for_review_root(Path(value))
    if study_parent is None:
        return None
    payload = {
        "schema_version": REVIEW_STATE_SCHEMA_VERSION,
        "state_purpose": REVIEW_STATE_PURPOSE,
        "study_parent": str(study_parent),
    }
    path = _review_state_path()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        temporary = path.with_name(path.name + ".tmp")
        temporary.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
        temporary.replace(path)
    except OSError:
        return None
    return study_parent


def previous_study_review_roots() -> list[Path]:
    """Rebuild the last Human Review study selector without asking for an anchor.

    Only reviewable experimental LLM datasets are returned. Baseline artefacts are
    filtered by :func:`review_status`, exactly as in ordinary sibling discovery.
    """
    path = _review_state_path()
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return []
    if not isinstance(payload, dict):
        return []
    if payload.get("state_purpose") != REVIEW_STATE_PURPOSE:
        return []
    raw_parent = payload.get("study_parent")
    if not isinstance(raw_parent, str) or not raw_parent.strip():
        return []
    study_parent = Path(raw_parent).expanduser()
    if not study_parent.is_dir():
        return []

    roots: list[Path] = []
    try:
        siblings = sorted(
            (child for child in study_parent.iterdir() if child.is_dir()),
            key=lambda child: child.name.casefold(),
        )
    except OSError:
        return []
    for sibling in siblings:
        candidate = normalise_review_root(sibling)
        if candidate is None or not review_status(candidate):
            continue
        roots.append(candidate.resolve())
    return roots


def _read_json(path: Path) -> dict[str, Any] | None:
    try:
        value = json.loads(Path(path).read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else None
    except Exception:
        return None


def _algorithm_id_from_folder(folder: Path) -> int | None:
    try:
        return int(Path(folder).name.split("-")[-1].strip())
    except Exception:
        return None


def _direct_algorithm_folders(parent: Path) -> list[Path]:
    rows: list[tuple[int, Path]] = []
    for child in Path(parent).glob("Algorithm - *"):
        if not child.is_dir():
            continue
        aid = _algorithm_id_from_folder(child)
        if aid is not None:
            rows.append((aid, child))
    return [folder for _, folder in sorted(rows, key=lambda item: item[0])]


def normalise_review_root(selected_path: Path) -> Path | None:
    """Resolve an LLM review selection to the directory containing Algorithm folders.

    Accepted experimental layouts are either ``root/Algorithm - n`` or
    ``root/Results/Algorithm - n``. Baseline ``Pseudocode`` folders are
    deliberately not accepted for human review.
    """
    selected = Path(selected_path)
    if not selected.is_dir():
        return None
    if _direct_algorithm_folders(selected):
        return selected
    results_children = [
        child for child in selected.iterdir()
        if child.is_dir() and child.name.casefold() == "results"
    ]
    if len(results_children) == 1 and _direct_algorithm_folders(results_children[0]):
        return results_children[0]
    return None


def _questionnaire_for_algorithm(folder: Path) -> Path:
    return folder / "pipeline_artifacts" / "scoring" / "human_review_questionnaire.json"


def _is_baseline_questionnaire(document: dict[str, Any]) -> bool:
    algorithm = document.get("algorithm", {}) or {}
    if bool(algorithm.get("is_baseline")):
        return True
    return str(algorithm.get("dataset") or "").strip().casefold() == "baseline"


def review_status(parent: Path) -> list[dict[str, Any]]:
    """Return numerically sorted review rows for one experimental dataset."""
    parent = Path(parent)
    rows: list[dict[str, Any]] = []
    for algorithm_folder in _direct_algorithm_folders(parent):
        aid = _algorithm_id_from_folder(algorithm_folder)
        scoring = algorithm_folder / "pipeline_artifacts" / "scoring"
        questionnaire = scoring / "human_review_questionnaire.json"
        if not questionnaire.is_file():
            continue
        document = _read_json(questionnaire) or {}
        if _is_baseline_questionnaire(document):
            continue
        rows.append({
            "algorithm_id": aid,
            "scoring_directory": str(scoring.resolve()),
            "questionnaire": True,
            "questionnaire_html": str((scoring / "human_review_questionnaire.html").resolve()) if (scoring / "human_review_questionnaire.html").is_file() else None,
            "reviewed": (scoring / "human_review.json").exists(),
            "final_score": (scoring / "final_score.json").exists(),
        })
    return sorted(rows, key=lambda row: (row.get("algorithm_id") is None, row.get("algorithm_id") or 10**9))


def _dataset_name(root: Path, rows: list[dict[str, Any]]) -> str:
    if rows:
        scoring = Path(rows[0]["scoring_directory"])
        q = _read_json(scoring / "human_review_questionnaire.json") or {}
        dataset = str((q.get("algorithm") or {}).get("dataset") or "").strip()
        if dataset and dataset.casefold() != "baseline":
            return dataset
    root = Path(root)
    return root.parent.name if root.name.casefold() == "results" else root.name


def discover_review_datasets(parents: Iterable[Path] | Path) -> list[dict[str, Any]]:
    """Build a de-duplicated experimental review registry from selected/session roots."""
    if isinstance(parents, (str, Path)):
        candidates = [Path(parents)]
    else:
        candidates = [Path(value) for value in parents]

    seen: set[str] = set()
    datasets: list[dict[str, Any]] = []
    for candidate in candidates:
        normalised = normalise_review_root(candidate)
        if normalised is None:
            continue
        key = str(normalised.resolve()).casefold()
        if key in seen:
            continue
        seen.add(key)
        rows = review_status(normalised)
        if not rows:
            continue
        datasets.append({
            "name": _dataset_name(normalised, rows),
            "root": str(normalised.resolve()),
            "rows": rows,
        })
    return datasets


def discover_sibling_review_roots(anchor: Path) -> list[Path]:
    """Reconstruct a review registry from sibling completed experimental datasets.

    ``anchor`` may be an outer LLM dataset folder or its ``Results`` directory.
    Only immediate sibling folders that contain reviewable experimental LLM
    questionnaires are returned. Baseline datasets are excluded by
    :func:`review_status`.
    """
    normalised = normalise_review_root(Path(anchor))
    if normalised is None:
        return []

    outer = normalised.parent if normalised.name.casefold() == "results" else normalised
    study_parent = outer.parent
    candidate_roots: list[Path] = []
    try:
        siblings = sorted(
            (child for child in study_parent.iterdir() if child.is_dir()),
            key=lambda child: child.name.casefold(),
        )
    except OSError:
        siblings = []

    for sibling in siblings:
        candidate = normalise_review_root(sibling)
        if candidate is None:
            continue
        if not review_status(candidate):
            continue
        candidate_roots.append(candidate.resolve())

    if not candidate_roots:
        return [normalised.resolve()] if review_status(normalised) else []

    # De-duplicate in case a filesystem layout exposes the same Results path twice.
    seen: set[str] = set()
    output: list[Path] = []
    for candidate in candidate_roots:
        key = str(candidate).casefold()
        if key in seen:
            continue
        seen.add(key)
        output.append(candidate)
    return output


class ReviewSession:
    """Load, resume and save one questionnaire-driven review."""

    def __init__(self, scoring_directory: Path):
        self.scoring_directory = Path(scoring_directory)
        q = self.scoring_directory / "human_review_questionnaire.json"
        if not q.is_file():
            raise FileNotFoundError(q)
        questionnaire = json.loads(q.read_text(encoding="utf-8"))
        if _is_baseline_questionnaire(questionnaire):
            raise ValueError("Baseline algorithms do not require human review.")
        saved = _read_json(self.scoring_directory / "human_review.json")
        self.document = saved if saved is not None else questionnaire
        self.questionnaire_html = self.scoring_directory / "human_review_questionnaire.html"

    def save(
        self,
        *,
        reviewer_id: str,
        confidence: str | None,
        source_review: dict[str, Any] | None = None,
        evidence_review: dict[str, Any] | None = None,
        semantic_review: dict[str, Any] | None = None,
        criteria: dict[str, dict[str, Any]],
        overall: dict[str, Any],
        gate_result: str | None = None,
        gate_agreement: str | None = None,
        gate_justification: str = "",
        baseline_reference_appropriate: str | None = None,
        baseline_reference_justification: str = "",
    ) -> Path:
        out = deepcopy(self.document)
        out["reviewer"] = {
            "reviewer_id": reviewer_id,
            "reviewed_at_utc": datetime.now(timezone.utc).isoformat(),
            "overall_reviewer_confidence": confidence,
        }

        source_review = source_review or {
            "human_result": gate_result,
            "agreement_with_automated_result": gate_agreement,
            "reviewer_justification": gate_justification,
        }
        evidence_review = evidence_review or {}

        ss = out.setdefault("source_sufficiency", {})
        ss["human_result"] = source_review.get("human_result")
        ss["agreement_with_automated_result"] = source_review.get("agreement_with_automated_result")
        ss["reviewer_justification"] = source_review.get("reviewer_justification", "")

        g2 = out.setdefault("behavioural_evidence_adequacy", {})
        g2["human_result"] = evidence_review.get("human_result")
        g2["agreement_with_automated_result"] = evidence_review.get("agreement_with_automated_result")
        g2["reviewer_justification"] = evidence_review.get("reviewer_justification", "")

        if out.get("task_semantic_evaluation") is not None and semantic_review is not None:
            human = out["task_semantic_evaluation"].setdefault("human_assessment", {})
            human.update({
                "required_inputs_represented": semantic_review.get("required_inputs_represented"),
                "core_algorithm_logic": semantic_review.get("core_algorithm_logic"),
                "required_output_semantics_represented": semantic_review.get("required_output_semantics_represented"),
                "edge_and_domain_handling": semantic_review.get("edge_and_domain_handling"),
                "overall_semantic_assessment": semantic_review.get("overall_semantic_assessment"),
                "reviewer_justification": semantic_review.get("reviewer_justification", ""),
            })

        for item in out.get("criteria", []):
            cid = item.get("criterion_id")
            values = criteria.get(str(cid), {})
            ha = item.setdefault("human_assessment", {})
            score_label = values.get("score_label")
            ha.update({
                "score": values.get("score"),
                "score_label": score_label,
                "agreement_with_automated_score": values.get("agreement_with_automated_score"),
                "semantic_issue": values.get("semantic_issue"),
                "reviewer_justification": values.get("reviewer_justification", ""),
                "completed": score_label in _SCORE_LABELS,
            })

        out.setdefault("overall_review", {}).update(overall)
        path = self.scoring_directory / "human_review.json"
        path.write_text(json.dumps(out, indent=2), encoding="utf-8")
        adjudicate_files(self.scoring_directory)
        self.document = out
        return path


def launch_review_dashboard(parents: Iterable[Path] | Path) -> bool:
    """Launch a full questionnaire-driven LLM human-review dashboard.

    Returns ``True`` when at least one reviewable LLM dataset was available.
    """
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk

    datasets = discover_review_datasets(parents)
    if not datasets:
        root = tk.Tk(); root.withdraw(); root.attributes("-topmost", True)
        messagebox.showinfo(
            "No reviewable LLM algorithms",
            "No LLM human-review questionnaires were found.\n\n"
            "Human review applies only to experimental LLM result folders. "
            "Select either the LLM folder containing a Results child or the Results folder itself. "
            "Baseline algorithms do not require human review.",
            parent=root,
        )
        root.destroy()
        return False

    root = tk.Tk()
    root.title("NL-FDEP Human Review")
    root.geometry("1380x900")
    root.minsize(1120, 760)

    # ----------------------- top dataset selector -----------------------
    top = tk.Frame(root)
    top.pack(fill="x", padx=10, pady=(10, 4))
    tk.Label(top, text="Dataset:", font=("Arial", 10, "bold")).pack(side="left")
    dataset_var = tk.StringVar()
    dataset_combo = ttk.Combobox(top, textvariable=dataset_var, state="readonly", width=44)

    def dataset_display_labels() -> list[str]:
        labels: list[str] = []
        used: dict[str, int] = {}
        for ds in datasets:
            base = ds["name"] or "Unnamed dataset"
            used[base] = used.get(base, 0) + 1
            labels.append(base if used[base] == 1 else f"{base} ({used[base]})")
        return labels

    dataset_combo["values"] = dataset_display_labels()
    dataset_combo.current(0)
    dataset_combo.pack(side="left", padx=(6, 14))
    dataset_summary = tk.Label(top, text="")
    dataset_summary.pack(side="left")
    add_dataset_button = tk.Button(top, text="Add LLM dataset")
    add_dataset_button.pack(side="right")

    main = tk.PanedWindow(root, orient="horizontal", sashwidth=6)
    main.pack(fill="both", expand=True, padx=10, pady=(4, 10))
    left = tk.Frame(main, width=250)
    right = tk.Frame(main)
    main.add(left, minsize=230)
    main.add(right, stretch="always")

    tk.Label(left, text="Algorithms", font=("Arial", 11, "bold")).pack(anchor="w")
    lb = tk.Listbox(left, width=30, height=40, exportselection=False)
    lb.pack(fill="both", expand=True, pady=(5, 6))
    review_status_label = tk.Label(left, text="", justify="left", anchor="w")
    review_status_label.pack(fill="x")

    toolbar = tk.Frame(right)
    toolbar.pack(fill="x", pady=(0, 4))
    algorithm_title = tk.Label(toolbar, text="Select an algorithm", font=("Arial", 14, "bold"))
    algorithm_title.pack(side="left")
    open_html_button = tk.Button(toolbar, text="Open full questionnaire HTML", state="disabled")
    open_html_button.pack(side="right", padx=(6, 0))
    save_button = tk.Button(toolbar, text="Save review", state="disabled")
    save_button.pack(side="right")

    notebook = ttk.Notebook(right)
    notebook.pack(fill="both", expand=True)

    # Helper for read-only verbose evidence panes.
    def read_only_text(parent, height=10):
        frame = tk.Frame(parent)
        text = tk.Text(frame, height=height, wrap="word")
        scroll = ttk.Scrollbar(frame, orient="vertical", command=text.yview)
        text.configure(yscrollcommand=scroll.set)
        text.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")
        frame.pack(fill="both", expand=True, pady=4)
        return text

    def set_text(widget, value: Any):
        widget.config(state="normal")
        widget.delete("1.0", "end")
        if isinstance(value, (dict, list)):
            value = json.dumps(value, indent=2, ensure_ascii=False)
        widget.insert("1.0", "" if value is None else str(value))
        widget.config(state="disabled")

    # ----------------------- overview / gates tab -----------------------
    gates_tab = tk.Frame(notebook)
    notebook.add(gates_tab, text="Reviewer & Gates")
    gates_canvas = tk.Canvas(gates_tab, highlightthickness=0)
    gates_scroll = ttk.Scrollbar(gates_tab, orient="vertical", command=gates_canvas.yview)
    gates_inner = tk.Frame(gates_canvas)
    gates_inner.bind("<Configure>", lambda e: gates_canvas.configure(scrollregion=gates_canvas.bbox("all")))
    gates_canvas.create_window((0, 0), window=gates_inner, anchor="nw")
    gates_canvas.configure(yscrollcommand=gates_scroll.set)
    gates_canvas.pack(side="left", fill="both", expand=True)
    gates_scroll.pack(side="right", fill="y")

    reviewer_var = tk.StringVar(value="REVIEWER_01")
    confidence_var = tk.StringVar(value="HIGH")
    instructions_text = tk.Message(gates_inner, text="", width=950, justify="left")
    instructions_text.pack(anchor="w", fill="x", padx=8, pady=8)
    reviewer_row = tk.Frame(gates_inner); reviewer_row.pack(fill="x", padx=8, pady=4)
    tk.Label(reviewer_row, text="Reviewer ID").pack(side="left")
    tk.Entry(reviewer_row, textvariable=reviewer_var, width=28).pack(side="left", padx=(6, 18))
    tk.Label(reviewer_row, text="Overall confidence").pack(side="left")
    ttk.Combobox(reviewer_row, textvariable=confidence_var, values=["HIGH", "MODERATE", "LOW"], state="readonly", width=16).pack(side="left", padx=6)

    def labelled_section(parent, heading):
        frame = ttk.LabelFrame(parent, text=heading)
        frame.pack(fill="x", padx=8, pady=8)
        return frame

    g1_frame = labelled_section(gates_inner, "G1 · Source sufficiency")
    g1_question = tk.Message(g1_frame, text="", width=930, justify="left"); g1_question.pack(anchor="w", fill="x", padx=6, pady=4)
    g1_auto = tk.Message(g1_frame, text="", width=930, justify="left"); g1_auto.pack(anchor="w", fill="x", padx=6, pady=4)
    g1_result_var = tk.StringVar(); g1_agree_var = tk.StringVar()
    g1_row = tk.Frame(g1_frame); g1_row.pack(fill="x", padx=6, pady=4)
    tk.Label(g1_row, text="Human result").pack(side="left")
    ttk.Combobox(g1_row, textvariable=g1_result_var, values=["EVALUABLE", "EXPECTED_FAILURE", "REVIEW_REQUIRED"], state="readonly", width=22).pack(side="left", padx=(6, 18))
    tk.Label(g1_row, text="Agreement").pack(side="left")
    ttk.Combobox(g1_row, textvariable=g1_agree_var, values=_AGREEMENT_VALUES, state="readonly", width=20).pack(side="left", padx=6)
    g1_notes = tk.Text(g1_frame, height=4, wrap="word"); g1_notes.pack(fill="x", padx=6, pady=(2, 6))

    g2_frame = labelled_section(gates_inner, "G2 · Behavioural evidence adequacy")
    g2_verbose = tk.Text(g2_frame, height=17, wrap="word")
    g2_verbose.pack(fill="both", expand=True, padx=6, pady=4)
    g2_verbose.config(state="disabled")
    g2_result_var = tk.StringVar(); g2_agree_var = tk.StringVar()
    g2_row = tk.Frame(g2_frame); g2_row.pack(fill="x", padx=6, pady=4)
    tk.Label(g2_row, text="Human G2 assessment").pack(side="left")
    ttk.Combobox(g2_row, textvariable=g2_result_var, values=["ADEQUATE", "PARTIAL", "LIMITED", "NOT_EVALUABLE", "NOT_DECLARED"], state="readonly", width=20).pack(side="left", padx=(6, 18))
    tk.Label(g2_row, text="Agreement").pack(side="left")
    ttk.Combobox(g2_row, textvariable=g2_agree_var, values=_AGREEMENT_VALUES, state="readonly", width=20).pack(side="left", padx=6)
    g2_notes = tk.Text(g2_frame, height=4, wrap="word"); g2_notes.pack(fill="x", padx=6, pady=(2, 6))

    # ----------------------- semantic tab -----------------------
    semantic_tab = tk.Frame(notebook)
    notebook.add(semantic_tab, text="Task Semantics")
    sem_instruction = tk.Message(semantic_tab, text="", width=950, justify="left")
    sem_instruction.pack(anchor="w", fill="x", padx=8, pady=6)
    sem_evidence = read_only_text(semantic_tab, height=18)
    sem_inputs_var = tk.StringVar(); sem_logic_var = tk.StringVar(); sem_output_var = tk.StringVar(); sem_edge_var = tk.StringVar(); sem_overall_var = tk.StringVar()
    sem_fields = tk.Frame(semantic_tab); sem_fields.pack(fill="x", padx=8, pady=6)
    semantic_options = ["YES", "PARTIAL", "NO", "UNABLE_TO_DETERMINE"]
    semantic_edge_options = semantic_options + ["NOT_APPLICABLE"]
    semantic_specs = [
        ("Required inputs represented", sem_inputs_var, semantic_options),
        ("Core algorithm logic", sem_logic_var, semantic_options),
        ("Required output semantics represented", sem_output_var, semantic_options),
        ("Edge/domain handling", sem_edge_var, semantic_edge_options),
        ("Overall semantic assessment", sem_overall_var, ["CORRECT", "MOSTLY_CORRECT", "PARTIAL", "INCORRECT", "NOT_DETERMINABLE"]),
    ]
    for label, variable, values in semantic_specs:
        row = tk.Frame(sem_fields); row.pack(fill="x", pady=2)
        tk.Label(row, text=label, width=38, anchor="w").pack(side="left")
        ttk.Combobox(row, textvariable=variable, values=values, state="readonly", width=28).pack(side="left")
    tk.Label(semantic_tab, text="Reviewer semantic justification").pack(anchor="w", padx=8)
    sem_notes = tk.Text(semantic_tab, height=7, wrap="word"); sem_notes.pack(fill="x", padx=8, pady=(2, 8))

    # ----------------------- criteria tab -----------------------
    criteria_tab = tk.Frame(notebook)
    notebook.add(criteria_tab, text="16 Rubric Criteria")
    criterion_header = tk.Label(criteria_tab, text="", font=("Arial", 12, "bold")); criterion_header.pack(anchor="w", padx=8, pady=(8, 3))
    criterion_question = tk.Message(criteria_tab, text="", width=960, justify="left", font=("Arial", 10, "bold")); criterion_question.pack(anchor="w", fill="x", padx=8, pady=4)
    criterion_auto = tk.Message(criteria_tab, text="", width=960, justify="left"); criterion_auto.pack(anchor="w", fill="x", padx=8, pady=4)
    criterion_evidence = read_only_text(criteria_tab, height=14)
    score_var = tk.StringVar(); agree_var = tk.StringVar(); semantic_issue_var = tk.StringVar()
    score_row = tk.Frame(criteria_tab); score_row.pack(fill="x", padx=8, pady=5)
    tk.Label(score_row, text="Human score:").pack(side="left")
    for value, label in [("2", "2 — fully satisfied"), ("1", "1 — partial/uncertain"), ("0", "0 — not satisfied"), ("NA", "N/A")]:
        tk.Radiobutton(score_row, text=label, variable=score_var, value=value).pack(side="left", padx=5)
    criterion_meta_row = tk.Frame(criteria_tab); criterion_meta_row.pack(fill="x", padx=8, pady=4)
    tk.Label(criterion_meta_row, text="Agreement").pack(side="left")
    ttk.Combobox(criterion_meta_row, textvariable=agree_var, values=_AGREEMENT_VALUES, state="readonly", width=20).pack(side="left", padx=(6, 18))
    tk.Label(criterion_meta_row, text="Semantic issue").pack(side="left")
    ttk.Combobox(criterion_meta_row, textvariable=semantic_issue_var, values=["NO", "YES"], state="readonly", width=12).pack(side="left", padx=6)
    tk.Label(criteria_tab, text="Reviewer justification").pack(anchor="w", padx=8)
    criterion_notes = tk.Text(criteria_tab, height=6, wrap="word"); criterion_notes.pack(fill="x", padx=8, pady=(2, 4))
    criterion_nav = tk.Frame(criteria_tab); criterion_nav.pack(fill="x", padx=8, pady=6)
    prev_button = tk.Button(criterion_nav, text="Previous criterion", state="disabled")
    next_button = tk.Button(criterion_nav, text="Next criterion", state="disabled")
    prev_button.pack(side="left"); next_button.pack(side="left", padx=6)
    criterion_progress = tk.Label(criterion_nav, text=""); criterion_progress.pack(side="left", padx=12)

    # ----------------------- overall tab -----------------------
    overall_tab = tk.Frame(notebook)
    notebook.add(overall_tab, text="Overall Review")
    uncaptured_var = tk.StringVar(); first_loss_var = tk.StringVar(); faithful_var = tk.StringVar()
    overall_fields = [
        ("Material semantic error not captured by automated criteria?", uncaptured_var, ["NO", "YES"]),
        ("First semantic loss stage", first_loss_var, ["SOURCE", "CANONICALISATION", "AST", "FLOW_DIAGRAM", "PYTHON", "BEHAVIOURAL_TESTING", "NONE", "UNABLE_TO_DETERMINE"]),
        ("Final generated Python behaviourally faithful?", faithful_var, ["YES", "PARTIALLY", "NO", "NA"]),
    ]
    for label, variable, values in overall_fields:
        row = tk.Frame(overall_tab); row.pack(fill="x", padx=8, pady=8)
        tk.Label(row, text=label, width=52, anchor="w").pack(side="left")
        ttk.Combobox(row, textvariable=variable, values=values, state="readonly", width=28).pack(side="left")
    tk.Label(overall_tab, text="Additional observations").pack(anchor="w", padx=8, pady=(8, 0))
    observations = tk.Text(overall_tab, height=15, wrap="word"); observations.pack(fill="both", expand=True, padx=8, pady=(3, 8))

    state: dict[str, Any] = {
        "dataset_index": 0,
        "rows": datasets[0]["rows"],
        "session": None,
        "criteria": [],
        "criterion_index": 0,
        "criteria_working": {},
    }

    def clear_text(widget):
        widget.delete("1.0", "end")

    def set_entry_text(widget, value):
        widget.delete("1.0", "end")
        widget.insert("1.0", value or "")

    def capture_criterion():
        items = state.get("criteria") or []
        if not items:
            return
        item = items[state["criterion_index"]]
        cid = str(item.get("criterion_id"))
        raw = score_var.get() or None
        state["criteria_working"][cid] = {
            "score": None if raw in {None, "NA"} else int(raw),
            "score_label": raw,
            "agreement_with_automated_score": agree_var.get() or None,
            "semantic_issue": True if semantic_issue_var.get() == "YES" else (False if semantic_issue_var.get() == "NO" else None),
            "reviewer_justification": criterion_notes.get("1.0", "end").strip(),
        }

    def load_criterion():
        items = state.get("criteria") or []
        if not items:
            criterion_header.config(text="No rubric criteria available")
            criterion_question.config(text="")
            criterion_auto.config(text="")
            set_text(criterion_evidence, "")
            return
        index = state["criterion_index"]
        item = items[index]
        cid = str(item.get("criterion_id"))
        criterion_header.config(text=f"{cid} · {item.get('stage_name') or ''}")
        criterion_question.config(text=item.get("question") or "")
        criterion_auto.config(text=(
            f"Automated assessment: {item.get('automated_score') if item.get('automated_score') is not None else 'N/A'} / 2"
            f" · {item.get('automated_status')} · confidence {item.get('automated_confidence')}\n"
            f"Automated justification: {item.get('automated_justification') or ''}"
        ))
        set_text(criterion_evidence, item.get("evidence") or [])
        prev = state["criteria_working"].get(cid, {})
        score_var.set(prev.get("score_label") or "")
        agree_var.set(prev.get("agreement_with_automated_score") or "")
        sem_issue = prev.get("semantic_issue")
        semantic_issue_var.set("YES" if sem_issue is True else ("NO" if sem_issue is False else ""))
        set_entry_text(criterion_notes, prev.get("reviewer_justification") or "")
        criterion_progress.config(text=f"Criterion {index + 1} of {len(items)}")
        prev_button.config(state="normal" if index > 0 else "disabled")
        next_button.config(state="normal" if index + 1 < len(items) else "disabled")

    def move_criterion(delta):
        capture_criterion()
        items = state.get("criteria") or []
        if not items:
            return
        state["criterion_index"] = max(0, min(len(items) - 1, state["criterion_index"] + delta))
        load_criterion()

    prev_button.config(command=lambda: move_criterion(-1))
    next_button.config(command=lambda: move_criterion(1))

    def load_session(session: ReviewSession, aid: int | None):
        doc = session.document
        state["session"] = session
        state["criteria"] = doc.get("criteria", []) or []
        state["criterion_index"] = 0
        state["criteria_working"] = {
            str(item.get("criterion_id")): deepcopy(item.get("human_assessment", {}) or {})
            for item in state["criteria"]
        }
        algorithm_title.config(text=f"Algorithm {aid} · {(doc.get('algorithm') or {}).get('dataset') or ''}")
        instructions_text.config(text=doc.get("instructions") or "")
        reviewer = doc.get("reviewer", {}) or {}
        reviewer_var.set(reviewer.get("reviewer_id") or "REVIEWER_01")
        confidence_var.set(reviewer.get("overall_reviewer_confidence") or "HIGH")

        g1 = doc.get("source_sufficiency", {}) or {}
        g1_question.config(text=g1.get("question") or "")
        g1_auto.config(text=f"Automated result: {g1.get('automated_result')}\nAutomated justification: {g1.get('automated_justification') or ''}")
        g1_result_var.set(g1.get("human_result") or "")
        g1_agree_var.set(g1.get("agreement_with_automated_result") or "")
        set_entry_text(g1_notes, g1.get("reviewer_justification") or "")

        g2 = doc.get("behavioural_evidence_adequacy", {}) or {}
        g2_body = (
            f"Question: {g2.get('question') or ''}\n\n"
            f"Headline classification: {g2.get('automated_result')}\n"
            f"Evidence summary: {g2.get('summary') or ''}\n\n"
            f"Coverage profile:\n{json.dumps(g2.get('coverage_dimensions') or {}, indent=2)}\n\n"
            f"Strengths:\n{json.dumps(g2.get('strengths') or [], indent=2)}\n\n"
            f"Limitations:\n{json.dumps(g2.get('limitations') or [], indent=2)}\n\n"
            f"Coverage basis: {g2.get('coverage_basis') or ''}\n"
            f"Interpretation: {g2.get('interpretation') or ''}"
        )
        set_text(g2_verbose, g2_body)
        g2_result_var.set(g2.get("human_result") or "")
        g2_agree_var.set(g2.get("agreement_with_automated_result") or "")
        set_entry_text(g2_notes, g2.get("reviewer_justification") or "")

        sem = doc.get("task_semantic_evaluation")
        if sem:
            sem_instruction.config(text=sem.get("instruction") or "")
            set_text(sem_evidence, {"contract": sem.get("contract"), "automated_evidence": sem.get("automated_evidence")})
            human = sem.get("human_assessment", {}) or {}
            sem_inputs_var.set(human.get("required_inputs_represented") or "")
            sem_logic_var.set(human.get("core_algorithm_logic") or "")
            sem_output_var.set(human.get("required_output_semantics_represented") or "")
            sem_edge_var.set(human.get("edge_and_domain_handling") or "")
            sem_overall_var.set(human.get("overall_semantic_assessment") or "")
            set_entry_text(sem_notes, human.get("reviewer_justification") or "")
        else:
            sem_instruction.config(text="No task-semantic contract is declared for this algorithm.")
            set_text(sem_evidence, "")
            for variable in (sem_inputs_var, sem_logic_var, sem_output_var, sem_edge_var, sem_overall_var): variable.set("")
            set_entry_text(sem_notes, "")

        overall = doc.get("overall_review", {}) or {}
        uncaptured = overall.get("material_semantic_error_not_captured")
        uncaptured_var.set("YES" if uncaptured is True else ("NO" if uncaptured is False else ""))
        first_loss_var.set(overall.get("first_semantic_loss_stage") or "")
        faithful_var.set(overall.get("final_python_behaviourally_faithful") or "")
        set_entry_text(observations, overall.get("additional_observations") or "")

        load_criterion()
        save_button.config(state="normal")
        open_html_button.config(state="normal" if session.questionnaire_html.is_file() else "disabled")

    def update_algorithm_list(*_):
        idx = dataset_combo.current()
        if idx < 0:
            return
        state["dataset_index"] = idx
        rows = datasets[idx]["rows"]
        state["rows"] = rows
        state["session"] = None
        lb.delete(0, "end")
        for row in rows:
            lb.insert("end", f"Algorithm {row['algorithm_id']:>2}  {'✓ Reviewed' if row['reviewed'] else 'Pending'}")
        reviewed = sum(1 for row in rows if row["reviewed"])
        dataset_summary.config(text=f"{len(rows)} algorithms · {reviewed} reviewed · {len(rows)-reviewed} pending")
        review_status_label.config(text=f"Dataset: {datasets[idx]['name']}\nRoot: {datasets[idx]['root']}")
        algorithm_title.config(text="Select an algorithm")
        save_button.config(state="disabled")
        open_html_button.config(state="disabled")

    def select_algorithm(_=None):
        if not lb.curselection():
            return
        row = state["rows"][lb.curselection()[0]]
        try:
            session = ReviewSession(Path(row["scoring_directory"]))
            load_session(session, row.get("algorithm_id"))
        except Exception as exc:
            messagebox.showerror("Human review", str(exc), parent=root)

    def open_questionnaire_html():
        session = state.get("session")
        if not session or not session.questionnaire_html.is_file():
            return
        webbrowser.open(session.questionnaire_html.resolve().as_uri())

    def save_review():
        session: ReviewSession | None = state.get("session")
        if session is None:
            return
        capture_criterion()
        semantic_review = None
        if session.document.get("task_semantic_evaluation") is not None:
            semantic_review = {
                "required_inputs_represented": sem_inputs_var.get() or None,
                "core_algorithm_logic": sem_logic_var.get() or None,
                "required_output_semantics_represented": sem_output_var.get() or None,
                "edge_and_domain_handling": sem_edge_var.get() or None,
                "overall_semantic_assessment": sem_overall_var.get() or None,
                "reviewer_justification": sem_notes.get("1.0", "end").strip(),
            }
        try:
            path = session.save(
                reviewer_id=reviewer_var.get().strip() or "REVIEWER_01",
                confidence=confidence_var.get() or None,
                source_review={
                    "human_result": g1_result_var.get() or None,
                    "agreement_with_automated_result": g1_agree_var.get() or None,
                    "reviewer_justification": g1_notes.get("1.0", "end").strip(),
                },
                evidence_review={
                    "human_result": g2_result_var.get() or None,
                    "agreement_with_automated_result": g2_agree_var.get() or None,
                    "reviewer_justification": g2_notes.get("1.0", "end").strip(),
                },
                semantic_review=semantic_review,
                criteria=state["criteria_working"],
                overall={
                    "material_semantic_error_not_captured": True if uncaptured_var.get() == "YES" else (False if uncaptured_var.get() == "NO" else None),
                    "first_semantic_loss_stage": first_loss_var.get() or None,
                    "final_python_behaviourally_faithful": faithful_var.get() or None,
                    "additional_observations": observations.get("1.0", "end").strip(),
                },
            )
            # Refresh row status and retain current algorithm selection.
            selected_index = lb.curselection()[0] if lb.curselection() else None
            normalised = Path(datasets[state["dataset_index"]]["root"])
            datasets[state["dataset_index"]]["rows"] = review_status(normalised)
            update_algorithm_list()
            if selected_index is not None and selected_index < lb.size():
                lb.selection_set(selected_index)
                lb.see(selected_index)
                select_algorithm()
            completed = sum(
                1 for item in session.document.get("criteria", [])
                if (item.get("human_assessment") or {}).get("score_label") in _SCORE_LABELS
            )
            messagebox.showinfo(
                "Review saved",
                f"Saved {path.name}.\nRubric criteria completed: {completed}/16.\n"
                "Combined rubric scoring remains unavailable until all 16 criteria are explicitly completed.",
                parent=root,
            )
        except Exception as exc:
            messagebox.showerror("Review save failed", str(exc), parent=root)

    def add_llm_dataset():
        selected = filedialog.askdirectory(
            title="Select an additional LLM dataset or Results folder",
            parent=root,
        )
        if not selected:
            return

        additions = discover_review_datasets([Path(selected)])
        if not additions:
            messagebox.showinfo(
                "No reviewable LLM algorithms",
                "The selected folder contains no reviewable experimental LLM questionnaires. "
                "Baseline datasets are not eligible for Human Review.",
                parent=root,
            )
            return

        existing = {str(Path(item["root"]).resolve()).casefold() for item in datasets}
        added_index: int | None = None
        for item in additions:
            key = str(Path(item["root"]).resolve()).casefold()
            if key in existing:
                continue
            datasets.append(item)
            existing.add(key)
            added_index = len(datasets) - 1

        if added_index is None:
            messagebox.showinfo(
                "Dataset already loaded",
                "That LLM dataset is already present in this Human Review session.",
                parent=root,
            )
            return


        dataset_combo["values"] = dataset_display_labels()
        dataset_combo.current(added_index)
        update_algorithm_list()

    dataset_combo.bind("<<ComboboxSelected>>", update_algorithm_list)
    lb.bind("<<ListboxSelect>>", select_algorithm)
    open_html_button.config(command=open_questionnaire_html)
    save_button.config(command=save_review)
    add_dataset_button.config(command=add_llm_dataset)
    update_algorithm_list()
    root.mainloop()
    return True
