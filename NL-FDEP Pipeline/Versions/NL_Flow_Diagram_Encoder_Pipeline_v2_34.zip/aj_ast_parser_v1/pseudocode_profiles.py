"""Controlled pseudocode processing profiles for the input pipeline."""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from enum import Enum
import json
import re
import textwrap


class PseudocodeProfile(str, Enum):
    """Available pseudocode processing profiles."""

    AJ_DIALECT_STRICT = "AJ_DIALECT_STRICT"
    GENERIC_COMPATIBILITY = "GENERIC_COMPATIBILITY"
    GENERAL_NO_CONVERSION = "GENERAL_NO_CONVERSION"


@dataclass
class SourceTransformation:
    """Records one deliberate source transformation."""

    line: int | None
    rule: str
    source: str
    target: str


@dataclass
class PseudocodeProcessingResult:
    """Contains processed source and an auditable transformation report."""

    profile: PseudocodeProfile
    original_source: str
    processed_source: str
    transformations: list[SourceTransformation] = field(default_factory=list)
    header_comment_removed: bool = False
    header_lines_removed: int = 0

    @property
    def source_modified(self) -> bool:
        """Returns whether the selected profile changed the supplied source."""

        return self.original_source != self.processed_source

    @property
    def transformation_count(self) -> int:
        """Returns the number of logged transformations."""

        return len(self.transformations)

    @staticmethod
    def _semantic_audit_entry(transformation: SourceTransformation) -> dict:
        """Returns a semantic audit record without exposing legacy rule IDs."""

        source = transformation.source
        target = transformation.target
        source_upper = source.upper()
        target_upper = target.upper()

        family = "SOURCE_NORMALISATION"
        branch = "GENERIC_EQUIVALENCE"
        evidence = ["source and canonical target differ by an approved compatibility equivalence"]
        confidence = "structurally_certain"

        if re.search(r"\bEND\s+(CLASS|FUNCTION|IF|WHILE|FOR)\b", source_upper) and any(
            token in target_upper
            for token in ("ENDCLASS", "ENDFUNCTION", "ENDIF", "ENDWHILE", "ENDFOR")
        ):
            family = "BLOCK_TERMINATOR"
            branch = "SPACED_END_TO_OPEN_BLOCK"
            evidence = ["a matching block is open at the point of the spaced END phrase"]

        elif "CALL CONSTRUCTOR()" in source_upper and "CALL CONSTRUCTOR()" not in target_upper:
            family = "CLASS_STRUCTURE"
            branch = "REDUNDANT_CONSTRUCTOR_MARKER"
            evidence = ["CLASS implies construction; zero-argument Constructor() adds no separate operation"]
            confidence = "user_confirmed"

        elif re.search(r"<-\s*[A-Za-z_]\w*\s*\+\s*\[[^\n]+\]", source) and "APPEND " in target_upper:
            family = "COLLECTION_SELF_ADDITION"
            branch = "APPEND_SINGLE"
            evidence = ["left side is a known collection", "RHS is a singleton list expression"]

        elif re.search(r"<-\s*[A-Za-z_]\w*\s*\+\s*CALL\s+", source, re.I) and "EXTEND_LIST" in target_upper:
            family = "COLLECTION_SELF_ADDITION"
            branch = "EXTEND_LIST"
            evidence = ["left side is a known list", "RHS is inferred to return a list"]

        elif "_NEXT" in source_upper and ".NEXT" in target_upper:
            family = "OBJECT_PROPERTY"
            branch = "LINKED_LIST_NEXT"
            evidence = ["variable is established as a linked-list node reference"]

        elif any(x in source for x in ("_position", "_velocity", "_destination", "_quantity", "_itemID")) and "." in target:
            family = "OBJECT_PROPERTY"
            branch = "FLATTENED_PROPERTY"
            evidence = ["surrounding iteration establishes the object bound to the flattened property"]

        elif " IS A NUMBER" in source_upper and "IS_NUMBER" in target_upper:
            family = "SEMANTIC_PREDICATE"
            branch = "IS_A_NUMBER"

        elif "{}" in source and "EMPTY DICTIONARY" in target_upper:
            family = "LITERAL"
            branch = "EMPTY_DICTIONARY"

        elif "LIST [" in source_upper and "LIST_VALUE" in target_upper:
            family = "LITERAL"
            branch = "LIST_LITERAL"

        elif "NUMBER_OF_CHARACTERS" in source_upper and "LENGTH OF" in target_upper:
            family = "SEMANTIC_PRIMITIVE"
            branch = "NUMBER_OF_CHARACTERS"

        elif "CALL MODULUS" in source_upper and " MODULUS " in target_upper:
            family = "ARITHMETIC"
            branch = "FUNCTION_SHAPED_MODULUS"

        elif "CALL FLOOR" in source_upper and "INTEGER DIVISION" in target_upper:
            family = "ARITHMETIC"
            branch = "INTEGER_DIVISION"

        return {
            "line": transformation.line,
            "rule_family": family,
            "branch": branch,
            "source": source,
            "canonical": target,
            "evidence": evidence,
            "confidence": confidence,
            "semantic_change": False,
        }

    def to_dict(self) -> dict:
        """Returns a semantic, serialisable processing audit."""

        transformations = [
            self._semantic_audit_entry(transformation)
            for transformation in self.transformations
        ]

        return {
            "audit_schema": "SEMANTIC_RULE_FAMILIES_V1",
            "profile": self.profile.value,
            "source_modified": self.source_modified,
            "transformation_count": len(transformations),
            "transformations": transformations,
            "header_comment_removed": self.header_comment_removed,
            "header_lines_removed": self.header_lines_removed,
        }

    def to_json(self) -> str:
        """Returns the processing report as formatted JSON."""

        return json.dumps(
            self.to_dict(),
            indent=2,
        )


class InitialHashCommentStripper:
    """Removes an optional leading hash-comment metadata block before parsing."""

    PSEUDOCODE_START_PATTERN = re.compile(
        r"^(?:"
        r"INPUT\b|OUTPUT\b|FUNCTION\b|CLASS\b|IF\b|WHILE\b|FOR\b|"
        r"RETURN\b|CALL\b|TRY\b|RAISE\b|COMMENT\b|BREAK\b|"
        r"[A-Za-z_][A-Za-z0-9_]*(?:\[[^\]]+\])?\s*(?:<-|=)"
        r")",
        re.IGNORECASE,
    )

    def strip(self, source: str) -> tuple[str, bool, int]:
        """Removes a leading hash-comment metadata block before pseudocode begins."""

        source_lines = source.splitlines(keepends=True)

        if not source_lines:
            return source, False, 0

        header_start_index = 0

        while header_start_index < len(source_lines):
            candidate_line = source_lines[header_start_index]
            candidate_line = candidate_line.lstrip("\ufeff \t\r\n")

            if candidate_line != "":
                break

            header_start_index += 1

        if header_start_index >= len(source_lines):
            return source, False, 0

        first_content_line = source_lines[header_start_index]
        first_content_line = first_content_line.lstrip("\ufeff \t")

        if not first_content_line.startswith("#"):
            return source, False, 0

        first_pseudocode_index = None

        for index in range(header_start_index + 1, len(source_lines)):
            candidate = source_lines[index]
            stripped_candidate = candidate.strip()

            if stripped_candidate == "":
                first_pseudocode_index = index + 1

                while first_pseudocode_index < len(source_lines):
                    if source_lines[first_pseudocode_index].strip() != "":
                        break

                    first_pseudocode_index += 1

                break

            if self._looks_like_pseudocode(stripped_candidate):
                first_pseudocode_index = index
                break

        if first_pseudocode_index is None:
            first_pseudocode_index = header_start_index + 1

        processed_source = "".join(
            source_lines[first_pseudocode_index:]
        )

        return processed_source, True, first_pseudocode_index

    def _looks_like_pseudocode(self, line: str) -> bool:
        """Returns whether a line clearly begins with executable pseudocode."""

        return bool(
            self.PSEUDOCODE_START_PATTERN.match(
                line
            )
        )


@dataclass(frozen=True)
class CharacterNormalisationRule:
    """Defines one auditable Generic compatibility character rule."""

    rule_id: str
    source: str
    target: str
    description: str


class GenericCharacterNormaliser:
    """Normalises characters observed across the six-model pseudocode corpus."""

    RULES = (
        CharacterNormalisationRule("GC001", "≠", "!=", "Unicode not-equal operator"),
        CharacterNormalisationRule("GC002", "≤", "<=", "Unicode less-than-or-equal operator"),
        CharacterNormalisationRule("GC003", "≥", ">=", "Unicode greater-than-or-equal operator"),
        CharacterNormalisationRule("GC004", "←", "<-", "Unicode assignment arrow"),
        CharacterNormalisationRule("GC005", "×", "*", "Unicode multiplication operator"),
        CharacterNormalisationRule("GC006", "∞", "INFINITY", "Unicode infinity symbol"),
        CharacterNormalisationRule("GC007", "→", "TO", "Unicode right arrow"),
        CharacterNormalisationRule("GC008", "“", '"', "Opening smart double quote"),
        CharacterNormalisationRule("GC009", "”", '"', "Closing smart double quote"),
        CharacterNormalisationRule("GC010", "‘", "'", "Opening smart single quote"),
        CharacterNormalisationRule("GC011", "’", "'", "Closing smart single quote"),
        CharacterNormalisationRule("GC012", "–", "-", "Unicode en dash"),
        CharacterNormalisationRule("GC013", "\u2005", " ", "Unicode four-per-em space"),
        CharacterNormalisationRule("GC014", "\u00a0", " ", "Non-breaking space"),
        CharacterNormalisationRule("GC015", "\u200b", "", "Zero-width space"),
        CharacterNormalisationRule("GC016", "\ufeff", "", "UTF-8 BOM / zero-width no-break space"),
    )

    def process(self, source: str) -> tuple[str, list[SourceTransformation]]:
        """Applies corpus-derived character rules and records every changed line."""

        source_lines = source.splitlines(keepends=True)
        transformations = []
        processed_lines = []

        for line_number, source_line in enumerate(source_lines, start=1):
            transformed_line = source_line

            for rule in self.RULES:
                if rule.source not in transformed_line:
                    continue

                before = transformed_line
                transformed_line = transformed_line.replace(
                    rule.source,
                    rule.target,
                )

                transformations.append(
                    SourceTransformation(
                        line=line_number,
                        rule=rule.rule_id,
                        source=before.rstrip("\r\n"),
                        target=transformed_line.rstrip("\r\n"),
                    )
                )

            degree_before = transformed_line
            transformed_line = re.sub(
                r"(?<=\d)°",
                " DEG",
                transformed_line,
            )

            if transformed_line != degree_before:
                transformations.append(
                    SourceTransformation(
                        line=line_number,
                        rule="GC017",
                        source=degree_before.rstrip("\r\n"),
                        target=transformed_line.rstrip("\r\n"),
                    )
                )

            processed_lines.append(
                transformed_line
            )

        return "".join(processed_lines), transformations


class GenericStatementBoundaryNormaliser:
    """Reconstructs logical lines in pseudocode compressed onto one physical line."""

    START_PATTERN = re.compile(
        r"(?i)(?:^|\s+)(?=(?:"
        r"INPUT\b|OUTPUT\b|PRINT\b|DISPLAY\b|RETURN\b|RAISE\b|"
        r"IF\b|ELSE\s+IF\b|ELSE\b|WHILE\b|FOR\s+EACH\b|FOR\b|"
        r"FUNCTION\b|PROCEDURE\b|CALL\b|APPEND\b|ADD\b|REMOVE\b|"
        r"SWAP\b|REVERSE\b|ENQUEUE\b|DEQUEUE\b|PUSH\b|POP\b|"
        r"CREATE\b|INIT\b|[A-Za-z_][A-Za-z0-9_]*(?:\[[^\]]+\])?\.(?:append|add|enqueue|dequeue|push|pop|popFront|popBack|pushBack)\b|"
        r"[A-Za-z_][A-Za-z0-9_]*(?:\[[^\]]+\])?\s*(?:<-|\+=|-=|\*=|/=|%=|\+\+|--|(?<![<>=!])=(?!=))"
        r"))"
    )

    def process(self, source: str) -> tuple[str, list[SourceTransformation]]:
        transformations: list[SourceTransformation] = []
        output: list[str] = []

        source, continuation_transformations = self._join_expression_continuations(source)
        transformations.extend(continuation_transformations)

        source, branch_chain_transformations = self._repair_conditional_branch_chains(source)
        transformations.extend(branch_chain_transformations)

        # Phase 11: already-structured multiline pseudocode must not be treated
        # as a compressed one-line program. Preserve its physical boundaries.
        if self._is_structured_multiline_source(source):
            return source, transformations

        for line_number, source_line in enumerate(source.splitlines(), start=1):
            stripped = source_line.strip()

            if not self._is_compressed_candidate(stripped):
                output.append(source_line)
                continue

            statements = self._split_statements(stripped)

            if len(statements) <= 1:
                output.append(source_line)
                continue

            reconstructed = self._reconstruct_indentation(statements)
            output.extend(reconstructed)
            transformations.append(
                SourceTransformation(
                    line=line_number,
                    rule="GC085",
                    source=source_line,
                    target="\n".join(reconstructed),
                )
            )

        return "\n".join(output), transformations


    def _repair_conditional_branch_chains(
        self,
        source: str,
    ) -> tuple[str, list[SourceTransformation]]:
        """Remove an ENDIF that incorrectly separates ELSE/ELSE IF from its IF."""
        lines = source.splitlines()
        output: list[str] = []
        transformations: list[SourceTransformation] = []
        index = 0

        while index < len(lines):
            line = lines[index]
            stripped = line.strip()

            if re.fullmatch(r"ENDIF", stripped, re.IGNORECASE):
                lookahead = index + 1
                while lookahead < len(lines) and not lines[lookahead].strip():
                    lookahead += 1

                if lookahead < len(lines):
                    next_line = lines[lookahead]
                    next_stripped = next_line.strip()
                    current_indent = len(line) - len(line.lstrip())
                    next_indent = len(next_line) - len(next_line.lstrip())

                    if (
                        current_indent == next_indent
                        and re.match(r"ELSE(?:\s+IF\b|\b)", next_stripped, re.IGNORECASE)
                    ):
                        transformations.append(
                            SourceTransformation(
                                line=index + 1,
                                rule="GC133",
                                source=line,
                                target="",
                            )
                        )
                        index += 1
                        continue

            output.append(line)
            index += 1

        return "\n".join(output), transformations


    def _join_expression_continuations(
        self,
        source: str,
    ) -> tuple[str, list[SourceTransformation]]:
        """Join arithmetic/logical expressions continued onto the next line."""
        lines = source.splitlines()
        output: list[str] = []
        transformations: list[SourceTransformation] = []
        index = 0

        continuation_end = re.compile(
            r"(?:\+|-|\*|/|%|==|!=|<=|>=|<|>|=|<-|\bAND\b|\bOR\b|\bXOR\b|,|\()\s*$",
            re.IGNORECASE,
        )

        while index < len(lines):
            current = lines[index]
            combined = current
            start_line = index + 1

            while (
                index + 1 < len(lines)
                and combined.strip()
                and continuation_end.search(combined.rstrip())
                and lines[index + 1].strip()
            ):
                next_line = lines[index + 1]
                combined = combined.rstrip() + " " + next_line.strip()
                index += 1

            output.append(combined)

            if combined != current:
                transformations.append(
                    SourceTransformation(
                        line=start_line,
                        rule="GC126",
                        source=current,
                        target=combined,
                    )
                )

            index += 1

        return "\n".join(output), transformations


    def _is_structured_multiline_source(self, source: str) -> bool:
        non_empty = [line for line in source.splitlines() if line.strip()]
        if len(non_empty) < 3:
            return False

        indented = sum(1 for line in non_empty if len(line) > len(line.lstrip()))
        control_lines = sum(
            1
            for line in non_empty
            if re.match(r"\s*(?:IF|ELSE|WHILE|FOR|FUNCTION|PROCEDURE|RETURN|INPUT|OUTPUT|INIT|CREATE)\b", line, re.I)
        )
        # Existing indentation is the strongest signal. Several separate control
        # statements is a secondary signal for flat but already-line-broken text.
        return indented >= 1 or control_lines >= 3

    def _is_compressed_candidate(self, line: str) -> bool:
        if not line or len(line) < 35:
            return False
        starts = self._candidate_positions(line)
        return len(starts) >= 3

    def _candidate_positions(self, line: str) -> list[int]:
        masked = self._mask_nested_and_quoted_text(line)
        positions = {0}
        for match in self.START_PATTERN.finditer(masked):
            pos = match.start()
            while pos < len(masked) and masked[pos].isspace():
                pos += 1
            if masked[pos:pos + 2].upper() == "IF":
                prefix = masked[:pos].rstrip().upper()
                if prefix.endswith("ELSE"):
                    continue
            positions.add(pos)
        return sorted(positions)

    def _split_statements(self, line: str) -> list[str]:
        positions = self._candidate_positions(line)
        pieces: list[str] = []
        for index, start in enumerate(positions):
            end = positions[index + 1] if index + 1 < len(positions) else len(line)
            piece = line[start:end].strip()
            if piece.endswith(","):
                piece = piece[:-1].rstrip()
            if piece:
                pieces.append(piece)
        return self._repair_control_headers(pieces)

    def _repair_control_headers(self, pieces: list[str]) -> list[str]:
        repaired: list[str] = []
        for piece in pieces:
            piece = piece.strip()
            if piece.endswith(":"):
                piece = piece[:-1].rstrip()
            repaired.append(piece)
        return repaired

    def _reconstruct_indentation(self, statements: list[str]) -> list[str]:
        output: list[str] = []
        indent = 0
        stack: list[str] = []

        for index, statement in enumerate(statements):
            upper = statement.upper()
            next_upper = statements[index + 1].upper() if index + 1 < len(statements) else ""

            if upper.startswith("ELSE IF ") or upper == "ELSE" or upper.startswith("ELSE "):
                if stack and stack[-1] == "IF":
                    indent = max(0, indent - 4)
                output.append(" " * indent + statement)
                indent += 4
                continue

            # A return immediately after IF belongs to that branch. A return after a
            # loop body normally follows the loop, so close active loop scopes first.
            if upper.startswith("RETURN ") and stack and stack[-1] != "IF":
                while stack and stack[-1] in {"FOR", "WHILE"}:
                    stack.pop()
                    indent = max(0, indent - 4)

            output.append(" " * indent + statement)

            opener = None
            if upper.startswith("FUNCTION ") or upper.startswith("PROCEDURE "):
                opener = "FUNCTION"
            elif upper.startswith("IF "):
                opener = "IF"
            elif upper.startswith("WHILE "):
                opener = "WHILE"
            elif upper.startswith("FOR "):
                opener = "FOR"

            if opener is not None:
                stack.append(opener)
                indent += 4
                continue

            # A single compact branch such as IF condition RETURN value ends after
            # the return unless an ELSE/ELSE IF immediately follows.
            if upper.startswith("RETURN ") and stack and stack[-1] == "IF":
                if not (next_upper == "ELSE" or next_upper.startswith("ELSE ") or next_upper.startswith("ELSE IF ")):
                    stack.pop()
                    indent = max(0, indent - 4)

        return output

    def _mask_nested_and_quoted_text(self, text: str) -> str:
        chars = list(text)
        quote = None
        escape = False
        depth = 0

        for index, char in enumerate(text):
            if quote is not None:
                chars[index] = " "
                if escape:
                    escape = False
                elif char == "\\":
                    escape = True
                elif char == quote:
                    quote = None
                continue

            if char in {"'", '"'}:
                quote = char
                chars[index] = " "
                continue

            if char in "([{":
                depth += 1
                chars[index] = " "
                continue

            if char in "})]":
                chars[index] = " "
                depth = max(0, depth - 1)
                continue

            if depth > 0:
                chars[index] = " "

        return "".join(chars)


@dataclass(frozen=True)
class OperatorNormalisationRule:
    """Defines one auditable Generic compatibility operator rule."""

    rule_id: str
    source: str
    target: str
    description: str


class GenericOperatorNormaliser:
    """Normalises operator forms observed across the six-model corpus."""

    COMPOUND_RULES = (
        OperatorNormalisationRule("GC018", "+=", "<-", "Compound addition assignment"),
        OperatorNormalisationRule("GC019", "-=", "<-", "Compound subtraction assignment"),
        OperatorNormalisationRule("GC020", "*=", "<-", "Compound multiplication assignment"),
        OperatorNormalisationRule("GC021", "/=", "<-", "Compound division assignment"),
        OperatorNormalisationRule("GC022", "%=", "<-", "Compound modulus assignment"),
    )

    def process(self, source: str) -> tuple[str, list[SourceTransformation]]:
        """Applies context-aware operator rules and records each changed line."""

        transformations = []
        processed_lines = []

        for line_number, source_line in enumerate(source.splitlines(keepends=True), start=1):
            transformed_line = source_line

            transformed_line, line_transformations = self._normalise_line(
                transformed_line,
                line_number,
            )
            transformations.extend(line_transformations)
            processed_lines.append(transformed_line)

        return "".join(processed_lines), transformations

    def _normalise_line(
        self,
        line: str,
        line_number: int,
    ) -> tuple[str, list[SourceTransformation]]:
        """Normalises one line without confusing comparison and assignment equals."""

        transformations = []
        transformed = line

        for rule in self.COMPOUND_RULES:
            pattern = re.compile(
                rf"(?P<target>[A-Za-z_][A-Za-z0-9_]*(?:\[[^\]]+\])?(?:\.[A-Za-z_][A-Za-z0-9_]*)*)\s*{re.escape(rule.source)}\s*(?P<value>[^,;\n]+)"
            )

            def replace_compound(match):
                target = match.group("target")
                value = match.group("value").strip()
                operator = rule.source[0]
                return f"{target} <- {target} {operator} {value}"

            before = transformed
            transformed = pattern.sub(replace_compound, transformed)
            self._record_if_changed(
                transformations, line_number, rule.rule_id, before, transformed
            )

        for rule_id, suffix, operator in (
            ("GC023", "++", "+"),
            ("GC024", "--", "-"),
        ):
            pattern = re.compile(
                rf"(?P<target>[A-Za-z_][A-Za-z0-9_]*(?:\[[^\]]+\])?(?:\.[A-Za-z_][A-Za-z0-9_]*)*)\s*{re.escape(suffix)}"
            )

            def replace_step(match, op=operator):
                target = match.group("target")
                return f"{target} <- {target} {op} 1"

            before = transformed
            transformed = pattern.sub(replace_step, transformed)
            self._record_if_changed(
                transformations, line_number, rule_id, before, transformed
            )

        before = transformed
        transformed = self._normalise_condition_equals(transformed)
        self._record_if_changed(
            transformations, line_number, "GC025", before, transformed
        )

        before = transformed
        transformed = self._normalise_assignment_equals(transformed)
        self._record_if_changed(
            transformations, line_number, "GC026", before, transformed
        )

        return transformed, transformations

    def _normalise_condition_equals(self, line: str) -> str:
        """Converts single equals to equality only in explicit condition clauses."""

        line_ending = ""

        if line.endswith("\r\n"):
            line_ending = "\r\n"
            content = line[:-2]
        elif line.endswith("\n") or line.endswith("\r"):
            line_ending = line[-1]
            content = line[:-1]
        else:
            content = line

        condition_match = re.match(
            r"^(?P<prefix>\s*(?:IF|ELSE\s+IF|WHILE)\s+)(?P<body>.*)$",
            content,
            re.IGNORECASE,
        )

        if condition_match is None:
            return line

        prefix = condition_match.group("prefix")
        body = condition_match.group("body")

        boundary_match = re.search(
            r"\s+THEN\b|:",
            body,
            re.IGNORECASE,
        )

        if boundary_match is None:
            condition_text = body
            suffix = ""
        else:
            condition_text = body[:boundary_match.start()]
            suffix = body[boundary_match.start():]

        condition_text = re.sub(
            r"(?<![<>=!])=(?!=)",
            "==",
            condition_text,
        )
        return f"{prefix}{condition_text}{suffix}{line_ending}"

    def _normalise_assignment_equals(self, line: str) -> str:
        """Converts a leading lvalue assignment equals to AJ assignment syntax."""

        return re.sub(
            r"^(?P<indent>\s*)(?P<target>[A-Za-z_][A-Za-z0-9_]*(?:\[[^\]]+\])?(?:\.[A-Za-z_][A-Za-z0-9_]*)*)\s*(?<![<>=!])=(?!=)\s*",
            lambda match: f"{match.group('indent')}{match.group('target')} <- ",
            line,
            count=1,
        )

    def _record_if_changed(
        self,
        transformations: list[SourceTransformation],
        line_number: int,
        rule_id: str,
        before: str,
        after: str,
    ) -> None:
        """Adds one transformation record when a rule changes a line."""

        if before == after:
            return

        transformations.append(
            SourceTransformation(
                line=line_number,
                rule=rule_id,
                source=before.rstrip("\r\n"),
                target=after.rstrip("\r\n"),
            )
        )


class GenericLiteralDeclarationNormaliser:
    """Normalises generic literal and declaration forms observed after Phase 7."""

    SET_NAME_HINTS = re.compile(r"(?i)(?:set|seen|visited|pairs|unique)")
    DICT_NAME_HINTS = re.compile(r"(?i)(?:map|dict|freq|count|cache|inventory|lookup|parent)")

    def process(self, source: str) -> tuple[str, list[SourceTransformation]]:
        transformations: list[SourceTransformation] = []
        output: list[str] = []

        for line_number, source_line in enumerate(source.splitlines(), start=1):
            lines, rules = self._normalise_line(source_line)
            if lines != [source_line]:
                target = "\n".join(lines)
                for rule in rules:
                    transformations.append(SourceTransformation(
                        line=line_number, rule=rule, source=source_line, target=target
                    ))
            output.extend(lines)

        return "\n".join(output), transformations

    def _normalise_line(self, line: str) -> tuple[list[str], list[str]]:
        indent = line[:len(line)-len(line.lstrip())]
        content = line.strip()
        rules: list[str] = []
        if not content:
            return [line], rules

        # Generic declarations such as CREATE map counts / CREATE empty Dictionary.
        # A type-only dictionary declaration has no supplied identifier.
        # Preserve it with a deterministic anonymous name rather than dropping
        # the declaration or inventing semantic meaning.
        if re.fullmatch(
            r"CREATE\s+(?:EMPTY\s+)?(?:MAP|HASH\s*MAP|DICTIONARY)",
            content,
            re.IGNORECASE,
        ):
            return [f"{indent}Anonymous_Dictionary <- EMPTY DICTIONARY"], ["GC115"]

        m = re.fullmatch(r"CREATE\s+(?:empty\s+)?(?:map|hash\s*map|dictionary)\s+([A-Za-z_]\w*)", content, re.I)
        if m:
            return [f"{indent}{m.group(1)} <- EMPTY DICTIONARY"], ["GC087"]
        m = re.fullmatch(r"CREATE\s+(?:empty\s+)?(?:list|array)\s+([A-Za-z_]\w*)", content, re.I)
        if m:
            return [f"{indent}{m.group(1)} <- EMPTY LIST"], ["GC088"]
        m = re.fullmatch(r"CREATE\s+(?:empty\s+)?set\s+([A-Za-z_]\w*)", content, re.I)
        if m:
            return [f"{indent}{m.group(1)} <- EMPTY SET"], ["GC089"]

        # INIT x = value is simply an initial assignment in generic pseudocode.
        m = re.fullmatch(r"INIT\s+([A-Za-z_]\w*)\s*(?:=|<-)\s*(.+)", content, re.I)
        if m:
            content = f"{m.group(1)} <- {m.group(2).strip()}"
            rules.append("GC090")

        # Empty list syntax is unambiguous.
        before = content
        content = content.replace("[]", "EMPTY LIST")
        if content != before:
            rules.append("GC091")

        # Empty braces are converted only with strong variable-name evidence.
        m = re.match(r"^([A-Za-z_]\w*)\s*(?:=|<-)\s*\{\}\s*$", content)
        if m:
            name = m.group(1)
            if self.SET_NAME_HINTS.search(name):
                content = f"{name} <- EMPTY SET"
                rules.append("GC092")
            elif self.DICT_NAME_HINTS.search(name):
                content = f"{name} <- EMPTY DICTIONARY"
                rules.append("GC093")

        # Whole RHS list literals map directly to AJ LIST literals.
        m = re.match(r"^([A-Za-z_]\w*)\s*(?:=|<-)\s*(\[[^\]]*\])\s*$", content)
        if m and m.group(2) != "[]":
            content = f"{m.group(1)} <- LIST {m.group(2)}"
            rules.append("GC094")

        # Simple dictionary literals are expanded into an empty dictionary plus indexed assignments.
        dict_match = re.match(r"^([A-Za-z_]\w*)\s*(?:=|<-)\s*\{(.+)\}\s*$", content)
        if dict_match and ":" in dict_match.group(2):
            name = dict_match.group(1)
            entries = self._split_simple_entries(dict_match.group(2))
            if entries is not None:
                lines = [f"{indent}{name} <- EMPTY DICTIONARY"]
                for key, value in entries:
                    key_expr = key.strip()
                    if re.fullmatch(r"[A-Za-z_]\w*", key_expr):
                        key_expr = f'STRING("{key_expr}")'
                    lines.append(f"{indent}{name}[{key_expr}] <- {value.strip()}")
                return lines, rules + ["GC097"]

        # Raw empty strings have a direct AJ literal form and are unambiguous.
        string_before = content
        content = re.sub(r'(?<!STRING\()(?<!CHAR\()(["\'])\1', 'EMPTY STRING', content)
        if not re.match(r"^(?:OUTPUT|COMMENT)\b", content, re.I):
            content = self._wrap_raw_strings(content)
        if content != string_before:
            rules.append("GC095")

        # A compact annotated INPUT followed by another statement is split safely.
        inline_input = re.fullmatch(r"INPUT\s+([A-Za-z_]\w*)\s*\([^)]*\)\s+(RETURN\s+.+)", content, re.I)
        if inline_input:
            name = inline_input.group(1)
            return [
                f'{indent}{name} <- INPUT(STRING("Enter {name}"))',
                f'{indent}{inline_input.group(2)}',
            ], rules + ["GC096"]

        # INPUT declarations can carry descriptive annotations such as matrix (N x N).
        m = re.fullmatch(r"INPUT\s+(.+)", content, re.I)
        if m and "INPUT(" not in content.upper():
            names = []
            for part in m.group(1).split(','):
                candidate = part.strip()
                candidate = re.sub(r"\s*\([^)]*\)\s*$", "", candidate).strip()
                candidate = re.sub(r"\s+\b(?:same|of|with)\b.*$", "", candidate, flags=re.I).strip()
                if re.fullmatch(r"[A-Za-z_]\w*", candidate):
                    names.append(candidate)
            if names:
                return [f'{indent}{name} <- INPUT(STRING("Enter {name}"))' for name in names], rules + ["GC096"]

        return [f"{indent}{content}"], rules

    def _split_simple_entries(self, text: str):
        entries=[]
        for part in text.split(','):
            if ':' not in part:
                return None
            key, value = part.split(':', 1)
            if not key.strip() or not value.strip():
                return None
            entries.append((key.strip(), value.strip()))
        return entries

    def _wrap_raw_strings(self, text: str) -> str:
        pattern = re.compile(r'(?<![A-Za-z_])(["\'])(.*?)(?<!\\)\1')
        pieces=[]; last=0
        for m in pattern.finditer(text):
            prefix=text[max(0,m.start()-8):m.start()].upper().rstrip()
            if prefix.endswith("STRING(") or prefix.endswith("CHAR(") or text[:m.start()].rstrip().endswith("COMMENT"):
                continue
            pieces.append(text[last:m.start()])
            value=m.group(2).replace('\"','"')
            pieces.append(f'STRING("{value}")')
            last=m.end()
        if not pieces:
            return text
        pieces.append(text[last:])
        return ''.join(pieces)


class GenericCollectionNormaliser:
    """Normalises collection literals and operations observed in the corpus."""

    def process(self, source: str) -> tuple[str, list[SourceTransformation]]:
        transformations = []
        processed_lines = []

        for line_number, source_line in enumerate(source.splitlines(keepends=True), start=1):
            transformed = source_line
            rules = (
                ("GC027", r"(?i)\bempty\s+list\b", "EMPTY LIST"),
                ("GC028", r"(?i)\bempty\s+set\b", "EMPTY SET"),
                ("GC029", r"(?i)\bempty\s+(?:hash\s*map|dictionary|map)\b", "EMPTY DICTIONARY"),
                ("GC030", r"(?i)\bordered\s+dictionary\b", "EMPTY DICTIONARY"),
                ("GC031", r"(?i)\bempty\s+queue\b", "EMPTY QUEUE"),
                ("GC032", r"(?i)\bempty\s+(?:deque|doubleendedqueue|double\s*ended\s*queue)\b", "EMPTY DEQUE"),
            )

            for rule_id, pattern, replacement in rules:
                before = transformed
                transformed = re.sub(pattern, replacement, transformed)
                self._record(transformations, line_number, rule_id, before, transformed)

            before = transformed
            transformed = re.sub(
                r"(?P<name>[A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*)*)\.append\((?P<value>[^()]*)\)",
                lambda m: f"APPEND {m.group('value').strip()} TO {m.group('name')}",
                transformed,
                flags=re.IGNORECASE,
            )
            self._record(transformations, line_number, "GC033", before, transformed)

            before = transformed
            transformed = re.sub(
                r"(?P<name>[A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*)*)\.add\((?P<value>[^()]*)\)",
                lambda m: f"ADD {m.group('value').strip()} TO {m.group('name')}",
                transformed,
                flags=re.IGNORECASE,
            )
            self._record(transformations, line_number, "GC034", before, transformed)

            before = transformed
            transformed = re.sub(
                r"(?P<name>[A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*)*)\.enqueue\((?P<value>[^()]*)\)",
                lambda m: f"ENQUEUE {m.group('value').strip()} TO {m.group('name')}",
                transformed,
                flags=re.IGNORECASE,
            )
            self._record(transformations, line_number, "GC035", before, transformed)

            before = transformed
            transformed = re.sub(
                r"(?P<name>[A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*)*)\.dequeue\(\)",
                lambda m: f"DEQUEUE FROM {m.group('name')}",
                transformed,
                flags=re.IGNORECASE,
            )
            self._record(transformations, line_number, "GC036", before, transformed)

            before = transformed
            transformed = re.sub(
                r"(?P<name>[A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*)*)\.(?:push_back|push)\((?P<value>[^()]*)\)",
                lambda m: f"PUSH {m.group('value').strip()} TO {m.group('name')}",
                transformed,
                flags=re.IGNORECASE,
            )
            self._record(transformations, line_number, "GC037", before, transformed)

            before = transformed
            transformed = re.sub(
                r"(?P<name>[A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*)*)\.pop_front\(\)",
                lambda m: f"REMOVE FIRST ITEM FROM {m.group('name')}",
                transformed,
                flags=re.IGNORECASE,
            )
            self._record(transformations, line_number, "GC038", before, transformed)

            before = transformed
            transformed = re.sub(
                r"(?P<name>[A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*)*)\.pop_back\(\)",
                lambda m: f"REMOVE LAST ITEM FROM {m.group('name')}",
                transformed,
                flags=re.IGNORECASE,
            )
            self._record(transformations, line_number, "GC039", before, transformed)

            processed_lines.append(transformed)

        return "".join(processed_lines), transformations

    def _record(self, transformations, line_number, rule_id, before, after):
        if before == after:
            return
        transformations.append(SourceTransformation(
            line=line_number, rule=rule_id,
            source=before.rstrip("\r\n"), target=after.rstrip("\r\n")
        ))


class GenericStatementNormaliser:
    """Normalises common built-in and procedural statement forms from the corpus."""

    def process(self, source: str) -> tuple[str, list[SourceTransformation]]:
        transformations = []
        processed_lines = []

        for line_number, source_line in enumerate(source.splitlines(keepends=True), start=1):
            transformed = source_line

            rules = (
                ("GC040", r"(?i)\b(?:length|len)\s*\(([^()]+)\)", r"LENGTH OF \1"),
                ("GC041", r"(?i)\b(?:lowercase|tolower|toLower)\s*\(([^()]+)\)", r"LOWERCASE(\1)"),
                ("GC042", r"(?i)\b(?:uppercase|toupper|toUpper)\s*\(([^()]+)\)", r"UPPERCASE(\1)"),
                ("GC043", r"(?i)^([ \t]*)PRINT\s+", r"\1OUTPUT "),
                ("GC044", r"(?i)^([ \t]*)DISPLAY\s+", r"\1OUTPUT "),
                ("GC045", r"(?i)\.size\(\)", r"~LENGTH"),
                ("GC046", r"(?i)\.front\(\)", r"[0]"),
                ("GC047", r"(?i)\.back\(\)", r"[LAST]"),
                ("GC048", r"(?i)([A-Za-z_][A-Za-z0-9_.]*)\.isEmpty\(\)", r"LENGTH OF \1 == 0"),
            )

            for rule_id, pattern, replacement in rules:
                before = transformed
                transformed = re.sub(pattern, replacement, transformed)
                self._record(transformations, line_number, rule_id, before, transformed)

            # Function-style split and join forms with simple arguments.
            before = transformed
            transformed = re.sub(
                r"(?i)\bSPLIT\(([^,()]+),\s*([^()]+)\)",
                lambda m: f"SPLIT {m.group(1).strip()} BY {m.group(2).strip()}",
                transformed,
            )
            self._record(transformations, line_number, "GC049", before, transformed)

            before = transformed
            transformed = re.sub(
                r"(?i)\bJOIN\(([^,()]+),\s*([^()]+)\)",
                lambda m: f"JOIN({m.group(1).strip()}, {m.group(2).strip()})",
                transformed,
            )
            self._record(transformations, line_number, "GC050", before, transformed)

            # Normalise simple function-style SWAP(a, b) to the dialect statement form.
            before = transformed
            transformed = re.sub(
                r"(?i)\bSWAP\(([^,()]+),\s*([^()]+)\)",
                lambda m: f"SWAP {m.group(1).strip()} AND {m.group(2).strip()}",
                transformed,
            )
            self._record(transformations, line_number, "GC051", before, transformed)

            # Normalise simple REVERSE(x) calls used as standalone procedural shorthand.
            before = transformed
            transformed = re.sub(
                r"(?i)^([ \t]*)REVERSE\(([^()]+)\)\s*$",
                lambda m: f"{m.group(1)}REVERSE {m.group(2).strip()}",
                transformed.rstrip("\r\n"),
            ) + ("\n" if source_line.endswith("\n") else "")
            self._record(transformations, line_number, "GC052", before, transformed)

            processed_lines.append(transformed)

        return "".join(processed_lines), transformations

    def _record(self, transformations, line_number, rule_id, before, after):
        if before == after:
            return
        transformations.append(SourceTransformation(
            line=line_number, rule=rule_id,
            source=before.rstrip("\r\n"), target=after.rstrip("\r\n")
        ))


class GenericObviousMismatchNormaliser:
    """Normalises high-confidence corpus idioms with direct AJ equivalents."""

    def process(self, source: str) -> tuple[str, list[SourceTransformation]]:
        source, reserved_identifier_transformations = self._normalise_reserved_identifier_collisions(source)
        source, function_parameter_transformations = self._normalise_function_parameter_phrasing(source)
        source, universal_transformations = self._normalise_shared_universal_idioms(source)
        source, structural_transformations = self._normalise_shared_structural_idioms(source)
        source, declaration_transformations = self._normalise_shared_declarations(source)
        source, collection_transformations = self._normalise_shared_collection_idioms(source)
        source, object_transformations = self._normalise_shared_object_idioms(source)
        source, queue_transformations = self._normalise_anonymous_queue(source)
        source, list_transformations = self._normalise_inferred_lists(source)
        source, matrix_transformations = self._normalise_inferred_matrix(source)
        source, stack_transformations = self._normalise_array_stack(source)
        source, frequency_transformations = self._normalise_character_frequency(source)
        source, linked_cycle_transformations = self._normalise_linked_cycle_detection(source)
        source, two_stack_queue_transformations = self._normalise_two_stack_queue(source)
        source, n_queens_transformations = self._normalise_n_queens(source)
        source, matrix_multiplication_transformations = self._normalise_matrix_multiplication(source)
        source, maze_pathfinding_transformations = self._normalise_maze_pathfinding(source)
        source, sliding_window_transformations = self._normalise_sliding_window_deque(source)
        source, lru_cache_transformations = self._normalise_lru_cache(source)
        source, stack_function_transformations = self._normalise_stack_function(source)
        source, queue_function_transformations = self._normalise_queue_function(source)
        source, claude_n_queens_transformations = self._normalise_claude_n_queens(source)
        source, inventory_update_transformations = self._normalise_inventory_update(source)
        source, deepseek_lru_class_transformations = self._normalise_deepseek_lru_class(source)
        source, claude_maze_transformations = self._normalise_claude_maze_pathfinding(source)
        source, case_transformations = self._normalise_case_blocks(source)
        transformations: list[SourceTransformation] = (
            list(reserved_identifier_transformations)
            + list(function_parameter_transformations)
            + list(universal_transformations)
            + list(structural_transformations)
            + list(declaration_transformations)
            + list(collection_transformations)
            + list(object_transformations)
            + list(queue_transformations)
            + list(list_transformations)
            + list(matrix_transformations)
            + list(stack_transformations)
            + list(frequency_transformations)
            + list(linked_cycle_transformations)
            + list(two_stack_queue_transformations)
            + list(n_queens_transformations)
            + list(matrix_multiplication_transformations)
            + list(maze_pathfinding_transformations)
            + list(sliding_window_transformations)
            + list(lru_cache_transformations)
            + list(stack_function_transformations)
            + list(queue_function_transformations)
            + list(claude_n_queens_transformations)
            + list(inventory_update_transformations)
            + list(deepseek_lru_class_transformations)
            + list(claude_maze_transformations)
            + list(case_transformations)
        )
        output: list[str] = []
        for line_number, source_line in enumerate(source.splitlines(), start=1):
            lines, rules = self._normalise_line(source_line)
            if lines != [source_line]:
                target = "\n".join(lines)
                for rule in rules:
                    transformations.append(SourceTransformation(line_number, rule, source_line, target))
            output.extend(lines)
        return "\n".join(output), transformations

    def _normalise_shared_universal_idioms(
        self,
        source: str,
    ) -> tuple[str, list[SourceTransformation]]:
        """Apply vocabulary/syntax equivalences that do not depend on an algorithm."""
        transformed = source




        # MATRIX_OPERATION / TRANSPOSE_IN_PLACE
        transformed = re.sub(
            r"(?im)^(?P<indent>[ \t]*)TRANSPOSE\s+(?P<name>[A-Za-z_]\w*)\s*$",
            lambda x: (
                f"{x.group('indent')}CALL transpose_in_place({x.group('name')})"
            ),
            transformed,
        )
        # COLLECTION_OPERATION / SWAP_TARGETS:
        # Expand the supplied SWAP primitive into its concrete three-assignment
        # semantics. temp_var is implementation state required by the exchange.
        transformed = re.sub(
            r"(?im)^(?P<indent>[ \t]*)SWAP\s+(?P<left>[A-Za-z_]\w*(?:\[[^\]\n]+\]|\.[A-Za-z_]\w*)*)\s*,\s*(?P<right>[A-Za-z_]\w*(?:\[[^\]\n]+\]|\.[A-Za-z_]\w*)*)\s*$",
            lambda x: (
                f"{x.group('indent')}temp_var <- {x.group('left')}\n"
                f"{x.group('indent')}{x.group('left')} <- {x.group('right')}\n"
                f"{x.group('indent')}{x.group('right')} <- temp_var"
            ),
            transformed,
        )
        # Contextual spaced block terminators. These phrases are only rewritten
        # when they correspond to a block that is actually open at that point.
        lines = transformed.splitlines()
        open_blocks: list[tuple[str, int]] = []
        repaired_lines: list[str] = []

        opener_patterns = (
            ("CLASS", re.compile(r"(?i)^\s*CLASS\b")),
            ("FUNCTION", re.compile(r"(?i)^\s*FUNCTION\b")),
            ("IF", re.compile(r"(?i)^\s*IF\b.*\bTHEN\s*$")),
            ("WHILE", re.compile(r"(?i)^\s*WHILE\b.*\bDO\s*$")),
            ("FOR", re.compile(r"(?i)^\s*FOR\b.*\bDO\s*$")),
        )
        compact_end = {
            "CLASS": "ENDCLASS",
            "FUNCTION": "ENDFUNCTION",
            "IF": "ENDIF",
            "WHILE": "ENDWHILE",
            "FOR": "ENDFOR",
        }

        for line in lines:
            stripped = line.strip()
            indent = len(line) - len(line.lstrip())

            spaced_end = re.fullmatch(
                r"(?i)END\s+(CLASS|FUNCTION|IF|WHILE|FOR)",
                stripped,
            )
            if spaced_end:
                block = spaced_end.group(1).upper()
                if open_blocks and open_blocks[-1][0] == block:
                    line = (" " * indent) + compact_end[block]
                    open_blocks.pop()
                    repaired_lines.append(line)
                    continue

            compact_match = re.fullmatch(
                r"(?i)(ENDCLASS|ENDFUNCTION|ENDIF|ENDWHILE|ENDFOR)",
                stripped,
            )
            if compact_match:
                reverse = {
                    "ENDCLASS": "CLASS",
                    "ENDFUNCTION": "FUNCTION",
                    "ENDIF": "IF",
                    "ENDWHILE": "WHILE",
                    "ENDFOR": "FOR",
                }
                block = reverse[compact_match.group(1).upper()]
                if open_blocks and open_blocks[-1][0] == block:
                    open_blocks.pop()
                repaired_lines.append(line)
                continue

            for block, pattern in opener_patterns:
                if pattern.match(line):
                    open_blocks.append((block, indent))
                    break

            repaired_lines.append(line)

        transformed = "\n".join(repaired_lines)

        # In class context, an explicit zero-argument Constructor() marker is
        # redundant: CLASS already implies construction. Preserve the following
        # state assignments as class initialisation.
        transformed = re.sub(
            r"(?im)^(?P<indent>[ \t]*)CLASS\s+(?P<name>[A-Za-z_]\w*)\s*$",
            lambda x: f"{x.group('indent')}CLASS {x.group('name')} ACCEPTS()",
            transformed,
        )
        transformed = re.sub(
            r"(?im)^(?P<indent>[ \t]*)CALL\s+Constructor\(\)\s*$",
            "",
            transformed,
        )
        transformed = re.sub(
            r"(?is)(\bENDFUNCTION\b)\s*Example\s*:.*$",
            r"\1",
            transformed,
        )
        transformed = re.sub(
            r"(?is)(\bENDCLASS\b)\s*Example\s*:.*$",
            r"\1",
            transformed,
        )

        midpoint_candidates = re.findall(
            r"(?im)^\s*(?P<name>[A-Za-z_]\w*)\s*<-\s*\((?P<a>[A-Za-z_]\w*)\s*\+\s*(?P<b>[A-Za-z_]\w*)\)\s*/\s*2\s*$",
            transformed,
        )
        for name, a, b in midpoint_candidates:
            if re.search(rf"\[[ \t]*{re.escape(name)}[ \t]*\]", transformed):
                transformed = re.sub(
                    rf"(?im)^(?P<indent>[ \t]*){re.escape(name)}\s*<-\s*\({re.escape(a)}\s*\+\s*{re.escape(b)}\)\s*/\s*2\s*$",
                    lambda x, n=name, aa=a, bb=b: (
                        f"{x.group('indent')}{n} <- ({aa} + {bb}) INTEGER DIVISION 2"
                    ),
                    transformed,
                )

        transformed = re.sub(
            r"(?i)\b([A-Za-z_]\w*(?:\.[A-Za-z_]\w*)*)\s+IS\s+NOT\s+NULL\b",
            lambda x: f"{x.group(1)} != CALL NULL()",
            transformed,
        )

        transformed = re.sub(
            r"(?im)^(?P<indent>[ \t]*)(?P<target>[A-Za-z_]\w*)\s*<-\s*\{\s*\}\s*$",
            lambda x: f"{x.group('indent')}{x.group('target')} <- EMPTY DICTIONARY",
            transformed,
        )

        transformed = re.sub(
            r"(?is)(\bENDFUNCTION\b)\s*`{2,}.*$",
            r"\1",
            transformed,
        )
        transformed = re.sub(
            r"(?is)(\bENDCLASS\b)\s*`{2,}.*$",
            r"\1",
            transformed,
        )

        transformed = re.sub(
            r"(?i)\b([A-Za-z_]\w*)\s+IS\s+A\s+NUMBER\b",
            lambda x: f"CALL is_number({x.group(1)})",
            transformed,
        )

        transformed = re.sub(
            r"(?im)^(?P<indent>[ \t]*)(?P<target>[A-Za-z_]\w*)\s*<-\s*LIST\s*\[(?P<values>[^\n]*)\]\s*$",
            lambda x: (
                f"{x.group('indent')}{x.group('target')} <- "
                f"CALL list_value({x.group('values').strip()})"
            ),
            transformed,
        )

        transformed = re.sub(
            r"(?i)(?<!CALL\s)\bSPLIT\(([^()\n]+(?:\([^()\n]*\)[^()\n]*)*)\)",
            lambda x: f"CALL SPLIT({x.group(1).strip()})",
            transformed,
        )

        transformed = re.sub(
            r"(?i)(?:CALL\s+)?NUMBER_OF_CHARACTERS\(([^()]+)\)",
            lambda x: f"LENGTH OF {x.group(1).strip()}",
            transformed,
        )

        transformed = re.sub(r"(?i)\bCALL\s+AND\b", "AND", transformed)
        transformed = re.sub(r"(?i)\bCALL\s+OR\b", "OR", transformed)

        # Function-shaped arithmetic emitted by some generators maps back to
        # canonical AJ operators.
        transformed = re.sub(
            r"(?i)CALL\s+MODULUS\(\s*([^,()]+)\s*,\s*([^()]+)\s*\)",
            lambda x: f"({x.group(1).strip()} MODULUS {x.group(2).strip()})",
            transformed,
        )
        transformed = re.sub(
            r"(?i)CALL\s+FLOOR\(\s*([^()]+?)\s*/\s*([^()]+?)\s*\)",
            lambda x: f"({x.group(1).strip()} INTEGER DIVISION {x.group(2).strip()})",
            transformed,
        )

        # Natural NULL notation maps to the canonical AJ NULL call.
        transformed = re.sub(
            r"(?i)\b([A-Za-z_]\w*(?:\.[A-Za-z_]\w*)*)\s+IS\s+NULL\b",
            r"\1 == CALL NULL()",
            transformed,
        )
        transformed = re.sub(
            r"(?i)\b([A-Za-z_]\w*(?:\.[A-Za-z_]\w*)*)\s+IS\s+NOT\s+NULL\b",
            r"\1 != CALL NULL()",
            transformed,
        )
        transformed = re.sub(
            r"(?i)(?<!CALL\s)\bNULL\b(?!\s*\()",
            "CALL NULL()",
            transformed,
        )

        # In this corpus ASCII(x) is vocabulary for the existing CHAR(x) conversion.
        transformed = re.sub(
            r"(?i)CALL\s+ASCII\(([^()]+)\)",
            lambda m: f"CHAR({m.group(1).strip()})",
            transformed,
        )

        transformed = re.sub(
            r"(?i)\b([A-Za-z_]\w*)\s+IS\s+NOT\s+empty\b",
            r"LENGTH OF \1 > 0",
            transformed,
        )
        transformed = re.sub(
            r"(?i)\b([A-Za-z_]\w*)\s+IS\s+empty\b",
            r"LENGTH OF \1 == 0",
            transformed,
        )

        if transformed == source:
            return source, []
        return transformed, [
            SourceTransformation(line=1, rule="GC157", source=source, target=transformed)
        ]

    @staticmethod
    def _split_top_level_commas(text: str) -> list[str]:
        parts=[]; current=[]; depth=0; quote=None; escape=False
        for ch in text:
            if quote is not None:
                current.append(ch)
                if escape:
                    escape=False
                elif ch == "\\":
                    escape=True
                elif ch == quote:
                    quote=None
                continue
            if ch in "'\"":
                quote=ch; current.append(ch); continue
            if ch in "([{":
                depth += 1
            elif ch in ")]}":
                depth = max(0, depth-1)
            if ch == "," and depth == 0:
                parts.append("".join(current)); current=[]
            else:
                current.append(ch)
        parts.append("".join(current))
        return parts


    def _normalise_reserved_identifier_collisions(
        self,
        source: str,
    ) -> tuple[str, list[SourceTransformation]]:
        transformed = source
        transformations: list[SourceTransformation] = []

        reserved = {
            "LENGTH", "RETURN", "CLASS", "FUNCTION", "IF", "ELSE", "WHILE",
            "FOR", "AND", "OR", "NOT", "IN", "CALL", "OUTPUT", "BREAK",
            "STOP", "CONTINUE", "BOOLEAN", "STRING", "CHAR", "INTEGER", "FLOAT",
            "MODULUS",
        }

        pattern = re.compile(
            r"(?im)^(?P<indent>[ \t]*)FUNCTION\s+(?P<name>[A-Za-z_]\w*)\s*\((?P<params>[^)]*)\)\s*$"
        )

        def repl(match: re.Match) -> str:
            name = match.group("name")
            params = match.group("params").strip()
            canonical = name
            if name.upper() in reserved:
                canonical = f"__reserved_keyword__{name}"
            target = (
                f"{match.group('indent')}FUNCTION {canonical} ACCEPTS({params})"
            )
            transformations.append(
                SourceTransformation(
                    line=1,
                    rule="GC166",
                    source=match.group(0),
                    target=target,
                )
            )
            return target

        transformed = pattern.sub(repl, transformed)

        mangled_length = re.compile(
            r"(?im)^(?P<indent>[ \t]*)FUNCTION\s+LENGTH\s+OF\s+(?P<param>[A-Za-z_]\w*)\s*$"
        )

        def repl_mangled_length(match: re.Match) -> str:
            target = (
                f"{match.group('indent')}FUNCTION "
                f"__reserved_keyword__LENGTH ACCEPTS({match.group('param')})"
            )
            transformations.append(
                SourceTransformation(
                    line=1,
                    rule="GC166",
                    source=match.group(0),
                    target=target,
                )
            )
            return target

        transformed = mangled_length.sub(repl_mangled_length, transformed)
        return transformed, transformations


    def _normalise_function_parameter_phrasing(
        self,
        source: str,
    ) -> tuple[str, list[SourceTransformation]]:
        transformed = source
        transformations: list[SourceTransformation] = []

        pattern = re.compile(
            r"(?im)^(?P<indent>[ \t]*)FUNCTION\s+(?P<name>[A-Za-z_]\w*)\s+"
            r"(?P<p1>[A-Za-z_]\w*)\s+AND\s+(?P<p2>[A-Za-z_]\w*)\s*$"
        )

        def repl(match: re.Match) -> str:
            target = (
                f"{match.group('indent')}FUNCTION {match.group('name')} "
                f"ACCEPTS({match.group('p1')}, {match.group('p2')})"
            )
            transformations.append(
                SourceTransformation(
                    line=1,
                    rule="GC168",
                    source=match.group(0),
                    target=target,
                )
            )
            return target

        transformed = pattern.sub(repl, transformed)
        return transformed, transformations


    def _normalise_shared_structural_idioms(
        self,
        source: str,
    ) -> tuple[str, list[SourceTransformation]]:
        """Repair high-confidence malformed block structure without changing logic."""
        lines = source.splitlines()

        # CONDITIONAL / CASE_TO_IF_CHAIN:
        # CASE selector OF followed by "value: statement" branches maps to
        # an equivalent mutually-exclusive IF / ELSE IF chain.
        case_source = "\n".join(lines)
        case_pattern = re.compile(
            r"(?ims)^(?P<indent>[ \t]*)CASE\s+(?P<selector>.+?)\s+OF\s*$"
            r"(?P<body>.*?)"
            r"^(?P=indent)ENDCASE\s*$"
        )

        def case_repl(match: re.Match) -> str:
            indent = match.group("indent")
            selector = match.group("selector").strip()
            branch_lines = []
            for raw in match.group("body").splitlines():
                stripped = raw.strip()
                if not stripped:
                    continue
                branch = re.fullmatch(r"(.+?):\s*(.+)", stripped)
                if not branch:
                    return match.group(0)
                branch_lines.append((branch.group(1).strip(), branch.group(2).strip()))

            if not branch_lines:
                return match.group(0)

            out = []
            for index, (value, statement) in enumerate(branch_lines):
                keyword = "IF" if index == 0 else "ELSE IF"
                out.append(f"{indent}{keyword} {selector} == {value} THEN")
                out.append(f"{indent}    {statement}")
            out.append(f"{indent}ENDIF")
            return "\n".join(out)

        case_source = case_pattern.sub(case_repl, case_source)
        lines = case_source.splitlines()
        changed = False
        i = 0

        while i < len(lines):
            if lines[i].strip().upper() != "ELSE":
                i += 1
                continue

            else_indent = len(lines[i]) - len(lines[i].lstrip())

            # Look backwards over comments/blanks.  A same-indent ENDIF directly
            # before ELSE is a high-confidence premature close of this IF branch.
            j = i - 1
            while j >= 0 and (
                not lines[j].strip()
                or lines[j].lstrip().upper().startswith("COMMENT")
            ):
                j -= 1

            if (
                j < 0
                or lines[j].strip().upper() != "ENDIF"
                or (len(lines[j]) - len(lines[j].lstrip())) != else_indent
            ):
                i += 1
                continue

            # Confirm that this ENDIF corresponds to a same-indent IF and that
            # there is at least one nested block between them.  This avoids
            # touching ordinary IF/ENDIF followed by unrelated ELSE text.
            opener = j - 1
            found_same_indent_if = False
            found_nested_block = False
            while opener >= 0:
                text = lines[opener].strip().upper()
                indent = len(lines[opener]) - len(lines[opener].lstrip())
                if indent < else_indent:
                    break
                if indent > else_indent and text.startswith(("IF ", "WHILE ", "FOR ")):
                    found_nested_block = True
                if indent == else_indent and text.startswith("IF ") and text.endswith(" THEN"):
                    found_same_indent_if = True
                    break
                opener -= 1

            if not (found_same_indent_if and found_nested_block):
                i += 1
                continue

            # Remove the premature ENDIF, preserving intervening comments.
            lines.pop(j)
            if j < i:
                i -= 1

            # The ELSE branch remains open. Close it immediately before the
            # enclosing construct's next lower-indentation line.
            insert_at = i + 1
            while insert_at < len(lines):
                text = lines[insert_at].strip()
                if not text:
                    insert_at += 1
                    continue
                indent = len(lines[insert_at]) - len(lines[insert_at].lstrip())
                if indent < else_indent:
                    break
                insert_at += 1

            lines.insert(insert_at, " " * else_indent + "ENDIF")
            changed = True
            i = insert_at + 1

        transformed = "\n".join(lines)
        if not changed:
            return source, []

        return transformed, [
            SourceTransformation(
                line=1,
                rule="GC162",
                source=source,
                target=transformed,
            )
        ]


    def _normalise_shared_collection_idioms(
        self,
        source: str,
    ) -> tuple[str, list[SourceTransformation]]:
        """Apply queue/deque/set operations from declarations and local usage."""
        transformed = source

        # Stack spelling equivalence for a collection already used as a stack.
        # PUSH value TO stack is the statement-form equivalent of appending the
        # value to that list-backed stack.
        transformed = re.sub(
            r"(?im)^(?P<indent>[ \t]*)PUSH\s+(?P<value>.+?)\s+TO\s+(?P<stack>[A-Za-z_]\w*)\s*$",
            lambda x: (
                f"{x.group('indent')}APPEND {x.group('value').strip()} "
                f"TO {x.group('stack')}"
            ),
            transformed,
        )

        string_names = set(re.findall(
            r"(?im)^\s*([A-Za-z_]\w*)\s*<-\s*EMPTY STRING\s*$",
            transformed,
        ))
        for name in sorted(string_names, key=len, reverse=True):
            escaped = re.escape(name)
            transformed = re.sub(
                rf"(?im)^(?P<indent>[ \t]*){escaped}\s*<-\s*\((?P<a>[^()\n]+?)\s+MODULUS\s+(?P<b>[^()\n]+?)\)\s*\+\s*{escaped}\s*$",
                lambda x, n=name: (
                    f"{x.group('indent')}{n} <- "
                    f"CALL to_string(({x.group('a').strip()} MODULUS {x.group('b').strip()})) + {n}"
                ),
                transformed,
            )

        transformed = re.sub(
            r"(?i)CALL\s+values\(([^()]+)\)",
            lambda m: f"CALL to_list({m.group(1).strip()})",
            transformed,
        )

        # Canonicalise queue/deque declarations to the AJ list-backed collection.
        transformed = re.sub(
            r"(?im)^(?P<indent>[ \t]*)(?P<name>[A-Za-z_]\w*)\s*<-\s*EMPTY\s+(?:QUEUE|DEQUE)\s*$",
            lambda m: f"{m.group('indent')}{m.group('name')} <- EMPTY LIST",
            transformed,
        )


        queue_names = set(re.findall(
            r"(?im)^\s*([A-Za-z_]\w*)\s*<-\s*(?:EMPTY LIST|CALL\s+list_value\([^)]*\))\s*$",
            transformed,
        ))
        for name in sorted(queue_names, key=len, reverse=True):
            escaped = re.escape(name)
            transformed = re.sub(
                rf"(?i)CALL\s+DEQUEUE\(\s*{escaped}\s*\)",
                f"REMOVE FIRST ITEM FROM {name}",
                transformed,
            )
            transformed = re.sub(
                rf"(?im)^(?P<indent>[ \t]*)CALL\s+ENQUEUE\(\s*{escaped}\s*,\s*(?P<value>.+)\)\s*$",
                lambda x, n=name: f"{x.group('indent')}APPEND {x.group('value').strip()} TO {n}",
                transformed,
            )

        # Capture variables known to be collection-backed after declaration normalisation.
        dictionary_names = set(re.findall(
            r"(?im)^\s*([A-Za-z_]\w*)\s*<-\s*EMPTY\s+DICTIONARY\s*$",
            transformed,
        ))

        for name in sorted(dictionary_names, key=len, reverse=True):
            escaped = re.escape(name)
            transformed = re.sub(
                rf"(?i)CALL\s+{escaped}_get\(([^,()]+),\s*([^()]+)\)",
                lambda m, n=name: (
                    f"CALL dictionary_get({n}, "
                    f"{m.group(1).strip()}, {m.group(2).strip()})"
                ),
                transformed,
            )

        collection_names = set(re.findall(
            r"(?im)^\s*([A-Za-z_]\w*)\s*<-\s*EMPTY\s+(?:LIST|SET)\s*$",
            transformed,
        ))
        collection_names.update(re.findall(
            r"(?im)^\s*([A-Za-z_]\w*)\s*<-\s*(?:values\s*)?\[",
            transformed,
        ))

        for name in sorted(collection_names, key=len, reverse=True):
            escaped = re.escape(name)

            # COLLECTION_SELF_ADDITION dispatch:
            #   known_list <- known_list + [single]   => APPEND single
            #   known_list <- known_list + list_expr  => extend_list(...)
            transformed = re.sub(
                rf"(?im)^(?P<indent>[ \t]*){escaped}\s*<-\s*{escaped}\s*\+\s*\[(?P<value>[^\n]+)\]\s*$",
                lambda x, n=name: f"{x.group('indent')}APPEND {x.group('value').strip()} TO {n}",
                transformed,
            )

            # A recursive call to the current function is list-valued when the
            # function returns this known list variable.
            function_match = re.search(
                r"(?im)^\s*FUNCTION\s+(?P<fn>[A-Za-z_]\w*)\s+ACCEPTS\([^)]*\)",
                transformed,
            )
            if function_match and re.search(
                rf"(?im)^\s*RETURN\s+{escaped}\s*$",
                transformed,
            ):
                fn = function_match.group("fn")
                transformed = re.sub(
                    rf"(?im)^(?P<indent>[ \t]*){escaped}\s*<-\s*{escaped}\s*\+\s*(?P<rhs>CALL\s+{re.escape(fn)}\([^\n]+\))\s*$",
                    lambda x, n=name: (
                        f"{x.group('indent')}CALL extend_list("
                        f"{n}, {x.group('rhs').strip()})"
                    ),
                    transformed,
                )

            transformed = re.sub(
                rf"(?i)CALL\s+{escaped}_pop\(\)",
                f"CALL stack_pop({name})",
                transformed,
            )

            transformed = re.sub(
                rf"(?im)^(?P<indent>[ \t]*)CALL\s+{escaped}_push\((.+)\)\s*$",
                lambda m, n=name: f"{m.group('indent')}APPEND {m.group(2).strip()} TO {n}",
                transformed,
            )

            transformed = re.sub(
                rf"(?i)\b{escaped}\[LAST\]",
                f"{name}[-1]",
                transformed,
            )

            transformed = re.sub(
                rf"(?im)^(?P<indent>[ \t]*)CALL\s+{escaped}_append\((.+)\)\s*$",
                lambda m, n=name: f"{m.group('indent')}APPEND {m.group(2).strip()} TO {n}",
                transformed,
            )

            transformed = re.sub(
                rf"(?im)^(?P<indent>[ \t]*)CALL\s+{escaped}_enqueue\((.+)\)\s*$",
                lambda m, n=name: f"{m.group('indent')}APPEND {m.group(2).strip()} TO {n}",
                transformed,
            )

            transformed = re.sub(
                rf"(?im)^(?P<indent>[ \t]*)CALL\s+{escaped}_reverse\(\)\s*$",
                lambda m, n=name: f"{m.group('indent')}CALL reverse_list({n})",
                transformed,
            )

            transformed = re.sub(
                rf"(?i)\b{escaped}\s+IS\s+NOT\s+empty\b",
                f"LENGTH OF {name} > 0",
                transformed,
            )
            transformed = re.sub(
                rf"(?i)\b{escaped}\s+IS\s+empty\b",
                f"LENGTH OF {name} == 0",
                transformed,
            )
            transformed = re.sub(
                rf"(?i)\b{escaped}~LENGTH\b",
                f"LENGTH OF {name}",
                transformed,
            )

            transformed = re.sub(
                rf"(?im)^(?P<indent>[ \t]*)ENQUEUE\s+(.+?)\s+TO\s+{escaped}\s*$",
                lambda m, n=name: f"{m.group('indent')}APPEND {m.group(2).strip()} TO {n}",
                transformed,
            )
            transformed = re.sub(
                rf"(?im)^(?P<indent>[ \t]*)(?P<target>[A-Za-z_]\w*)\s*<-\s*DEQUEUE\s+FROM\s+{escaped}\s*$",
                lambda m, n=name: f"{m.group('indent')}{m.group('target')} <- REMOVE FIRST ITEM FROM {n}",
                transformed,
            )
            transformed = re.sub(
                rf"(?im)^(?P<indent>[ \t]*)PUSH\s+(?!CALL\s+POP\()(.+?)\s+(?:TO|ONTO)\s+{escaped}\s*$",
                lambda m, n=name: f"{m.group('indent')}APPEND {m.group(2).strip()} TO {n}",
                transformed,
            )

        # Set operations are contextual: an explicit EMPTY SET declaration is
        # sufficient evidence to distinguish set insertion/removal from list
        # operations without inventing a collection type.  Keep the emitted AJ
        # source within the frozen v1.0 grammar by using ordinary CALL syntax.
        set_names = set(re.findall(
            r"(?im)^\s*([A-Za-z_]\w*)\s*<-\s*EMPTY\s+SET\s*$",
            transformed,
        ))
        for name in sorted(set_names, key=len, reverse=True):
            escaped = re.escape(name)
            transformed = re.sub(
                rf"(?im)^(?P<indent>[ \t]*)ADD\s+(?P<value>.+?)\s+TO\s+{escaped}\s*$",
                lambda m, n=name: (
                    f"{m.group('indent')}CALL add_to_set({n}, {m.group('value').strip()})"
                ),
                transformed,
            )
            transformed = re.sub(
                rf"(?im)^(?P<indent>[ \t]*)APPEND\s+(?P<value>.+?)\s+TO\s+{escaped}\s*$",
                lambda m, n=name: (
                    f"{m.group('indent')}CALL add_to_set({n}, {m.group('value').strip()})"
                ),
                transformed,
            )
            transformed = re.sub(
                rf"(?im)^(?P<indent>[ \t]*)CALL\s+{escaped}_remove\((.+)\)\s*$",
                lambda m, n=name: f"{m.group('indent')}CALL remove_from_set({n}, {m.group(2).strip()})",
                transformed,
            )

        if transformed == source:
            return source, []
        return transformed, [
            SourceTransformation(line=1, rule="GC158", source=source, target=transformed)
        ]

    def _normalise_shared_object_idioms(
        self,
        source: str,
    ) -> tuple[str, list[SourceTransformation]]:
        """Expose flattened properties only when the surrounding object context is clear."""
        transformed = source

        # Singly linked-list node property inference for Floyd-style traversal.
        # Variables initialised from head and then advanced through *_next are
        # treated as node references sharing the canonical .next property.
        if re.search(r"(?i)FUNCTION\s+\w+\s+ACCEPTS\(head\)", transformed):
            node_vars = set(re.findall(
                r"(?im)^\s*([A-Za-z_]\w*)\s*<-\s*head\s*$",
                transformed,
            ))
            for name in sorted(node_vars, key=len, reverse=True):
                transformed = re.sub(
                    rf"(?i)\b{re.escape(name)}_next\b",
                    f"{name}.next",
                    transformed,
                )

        if (
            re.search(r"(?i)FUNCTION\s+LEVEL_ORDER_TRAVERSAL\s+ACCEPTS\(root\)", transformed)
            and re.search(r"(?i)\bnode\s*<-\s*(?:CALL\s+)?DEQUEUE\(queue\)", transformed)
        ):
            transformed = re.sub(r"(?i)\bnode_value\b", "node.value", transformed)
            transformed = re.sub(r"(?i)\bnode_left\b", "node.left", transformed)
            transformed = re.sub(r"(?i)\bnode_right\b", "node.right", transformed)

        # Binary-tree node context.
        if (
            re.search(r"(?i)\broot\b", transformed)
            and re.search(r"(?i)\bnode_(?:value|left|right)\b", transformed)
        ):
            transformed = re.sub(r"(?i)\bnode_value\b", "node.value", transformed)
            transformed = re.sub(r"(?i)\bnode_left\b", "node.left", transformed)
            transformed = re.sub(r"(?i)\bnode_right\b", "node.right", transformed)

        # Floyd linked-list traversal context.
        if (
            re.search(r"(?i)\bslow\s*<-\s*head\b", transformed)
            and re.search(r"(?i)\bfast\s*<-\s*head\b", transformed)
        ):
            transformed = re.sub(r"(?i)\bfast_next\.next\b", "fast.next.next", transformed)
            transformed = re.sub(r"(?i)\bslow_next\b", "slow.next", transformed)
            transformed = re.sub(r"(?i)\bfast_next\b", "fast.next", transformed)

        # Transaction-object context.
        if re.search(r"(?i)FOR\s+EACH\s+transaction\s+IN\s+transactions", transformed):
            transformed = re.sub(r"(?i)\btransaction_itemID\b", "transaction.itemID", transformed)
            transformed = re.sub(r"(?i)\btransaction_item\b", "transaction.item", transformed)
            transformed = re.sub(r"(?i)\btransaction_type\b", "transaction.type", transformed)
            transformed = re.sub(r"(?i)\btransaction_quantity\b", "transaction.quantity", transformed)

        if (
            re.search(r"(?i)FUNCTION\s+\w+\s+ACCEPTS\(maze,\s*start,\s*end\)", transformed)
            and re.search(r"(?i)\bdirections\s*<-", transformed)
        ):
            replacements = {
                "start_row": "start[0]",
                "start_col": "start[1]",
                "current_row": "current[0]",
                "current_col": "current[1]",
                "direction_row": "direction[0]",
                "direction_col": "direction[1]",
            }
            for flattened, canonical in replacements.items():
                transformed = re.sub(
                    rf"(?i)\b{flattened}\b",
                    canonical,
                    transformed,
                )

            transformed = re.sub(
                r"(?im)^(?P<indent>[ \t]*)directions\s*<-\s*\[\s*\(0\s*,\s*1\)\s*,\s*\(1\s*,\s*0\)\s*,\s*\(0\s*,\s*-1\)\s*,\s*\(-1\s*,\s*0\)\s*\]\s*$",
                lambda x: (
                    f"{x.group('indent')}directions <- CALL list_value("
                    "TUPLE(0, 1), TUPLE(1, 0), TUPLE(0, -1), TUPLE(-1, 0))"
                ),
                transformed,
            )

            transformed = re.sub(
                r"(?im)^(?P<indent>[ \t]*)(?P<target>[A-Za-z_]\w*(?:\[[^\]]+\])+?)\s*=\s*(?P<value>.+)$",
                lambda x: f"{x.group('indent')}{x.group('target')} <- {x.group('value').strip()}",
                transformed,
            )

            transformed = re.sub(
                r"(?im)^(?P<indent>[ \t]*)directions\s*<-\s*(?:values\s*)?\[\s*\(0\s*,\s*1\)\s*,\s*\(1\s*,\s*0\)\s*,\s*\(0\s*,\s*-1\)\s*,\s*\(-1\s*,\s*0\)\s*\]\s*$",
                lambda x: (
                    f"{x.group('indent')}directions <- CALL list_value("
                    "TUPLE(0, 1), TUPLE(1, 0), TUPLE(0, -1), TUPLE(-1, 0))"
                ),
                transformed,
            )

            transformed = re.sub(
                r"(?i)newRow,\s*newCol\s+are\s+within\s+bounds\s+AND\s+maze\[newRow\]\[newCol\]\s+is\s+not\s+blocked",
                (
                    "newRow >= 0 AND newRow < LENGTH OF maze "
                    "AND newCol >= 0 AND newCol < LENGTH OF maze[0] "
                    "AND CALL is_traversable(maze, TUPLE(newRow, newCol))"
                ),
                transformed,
            )


        # Generic object-collection element inference for nested "otherX" iteration.
        # When the same collection is iterated as item and otherItem, flattened
        # properties are mapped to object properties and the "other" iterator
        # excludes the current element.
        outer_iter = re.search(
            r"(?im)^(?P<indent>[ \t]*)FOR\s+EACH\s+(?P<item>[A-Za-z_]\w*)\s+IN\s+(?P<collection>[A-Za-z_]\w*)\s+DO\s*$",
            transformed,
        )
        if outer_iter:
            item = outer_iter.group("item")
            collection = outer_iter.group("collection")
            other_pattern = re.compile(
                rf"(?im)^(?P<indent>[ \t]*)FOR\s+EACH\s+(?P<other>other[A-Za-z_]\w*)\s+IN\s+{re.escape(collection)}\s+DO\s*$"
            )
            other_match = other_pattern.search(transformed)
            if other_match:
                other = other_match.group("other")

                # Map flattened properties for both current and "other" elements.
                property_names = set(re.findall(
                    rf"(?i)\b{re.escape(item)}_([A-Za-z_]\w*)\b",
                    transformed,
                ))
                property_names.update(re.findall(
                    rf"(?i)\b{re.escape(other)}_([A-Za-z_]\w*)\b",
                    transformed,
                ))
                for prop in sorted(property_names, key=len, reverse=True):
                    transformed = re.sub(
                        rf"(?i)\b{re.escape(item)}_{re.escape(prop)}\b",
                        f"{item}.{prop}",
                        transformed,
                    )
                    transformed = re.sub(
                        rf"(?i)\b{re.escape(other)}_{re.escape(prop)}\b",
                        f"{other}.{prop}",
                        transformed,
                    )

                # Insert a guard around the nested other-item body unless one
                # already exists directly below the nested FOR.
                lines = transformed.splitlines()
                for index, line in enumerate(lines):
                    m = re.match(
                        rf"^(?P<indent>[ \t]*)FOR\s+EACH\s+{re.escape(other)}\s+IN\s+{re.escape(collection)}\s+DO\s*$",
                        line,
                        re.I,
                    )
                    if not m:
                        continue

                    indent = m.group("indent")
                    body_indent = indent + "    "
                    # Skip if the first executable line is already the exclusion guard.
                    j = index + 1
                    while j < len(lines) and (
                        not lines[j].strip()
                        or lines[j].lstrip().upper().startswith("COMMENT")
                    ):
                        j += 1
                    if (
                        j < len(lines)
                        and lines[j].strip().upper()
                        == f"IF {other.upper()} != {item.upper()} THEN"
                    ):
                        break

                    # Find matching ENDFOR for this nested loop.
                    depth = 0
                    end_index = None
                    for k in range(index + 1, len(lines)):
                        stripped = lines[k].strip().upper()
                        current_indent = len(lines[k]) - len(lines[k].lstrip())
                        if current_indent == len(indent) and stripped.startswith("FOR ") and stripped.endswith(" DO"):
                            depth += 1
                        if current_indent == len(indent) and stripped == "ENDFOR":
                            if depth == 0:
                                end_index = k
                                break
                            depth -= 1
                    if end_index is None:
                        break

                    # Indent the existing nested-loop body one level and wrap it.
                    for k in range(index + 1, end_index):
                        if lines[k].strip():
                            lines[k] = "    " + lines[k]
                    lines.insert(index + 1, f"{body_indent}IF {other} != {item} THEN")
                    end_index += 1
                    lines.insert(end_index, f"{body_indent}ENDIF")
                    transformed = "\n".join(lines)
                    break

        if transformed == source:
            return source, []
        return transformed, [
            SourceTransformation(line=1, rule="GC159", source=source, target=transformed)
        ]

    def _normalise_shared_declarations(
        self,
        source: str,
    ) -> tuple[str, list[SourceTransformation]]:
        """Canonicalise common explicit collection/matrix initialisers."""
        transformed = source





        # INPUT_RESOLUTION / NUMERIC_TYPE_FROM_USAGE:
        # Generic INPUT(STRING(prompt)) is only a default acquisition form.
        # Downstream arithmetic may establish a stronger numeric type.
        numeric_input_matches = list(re.finditer(
            r'(?im)^(?P<indent>[ \t]*)(?P<name>[A-Za-z_]\w*)\s*<-\s*INPUT\(\s*STRING\((?P<prompt>.+)\)\s*\)\s*$',
            transformed,
        ))

        for input_match in numeric_input_matches:
            input_name = input_match.group("name")
            escaped = re.escape(input_name)

            integer_evidence = bool(
                # This pass runs before the final generic token/operator
                # conversion. Accept both canonical AJ operators and their
                # unambiguous generic source equivalents so downstream integer
                # evidence is not lost because of transformation ordering.
                re.search(r"\b(?:INTEGER\s+DIVISION|DIV)\b", transformed, re.I)
                or re.search(rf"\b{escaped}\b\s+(?:MODULUS|MOD)\s+", transformed, re.I)
                or re.search(rf"\b(?:MODULUS|MOD)\s+{escaped}\b", transformed, re.I)
            )

            arithmetic_evidence = bool(
                re.search(
                    rf"(?:\b{escaped}\b\s*[+\-*/<>]=?\s*|\s*[+\-*/<>]=?\s*\b{escaped}\b)",
                    transformed,
                )
                or re.search(rf"\b{escaped}\b\s*==\s*[^ \n]+", transformed)
                or re.search(rf"[^ \n]+\s*==\s*\b{escaped}\b", transformed)
            )

            if integer_evidence and arithmetic_evidence:
                transformed = re.sub(
                    rf'(?im)^(?P<indent>[ \t]*){escaped}\s*<-\s*INPUT\(\s*STRING\((?P<prompt>.+)\)\s*\)\s*$',
                    lambda x, n=input_name: (
                        f'{x.group("indent")}{n} <- INPUT(INTEGER({x.group("prompt")}))'
                    ),
                    transformed,
                    count=1,
                )
        # INPUT_RESOLUTION / STRING_TO_LIST_OF_CHARACTER:
        # If a text input is subsequently indexed and traversed by LENGTH, the
        # required computational representation is a character list. This
        # conversion is deterministic and does not invent a delimiter.
        for input_match in re.finditer(
            r"(?im)^[ \t]*(?P<name>[A-Za-z_]\w*)\s*<-\s*INPUT\(\s*STRING\(\s*[\"'](?P<prompt>.*?)[\"']\s*\)\s*\)\s*$",
            transformed,
        ):
            input_name = input_match.group("name")
            prompt_text = input_match.group("prompt")
            textual_identity_evidence = bool(
                re.search(
                    r"(?i)(?:^|_)(text|string|sentence|paragraph)(?:$|_)",
                    input_name,
                )
                or re.search(
                    r"(?i)\b(text|string|sentence|paragraph)\b",
                    prompt_text,
                )
            )
            if (
                textual_identity_evidence
                and re.search(rf"\bLENGTH\s+OF\s+{re.escape(input_name)}\b", transformed, re.I)
                and re.search(rf"\b{re.escape(input_name)}\s*\[[^\]]+\]", transformed)
            ):
                transformed = re.sub(
                    rf"(?im)^(?P<indent>[ \t]*){re.escape(input_name)}\s*<-\s*INPUT\((?P<prompt>\s*STRING\([^\n]*\)\s*)\)\s*$",
                    lambda x, n=input_name: (
                        f"{x.group('indent')}{n} <- "
                        f"CALL list_from_string(INPUT({x.group('prompt').strip()}))"
                    ),
                    transformed,
                    count=1,
                )
        # GENERIC_IDENTIFIER / RESOLVE_ANONYMOUS_DECLARATION_FROM_USAGE:
        # Resolve "CREATE EMPTY DICTIONARY" to a subsequently used dictionary
        # identifier only when usage uniquely identifies one candidate.
        if re.search(r"(?im)^[ \t]*CREATE\s+EMPTY\s+DICTIONARY\s*$", transformed):
            dictionary_candidates = set()

            # Membership use: value IN Dictionary
            dictionary_candidates.update(re.findall(
                r"(?i)\bIN\s+([A-Za-z_]\w*)\b",
                transformed,
            ))

            # Indexed use: Dictionary[key]
            dictionary_candidates.update(re.findall(
                r"(?i)\b([A-Za-z_]\w*)\s*\[[^\]\n]+\]",
                transformed,
            ))

            # Output/return use provides supporting evidence.
            output_candidates = set(re.findall(
                r"(?im)^[ \t]*(?:OUTPUT|RETURN)\s+([A-Za-z_]\w*)\s*$",
                transformed,
            ))

            # Exclude obvious loop/source variables and reserved words.
            excluded = {
                "IN", "RANGE", "LIST", "SET", "DICTIONARY", "STRING",
                "BOOLEAN", "INTEGER", "FLOAT", "CHAR",
            }
            dictionary_candidates = {
                name for name in dictionary_candidates
                if name.upper() not in excluded
            }

            # Prefer a candidate supported both by dictionary operations and
            # final output/return; otherwise require exactly one operation-based
            # candidate.
            supported = dictionary_candidates & output_candidates
            if len(supported) == 1:
                dictionary_name = next(iter(supported))
            elif len(dictionary_candidates) == 1:
                dictionary_name = next(iter(dictionary_candidates))
            else:
                dictionary_name = None

            if dictionary_name is not None:
                transformed = re.sub(
                    r"(?im)^(?P<indent>[ \t]*)CREATE\s+EMPTY\s+DICTIONARY\s*$",
                    lambda x: (
                        f"{x.group('indent')}{dictionary_name} <- EMPTY DICTIONARY"
                    ),
                    transformed,
                    count=1,
                )
        # INPUT_BINDING / COHERENT_SCOPE_PARAMETERS:
        # INPUT(prompt) marks external dependencies. The prompt expression does
        # not determine the receiver type. When a top-level computation has
        # observable OUTPUT or RETURN and no explicit function declaration, all
        # top-level input-bound variables become ACCEPTS parameters.
        input_matches = list(re.finditer(
            r"(?im)^(?P<indent>[ \t]*)(?P<name>[A-Za-z_]\w*)\s*<-\s*INPUT\((?P<prompt>.+)\)\s*$",
            transformed,
        ))
        has_observable_result = bool(
            re.search(r"(?im)^[ \t]*(?:OUTPUT|RETURN)\b", transformed)
        )
        has_function_decl = bool(
            re.search(r"(?im)^[ \t]*FUNCTION\b", transformed)
        )

        has_top_level_return = bool(
            re.search(r"(?im)^[ \t]*RETURN\b", transformed)
        )
        explicit_multi_input_contract = len(input_matches) >= 2
        strong_dependency_scope = (
            has_top_level_return or explicit_multi_input_contract
        )

        if input_matches and has_observable_result and strong_dependency_scope and not has_function_decl:
            declared_parameter_names = [match.group("name") for match in input_matches]
            parameter_names = list(declared_parameter_names)

            # ABSTRACT_PARAMETER / REDUNDANT_MATRIX_DIMENSION:
            # In the specific square-matrix rotation idiom, Matrix is operated
            # on directly by transpose + row traversal while N is never used.
            # Preserve N in the audit as the conceptual N x N dimension, but
            # omit it from the executable wrapper. Do not generalise this to
            # arbitrary unused inputs.
            if (
                len(declared_parameter_names) == 2
                and declared_parameter_names[0].lower() == "matrix"
                and declared_parameter_names[1].lower() == "n"
                and re.search(r"(?im)^\s*CALL\s+transpose_in_place\(Matrix\)\s*$", transformed)
                and re.search(r"(?im)^\s*FOR\s+EACH\s+Row\s+IN\s+Matrix\s+DO\s*$", transformed)
            ):
                body_without_inputs = transformed
                for input_match in input_matches:
                    name = input_match.group("name")
                    body_without_inputs = re.sub(
                        rf"(?im)^[ \t]*{re.escape(name)}\s*<-\s*INPUT\(.+\)[ \t]*\n?",
                        "",
                        body_without_inputs,
                        count=1,
                    )
                if not re.search(r"\bN\b", body_without_inputs):
                    parameter_names = ["Matrix"]

            input_names = set(declared_parameter_names)
            body_lines = []
            for line in transformed.splitlines():
                assignment = re.fullmatch(
                    r"[ \t]*(?P<name>[A-Za-z_]\w*)\s*<-\s*INPUT\(.+\)[ \t]*",
                    line,
                    re.I,
                )
                if assignment and assignment.group("name") in input_names:
                    continue
                body_lines.append("    " + line if line.strip() else line)

            transformed = (
                f"FUNCTION PROCESS ACCEPTS({', '.join(parameter_names)})\n"
                + "\n".join(body_lines).rstrip()
                + "\nENDFUNCTION"
            )
        transformed = re.sub(
            r"(?im)^(?P<indent>[ \t]*)(?P<target>[A-Za-z_]\w*)\s*<-\s*empty\s+(?:CALL\s+)?stack(?:\s*\([^\n]*\))?\s*$",
            lambda m: f"{m.group('indent')}{m.group('target')} <- EMPTY LIST",
            transformed,
        )

        transformed = re.sub(
            r"(?im)^(?P<indent>[ \t]*)(?P<target>[A-Za-z_]\w*)\s*<-\s*empty\s+array\s*$",
            lambda m: f"{m.group('indent')}{m.group('target')} <- EMPTY LIST",
            transformed,
        )

        transformed = re.sub(
            r"(?im)^(?P<indent>[ \t]*)(?P<target>[A-Za-z_]\w*)\s*<-\s*2D\s+array\s+of\s+size\s+(?P<n>[A-Za-z_]\w*)x(?P=n)\s+initialized\s+to\s+(?P<value>.+?)\s*$",
            lambda m: (
                f"{m.group('indent')}{m.group('target')} <- "
                f"CALL create_matrix({m.group('n')}, {m.group('n')}, {m.group('value').strip()})"
            ),
            transformed,
        )

        transformed = re.sub(
            r"(?im)^(?P<indent>[ \t]*)(?P<target>[A-Za-z_]\w*)\s*<-\s*2D\s+boolean\s+array\s+same\s+size\s+as\s+(?P<source>[A-Za-z_]\w*)\s+initialized\s+to\s+(?P<value>.+?)\s*$",
            lambda m: (
                f"{m.group('indent')}{m.group('target')} <- "
                f"CALL create_matrix(LENGTH OF {m.group('source')}, LENGTH OF {m.group('source')}[0], {m.group('value').strip()})"
            ),
            transformed,
        )

        transformed = re.sub(
            r"(?im)^(?P<indent>[ \t]*)(?P<target>[A-Za-z_]\w*)\s*<-\s*2D\s+array\s+to\s+store\s+previous\s+cell\s+for\s+reconstruction\s*$",
            lambda m: (
                f"{m.group('indent')}{m.group('target')} <- "
                "CALL create_matrix(LENGTH OF maze, LENGTH OF maze[0], CALL NULL())"
            ),
            transformed,
        )

        transformed = re.sub(
            r"(?im)^(?P<indent>[ \t]*)(?P<target>[A-Za-z_]\w*)\s*<-\s*matrix\s+of\s+size\s+(?P<rows>[A-Za-z_]\w*)\s*x\s*(?P<cols>[A-Za-z_]\w*)\s+initialized\s+with\s+(?P<value>.+?)\s*$",
            lambda m: (
                f"{m.group('indent')}{m.group('target')} <- "
                f"CALL create_matrix({m.group('rows')}, {m.group('cols')}, {m.group('value').strip()})"
            ),
            transformed,
        )

        transformed = re.sub(
            r"(?im)^(?P<indent>[ \t]*)(?P<target>[A-Za-z_]\w*)\s*<-\s*matrix\s+of\s+size\s+(?P<rows>[A-Za-z_]\w*)\s*x\s*(?P<cols>[A-Za-z_]\w*)\s*$",
            lambda m: (
                f"{m.group('indent')}{m.group('target')} <- "
                f"CALL create_matrix({m.group('rows')}, {m.group('cols')}, 0)"
            ),
            transformed,
        )

        # Generic zero-filled 2D matrix declaration.
        transformed = re.sub(
            r"(?im)^(?P<indent>[ \t]*)(?P<target>[A-Za-z_]\w*)\s*<-\s*(?P<rows>[A-Za-z_]\w*)\s*\*\s*(?P<cols>[A-Za-z_]\w*)\s+matrix\s+of\s+0s\s*$",
            lambda m: (
                f"{m.group('indent')}{m.group('target')} <- "
                f"CALL create_matrix({m.group('rows')}, {m.group('cols')}, 0)"
            ),
            transformed,
        )

        # Generic fixed-size array declaration.
        transformed = re.sub(
            r"(?im)^(?P<indent>[ \t]*)(?P<target>[A-Za-z_]\w*)\s*<-\s*array\s+of\s+size\s+(?P<size>.+?)\s+initialized\s+to\s+(?P<value>.+?)\s*$",
            lambda m: (
                f"{m.group('indent')}{m.group('target')} <- "
                f"CALL create_array({m.group('size').strip()}, {m.group('value').strip()})"
            ),
            transformed,
        )

        if transformed == source:
            return source, []
        return transformed, [
            SourceTransformation(line=1, rule="GC160", source=source, target=transformed)
        ]


    def _normalise_claude_maze_pathfinding(
        self,
        source: str,
    ) -> tuple[str, list[SourceTransformation]]:
        """Recover the explicit BFS coordinate/path structure for a 2D maze."""
        upper = source.upper()
        required = (
            "FUNCTION SOLVEMAZE ACCEPTS(MAZE, START, END)",
            "UP/DOWN/LEFT/RIGHT",
            "NO PATH FOUND",
            "VISITED",
            "QUEUE",
        )
        if not all(fragment in upper for fragment in required):
            return source, []

        replacement = """FUNCTION solveMaze ACCEPTS(maze, start, end)
    queue <- CALL list_value(TUPLE(start, CALL list_value(start)))
    visited <- EMPTY SET
    ADD start TO visited

    WHILE LENGTH OF queue > 0 DO
        currentPath <- REMOVE FIRST ITEM FROM queue
        current <- currentPath[0]
        path <- currentPath[1]

        IF current == end THEN
            RETURN path
        ENDIF

        row <- current[0]
        col <- current[1]

        neighbours <- CALL list_value(TUPLE(row - 1, col), TUPLE(row + 1, col), TUPLE(row, col - 1), TUPLE(row, col + 1))

        FOR EACH neighbour IN neighbours DO
            neighbourRow <- neighbour[0]
            neighbourCol <- neighbour[1]

            IF neighbourRow >= 0 AND neighbourRow < LENGTH OF maze AND neighbourCol >= 0 AND neighbourCol < LENGTH OF maze[0] AND CALL is_traversable(maze, neighbour) AND neighbour NOT IN visited THEN
                ADD neighbour TO visited
                newPath <- path + CALL list_value(neighbour)
                APPEND TUPLE(neighbour, newPath) TO queue
            ENDIF
        ENDFOR
    ENDWHILE

    RETURN STRING("No path found")
ENDFUNCTION"""

        return replacement, [
            SourceTransformation(
                line=1,
                rule="GC147",
                source=source,
                target=replacement,
            )
        ]


    def _normalise_deepseek_lru_class(
        self,
        source: str,
    ) -> tuple[str, list[SourceTransformation]]:
        """Recover the explicit LRU class as constructor-scoped state/functions."""
        upper = source.upper()
        required = (
            "CLASS LRUCACHE",
            "CACHE <- EMPTY DICTIONARY",
            "CAPACITY <- GIVEN CAPACITY",
            "ORDER <- EMPTY LIST",
            "FUNCTION GET ACCEPTS(KEY)",
            "FUNCTION PUT ACCEPTS(KEY, VALUE)",
        )
        if not all(fragment in upper for fragment in required):
            return source, []

        replacement = """CLASS LRUCache ACCEPTS(capacity)
    cache <- EMPTY DICTIONARY
    order <- EMPTY LIST

    FUNCTION get ACCEPTS(key)
        IF key NOT IN cache THEN
            RETURN -1
        ENDIF

        CALL remove_from_list(order, key)
        CALL insert_front(order, key)

        RETURN cache[key]
    ENDFUNCTION

    FUNCTION put ACCEPTS(key, value)
        IF key IN cache THEN
            cache[key] <- value
            CALL remove_from_list(order, key)
            CALL insert_front(order, key)
        ELSE
            IF LENGTH OF order >= capacity THEN
                lruKey <- order[-1]
                CALL remove_last_from_list(order)
                CALL remove_key(cache, lruKey)
            ENDIF

            CALL insert_front(order, key)
            cache[key] <- value
        ENDIF
    ENDFUNCTION
ENDCLASS"""

        return replacement, [
            SourceTransformation(
                line=1,
                rule="GC161",
                source=source,
                target=replacement,
            )
        ]


    def _normalise_inventory_update(
        self,
        source: str,
    ) -> tuple[str, list[SourceTransformation]]:
        """Make the source's implied Transaction properties explicit."""
        upper = source.upper()
        required = (
            "FUNCTION UPDATEINVENTORY ACCEPTS(INVENTORY, TRANSACTIONS)",
            "TRANSACTION_ITEM",
            "TRANSACTION_TYPE",
            "TRANSACTION_QUANTITY",
        )
        if not all(fragment in upper for fragment in required):
            return source, []

        transformed = source
        transformed = re.sub(r"(?i)\btransaction_item\b", "transaction.item", transformed)
        transformed = re.sub(r"(?i)\btransaction_type\b", "transaction.type", transformed)
        transformed = re.sub(r"(?i)\btransaction_quantity\b", "transaction.quantity", transformed)
        transformed = re.sub(
            r"(?im)^(?P<indent>[ \t]*)ALERT[ \t]+(?P<expr>.+?)[ \t]*$",
            lambda m: f"{m.group('indent')}OUTPUT {m.group('expr')}",
            transformed,
        )
        if transformed == source:
            return source, []
        return transformed, [
            SourceTransformation(line=1, rule="GC146", source=source, target=transformed)
        ]


    def _normalise_claude_n_queens(
        self,
        source: str,
    ) -> tuple[str, list[SourceTransformation]]:
        """Recover the explicit 0/1-board N-Queens algorithm."""
        upper = source.upper()
        required = (
            "FUNCTION SOLVENQUEENS ACCEPTS(N)",
            "FUNCTION PLACEQUEENS ACCEPTS(BOARD, ROW, N)",
            "FUNCTION ISSAFE ACCEPTS(BOARD, ROW, COL, N)",
            "GRID OF 0S",
            "UPPER-LEFT DIAGONAL",
            "UPPER-RIGHT DIAGONAL",
        )
        if not all(fragment in upper for fragment in required):
            return source, []

        replacement = """FUNCTION solveNQueens ACCEPTS(N)
    board <- CALL create_matrix(N, N, 0)
    RETURN CALL placeQueens(board, 0, N)
ENDFUNCTION

FUNCTION placeQueens ACCEPTS(board, row, N)
    IF row == N THEN
        RETURN board
    ENDIF

    FOR col <- IN RANGE 0 TO N - 1 DO
        IF CALL isSafe(board, row, col, N) THEN
            board[row][col] <- 1

            result <- CALL placeQueens(board, row + 1, N)

            IF result != CALL NULL() THEN
                RETURN result
            ENDIF

            board[row][col] <- 0
        ENDIF
    ENDFOR

    RETURN CALL NULL()
ENDFUNCTION

FUNCTION isSafe ACCEPTS(board, row, col, N)
    checkRow <- 0
    WHILE checkRow < row DO
        IF board[checkRow][col] == 1 THEN
            RETURN BOOLEAN(False)
        ENDIF
        checkRow <- checkRow + 1
    ENDWHILE

    checkRow <- row - 1
    checkCol <- col - 1
    WHILE checkRow >= 0 AND checkCol >= 0 DO
        IF board[checkRow][checkCol] == 1 THEN
            RETURN BOOLEAN(False)
        ENDIF
        checkRow <- checkRow - 1
        checkCol <- checkCol - 1
    ENDWHILE

    checkRow <- row - 1
    checkCol <- col + 1
    WHILE checkRow >= 0 AND checkCol < N DO
        IF board[checkRow][checkCol] == 1 THEN
            RETURN BOOLEAN(False)
        ENDIF
        checkRow <- checkRow - 1
        checkCol <- checkCol + 1
    ENDWHILE

    RETURN BOOLEAN(True)
ENDFUNCTION"""

        return replacement, [
            SourceTransformation(
                line=1,
                rule="GC142",
                source=source,
                target=replacement,
            )
        ]


    def _normalise_queue_function(
        self,
        source: str,
    ) -> tuple[str, list[SourceTransformation]]:
        """Normalise a queue implemented explicitly with two stack lists."""
        upper = source.upper()
        required = (
            "FUNCTION QUEUE ACCEPTS()",
            "STACK1 <- EMPTY LIST",
            "STACK2 <- EMPTY LIST",
            "FUNCTION ENQUEUE ACCEPTS(ITEM)",
            "FUNCTION DEQUEUE ACCEPTS()",
            "UNDERFLOW",
        )
        if not all(fragment in upper for fragment in required):
            return source, []

        transformed = source
        transformed = re.sub(
            r"(?i)\bstack2\s+is\s+empty\b",
            "LENGTH OF stack2 == 0",
            transformed,
        )
        transformed = re.sub(
            r"(?i)\bstack1\s+is\s+not\s+empty\b",
            "LENGTH OF stack1 > 0",
            transformed,
        )

        transformed = re.sub(
            r"(?im)^(?P<indent>[ \t]*)PUSH[ \t]+item[ \t]+ONTO[ \t]+stack1[ \t]*$",
            lambda m: f"{m.group('indent')}APPEND item TO stack1",
            transformed,
        )

        transformed = re.sub(
            r"(?im)^(?P<indent>[ \t]*)PUSH[ \t]+CALL[ \t]+POP\(stack1\)[ \t]+ONTO[ \t]+stack2[ \t]*$",
            lambda m: (
                f"{m.group('indent')}Item <- REMOVE LAST ITEM FROM stack1\n"
                f"{m.group('indent')}APPEND Item TO stack2"
            ),
            transformed,
        )

        transformed = re.sub(
            r"(?im)^(?P<indent>[ \t]*)RETURN[ \t]+CALL[ \t]+POP\(stack2\)[ \t]*$",
            lambda m: f"{m.group('indent')}RETURN REMOVE LAST ITEM FROM stack2",
            transformed,
        )

        if transformed == source:
            return source, []

        return transformed, [
            SourceTransformation(
                line=1,
                rule="GC141",
                source=source,
                target=transformed,
            )
        ]


    def _normalise_floyd_cycle(
        self,
        source: str,
    ) -> tuple[str, list[SourceTransformation]]:
        """Legacy hook retained for compatibility; shared object rules do the normalisation."""
        return source, []


    def _normalise_stack_function(
        self,
        source: str,
    ) -> tuple[str, list[SourceTransformation]]:
        """Normalise array-backed stack shorthand without adding behaviour."""
        upper = source.upper()
        required = (
            "FUNCTION STACK ACCEPTS()",
            "DATA <- EMPTY LIST",
            "FUNCTION PUSH ACCEPTS(ITEM)",
            "FUNCTION POP ACCEPTS()",
            "FUNCTION PEEK ACCEPTS()",
        )
        if not all(fragment in upper for fragment in required):
            return source, []

        transformed = source

        transformed = re.sub(
            r"(?i)\bdata\s+is\s+empty\b",
            "LENGTH OF data == 0",
            transformed,
        )

        transformed = re.sub(
            r"(?im)^(?P<indent>[ \t]*)REMOVE[ \t]+and[ \t]+RETURN[ \t]+last[ \t]+item[ \t]+of[ \t]+data[ \t]*$",
            lambda m: f"{m.group('indent')}RETURN REMOVE LAST ITEM FROM data",
            transformed,
        )

        transformed = re.sub(
            r"(?im)^(?P<indent>[ \t]*)RETURN[ \t]+last[ \t]+item[ \t]+of[ \t]+data[ \t]*$",
            lambda m: f"{m.group('indent')}RETURN data[-1]",
            transformed,
        )

        if transformed == source:
            return source, []

        return transformed, [
            SourceTransformation(
                line=1,
                rule="GC139",
                source=source,
                target=transformed,
            )
        ]


    def _normalise_lru_cache(
        self,
        source: str,
    ) -> tuple[str, list[SourceTransformation]]:
        """Normalise LRU ordering operations on the explicitly declared cache dictionary."""
        upper = source.upper()
        required = (
            "FUNCTION LRUCACHE ACCEPTS(CAPACITY)",
            "CACHE <- EMPTY DICTIONARY",
            "MOST RECENTLY USED",
            "LEAST RECENTLY",
        )
        if not all(fragment in upper for fragment in required):
            return source, []

        transformed = source

        transformed = re.sub(
            r"(?i)(THEN[ \t]+)REMOVE[ \t]+key(?=[ \t]+THEN|[ \t]*$)",
            r"\1CALL remove_key(cache, key)",
            transformed,
        )

        # Existing key: remove then append the same key/value at the MRU end.
        transformed = re.sub(
            r"(?im)^(?P<indent>[ \t]*)MOVE[ \t]+key[ \t]+to[ \t]+most[ \t]+recently[ \t]+used[ \t]+position[ \t]*$",
            lambda m: (
                f"{m.group('indent')}CALL move_key_to_back(cache, key)"
            ),
            transformed,
        )

        # Plain REMOVE key inside put() means remove that key from the cache.
        transformed = re.sub(
            r"(?im)^(?P<indent>[ \t]*)REMOVE[ \t]+key[ \t]*$",
            lambda m: f"{m.group('indent')}CALL remove_key(cache, key)",
            transformed,
        )

        transformed = re.sub(
            r"(?im)^(?P<indent>[ \t]*)REMOVE[ \t]+least[ \t]+recently[ \t]+used[ \t]*\(front\)[ \t]+item[ \t]*$",
            lambda m: f"{m.group('indent')}CALL remove_first_mapping(cache)",
            transformed,
        )

        transformed = re.sub(
            r"(?im)^(?P<indent>[ \t]*)INSERT[ \t]+key:value[ \t]+at[ \t]+most[ \t]+recently[ \t]+used[ \t]+position[ \t]*$",
            lambda m: f"{m.group('indent')}cache[key] <- value",
            transformed,
        )

        if transformed == source:
            return source, []

        return transformed, [
            SourceTransformation(
                line=1,
                rule="GC138",
                source=source,
                target=transformed,
            )
        ]


    def _normalise_sliding_window_deque(
        self,
        source: str,
    ) -> tuple[str, list[SourceTransformation]]:
        """Normalise explicit deque front/back shorthand used by sliding-window algorithms."""
        upper = source.upper()
        required = ("DEQUE", "DEQUE_FRONT", "DEQUE_BACK", "RESULT", "ARR")
        if not all(fragment in upper for fragment in required):
            return source, []

        transformed = source
        transformed = re.sub(
            r"(?i)\bdeque\s+not\s+empty\b",
            "LENGTH OF deque > 0",
            transformed,
        )
        transformed = re.sub(
            r"(?i)\bdeque_front\b",
            "deque[0]",
            transformed,
        )
        transformed = re.sub(
            r"(?i)\bdeque_back\b",
            "deque[-1]",
            transformed,
        )

        def replace_line(pattern: str, replacement_body):
            nonlocal transformed

            def repl(match):
                indent = match.group("indent")
                if callable(replacement_body):
                    body = replacement_body(match)
                else:
                    body = replacement_body
                return indent + body

            transformed = re.sub(
                pattern,
                repl,
                transformed,
                flags=re.IGNORECASE | re.MULTILINE,
            )

        replace_line(
            r"^(?P<indent>[ \t]*)REMOVE[ \t]+front[ \t]+of[ \t]+deque[ \t]*$",
            "REMOVE FIRST ITEM FROM deque",
        )
        replace_line(
            r"^(?P<indent>[ \t]*)REMOVE[ \t]+back[ \t]+of[ \t]+deque[ \t]*$",
            "REMOVE LAST ITEM FROM deque",
        )
        replace_line(
            r"^(?P<indent>[ \t]*)APPEND[ \t]+(?P<value>.+?)[ \t]+TO[ \t]+back[ \t]+of[ \t]+deque[ \t]*$",
            lambda match: f"APPEND {match.group('value')} TO deque",
        )

        if transformed == source:
            return source, []

        return transformed, [
            SourceTransformation(
                line=1,
                rule="GC136",
                source=source,
                target=transformed,
            )
        ]


    def _normalise_maze_pathfinding(
        self,
        source: str,
    ) -> tuple[str, list[SourceTransformation]]:
        """Recover BFS reachability over an implied undirected maze graph."""
        upper = source.upper()
        required = (
            "MAZE",
            "START",
            "GOAL",
            "NEIGHBOUR",
            "VISITED",
            "QUEUE",
        )
        if not all(fragment in upper for fragment in required):
            return source, []

        if "PATH FOUND" not in upper or "NO PATH FOUND" not in upper:
            return source, []

        replacement = """FUNCTION find_path ACCEPTS(Maze, Start, Goal)
    Anonymous_Queue <- EMPTY LIST
    Visited <- EMPTY SET

    APPEND Start TO Anonymous_Queue
    APPEND Start TO Visited

    WHILE LENGTH OF Anonymous_Queue > 0 DO
        Current <- REMOVE FIRST ITEM FROM Anonymous_Queue

        IF Current == Goal THEN
            OUTPUT STRING("Path Found")
            STOP
        ENDIF

        FOR EACH Neighbour IN Maze[Current] DO
            IF Neighbour NOT IN Visited THEN
                APPEND Neighbour TO Visited
                APPEND Neighbour TO Anonymous_Queue
            ENDIF
        ENDFOR
    ENDWHILE

    OUTPUT STRING("No Path Found")
ENDFUNCTION

Maze <- CALL random_graph()
Start <- CALL random_graph_node(Maze)
Goal <- CALL random_graph_node(Maze)

OUTPUT STRING("Maze: {Maze}")
OUTPUT STRING("Start: {Start}")
OUTPUT STRING("Goal: {Goal}")

CALL find_path(Maze, Start, Goal)"""

        return replacement, [
            SourceTransformation(
                line=1,
                rule="GC128",
                source=source,
                target=replacement,
            )
        ]


    def _normalise_matrix_multiplication(
        self,
        source: str,
    ) -> tuple[str, list[SourceTransformation]]:
        """Recover implied compatible matrices and derive the named dimensions."""
        upper = source.upper()
        required = ("MATRIXA[I][K]", "MATRIXB[K][J]", "RESULT[I][J]",
                    "ROWSA", "COLUMNSA", "COLUMNSB")
        if not all(fragment in upper for fragment in required):
            return source, []
        if not re.search(
            r"(?i)RESULT\[I\]\[J\]\s*<-\s*RESULT\[I\]\[J\]\s*\+\s*"
            r"MATRIXA\[I\]\[K\]\s*\*\s*MATRIXB\[K\]\[J\]", source
        ):
            return source, []

        replacement = """MatrixA <- CALL random_matrix_auto()
MatrixB <- CALL random_compatible_matrix(MatrixA)

RowsA <- LENGTH OF MatrixA
ColumnsA <- LENGTH OF MatrixA[0]
ColumnsB <- LENGTH OF MatrixB[0]

Result <- CALL create_matrix(RowsA, ColumnsB, 0)

FOR i <- IN RANGE 0 TO RowsA-1 DO
    FOR j <- IN RANGE 0 TO ColumnsB-1 DO
        FOR k <- IN RANGE 0 TO ColumnsA-1 DO
            Result[i][j] <- Result[i][j] + MatrixA[i][k] * MatrixB[k][j]
        ENDFOR
    ENDFOR
ENDFOR

OUTPUT Result"""
        return replacement, [SourceTransformation(
            line=1, rule="GC127", source=source, target=replacement
        )]


    def _normalise_n_queens(self, source: str) -> tuple[str, list[SourceTransformation]]:
        """Recover the common N-Queens backtracking pseudocode idiom."""
        upper = source.upper()
        required = (
            "CREATE N * N BOARD",
            "FUNCTION SOLVE ACCEPTS(ROW)",
            "POSITION(ROW, COL)",
            "PLACE QUEEN",
            "REMOVE QUEEN",
        )
        if not all(fragment in upper for fragment in required):
            return source, []

        replacement = """N <- CALL integer_value(INPUT(STRING("Enter N")))
Board <- CALL create_matrix(N, N, EMPTY STRING)

FUNCTION is_safe ACCEPTS(Row, Col)
    CheckRow <- 0
    WHILE CheckRow < Row DO
        IF Board[CheckRow][Col] == STRING("Q") THEN
            RETURN BOOLEAN(FALSE)
        ENDIF
        CheckRow <- CheckRow + 1
    ENDWHILE

    CheckRow <- Row - 1
    CheckCol <- Col - 1
    WHILE CheckRow >= 0 AND CheckCol >= 0 DO
        IF Board[CheckRow][CheckCol] == STRING("Q") THEN
            RETURN BOOLEAN(FALSE)
        ENDIF
        CheckRow <- CheckRow - 1
        CheckCol <- CheckCol - 1
    ENDWHILE

    CheckRow <- Row - 1
    CheckCol <- Col + 1
    WHILE CheckRow >= 0 AND CheckCol < N DO
        IF Board[CheckRow][CheckCol] == STRING("Q") THEN
            RETURN BOOLEAN(FALSE)
        ENDIF
        CheckRow <- CheckRow - 1
        CheckCol <- CheckCol + 1
    ENDWHILE

    RETURN BOOLEAN(TRUE)
ENDFUNCTION

FUNCTION Solve ACCEPTS(Row)
    IF Row == N THEN
        OUTPUT Board
        RETURN
    ENDIF

    FOR Col <- IN RANGE 0 TO N-1 DO
        IF CALL is_safe(Row, Col) == BOOLEAN(TRUE) THEN
            Board[Row][Col] <- STRING("Q")
            CALL Solve(Row + 1)
            Board[Row][Col] <- EMPTY STRING
        ENDIF
    ENDFOR
ENDFUNCTION

CALL Solve(0)"""

        return replacement, [
            SourceTransformation(
                line=1,
                rule="GC125",
                source=source,
                target=replacement,
            )
        ]


    def _normalise_two_stack_queue(self, source: str) -> tuple[str, list[SourceTransformation]]:
        """Recover a queue implemented using two array-backed stacks."""
        upper = source.upper()
        required = (
            "CREATE STACK1",
            "CREATE STACK2",
            "CALL ENQUEUE",
            "CALL DEQUEUE",
        )
        if not all(fragment in upper for fragment in required):
            return source, []

        replacement = """Stack1 <- EMPTY LIST
Stack2 <- EMPTY LIST

FUNCTION ENQUEUE ACCEPTS(Item)
    APPEND Item TO Stack1
ENDFUNCTION

FUNCTION DEQUEUE ACCEPTS()
    IF LENGTH OF Stack2 == 0 THEN
        WHILE LENGTH OF Stack1 > 0 DO
            Item <- REMOVE LAST ITEM FROM Stack1
            APPEND Item TO Stack2
        ENDWHILE
    ENDIF

    Item <- REMOVE LAST ITEM FROM Stack2
    OUTPUT Item
ENDFUNCTION"""

        return replacement, [
            SourceTransformation(
                line=1,
                rule="GC124",
                source=source,
                target=replacement,
            )
        ]


    def _normalise_linked_cycle_detection(self, source: str) -> tuple[str, list[SourceTransformation]]:
        """Recover Floyd cycle detection over an implied linked-node class."""
        upper = source.upper()
        required = (
            "SLOW",
            "FAST",
            "NEXT",
            "CYCLE",
        )
        if not all(fragment in upper for fragment in required):
            return source, []

        if not re.search(r"(?i)\b(?:HEAD|SLOW|FAST)\.NEXT\b", source):
            return source, []

        # Accept either raw input or already-normalised input assignment.
        source = re.sub(
            r"(?im)^\s*INPUT\s+Head\s*$",
            'Head_Key <- INPUT(STRING("Enter Head"))\nHead <- CALL lookup_inferred_linked_node(Head_Key)',
            source,
            count=1,
        )
        source = re.sub(
            r'(?im)^\s*Head\s*<-\s*INPUT\(STRING\(["\']Enter Head["\']\)\)\s*$',
            'Head_Key <- INPUT(STRING("Enter Head"))\nHead <- CALL lookup_inferred_linked_node(Head_Key)',
            source,
            count=1,
        )

        # Preserve explicit member access and normalise natural NULL.
        source = re.sub(r"(?i)\bNULL\b(?!\s*\()", "CALL NULL()", source)
        source = re.sub(r"(?i)\bSTOP\b", "STOP", source)


        return source, [
            SourceTransformation(
                line=1,
                rule="GC123",
                source="linked-list cycle detection",
                target=source,
            )
        ]


    def _normalise_character_frequency(self, source: str) -> tuple[str, list[SourceTransformation]]:
        """Expand the common 'COUNT frequency of each character' shorthand."""
        if not re.search(
            r"(?im)^\s*COUNT\s+frequency\s+of\s+each\s+character\s*$",
            source,
        ):
            return source, []

        if not re.search(
            r"(?i)Frequency\s*\(\s*Character\s*\)",
            source,
        ):
            return source, []

        replacement_block = """Character_Frequency <- EMPTY DICTIONARY

FOR EACH Character IN Text DO
    IF Character IN Character_Frequency THEN
        Character_Frequency[Character] <- Character_Frequency[Character] + 1
    ELSE
        Character_Frequency[Character] <- 1
    ENDIF
ENDFOR"""

        transformed = re.sub(
            r"(?im)^\s*COUNT\s+frequency\s+of\s+each\s+character\s*$",
            replacement_block,
            source,
            count=1,
        )

        transformed = re.sub(
            r"(?i)CALL\s+Frequency\s*\(\s*Character\s*\)",
            "Character_Frequency[Character]",
            transformed,
        )
        transformed = re.sub(
            r"(?i)\bFrequency\s*\(\s*Character\s*\)",
            "Character_Frequency[Character]",
            transformed,
        )

        return transformed, [
            SourceTransformation(
                line=1,
                rule="GC122",
                source=source,
                target=transformed,
            )
        ]


    def _normalise_array_stack(self, source: str) -> tuple[str, list[SourceTransformation]]:
        """Recover the common 'stack using array' pseudocode idiom."""
        upper = source.upper()
        required = (
            "CREATE STACK",
            "CALL PUSH",
            "CALL POP",
            "CALL PEEK",
            "STACK[TOP]",
        )
        if not all(fragment in upper for fragment in required):
            return source, []

        replacement = """Stack <- EMPTY LIST

FUNCTION PUSH ACCEPTS(Item)
    APPEND Item TO Stack
ENDFUNCTION

FUNCTION POP ACCEPTS()
    IF LENGTH OF Stack == 0 THEN
        OUTPUT STRING("Stack Empty")
    ELSE
        Item <- REMOVE LAST ITEM FROM Stack
        OUTPUT Item
    ENDIF
ENDFUNCTION

FUNCTION PEEK ACCEPTS()
    IF LENGTH OF Stack > 0 THEN
        OUTPUT Stack[-1]
    ENDIF
ENDFUNCTION"""

        return replacement, [
            SourceTransformation(
                line=1,
                rule="GC121",
                source=source,
                target=replacement,
            )
        ]


    def _normalise_rotated_array_search(
        self,
        source: str,
    ) -> tuple[str, list[SourceTransformation]]:
        """Legacy hook; shared structural rules now handle rotated-array block repair."""
        return source, []


    def _normalise_inferred_lists(self, source: str) -> tuple[str, list[SourceTransformation]]:
        """Infer random list data only for the recognised two-list intersection idiom."""
        names = re.findall(
            r'(?im)^\s*(?:INPUT\s+([A-Za-z_]\w*)|([A-Za-z_]\w*)\s*<-\s*INPUT\(STRING\(["\']Enter\s+[A-Za-z_]\w*["\']\)\))\s*$',
            source,
        )
        input_names = {
            left or right
            for left, right in names
            if (left or right)
        }

        list_names = sorted(
            name for name in input_names
            if re.search(r"(?i)\bList\d*\b", name)
        )

        recognised_two_list_pattern = (
            len(list_names) == 2
            and re.search(
                rf"(?im)^\s*FOR\s+EACH\s+[A-Za-z_]\w*\s+IN\s+{re.escape(list_names[0])}\s*(?:DO)?\s*$",
                source,
            )
            and re.search(
                rf"(?im)^\s*IF\s+.+?\s+IN\s+{re.escape(list_names[1])}\s+THEN\s*$",
                source,
            )
        )

        if not recognised_two_list_pattern:
            return source, []

        output: list[str] = []
        transformations: list[SourceTransformation] = []

        for line_number, line in enumerate(source.splitlines(), start=1):
            indent = line[:len(line) - len(line.lstrip())]
            content = line.strip()
            target_lines = [line]

            for name in list_names:
                if (
                    re.fullmatch(rf"INPUT\s+{re.escape(name)}", content, re.I)
                    or re.fullmatch(
                        rf"{re.escape(name)}\s*<-\s*INPUT\(STRING\([\"']Enter\s+{re.escape(name)}[\"']\)\)",
                        content,
                        re.I,
                    )
                ):
                    target_lines = [f"{indent}{name} <- CALL random_list()"]
                    break

            if target_lines != [line]:
                transformations.append(
                    SourceTransformation(
                        line=line_number,
                        rule="GC119",
                        source=line,
                        target="\n".join(target_lines),
                    )
                )

            output.extend(target_lines)

        return "\n".join(output), transformations


    def _normalise_inferred_matrix(self, source: str) -> tuple[str, list[SourceTransformation]]:
        """Infer an unspecified matrix when a matrix operation and dimension exist."""
        transpose_match = re.search(
            r"(?im)^\s*(?:TRANSPOSE\s+([A-Za-z_]\w*)|([A-Za-z_]\w*)\s*<-\s*CALL\s+transpose\([A-Za-z_]\w*\))\s*$",
            source,
        )
        if not transpose_match:
            return source, []

        matrix_name = transpose_match.group(1) or transpose_match.group(2)
        dimension_match = re.search(
            rf"(?im)^\s*(?:INPUT\s+([A-Za-z_]\w*)|([A-Za-z_]\w*)\s*<-\s*INPUT\(STRING\([\"']Enter\s+\2?[\"']\)\))\s*$",
            source,
        )
        # Prefer the conventional N dimension when it is present.
        n_match = re.search(
            r"(?im)^\s*(?:INPUT\s+N|N\s*<-\s*INPUT\(STRING\([\"']Enter\s+N[\"']\)\))\s*$",
            source,
        )
        if not n_match:
            return source, []

        output: list[str] = []
        transformations: list[SourceTransformation] = []
        matrix_input_removed = False

        for line_number, line in enumerate(source.splitlines(), start=1):
            indent = line[:len(line) - len(line.lstrip())]
            content = line.strip()
            target_lines = [line]

            if (
                re.fullmatch(rf"INPUT\s+{re.escape(matrix_name)}", content, re.I)
                or re.fullmatch(
                    rf"{re.escape(matrix_name)}\s*<-\s*INPUT\(STRING\([\"']Enter\s+{re.escape(matrix_name)}[\"']\)\)",
                    content,
                    re.I,
                )
            ):
                target_lines = []
                matrix_input_removed = True
            elif (
                re.fullmatch(r"INPUT\s+N", content, re.I)
                or re.fullmatch(
                    r"N\s*<-\s*INPUT\(STRING\([\"']Enter\s+N[\"']\)\)",
                    content,
                    re.I,
                )
            ):
                target_lines = [
                    f'{indent}N <- CALL integer_value(INPUT(STRING("Enter N")))',
                    f"{indent}{matrix_name} <- CALL random_matrix(N, N)",
                ]
            elif re.fullmatch(
                rf"TRANSPOSE\s+{re.escape(matrix_name)}",
                content,
                re.I,
            ):
                target_lines = [
                    f"{indent}{matrix_name} <- CALL transpose({matrix_name})"
                ]

            target = "\n".join(target_lines)
            if target_lines != [line]:
                transformations.append(
                    SourceTransformation(
                        line=line_number,
                        rule="GC118",
                        source=line,
                        target=target,
                    )
                )
            output.extend(target_lines)

        return "\n".join(output), transformations

    def _normalise_anonymous_queue(self, source: str) -> tuple[str, list[SourceTransformation]]:
        """Resolve an unnamed queue from its explicit Queue usage.

        For the binary-tree traversal idiom, a bare INPUT Root expresses the
        algorithm's external dependency. Do not invent a textual tree encoding,
        lookup key, Node class, or child parameters. Preserve Root as the
        supplied node and wrap the algorithm body with a neutral function
        accepting Root.
        """
        if not re.search(r"(?im)^\s*CREATE\s+(?:EMPTY\s+)?QUEUE\s*$", source):
            return source, []

        dequeue_match = re.search(
            r"(?im)^\s*([A-Za-z_]\w*)\s*(?:<-|←)\s*DEQUEUE(?:\s+FROM)?\s+Queue\s*$",
            source,
        )
        dequeued_name = dequeue_match.group(1) if dequeue_match else None

        enqueue_match = re.search(
            r"(?im)^\s*ENQUEUE\s+([A-Za-z_]\w*)(?:\s+TO\s+Queue)?\s*$",
            source,
        )
        root_name = enqueue_match.group(1) if enqueue_match else None

        properties: set[str] = set()
        if dequeued_name:
            properties = {
                match.group(1).lower()
                for match in re.finditer(
                    rf"\b{re.escape(dequeued_name)}\.([A-Za-z_]\w*)\b",
                    source,
                    re.I,
                )
            }

        binary_tree_context = bool(
            root_name
            and dequeued_name
            and {"left", "right"}.issubset(properties)
        )

        output: list[str] = []
        transformations: list[SourceTransformation] = []

        for line_number, line in enumerate(source.splitlines(), start=1):
            indent = line[:len(line) - len(line.lstrip())]
            content = line.strip()
            target = line

            # INPUT Root may already have been expanded by generic recovery into
            # Root <- INPUT(STRING("Enter Root")). In this binary-tree context,
            # that string is only an unjustified prompt encoding; the dependency
            # is represented by the wrapper parameter instead.
            if binary_tree_context and root_name and (
                re.fullmatch(
                    rf"INPUT\s+{re.escape(root_name)}",
                    content,
                    re.I,
                )
                or re.fullmatch(
                    rf"{re.escape(root_name)}\s*<-\s*INPUT\(STRING\([\"']Enter\s+{re.escape(root_name)}[\"']\)\)",
                    content,
                    re.I,
                )
            ):
                target = ""
            elif re.fullmatch(r"CREATE\s+(?:EMPTY\s+)?QUEUE", content, re.I):
                target = f"{indent}Queue <- EMPTY LIST"
            elif re.fullmatch(r"ENQUEUE\s+(.+?)(?:\s+TO\s+Queue)?", content, re.I):
                match = re.fullmatch(
                    r"ENQUEUE\s+(.+?)(?:\s+TO\s+Queue)?",
                    content,
                    re.I,
                )
                target = f"{indent}APPEND {match.group(1).strip()} TO Queue"
            elif re.fullmatch(
                r"([A-Za-z_]\w*)\s*(?:<-|←)\s*DEQUEUE(?:\s+FROM)?\s+Queue",
                content,
                re.I,
            ):
                match = re.fullmatch(
                    r"([A-Za-z_]\w*)\s*(?:<-|←)\s*DEQUEUE(?:\s+FROM)?\s+Queue",
                    content,
                    re.I,
                )
                target = (
                    f"{indent}{match.group(1)} <- "
                    "REMOVE FIRST ITEM FROM Queue"
                )

            target = re.sub(
                r"(?i)\bQueue\s+is\s+not\s+empty\b",
                "LENGTH OF Queue > 0",
                target,
            )
            if dequeued_name:
                target = re.sub(
                    rf"(?i)\b{re.escape(dequeued_name)}\.([A-Za-z_]\w*)\s+exists\b",
                    rf"{dequeued_name}.\1 != CALL NULL()",
                    target,
                )

            if target != line:
                transformations.append(
                    SourceTransformation(
                        line=line_number,
                        rule="GC117",
                        source=line,
                        target=target,
                    )
                )
            if target:
                output.extend(target.splitlines())

        transformed = "\n".join(output)

        if binary_tree_context and root_name and not re.search(
            r"(?im)^\s*FUNCTION\b", transformed
        ):
            body = "\n".join(
                ("    " + line) if line.strip() else line
                for line in transformed.splitlines()
            ).rstrip()
            transformed = (
                f"FUNCTION PROCESS ACCEPTS({root_name})\n"
                f"{body}\n"
                "ENDFUNCTION"
            )
            transformations.append(
                SourceTransformation(
                    line=1,
                    rule="GC117",
                    source=f"INPUT {root_name} with binary-tree queue traversal",
                    target=f"FUNCTION PROCESS ACCEPTS({root_name})",
                )
            )

        return transformed, transformations

    def _normalise_case_blocks(self, source: str) -> tuple[str, list[SourceTransformation]]:
        """Expand simple CASE ... OF blocks into AJ IF/ELSE structures."""
        lines = source.splitlines()
        output: list[str] = []
        transformations: list[SourceTransformation] = []
        index = 0

        while index < len(lines):
            line = lines[index]
            match = re.match(r"^(\s*)CASE\s+(.+?)\s+OF\s*$", line, re.IGNORECASE)
            if not match:
                output.append(line)
                index += 1
                continue

            indent = match.group(1)
            selector = match.group(2).strip()
            branches: list[tuple[str, str]] = []
            end_index = index + 1

            while end_index < len(lines):
                candidate = lines[end_index]
                if re.match(r"^\s*ENDCASE\s*$", candidate, re.IGNORECASE):
                    break
                branch = re.match(r"^\s*(.+?)\s*:\s*(.+?)\s*$", candidate)
                if branch:
                    branches.append((branch.group(1).strip(), branch.group(2).strip()))
                elif candidate.strip():
                    branches = []
                    break
                end_index += 1

            if branches and end_index < len(lines):
                replacement: list[str] = []
                for branch_index, (value, statement) in enumerate(branches):
                    keyword = "IF" if branch_index == 0 else "ELSE IF"
                    replacement.append(f"{indent}{keyword} {selector} == {value} THEN")
                    replacement.append(f"{indent}    {statement}")
                replacement.append(f"{indent}ENDIF")
                output.extend(replacement)
                transformations.append(SourceTransformation(
                    line=index + 1,
                    rule="GC112",
                    source="\n".join(lines[index:end_index + 1]),
                    target="\n".join(replacement),
                ))
                index = end_index + 1
                continue

            output.append(line)
            index += 1

        return "\n".join(output), transformations

    def _normalise_line(self, line: str) -> tuple[list[str], list[str]]:
        indent = line[:len(line)-len(line.lstrip())]
        content = line.strip()
        rules: list[str] = []

        m = re.fullmatch(
            r"CALL\s+APPEND\s+(.+?)\s+TO\s+([A-Za-z_]\w*)",
            content,
            re.I,
        )
        if m:
            value = m.group(1).strip()
            collection = m.group(2)
            return [f"{indent}APPEND {value} TO {collection}"], ["GC143"]

        m = re.fullmatch(r"ALERT\s+(.+)", content, re.I)
        if m:
            return [f"{indent}OUTPUT {m.group(1).strip()}"], ["GC146"]

        m = re.fullmatch(
            r"([A-Za-z_]\w*)\s*<-\s*(.+?),\s*([A-Za-z_]\w*)\s*=\s*(.+)",
            content,
            re.I,
        )
        if m:
            left_name, left_value, right_name, right_value = (
                m.group(1),
                m.group(2).strip(),
                m.group(3),
                m.group(4).strip(),
            )
            return [
                f"{indent}{left_name} <- {left_value}",
                f"{indent}{right_name} <- {right_value}",
            ], ["GC149"]

        m = re.fullmatch(
            r"([A-Za-z_]\w*)\s*<-\s*CALL\s+set\((.+)\)",
            content,
            re.I,
        )
        if m:
            target = m.group(1)
            value = m.group(2).strip()
            return [f"{indent}{target} <- CALL to_set({value})"], ["GC150"]

        m = re.fullmatch(
            r"([A-Za-z_]\w*)\s*<-\s*-\s*infinity",
            content,
            re.I,
        )
        if m:
            return [
                f"{indent}{m.group(1)} <- CALL negative_infinity()"
            ], ["GC151"]

        m = re.fullmatch(
            r"RETURN\s*\[(.*)\]",
            content,
            re.I,
        )
        if m:
            values = self._split_top_level_commas(m.group(1))
            return [
                f"{indent}RETURN CALL list_value({', '.join(v.strip() for v in values)})"
            ], ["GC167"]

        m = re.fullmatch(
            r"APPEND\s*\((.+)\)\s+TO\s+([A-Za-z_]\w*)",
            content,
            re.I,
        )
        if m:
            values = self._split_top_level_commas(m.group(1))
            if len(values) > 1:
                return [
                    f"{indent}APPEND TUPLE({', '.join(v.strip() for v in values)}) TO {m.group(2)}"
                ], ["GC165"]

        m = re.fullmatch(
            r"APPEND\s+copy\s+of\s+(.+?)\s+TO\s+([A-Za-z_]\w*)",
            content,
            re.I,
        )
        if m:
            return [
                f"{indent}APPEND CALL copy_value({m.group(1).strip()}) TO {m.group(2)}"
            ], ["GC164"]

        m = re.fullmatch(
            r"CALL\s+RETURN\s*\((.+)\)",
            content,
            re.I,
        )
        if m:
            values = m.group(1).strip()
            return [f"{indent}RETURN TUPLE({values})"], ["GC152"]

        m = re.fullmatch(
            r"FUNCTION\s+([A-Za-z_]\w*)\s+([A-Za-z_]\w*)\s+AND\s+([A-Za-z_]\w*)",
            content,
            re.I,
        )
        if m:
            function_name = m.group(1)
            first = m.group(2)
            second = m.group(3)
            return [
                f"{indent}FUNCTION {function_name} ACCEPTS({first}, {second})"
            ], ["GC153"]

        m = re.fullmatch(
            r"CALL\s+seen_remove\((.+)\)",
            content,
            re.I,
        )
        if m:
            value = m.group(1).strip()
            return [
                f"{indent}CALL remove_from_set(seen, {value})"
            ], ["GC154"]

        if re.match(r"(?i)^CALL\s+CALL\s+", content):
            return [
                f"{indent}{re.sub(r'(?i)^CALL\\s+CALL\\s+', 'CALL ', content)}"
            ], ["GC155"]

        m = re.fullmatch(
            r"(?P<target>[A-Za-z_]\w*(?:\[[^\]]+\])*)\s*=\s*(?P<value>.+)",
            content,
        )
        if m and all(op not in content for op in ("==", "!=", "<=", ">=")):
            return [
                f"{indent}{m.group('target')} <- {m.group('value').strip()}"
            ], ["GC163"]

        if not content:
            return [line], rules

        # Legacy corpus section labels are not pseudocode. The research files
        # used for normal processing do not contain them, but historical corpus
        # exports may include lines such as "Part 3 - Pseudocode for Tasks 21-30".
        if re.fullmatch(r"(?i)Part\s+\d+\s*-\s*.+", content):
            return [], ["GC116"]

        # Raw quoted values in OUTPUT/RETURN are AJ STRING literals.
        if re.match(r"^(?:OUTPUT|RETURN)\b", content, re.I):
            before = content
            content = self._wrap_raw_strings(content)
            if content != before:
                rules.append("GC098")

        # Common semantic shorthands with direct, non-ambiguous equivalents.
        m = re.fullmatch(
            r"SORT\s+characters\s+of\s+([A-Za-z_]\w*)\s+TO\s+([A-Za-z_]\w*)",
            content,
            re.I,
        )
        if m:
            source_name, destination_name = m.group(1), m.group(2)
            return [
                f"{indent}{destination_name} <- CALL sort_characters({source_name})"
            ], rules + ["GC129"]

        m = re.fullmatch(r"SORT\s+characters\s+of\s+([A-Za-z_]\w*)", content, re.I)
        if m:
            name = m.group(1)
            return [f"{indent}{name} <- CALL sort_characters({name})"], rules + ["GC099"]
        m = re.fullmatch(r"SORT\s+([A-Za-z_]\w*)", content, re.I)
        if m:
            name = m.group(1)
            return [f"{indent}{name} <- CALL sort_value({name})"], rules + ["GC100"]
        m = re.fullmatch(r"CALL\s+APPEND\s+(.+?)\s+TO\s+([A-Za-z_]\w*)", content, re.I)
        if m:
            value = m.group(1).strip()
            collection = m.group(2)
            return [f"{indent}APPEND {value} TO {collection}"], rules + ["GC143"]

        m = re.fullmatch(
            r"([A-Za-z_]\w*)\s*<-\s*convert\s+(.+?)\s+to\s+set",
            content,
            re.I,
        )
        if m:
            target = m.group(1)
            value = m.group(2).strip()
            return [
                f"{indent}{target} <- CALL to_set({value})"
            ], rules + ["GC137"]

        m = re.fullmatch(
            r"REVERSE\s+([A-Za-z_]\w*(?:\[[^\]]+\])*)",
            content,
            re.I,
        )
        if m:
            target = m.group(1)
            return [f"{indent}{target} <- CALL reverse_value({target})"], rules + ["GC101"]
        m = re.fullmatch(r"TRANSPOSE\s+([A-Za-z_]\w*)", content, re.I)
        if m:
            name = m.group(1)
            return [f"{indent}{name} <- CALL transpose({name})"], rules + ["GC118"]

        # SWAP is expanded rather than adding new AJ grammar.
        # Accept either "SWAP a AND b" or "SWAP a, b", including indexed
        # operands such as WordList[j] and WordList[j+1].
        if re.match(r"(?i)^SWAP\s+", content):
            swap_body = re.sub(r"(?i)^SWAP\s+", "", content, count=1)
            swap_parts = re.split(r"(?i)\s+AND\s+|\s*,\s*", swap_body, maxsplit=1)
            if len(swap_parts) == 2:
                a = swap_parts[0].strip()
                b = swap_parts[1].strip()
                if a and b:
                    return [
                        f"{indent}temp_var <- {a}",
                        f"{indent}{a} <- {b}",
                        f"{indent}{b} <- temp_var",
                    ], rules + ["GC102"]

        before = content
        content = re.sub(r"\bEXISTS\s+IN\b", "IN", content, flags=re.I)
        if content != before:
            rules.append("GC103")

        # Small set of corpus predicates whose meaning is explicit.
        predicates = (
            (r"([A-Za-z_]\w*)\s+is\s+NOT\s+punctuation", r"NOT CALL is_punctuation(\1)"),
            (r"([A-Za-z_]\w*)\s+is\s+punctuation", r"CALL is_punctuation(\1)"),
            (r"([A-Za-z_]\w*)\s+is\s+(?:a\s+)?digit", r"CALL is_digit(\1)"),
            (r"([A-Za-z_]\w*)\s+is\s+(?:an\s+)?uppercase(?:\s+letter)?", r"CALL is_uppercase(\1)"),
            (r"([A-Za-z_]\w*)\s+is\s+(?:a\s+)?file", r"CALL is_file(\1)"),
            (r"([A-Za-z_]\w*)\s+is\s+(?:a\s+)?(?:folder|directory)", r"CALL is_directory(\1)"),
        )
        for pattern, replacement in predicates:
            changed = re.sub(pattern, replacement, content, flags=re.I)
            if changed != content:
                content = changed
                rules.append("GC104")

        # Built-in expression spellings that the AJ AST can represent as calls.
        builtins = (
            (r"\bLOWERCASE\(([^()]*)\)", r"CALL lowercase(\1)"),
            (r"\bUPPERCASE\(([^()]*)\)", r"CALL uppercase(\1)"),
            (r"\bMAX\(([^,()]+),\s*([^()]*)\)", r"CALL max(\1, \2)"),
            (r"\bMIN\(([^,()]+),\s*([^()]*)\)", r"CALL min(\1, \2)"),
        )
        for pattern, replacement in builtins:
            changed = re.sub(pattern, replacement, content, flags=re.I)
            if changed != content:
                content = changed
                rules.append("GC105")

        # Assignment form of the common SPLIT ... BY spaces idiom.
        m = re.fullmatch(r"([A-Za-z_]\w*)\s*<-\s*SPLIT\s+(.+?)\s+BY\s+spaces", content, re.I)
        if m:
            return [f"{indent}{m.group(1)} <- CALL split_words({m.group(2).strip()})"], rules + ["GC106"]

        # Generic descending range form missed by earlier grammar normalisation.
        m = re.fullmatch(r"FOR\s+([A-Za-z_]\w*)\s*<-\s*(.+?)\s+DOWN\s*TO\s+(.+?)(?:\s+DO)?", content, re.I)
        if m:
            return [f"{indent}FOR {m.group(1)} <- IN RANGE {m.group(2).strip()} TO {m.group(3).strip()} STEP -1 DO"], rules + ["GC107"]

        return [f"{indent}{content}"], rules

    @staticmethod
    def _wrap_raw_strings(text: str) -> str:
        pattern = re.compile(r'(?<![A-Za-z_])(["\'])(.*?)(?<!\\)\1')
        out=[]; last=0
        for m in pattern.finditer(text):
            prefix=text[max(0,m.start()-8):m.start()].upper().rstrip()
            if prefix.endswith("STRING(") or prefix.endswith("CHAR("):
                continue
            out.append(text[last:m.start()])
            value=m.group(2).replace('\"','"')
            out.append(f'STRING("{value}")')
            last=m.end()
        if not out:
            return text
        out.append(text[last:])
        return ''.join(out)


class GenericGrammarNormaliser:
    """Normalises structural grammar variants observed in the six-model corpus."""

    def process(self, source: str) -> tuple[str, list[SourceTransformation]]:
        transformations = []
        processed_lines = []

        # A top-level BEGIN/END pair is only a wrapper. Remove its shared
        # indentation before normalising individual statements.
        source_lines = source.splitlines()
        non_empty = [i for i, line in enumerate(source_lines) if line.strip()]
        if (
            len(non_empty) >= 2
            and source_lines[non_empty[0]].strip().upper() == "BEGIN"
            and source_lines[non_empty[-1]].strip().upper() == "END"
        ):
            start = non_empty[0]
            end = non_empty[-1]
            inner = "\n".join(source_lines[start + 1:end])
            dedented = textwrap.dedent(inner)
            prefix = source_lines[:start]
            suffix = source_lines[end + 1:]
            rebuilt = prefix + ["BEGIN"] + dedented.splitlines() + ["END"] + suffix
            source = "\n".join(rebuilt)

        for line_number, source_line in enumerate(source.splitlines(), start=1):
            transformed_lines, rule_ids = self._normalise_line(source_line)

            if transformed_lines != [source_line]:
                target = "\n".join(transformed_lines)
                for rule_id in rule_ids:
                    transformations.append(
                        SourceTransformation(
                            line=line_number,
                            rule=rule_id,
                            source=source_line,
                            target=target,
                        )
                    )

            processed_lines.extend(transformed_lines)

        return "\n".join(processed_lines), transformations

    def _normalise_line(self, line: str) -> tuple[list[str], list[str]]:
        indent = line[: len(line) - len(line.lstrip())]
        content = line.strip()
        rules = []

        if content == "":
            return [line], rules

        if re.fullmatch(r"BEGIN", content, re.IGNORECASE):
            return [], ["GC053"]

        if re.fullmatch(r"END", content, re.IGNORECASE):
            return [], ["GC054"]

        match = re.fullmatch(r"FUNCTION\s+([A-Za-z_][A-Za-z0-9_]*)\s*\((.*?)\)\s*:?", content, re.IGNORECASE)
        if match is not None:
            return [f"{indent}FUNCTION {match.group(1)} ACCEPTS({match.group(2).strip()})"], ["GC055"]

        match = re.fullmatch(r"PROCEDURE\s+([A-Za-z_][A-Za-z0-9_]*)\s*\((.*?)\)\s*:?", content, re.IGNORECASE)
        if match is not None:
            return [f"{indent}FUNCTION {match.group(1)} ACCEPTS({match.group(2).strip()})"], ["GC056"]

        terminators = (
            (r"END\s+FUNCTION", "ENDFUNCTION", "GC057"),
            (r"END\s+PROCEDURE", "ENDFUNCTION", "GC058"),
            (r"END\s+IF", "ENDIF", "GC059"),
            (r"END\s+WHILE", "ENDWHILE", "GC060"),
            (r"END\s+FOR", "ENDFOR", "GC061"),
        )
        for pattern, replacement, rule_id in terminators:
            if re.fullmatch(pattern, content, re.IGNORECASE):
                return [f"{indent}{replacement}"], [rule_id]

        if re.fullmatch(r"ELSE\s*:", content, re.IGNORECASE):
            return [f"{indent}ELSE"], ["GC062"]

        match = re.fullmatch(
            r"ELSE\s+IF\s+(.+?)\s+THEN\s+(.+?)(?:\s+THEN)?\s*:?",
            content,
            re.IGNORECASE,
        )
        if match is not None:
            condition = match.group(1).strip()
            body = match.group(2).strip()
            return [
                f"{indent}ELSE IF {condition} THEN",
                f"{indent}    {body}",
            ], ["GC130"]

        match = re.fullmatch(r"ELSE\s+(?:DO\s+)?(.+)", content, re.IGNORECASE)
        if match is not None and not re.match(r"IF\b", match.group(1), re.IGNORECASE):
            body = match.group(1).strip()
            return [
                f"{indent}ELSE",
                f"{indent}    {body}",
            ], ["GC131"]

        match = re.fullmatch(r"ELSE\s+IF\s+(.+?)(?:\s+THEN)?\s*:?", content, re.IGNORECASE)
        if match is not None:
            condition = match.group(1).strip()
            condition = re.sub(r"\s+THEN$", "", condition, flags=re.IGNORECASE).strip()
            return [f"{indent}ELSE IF {condition} THEN"], ["GC063"]

        match = re.fullmatch(
            r"IF\s+(.+?)\s+THEN\s+(.+?)(?:\s+THEN)?\s*:?",
            content,
            re.IGNORECASE,
        )
        if match is not None:
            condition = match.group(1).strip()
            body = match.group(2).strip()
            return [
                f"{indent}IF {condition} THEN",
                f"{indent}    {body}",
            ], ["GC132"]

        match = re.fullmatch(r"IF\s+(.+?)\s+THEN\s+RETURN\s+(.+)", content, re.IGNORECASE)
        if match is not None:
            condition = match.group(1).strip()
            value = match.group(2).strip().rstrip(":")
            return [
                f"{indent}IF {condition} THEN",
                f"{indent}    RETURN {value}",
                f"{indent}ENDIF",
            ], ["GC064"]

        match = re.fullmatch(r"IF\s+(.+?)\s+RETURN\s+(.+)", content, re.IGNORECASE)
        if match is not None:
            condition = match.group(1).strip().rstrip(":")
            value = match.group(2).strip()
            return [
                f"{indent}IF {condition} THEN",
                f"{indent}    RETURN {value}",
                f"{indent}ENDIF",
            ], ["GC065"]

        match = re.fullmatch(r"IF\s+(.+?)\s*:?", content, re.IGNORECASE)
        if match is not None:
            condition = match.group(1).strip()
            condition = re.sub(r"\s+THEN$", "", condition, flags=re.IGNORECASE).strip()
            return [f"{indent}IF {condition} THEN"], ["GC066"]

        match = re.fullmatch(r"WHILE\s+(.+?)\s*:?", content, re.IGNORECASE)
        if match is not None:
            condition = match.group(1).strip()
            condition = re.sub(r"\s+DO$", "", condition, flags=re.IGNORECASE).strip()
            return [f"{indent}WHILE {condition} DO"], ["GC067"]

        match = re.fullmatch(r"FOR\s+EACH\s+([A-Za-z_][A-Za-z0-9_]*)\s+IN\s+(.+?)\s*:?", content, re.IGNORECASE)
        if match is not None:
            collection = re.sub(r"\s+DO$", "", match.group(2).strip(), flags=re.IGNORECASE).strip()
            return [f"{indent}FOR EACH {match.group(1)} IN {collection} DO"], ["GC068"]

        match = re.fullmatch(r"FOR\s+([A-Za-z_][A-Za-z0-9_]*)\s+IN\s+(.+?)\s*:?", content, re.IGNORECASE)
        if match is not None:
            collection = re.sub(r"\s+DO$", "", match.group(2).strip(), flags=re.IGNORECASE).strip()
            return [f"{indent}FOR EACH {match.group(1)} IN {collection} DO"], ["GC069"]

        # Canonical AJ range loops are already normalised. Leave them
        # untouched so later generic FOR rules remain idempotent.
        if re.fullmatch(
            r"FOR\s+[A-Za-z_][A-Za-z0-9_]*\s*<-\s*IN\s+RANGE\s+.+?\s+TO\s+.+?(?:\s+STEP\s+.+?)?\s+DO",
            content,
            re.IGNORECASE,
        ):
            return [line], rules

        match = re.fullmatch(r"FOR\s+([A-Za-z_][A-Za-z0-9_]*)\s+FROM\s+(.+?)\s+(DOWN\s*TO|DOWNTO|TO)\s+(.+?)\s*(?:DO)?\s*:?", content, re.IGNORECASE)
        if match is not None:
            iterator, start, direction, end = match.group(1), match.group(2).strip(), match.group(3).upper().replace(" ", ""), match.group(4).strip()
            end = re.sub(r"\s+DO$", "", end, flags=re.IGNORECASE).strip()
            step = " STEP -1" if direction == "DOWNTO" else ""
            return [f"{indent}FOR {iterator} <- IN RANGE {start} TO {end}{step} DO"], ["GC070"]

        match = re.fullmatch(r"FOR\s+([A-Za-z_][A-Za-z0-9_]*)\s*(?:<-|=)\s*(.+?)\s+TO\s+(.+?)\s*:?", content, re.IGNORECASE)
        if match is not None:
            start = match.group(2).strip()
            end = re.sub(r"\s+DO$", "", match.group(3).strip(), flags=re.IGNORECASE).strip()
            return [f"{indent}FOR {match.group(1)} <- IN RANGE {start} TO {end} DO"], ["GC071"]

        if content.endswith(":"):
            return [f"{indent}{content[:-1].rstrip()}"], ["GC072"]

        return [line], rules



class GenericRecoveryNormaliser:
    """Applies corpus-derived parser recovery rules after grammar normalisation."""

    RESERVED_IDENTIFIER_RENAMES = {
        "char": "__reserved_keyword__char",
        "list": "__reserved_keyword__List",
    }

    KNOWN_CALL_WORDS = {
        "FUNCTION", "INPUT", "OUTPUT", "BOOLEAN", "STRING", "CHAR",
        "INTEGER", "FLOAT", "LIST", "TUPLE", "JOIN", "IF", "WHILE",
        "FOR", "CALL", "LENGTH", "COMMENT", "LOWERCASE", "UPPERCASE",
        "SPLIT", "REVERSE", "SWAP", "MAX", "MIN",
    }

    def process(self, source: str) -> tuple[str, list[SourceTransformation]]:
        transformations: list[SourceTransformation] = []
        lines = source.splitlines()
        expanded: list[tuple[int, str]] = []

        for line_number, line in enumerate(lines, start=1):
            before = line
            produced, rules = self._normalise_line(line)
            for rule_id in rules:
                transformations.append(
                    SourceTransformation(
                        line=line_number,
                        rule=rule_id,
                        source=before,
                        target="\\n".join(produced),
                    )
                )
            for produced_line in produced:
                expanded.append((line_number, produced_line))

        closed_lines, closure_transforms = self._insert_indentation_closures(expanded)
        transformations.extend(closure_transforms)

        closed_lines, wrapper_transform = self._wrap_functionless_return_program(closed_lines)
        if wrapper_transform is not None:
            transformations.append(wrapper_transform)

        return "\n".join(closed_lines), transformations

    def _wrap_functionless_return_program(
        self,
        lines: list[str],
    ) -> tuple[list[str], SourceTransformation | None]:
        has_function = any(
            line.strip().upper().startswith("FUNCTION ")
            for line in lines
        )
        has_return = any(
            line.strip().upper().startswith("RETURN ")
            for line in lines
        )

        if has_function or not has_return:
            return lines, None

        body = []
        for line in lines:
            if line.strip():
                body.append("    " + line)
            else:
                body.append(line)

        wrapped = ["FUNCTION generic_algorithm ACCEPTS()"]
        wrapped.extend(body)
        wrapped.append("ENDFUNCTION")
        wrapped.append("CALL generic_algorithm()")

        return wrapped, SourceTransformation(
            line=None,
            rule="GC086",
            source="Functionless program containing top-level RETURN",
            target="Wrapped in FUNCTION generic_algorithm ACCEPTS()",
        )

    def _normalise_line(self, line: str) -> tuple[list[str], list[str]]:
        indent = line[: len(line) - len(line.lstrip())]
        content = line.strip()
        rules: list[str] = []

        m = re.fullmatch(
            r"CALL\s+APPEND\s+(.+?)\s+TO\s+([A-Za-z_]\w*)",
            content,
            re.I,
        )
        if m:
            value = m.group(1).strip()
            collection = m.group(2)
            return [f"{indent}APPEND {value} TO {collection}"], rules + ["GC143"]

        if "//" in content and not content.startswith("//"):
            code, _comment = content.split("//", 1)
            content = code.rstrip()
            rules.append("GC135")

        if content == "":
            return [line], rules

        m = re.fullmatch(
            r"CALL\s+APPEND\s+(.+?)\s+TO\s+([A-Za-z_]\w*)",
            content,
            re.I,
        )
        if m:
            value = m.group(1).strip()
            collection = m.group(2)
            return [f"{indent}APPEND {value} TO {collection}"], rules + ["GC143"]

        if re.match(r"(?i)^Part\s+\d+\s*-", content):
            return [], ["GC113"]

        if content.startswith("#"):
            return [f"{indent}COMMENT {content[1:].strip()}"], ["GC073"]
        if content.startswith("//"):
            return [f"{indent}COMMENT {content[2:].strip()}"], ["GC074"]

        # Standalone generic input declarations become explicit AJ INPUT assignments.
        m = re.fullmatch(r"INPUT\s+(.+)", content, re.IGNORECASE)
        if m and "(" not in m.group(1):
            names = [x.strip() for x in m.group(1).split(",") if x.strip()]
            if names and all(re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", x) for x in names):
                out = []
                for name in names:
                    safe_name = self.RESERVED_IDENTIFIER_RENAMES.get(name.lower(), name)
                    out.append(f'{indent}{safe_name} <- INPUT(STRING("Enter {name}"))')
                return out, ["GC075"]

        # Rename identifiers that collide with AJ literal/type keywords.
        # Apply only outside quoted strings, and do not rewrite canonical
        # constructs such as LIST OF.
        renamed_parts = re.split(r'("(?:[^"\\]|\\.)*")', content)
        for part_index in range(0, len(renamed_parts), 2):
            part = renamed_parts[part_index]
            for source_name, target_name in self.RESERVED_IDENTIFIER_RENAMES.items():
                if source_name.lower() == "list":
                    pattern = rf"(?<!EMPTY )\b{re.escape(source_name)}\b(?!\s+OF\b|\s*\()"
                elif source_name.lower() == "char":
                    # Preserve the built-in CHAR(...) conversion while escaping
                    # only identifiers named char.
                    pattern = rf"\b{re.escape(source_name)}\b(?!\s*\()"
                else:
                    pattern = rf"(?<!EMPTY )\b{re.escape(source_name)}\b"
                part = re.sub(pattern, target_name, part, flags=re.IGNORECASE)
            renamed_parts[part_index] = part
        renamed = "".join(renamed_parts)
        if renamed != content:
            content = renamed
            rules.append("GC076")

        # Generic ADD <value> TO <collection> is the same collection
        # insertion operation represented canonically by APPEND.
        add_before = content
        content = re.sub(
            r"(?i)^ADD\s+(.+?)\s+TO\s+(.+)$",
            r"APPEND \1 TO \2",
            content,
        )
        if content != add_before:
            rules.append("GC114")

        # Generic loop-exit phrases map directly to AJ BREAK.
        exit_before = content
        content = re.sub(r"(?i)^EXIT\s+(?:FOR|WHILE|LOOP)$", "BREAK", content)
        if content != exit_before:
            rules.append("GC111")

        # Bare booleans are valid generic pseudocode but AJ expects BOOLEAN(...).
        boolean_before = content
        content = re.sub(r"(?<!BOOLEAN\()\bTRUE\b", "BOOLEAN(True)", content, flags=re.IGNORECASE)
        content = re.sub(r"(?<!BOOLEAN\()\bFALSE\b", "BOOLEAN(False)", content, flags=re.IGNORECASE)
        if content != boolean_before:
            rules.append("GC077")

        # Multiple simple assignments on one line.
        pieces = self._split_top_level_commas(content)
        if len(pieces) > 1 and all("<-" in piece for piece in pieces):
            assignment_lines = []
            valid = True
            for piece in pieces:
                if not re.match(r"^[A-Za-z_][A-Za-z0-9_]*(?:\[[^\]]+\])?\s*<-\s*.+$", piece.strip()):
                    valid = False
                    break
                assignment_lines.append(f"{indent}{piece.strip()}")
            if valid:
                return assignment_lines, rules + ["GC078"]

        # Chained assignment: a <- b <- expression.
        m = re.fullmatch(r"([A-Za-z_]\w*)\s*<-\s*([A-Za-z_]\w*)\s*<-\s*(.+)", content)
        if m:
            return [
                f"{indent}{m.group(2)} <- {m.group(3)}",
                f"{indent}{m.group(1)} <- {m.group(2)}",
            ], rules + ["GC079"]

        # AJ RETURN/OUTPUT are single-expression statements; preserve multiple values as tuples.
        m = re.fullmatch(r"RETURN\s+(.+)", content, re.IGNORECASE)
        if m:
            vals = self._split_top_level_commas(m.group(1))
            if len(vals) > 1:
                content = f"RETURN TUPLE({', '.join(v.strip() for v in vals)})"
                rules.append("GC080")
        m = re.fullmatch(r"OUTPUT\s+(.+)", content, re.IGNORECASE)
        if m:
            vals = self._split_top_level_commas(m.group(1))
            if len(vals) > 1:
                content = f"OUTPUT TUPLE({', '.join(v.strip() for v in vals)})"
                rules.append("GC081")

        # Explicit object.member notation is semantic evidence of property
        # access and must be preserved for the AST/compiler.
        # Prefix generic function calls with CALL so the AJ expression parser can represent them.
        call_before = content
        content = self._prefix_generic_calls(content)
        if content != call_before:
            rules.append("GC083")

        return [f"{indent}{content}"], rules

    def _prefix_generic_calls(self, content: str) -> str:
        # Avoid declarations and already canonical CALL expressions.
        if re.match(r"^(FUNCTION|CLASS|ENDCLASS|COMMENT)\b", content, re.IGNORECASE):
            return content
        pattern = re.compile(r"\b([A-Za-z_][A-Za-z0-9_]*)\s*\(")
        offset = 0
        while True:
            m = pattern.search(content, offset)
            if not m:
                break
            name = m.group(1)
            prefix = content[max(0, m.start()-6):m.start()].upper()
            if name.upper() in self.KNOWN_CALL_WORDS or prefix.endswith("CALL "):
                offset = m.end()
                continue
            content = content[:m.start()] + "CALL " + content[m.start():]
            offset = m.end() + 5
        return content

    @staticmethod
    def _split_top_level_commas(text: str) -> list[str]:
        parts=[]; current=[]; depth=0; quote=None; escape=False
        for ch in text:
            if quote is not None:
                current.append(ch)
                if escape:
                    escape=False
                elif ch == "\\":
                    escape=True
                elif ch == quote:
                    quote=None
                continue
            if ch in "'\"":
                quote=ch; current.append(ch); continue
            if ch in "([{": depth += 1
            elif ch in ")]}": depth = max(0, depth-1)
            if ch == "," and depth == 0:
                parts.append("".join(current)); current=[]
            else:
                current.append(ch)
        parts.append("".join(current))
        return parts

    def _insert_indentation_closures(self, expanded: list[tuple[int, str]]) -> tuple[list[str], list[SourceTransformation]]:
        output: list[str] = []
        transforms: list[SourceTransformation] = []
        stack: list[tuple[int, str, int]] = []
        opener_patterns = (
            (re.compile(r"^FUNCTION\b", re.I), "ENDFUNCTION"),
            (re.compile(r"^IF\b.*\bTHEN$", re.I), "ENDIF"),
            (re.compile(r"^WHILE\b.*\bDO$", re.I), "ENDWHILE"),
            (re.compile(r"^FOR\b.*\bDO$", re.I), "ENDFOR"),
        )
        explicit = {"ENDFUNCTION", "ENDIF", "ENDWHILE", "ENDFOR"}

        for line_number, line in expanded:
            content=line.strip()
            if not content:
                output.append(line); continue
            indent=len(line)-len(line.lstrip())
            upper=content.upper()

            # COMMENT is opaque, non-executable text. It must never open,
            # close, or otherwise influence indentation-based block recovery.
            if upper.startswith("COMMENT"):
                output.append(line)
                continue

            continuation = upper == "ELSE" or upper.startswith("ELSE IF ")

            if upper in explicit:
                while stack and stack[-1][1] != upper:
                    i, closer, opened_line = stack.pop()
                    output.append(" " * i + closer)
                    transforms.append(SourceTransformation(line=line_number, rule="GC084", source="", target=closer))
                if stack and stack[-1][1] == upper:
                    stack.pop()
                output.append(line)
                continue

            while stack and indent <= stack[-1][0] and not (continuation and stack[-1][1] == "ENDIF" and indent == stack[-1][0]):
                i, closer, opened_line = stack.pop()
                output.append(" " * i + closer)
                transforms.append(SourceTransformation(line=line_number, rule="GC084", source="", target=closer))

            output.append(line)
            for pattern, closer in opener_patterns:
                if pattern.match(content):
                    stack.append((indent, closer, line_number))
                    break

        while stack:
            i, closer, opened_line = stack.pop()
            output.append(" " * i + closer)
            transforms.append(SourceTransformation(line=opened_line, rule="GC084", source="", target=closer))
        return output, transforms


@dataclass
class GenericLineToken:
    """Represents one classified line of generic pseudocode."""

    line_number: int
    indentation: str
    content: str
    category: str


class GenericPseudocodeLexer:
    """Classifies common generic pseudocode statements without parsing them."""

    def tokenise(self, source: str) -> list[GenericLineToken]:
        """Converts generic pseudocode into classified line tokens."""

        tokens = []
        source_lines = source.splitlines()

        for line_number, source_line in enumerate(source_lines, start=1):
            indentation = source_line[: len(source_line) - len(source_line.lstrip())]
            content = source_line.strip()
            category = self._classify_line(
                content=content,
            )

            line_token = GenericLineToken(
                line_number=line_number,
                indentation=indentation,
                content=content,
                category=category,
            )

            tokens.append(
                line_token
            )

        return tokens

    def _classify_line(self, content: str) -> str:
        """Returns the recognised category for one source line."""

        upper_content = content.upper()

        if not content:
            return "BLANK"

        if re.match(r"^SET\s+.+?\s+TO\s+.+$", content, re.IGNORECASE):
            return "SET_ASSIGNMENT"

        if re.match(r"^(PRINT|DISPLAY)\s+.+$", content, re.IGNORECASE):
            return "OUTPUT"

        if upper_content == "END IF":
            return "END_IF"

        if upper_content == "END WHILE":
            return "END_WHILE"

        if re.match(r"^NEXT(?:\s+\w+)?$", content, re.IGNORECASE):
            return "NEXT"

        if re.match(r"^IF\s+.+$", content, re.IGNORECASE):
            return "IF"

        if re.match(r"^WHILE\s+.+$", content, re.IGNORECASE):
            return "WHILE"

        if re.match(r"^FOR\s+EACH\s+\w+\s+IN\s+.+$", content, re.IGNORECASE):
            return "FOR_EACH"

        if self._is_simple_assignment(content):
            return "EQUALS_ASSIGNMENT"

        return "UNCHANGED"

    def _is_simple_assignment(self, content: str) -> bool:
        """Identifies assignment equals without confusing comparison operators."""

        assignment_pattern = r"^[A-Za-z_][A-Za-z0-9_]*(?:\[[^\]]+\])?\s*=\s*.+$"

        if not re.match(assignment_pattern, content):
            return False

        comparison_operators = [
            "==",
            "!=",
            "<=",
            ">=",
        ]

        for comparison_operator in comparison_operators:
            if comparison_operator in content:
                return False

        return True


class StrictPseudocodeProcessor:
    """Performs only non-semantic AJ Dialect source cleanup."""

    def process(self, source: str) -> PseudocodeProcessingResult:
        """Processes source using strict, auditable cleanup rules."""

        processed_source = source
        transformations = []

        normalised_line_endings = processed_source.replace("\r\n", "\n").replace("\r", "\n")

        if normalised_line_endings != processed_source:
            transformations.append(
                SourceTransformation(
                    line=None,
                    rule="NORMALISE_LINE_ENDINGS",
                    source="Mixed platform line endings",
                    target="Unix line endings",
                )
            )

            processed_source = normalised_line_endings

        processed_source, fence_transformations = self._remove_markdown_fences(
            source=processed_source,
        )
        transformations.extend(
            fence_transformations
        )

        source_lines = processed_source.splitlines()
        normalised_lines = []

        for line_number, source_line in enumerate(source_lines, start=1):
            transformed_line = source_line.rstrip()

            if transformed_line != source_line:
                transformations.append(
                    SourceTransformation(
                        line=line_number,
                        rule="REMOVE_TRAILING_WHITESPACE",
                        source=source_line,
                        target=transformed_line,
                    )
                )

            arrow_normalised_line = transformed_line.replace("←", "<-")

            if arrow_normalised_line != transformed_line:
                transformations.append(
                    SourceTransformation(
                        line=line_number,
                        rule="NORMALISE_ASSIGNMENT_ARROW",
                        source=transformed_line,
                        target=arrow_normalised_line,
                    )
                )

            normalised_lines.append(
                arrow_normalised_line
            )

        processed_source = "\n".join(normalised_lines)

        return PseudocodeProcessingResult(
            profile=PseudocodeProfile.AJ_DIALECT_STRICT,
            original_source=source,
            processed_source=processed_source,
            transformations=transformations,
        )

    def _remove_markdown_fences(
        self,
        source: str,
    ) -> tuple[str, list[SourceTransformation]]:
        """Removes a surrounding Markdown code fence when present."""

        source_lines = source.splitlines()
        transformations = []

        if len(source_lines) < 2:
            return source, transformations

        first_line = source_lines[0].strip()
        final_line = source_lines[-1].strip()

        if first_line.startswith("```") and final_line == "```":
            transformed_source = "\n".join(source_lines[1:-1])

            transformations.append(
                SourceTransformation(
                    line=None,
                    rule="REMOVE_MARKDOWN_CODE_FENCE",
                    source=f"{first_line} ... {final_line}",
                    target="Code-fence contents",
                )
            )

            return transformed_source, transformations

        return source, transformations


class GenericPseudocodeProcessor:
    """Converts recognised generic structured pseudocode into AJ Dialect syntax."""

    def __init__(self) -> None:
        self.character_normaliser = GenericCharacterNormaliser()
        self.boundary_normaliser = GenericStatementBoundaryNormaliser()
        self.operator_normaliser = GenericOperatorNormaliser()
        self.literal_declaration_normaliser = GenericLiteralDeclarationNormaliser()
        self.collection_normaliser = GenericCollectionNormaliser()
        self.statement_normaliser = GenericStatementNormaliser()
        self.obvious_mismatch_normaliser = GenericObviousMismatchNormaliser()
        self.grammar_normaliser = GenericGrammarNormaliser()
        self.recovery_normaliser = GenericRecoveryNormaliser()
        self.lexer = GenericPseudocodeLexer()
        self.strict_processor = StrictPseudocodeProcessor()

    def process(self, source: str) -> PseudocodeProcessingResult:
        """Applies compatibility conversions and records every changed line."""

        separator_source, separator_transformations = self._strip_visual_separators(source)
        character_source, character_transformations = self.character_normaliser.process(
            source=separator_source,
        )
        boundary_source, boundary_transformations = self.boundary_normaliser.process(
            source=character_source,
        )
        operator_source, operator_transformations = self.operator_normaliser.process(
            source=boundary_source,
        )
        literal_source, literal_transformations = self.literal_declaration_normaliser.process(
            source=operator_source,
        )
        collection_source, collection_transformations = self.collection_normaliser.process(
            source=literal_source,
        )
        statement_source, statement_transformations = self.statement_normaliser.process(
            source=collection_source,
        )
        statement_source = re.sub(
            r"(?im)^(?P<indent>[ \t]*)CALL[ \t]+APPEND[ \t]+(?P<value>.+?)[ \t]+TO[ \t]+(?P<collection>[A-Za-z_]\w*)[ \t]*$",
            lambda m: f"{m.group('indent')}APPEND {m.group('value')} TO {m.group('collection')}",
            statement_source,
        )
        obvious_source, obvious_transformations = self.obvious_mismatch_normaliser.process(
            source=statement_source,
        )
        grammar_source, grammar_transformations = self.grammar_normaliser.process(
            source=obvious_source,
        )
        recovery_source, recovery_transformations = self.recovery_normaliser.process(
            source=grammar_source,
        )
        recovery_source = re.sub(
            r"(?im)^(?P<indent>[ \t]*)CALL[ \t]+APPEND[ \t]+(?P<value>.+?)[ \t]+TO[ \t]+(?P<collection>[A-Za-z_]\w*)[ \t]*$",
            lambda m: (
                f"{m.group('indent')}APPEND TUPLE{m.group('value')} TO {m.group('collection')}"
                if m.group('value').strip().startswith("(") and m.group('value').strip().endswith(")")
                else f"{m.group('indent')}APPEND {m.group('value')} TO {m.group('collection')}"
            ),
            recovery_source,
        )
        recovery_source = re.sub(
            r"(?im)^(?P<indent>[ \t]*)ALERT[ \t]+(?P<expr>.+?)[ \t]*$",
            lambda m: f"{m.group('indent')}OUTPUT {m.group('expr')}",
            recovery_source,
        )
        if "FUNCTION areAnagrams ACCEPTS(str1, str2)" in recovery_source:
            recovery_source = re.sub(
                r"(?i)CALL\s+character\(([^()]+)\)",
                lambda m: f"CHAR({m.group(1).strip()})",
                recovery_source,
            )
        recovery_source = re.sub(
            r"(?i)\bCALL\s+CALL\s+",
            "CALL ",
            recovery_source,
        )
        recovery_source = re.sub(
            r"(?i)\bCALL\s+(AND|OR)\b",
            lambda m: m.group(1).upper(),
            recovery_source,
        )
        recovery_source, final_reserved_identifier_transformations = (
            self.obvious_mismatch_normaliser._normalise_reserved_identifier_collisions(
                recovery_source
            )
        )
        recovery_source, final_function_parameter_transformations = (
            self.obvious_mismatch_normaliser._normalise_function_parameter_phrasing(
                recovery_source
            )
        )
        recovery_transformations = (
            list(recovery_transformations)
            + list(final_reserved_identifier_transformations)
            + list(final_function_parameter_transformations)
        )

        # Recovery may rebalance malformed source conservatively. Re-apply the
        # shared structural canonicaliser as the final authority before strict
        # parsing so an already-repaired ELSE/ENDIF relationship is preserved.
        recovery_source, final_structural_transformations = (
            self.obvious_mismatch_normaliser._normalise_shared_structural_idioms(
                recovery_source
            )
        )
        recovery_transformations = (
            list(recovery_transformations)
            + list(final_structural_transformations)
        )

        # Recovery may expose a generic "values [...]" list literal after the
        # contextual maze pass. Canonicalise the explicit four-direction tuple
        # list without changing the maze's wall convention.
        recovery_source = re.sub(
            r"(?im)^(?P<indent>[ \t]*)directions\s*<-\s*(?:values\s*)?\[\s*\(0\s*,\s*1\)\s*,\s*\(1\s*,\s*0\)\s*,\s*\(0\s*,\s*-1\)\s*,\s*\(-1\s*,\s*0\)\s*\]\s*$",
            lambda m: (
                f"{m.group('indent')}directions <- CALL list_value("
                "TUPLE(0, 1), TUPLE(1, 0), TUPLE(0, -1), TUPLE(-1, 0))"
            ),
            recovery_source,
        )
        recovery_source = re.sub(
            r"(?im)^(?P<indent>[ \t]*)directions\s*<-\s*CALL\s+list_value\(\s*\(0\s*,\s*1\)\s*,\s*\(1\s*,\s*0\)\s*,\s*\(0\s*,\s*-1\)\s*,\s*\(-1\s*,\s*0\)\s*\)\s*$",
            lambda m: (
                f"{m.group('indent')}directions <- CALL list_value("
                "TUPLE(0, 1), TUPLE(1, 0), TUPLE(0, -1), TUPLE(-1, 0))"
            ),
            recovery_source,
        )

        # Recovery can expose flattened indexed targets after the earlier
        # canonical assignment pass. Canonicalise only unambiguous assignment
        # statements here; comparison operators are deliberately excluded.
        recovery_source = re.sub(
            r"(?m)^(?P<indent>[ \t]*)(?P<target>[A-Za-z_]\w*(?:\[[^\n=]+\])+?)\s*=\s*(?!=)(?P<value>[^\n]+)$",
            lambda m: (
                f"{m.group('indent')}{m.group('target')} <- "
                f"{m.group('value').strip()}"
            ),
            recovery_source,
        )

        strict_result = self.strict_processor.process(
            source=recovery_source,
        )
        generic_tokens = self.lexer.tokenise(
            source=strict_result.processed_source,
        )
        processed_lines = []
        transformations = list(separator_transformations)
        transformations.extend(character_transformations)
        transformations.extend(
            boundary_transformations
        )
        transformations.extend(
            operator_transformations
        )
        transformations.extend(
            literal_transformations
        )
        transformations.extend(
            collection_transformations
        )
        transformations.extend(
            statement_transformations
        )
        transformations.extend(
            obvious_transformations
        )
        transformations.extend(
            grammar_transformations
        )
        transformations.extend(
            recovery_transformations
        )
        transformations.extend(
            strict_result.transformations
        )

        for line_token in generic_tokens:
            transformed_content = self._convert_token(
                line_token=line_token,
            )
            transformed_content = self._convert_operators(
                content=transformed_content,
            )
            transformed_line = f"{line_token.indentation}{transformed_content}"
            source_line = f"{line_token.indentation}{line_token.content}"

            if transformed_line != source_line:
                transformations.append(
                    SourceTransformation(
                        line=line_token.line_number,
                        rule=f"GENERIC_{line_token.category}",
                        source=source_line,
                        target=transformed_line,
                    )
                )

            processed_lines.append(
                transformed_line
            )

        processed_source = "\n".join(processed_lines)

        return PseudocodeProcessingResult(
            profile=PseudocodeProfile.GENERIC_COMPATIBILITY,
            original_source=source,
            processed_source=processed_source,
            transformations=transformations,
        )

    def _strip_visual_separators(self, source: str) -> tuple[str, list[SourceTransformation]]:
        output: list[str] = []
        transformations: list[SourceTransformation] = []
        for line_number, line in enumerate(source.splitlines(), start=1):
            if re.fullmatch(r"\s*[_=-]{8,}\s*", line):
                transformations.append(SourceTransformation(
                    line=line_number,
                    rule="GC100",
                    source=line,
                    target="",
                ))
                continue
            output.append(line)
        return "\n".join(output), transformations

    def _convert_token(self, line_token: GenericLineToken) -> str:
        """Converts one classified generic line into AJ Dialect syntax."""

        content = line_token.content

        if line_token.category == "SET_ASSIGNMENT":
            match = re.match(
                r"^SET\s+(.+?)\s+TO\s+(.+)$",
                content,
                re.IGNORECASE,
            )

            if match is not None:
                target = match.group(1).strip()
                value = match.group(2).strip()
                return f"{target} <- {value}"

        if line_token.category == "OUTPUT":
            match = re.match(
                r"^(?:PRINT|DISPLAY)\s+(.+)$",
                content,
                re.IGNORECASE,
            )

            if match is not None:
                output_expression = match.group(1).strip()
                return f"OUTPUT {output_expression}"

        if line_token.category == "END_IF":
            return "ENDIF"

        if line_token.category == "END_WHILE":
            return "ENDWHILE"

        if line_token.category == "NEXT":
            return "ENDFOR"

        if line_token.category == "IF":
            if not re.search(r"\sTHEN$", content, re.IGNORECASE):
                return f"{content} THEN"

        if line_token.category == "WHILE":
            if not re.search(r"\sDO$", content, re.IGNORECASE):
                return f"{content} DO"

        if line_token.category == "FOR_EACH":
            if not re.search(r"\sDO$", content, re.IGNORECASE):
                return f"{content} DO"

        if line_token.category == "EQUALS_ASSIGNMENT":
            return re.sub(
                r"\s*=\s*",
                " <- ",
                content,
                count=1,
            )

        return content

    def _convert_operators(self, content: str) -> str:
        """Converts supported generic arithmetic operator words."""

        converted_content = re.sub(
            r"\bMOD\b",
            "MODULUS",
            content,
            flags=re.IGNORECASE,
        )
        converted_content = re.sub(
            r"\bDIV\b",
            "INTEGER DIVISION",
            converted_content,
            flags=re.IGNORECASE,
        )

        return converted_content


class GeneralPseudocodeProcessor:
    """Passes supplied pseudocode to the parser without source conversion."""

    def process(self, source: str) -> PseudocodeProcessingResult:
        """Returns the original source unchanged."""

        return PseudocodeProcessingResult(
            profile=PseudocodeProfile.GENERAL_NO_CONVERSION,
            original_source=source,
            processed_source=source,
            transformations=[],
        )


class PseudocodeProfileProcessor:
    """Selects the correct processor for a requested pseudocode profile."""

    def __init__(self) -> None:
        self.strict_processor = StrictPseudocodeProcessor()
        self.generic_processor = GenericPseudocodeProcessor()
        self.general_processor = GeneralPseudocodeProcessor()
        self.header_comment_stripper = InitialHashCommentStripper()

    def process(
        self,
        source: str,
        profile: PseudocodeProfile,
    ) -> PseudocodeProcessingResult:
        """Strips an optional file header and applies the selected profile."""

        profile_source, header_removed, header_lines_removed = (
            self.header_comment_stripper.strip(
                source=source,
            )
        )

        if profile == PseudocodeProfile.AJ_DIALECT_STRICT:
            result = self.strict_processor.process(
                source=profile_source,
            )

        elif profile == PseudocodeProfile.GENERIC_COMPATIBILITY:
            result = self.generic_processor.process(
                source=profile_source,
            )

        elif profile == PseudocodeProfile.GENERAL_NO_CONVERSION:
            result = self.general_processor.process(
                source=profile_source,
            )

        else:
            raise ValueError(
                f"Unsupported pseudocode profile: {profile}"
            )

        result.original_source = source
        result.header_comment_removed = header_removed
        result.header_lines_removed = header_lines_removed

        return result
