from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
STUDY = ROOT / "study components"
if str(STUDY) not in sys.path:
    sys.path.insert(0, str(STUDY))

from pseudocode_profiles import PseudocodeProfile
from study_batch import StudyBatchProcessor


class CalibratedBaselineComparisonV420Tests(unittest.TestCase):
    def _baseline(self, directory: str, baseline_pseudocode: str = 'OUTPUT STRING("ok")\n') -> Path:
        root = Path(directory) / "Baseline"
        pseudo = root / "pseudocode" / "Algorithm - 1"
        python = root / "python" / "Algorithm - 1"
        pseudo.mkdir(parents=True)
        python.mkdir(parents=True)
        (pseudo / "Algorithm 1 Pseudocode.txt").write_text(baseline_pseudocode, encoding="utf-8")
        (python / "Algorithm 1 Baseline Python code.txt").write_text("print('ok')\n", encoding="utf-8")
        # Input-only test: the frozen baseline Python supplies the expected behaviour.
        (python / "Algorithm 1 Tests.json").write_text(
            json.dumps({"tests": [{"name": "common-output"}]}), encoding="utf-8"
        )
        return root

    def test_input_only_tests_create_trusted_reference_calibration(self):
        with tempfile.TemporaryDirectory() as directory:
            baseline = self._baseline(directory)
            result = StudyBatchProcessor().process_baseline(
                baseline, profile=PseudocodeProfile.GENERIC_COMPATIBILITY
            )
            record = result["report"]["algorithms"][0]
            self.assertEqual("TRUSTED_REFERENCE", record["reference_validation_status"])
            self.assertEqual("CALIBRATED", record["calibration_status"])
            self.assertEqual(100.0, record["baseline_calibration_percentage"])
            calibration_path = baseline / "pseudocode" / "Algorithm - 1" / "pipeline_artifacts" / "baseline_calibration.json"
            calibration = json.loads(calibration_path.read_text(encoding="utf-8"))
            self.assertEqual("PIPELINE_CALIBRATION", calibration["comparison_role"])
            self.assertEqual(100.0, calibration["calibration_score_percentage"])

    def test_experimental_result_is_compared_side_by_side_with_baseline(self):
        with tempfile.TemporaryDirectory() as directory:
            baseline = self._baseline(directory)
            processor = StudyBatchProcessor()
            processor.process_baseline(baseline, profile=PseudocodeProfile.GENERIC_COMPATIBILITY)

            results = Path(directory) / "source_a" / "results"
            algorithm = results / "Algorithm - 1"
            algorithm.mkdir(parents=True)
            (algorithm / "Algorithm 1 Pseudocode.txt").write_text('OUTPUT STRING("wrong")\n', encoding="utf-8")

            result = processor.process_llm_results(
                results,
                profile=PseudocodeProfile.AJ_DIALECT_STRICT,
                baseline_root=baseline,
            )
            record = result["report"]["algorithms"][0]
            self.assertEqual(100.0, record["baseline_calibration_percentage"])
            self.assertEqual(0.0, record["experimental_behavioural_percentage"])
            self.assertEqual(-100.0, record["delta_from_baseline_percentage_points"])
            self.assertEqual("BELOW_BASELINE", record["comparison_to_baseline"])

            comparison_path = algorithm / "pipeline_artifacts" / "baseline_relative_comparison.json"
            comparison = json.loads(comparison_path.read_text(encoding="utf-8"))
            self.assertEqual("COMPARABLE", comparison["comparison_status"])
            self.assertTrue(comparison["common_test_set"])
            self.assertEqual(100.0, comparison["baseline_calibration_score_percentage"])
            self.assertEqual(0.0, comparison["experimental_behavioural_score_percentage"])
            self.assertEqual(-100.0, comparison["delta_from_baseline_percentage_points"])

            analysis = json.loads((results / "study_analysis" / "algorithm_scores.json").read_text(encoding="utf-8"))
            row = next(row for row in analysis if row["Algorithm"] == 1)
            self.assertEqual(100.0, row["BaselineCalibrationPercent"])
            self.assertEqual(0.0, row["ExperimentalBehaviouralPercent"])
            self.assertEqual(-100.0, row["DeltaFromBaselinePercentagePoints"])
            self.assertEqual("BELOW_BASELINE", row["ComparisonToBaseline"])

    def test_calibration_score_is_measured_even_when_below_100(self):
        with tempfile.TemporaryDirectory() as directory:
            baseline = self._baseline(directory, baseline_pseudocode='OUTPUT STRING("wrong")\n')
            result = StudyBatchProcessor().process_baseline(
                baseline, profile=PseudocodeProfile.GENERIC_COMPATIBILITY
            )
            record = result["report"]["algorithms"][0]
            # The core pipeline marks failed behavioural tests as FAILURE, but the calibration
            # measurement itself remains valid and is retained as the benchmark score.
            self.assertEqual("FAILURE", record["status"])
            self.assertEqual("CALIBRATED", record["calibration_status"])
            self.assertEqual(0.0, record["baseline_calibration_percentage"])

    def test_model_result_reprocesses_when_baseline_calibration_run_changes(self):
        with tempfile.TemporaryDirectory() as directory:
            baseline = self._baseline(directory)
            processor = StudyBatchProcessor()
            processor.process_baseline(baseline, profile=PseudocodeProfile.GENERIC_COMPATIBILITY)
            results = Path(directory) / "source_a" / "results"
            algorithm = results / "Algorithm - 1"
            algorithm.mkdir(parents=True)
            (algorithm / "Algorithm 1 Pseudocode.txt").write_text('OUTPUT STRING("ok")\n', encoding="utf-8")
            first = processor.process_llm_results(results, profile=PseudocodeProfile.AJ_DIALECT_STRICT, baseline_root=baseline)
            self.assertEqual("PROCESSED", first["report"]["algorithms"][0]["action"])

            processor.process_baseline(baseline, profile=PseudocodeProfile.AJ_DIALECT_STRICT, force=True)
            second = processor.process_llm_results(results, profile=PseudocodeProfile.AJ_DIALECT_STRICT, baseline_root=baseline)
            self.assertEqual("PROCESSED", second["report"]["algorithms"][0]["action"])

    def test_model_reference_oracle_requires_current_baseline_calibration(self):
        with tempfile.TemporaryDirectory() as directory:
            baseline = self._baseline(directory)
            results = Path(directory) / "source_a" / "results"
            algorithm = results / "Algorithm - 1"
            algorithm.mkdir(parents=True)
            (algorithm / "Algorithm 1 Pseudocode.txt").write_text('OUTPUT STRING("ok")\n', encoding="utf-8")

            StudyBatchProcessor().process_llm_results(
                results,
                profile=PseudocodeProfile.AJ_DIALECT_STRICT,
                baseline_root=baseline,
            )
            comparison = json.loads(
                (algorithm / "pipeline_artifacts" / "baseline_relative_comparison.json").read_text(encoding="utf-8")
            )
            self.assertFalse(comparison["baseline_reference_oracle_eligible"])
            self.assertEqual("NOT_EVALUABLE", comparison["comparison_status"])
            self.assertIn("run the baseline calibration first", comparison["oracle_block_reason"])


if __name__ == "__main__":
    unittest.main()
