import unittest

from aj_parser import AJParserFacade
from pseudocode_profiles import PseudocodeProfile, PseudocodeProfileProcessor
from flow_diagram import FlowDiagramEncoder
from aj_python_compiler import AJPythonCompiler


class GenericObviousMismatchTests(unittest.TestCase):
    def setUp(self):
        self.processor = PseudocodeProfileProcessor()

    def process(self, source):
        return self.processor.process(source, PseudocodeProfile.GENERIC_COMPATIBILITY)

    def test_raw_output_string_and_sort_characters_parse(self):
        source = """String1 <- INPUT(STRING(\"Enter String1\"))
String2 <- INPUT(STRING(\"Enter String2\"))
IF LENGTH OF String1 != LENGTH OF String2 THEN
    OUTPUT \"Not Anagrams\"
ELSE
    SORT characters of String1
    SORT characters of String2
    IF String1 == String2 THEN
        OUTPUT \"Anagrams\"
    ELSE
        OUTPUT \"Not Anagrams\"
    ENDIF
ENDIF
"""
        result = self.process(source)
        self.assertIn('OUTPUT STRING("Not Anagrams")', result.processed_source)
        self.assertIn('String1 <- CALL sort_characters(String1)', result.processed_source)
        parsed = AJParserFacade().parse(result.processed_source)
        self.assertTrue(parsed.success, parsed.error)

    def test_not_in_operator_parses(self):
        parsed = AJParserFacade().parse("FUNCTION f ACCEPTS(x, seen)\n    IF x NOT IN seen THEN\n        RETURN BOOLEAN(True)\n    ENDIF\n    RETURN BOOLEAN(False)\nENDFUNCTION\n")
        self.assertTrue(parsed.success, parsed.error)

    def test_swap_expands_to_assignments(self):
        result = self.process("SWAP left AND right\n")
        self.assertIn('_swap_temp <- left', result.processed_source)
        self.assertIn('left <- right', result.processed_source)

    def test_swap_indexed_items_expands_and_parses(self):
        source = "WordList <- EMPTY LIST\nj <- 0\nSWAP WordList[j], WordList[j+1]\n"
        result = self.process(source)
        self.assertIn("_swap_temp <- WordList[j]", result.processed_source)
        self.assertIn("WordList[j] <- WordList[j+1]", result.processed_source)
        self.assertIn("WordList[j+1] <- _swap_temp", result.processed_source)
        parsed = AJParserFacade().parse(result.processed_source)
        self.assertTrue(parsed.success, parsed.error)

    def test_reserved_list_identifier_and_exit_for_parse(self):
        source = """List <- INPUT(STRING("Enter List"))
Target <- INPUT(STRING("Enter Target"))
Found <- BOOLEAN(False)
FOR i from 0 to length(List)-1:
    IF List[i] == Target THEN
        OUTPUT TUPLE(STRING("Found at position"), i)
        Found <- BOOLEAN(True)
        EXIT FOR
    ENDIF
ENDFOR
IF Found == BOOLEAN(False) THEN
    OUTPUT STRING("Target not found")
ENDIF
"""
        result = self.process(source)
        self.assertIn("values <- INPUT", result.processed_source)
        self.assertIn("IF values[i] == Target THEN", result.processed_source)
        self.assertIn("BREAK", result.processed_source)
        parsed = AJParserFacade().parse(result.processed_source)
        self.assertTrue(parsed.success, parsed.error)

    def test_case_block_and_part_heading_normalise_and_parse(self):
        source = """Text <- INPUT(STRING("Enter Text"))
A <- 0
E <- 0
FOR EACH Character IN Text DO
    CASE Character OF
        STRING("a"): A <- A + 1
        STRING("e"): E <- E + 1
    ENDCASE
ENDFOR
OUTPUT TUPLE(A, E)
Part 2 - Pseudocode for Tasks 11-20
"""
        result = self.process(source)
        self.assertIn('IF Character == STRING("a") THEN', result.processed_source)
        self.assertIn('ELSE IF Character == STRING("e") THEN', result.processed_source)
        self.assertNotIn("Part 2 -", result.processed_source)
        parsed = AJParserFacade().parse(result.processed_source)
        self.assertTrue(parsed.success, parsed.error)

    def test_add_to_collection_becomes_append_and_parses(self):
        source = """IP_List <- INPUT(STRING("Enter IP_List"))
UniqueIPs <- EMPTY SET
FOR EACH IP IN IP_List DO
    ADD IP TO UniqueIPs
ENDFOR
OUTPUT UniqueIPs
"""
        result = self.process(source)
        self.assertIn("APPEND IP TO UniqueIPs", result.processed_source)
        parsed = AJParserFacade().parse(result.processed_source)
        self.assertTrue(parsed.success, parsed.error)

    def test_downto_range_is_normalised_once(self):
        source = """BEGIN
    INPUT Text

    Reverse ← ""

    FOR i ← LENGTH(Text)-1 DOWNTO 0
        Reverse ← Reverse + Text[i]
    ENDFOR

    OUTPUT Reverse
END
"""
        result = self.process(source)
        expected = """Text <- INPUT(STRING("Enter Text"))

Reverse <- EMPTY STRING

FOR i <- IN RANGE LENGTH OF Text-1 TO 0 STEP -1 DO
    Reverse <- Reverse + Text[i]
ENDFOR

OUTPUT Reverse"""
        self.assertEqual(expected, result.processed_source.strip())
        self.assertNotIn("IN RANGE IN RANGE", result.processed_source)
        parsed = AJParserFacade().parse(result.processed_source)
        self.assertTrue(parsed.success, parsed.error)

    def test_anonymous_dictionary_declaration_parses(self):
        source = """Text <- INPUT(STRING("Enter Text"))
Create Dictionary
OUTPUT Text
"""
        result = self.process(source)
        self.assertIn("Anonymous_Dictionary <- EMPTY DICTIONARY", result.processed_source)
        parsed = AJParserFacade().parse(result.processed_source)
        self.assertTrue(parsed.success, parsed.error)

    def test_all_part_section_labels_are_stripped(self):
        for heading in (
            "Part 1 - Pseudocode for Tasks 1-10",
            "Part 2 - Pseudocode for Tasks 11-20",
            "Part 3 - Pseudocode for Tasks 21-30",
            "Part 10 - Additional Pseudocode",
        ):
            source = f"""Number <- 6
OUTPUT Number
{heading}
"""
            result = self.process(source)
            self.assertNotIn("Part ", result.processed_source)
            parsed = AJParserFacade().parse(result.processed_source)
            self.assertTrue(parsed.success, parsed.error)

    def test_anonymous_queue_uses_append_and_pop_zero_semantics(self):
        source = """Root <- INPUT(STRING("Enter Root"))
CREATE EMPTY QUEUE
ENQUEUE Root
WHILE Queue is not empty DO
    Node <- DEQUEUE Queue
    OUTPUT Node
ENDWHILE
"""
        result = self.process(source)
        self.assertIn("Anonymous_Queue <- EMPTY LIST", result.processed_source)
        self.assertIn("APPEND Root TO Anonymous_Queue", result.processed_source)
        self.assertIn("Node <- REMOVE FIRST ITEM FROM Anonymous_Queue", result.processed_source)
        self.assertNotRegex(result.processed_source, r"\\bQueue\\b")

    def test_inferred_node_queue_traversal_compiles(self):
        source = """BEGIN
    INPUT Root

    CREATE Empty Queue
    ENQUEUE Root

    WHILE Queue is not empty
        Node ← DEQUEUE Queue
        OUTPUT Node.Value

        IF Node.Left exists THEN
            ENQUEUE Node.Left
        ENDIF

        IF Node.Right exists THEN
            ENQUEUE Node.Right
        ENDIF
    ENDWHILE
END
"""
        result = self.process(source)
        self.assertIn('Root_Key <- INPUT(STRING("Enter Root"))', result.processed_source)
        self.assertIn("Root <- CALL lookup_inferred_node(Root_Key)", result.processed_source)
        self.assertIn("Node <- REMOVE FIRST ITEM FROM Anonymous_Queue", result.processed_source)
        self.assertIn("OUTPUT Node.Value", result.processed_source)
        self.assertIn("IF Node.Left != CALL NULL() THEN", result.processed_source)

        parsed = AJParserFacade().parse(result.processed_source)
        self.assertTrue(parsed.success, parsed.error)

        flow = FlowDiagramEncoder().encode(parsed.ast)
        compiled = AJPythonCompiler().compile(flow)
        self.assertTrue(compiled.success)
        self.assertIn("class InferredNode:", compiled.source_code)
        self.assertIn("Node = Anonymous_Queue.pop(0)", compiled.source_code)
        self.assertIn("print(Node.value)", compiled.source_code)
        self.assertIn("if (Node.left != None):", compiled.source_code)

    def test_inferred_node_lookup_is_preinitialised_and_does_not_insert_missing_key(self):
        source = """BEGIN
    INPUT Root
    CREATE Empty Queue
    ENQUEUE Root
    WHILE Queue is not empty
        Node ← DEQUEUE Queue
        OUTPUT Node.Value
        IF Node.Left exists THEN
            ENQUEUE Node.Left
        ENDIF
        IF Node.Right exists THEN
            ENQUEUE Node.Right
        ENDIF
    ENDWHILE
END
"""
        result = self.process(source)
        parsed = AJParserFacade().parse(result.processed_source)
        self.assertTrue(parsed.success, parsed.error)
        flow = FlowDiagramEncoder().encode(parsed.ast)
        compiled = AJPythonCompiler().compile(flow)
        self.assertIn("random.sample(range(1, 101), k=10)", compiled.source_code)
        self.assertIn("_inferred_node_lookup = {", compiled.source_code)
        self.assertIn("return None", compiled.source_code)
        self.assertNotIn("_inferred_node_lookup[key] = InferredNode(key)", compiled.source_code)

    def test_inferred_lookup_does_not_output_success_value(self):
        source = """BEGIN
    INPUT Root
    CREATE Empty Queue
    ENQUEUE Root
    WHILE Queue is not empty
        Node ← DEQUEUE Queue
        OUTPUT Node.Value
        IF Node.Left exists THEN
            ENQUEUE Node.Left
        ENDIF
        IF Node.Right exists THEN
            ENQUEUE Node.Right
        ENDIF
    ENDWHILE
END
"""
        result = self.process(source)
        parsed = AJParserFacade().parse(result.processed_source)
        self.assertTrue(parsed.success, parsed.error)

        flow = FlowDiagramEncoder().encode(parsed.ast)
        compiled = AJPythonCompiler().compile(flow)

        self.assertIn("return _inferred_node_lookup[key]", compiled.source_code)
        self.assertNotIn("print(f'{_inferred_node_lookup[key]}')", compiled.source_code)
        self.assertIn("print(Node.value)", compiled.source_code)

    def test_stop_compiles_to_quit(self):
        source = """Number <- 9
WHILE Number > 0 DO
    IF Number == 9 THEN
        OUTPUT Number
        STOP
    ENDIF
    Number <- Number - 1
ENDWHILE
"""
        parsed = AJParserFacade().parse(source)
        self.assertTrue(parsed.success, parsed.error)
        flow = FlowDiagramEncoder().encode(parsed.ast)
        compiled = AJPythonCompiler().compile(flow)
        self.assertTrue(compiled.success)
        self.assertIn("quit()", compiled.source_code)
        self.assertNotIn("break", compiled.source_code)

    def test_array_stack_recovery_compiles_to_push_pop_peek(self):
        source = """CREATE Stack
Top <- -1

CALL PUSH(Item)
    Top <- Top + 1
    Stack[Top] <- Item

CALL POP()
    IF Top == -1 THEN
        OUTPUT STRING("Stack Empty")
    ELSE
        Item <- Stack[Top]
        Top <- Top - 1
        OUTPUT Item
    ENDIF

CALL PEEK()
    IF Top != -1 THEN
        OUTPUT Stack[Top]
    ENDIF
"""
        result = self.process(source)
        self.assertIn("Stack <- EMPTY LIST", result.processed_source)
        self.assertIn("FUNCTION PUSH ACCEPTS(Item)", result.processed_source)
        self.assertIn("Item <- REMOVE LAST ITEM FROM Stack", result.processed_source)
        self.assertIn("IF LENGTH OF Stack > 0 THEN", result.processed_source)
        self.assertIn('OUTPUT STRING("Stack Empty")', result.processed_source)

        parsed = AJParserFacade().parse(result.processed_source)
        self.assertTrue(parsed.success, parsed.error)

        flow = FlowDiagramEncoder().encode(parsed.ast)
        compiled = AJPythonCompiler().compile(flow)

        self.assertIn("Stack.append(Item)", compiled.source_code)
        self.assertIn("Item = Stack.pop(-1)", compiled.source_code)
        self.assertIn("if (len(Stack) > 0):", compiled.source_code)
        self.assertIn("print(Stack[(-1)])", compiled.source_code)

    def test_character_frequency_expansion_preserves_text_input(self):
        source = """BEGIN
    INPUT Text
    COUNT frequency of each character
    FOR EACH Character IN Text DO
        IF Frequency(Character) = 1 THEN
            OUTPUT Character
            STOP
        ENDIF
    ENDFOR
    OUTPUT "None Found"
END
"""
        result = self.process(source)
        self.assertIn('Text <- INPUT(STRING("Enter Text"))', result.processed_source)
        self.assertIn("Character_Frequency <- EMPTY DICTIONARY", result.processed_source)
        self.assertIn(
            "Character_Frequency[Character] <- Character_Frequency[Character] + 1",
            result.processed_source,
        )
        self.assertIn("IF Character_Frequency[Character] == 1 THEN", result.processed_source)

        parsed = AJParserFacade().parse(result.processed_source)
        self.assertTrue(parsed.success, parsed.error)

        flow = FlowDiagramEncoder().encode(parsed.ast)
        compiled = AJPythonCompiler().compile(flow)

        self.assertIn("Character_Frequency = {}", compiled.source_code)
        self.assertIn("print(Character)", compiled.source_code)
        self.assertIn("quit()", compiled.source_code)

    def test_linked_cycle_detection_outputs_adjacency(self):
        source = """BEGIN
    INPUT Head
    Slow <- Head
    Fast <- Head
    WHILE Fast != NULL AND Fast.Next != NULL
        Slow <- Slow.Next
        Fast <- Fast.Next.Next
        IF Slow == Fast THEN
            OUTPUT "Cycle Detected"
            STOP
        ENDIF
    ENDWHILE
    OUTPUT "No Cycle"
END
"""
        result = self.process(source)
        self.assertIn("lookup_inferred_linked_node", result.processed_source)
        self.assertIn("Fast.Next.Next", result.processed_source)
        self.assertEqual(
            result.processed_source.count("CALL output_adjacency_list(Head)"),
            2,
        )

        parsed = AJParserFacade().parse(result.processed_source)
        self.assertTrue(parsed.success, parsed.error)

        flow = FlowDiagramEncoder().encode(parsed.ast)
        compiled = AJPythonCompiler().compile(flow)

        self.assertIn("class InferredNode:", compiled.source_code)
        self.assertIn("def output_adjacency_list(head):", compiled.source_code)
        self.assertIn("Fast = Fast.next.next", compiled.source_code)
        self.assertEqual(
            compiled.source_code.count("output_adjacency_list(Head)"),
            2,
        )

    def test_two_stack_queue_recovery(self):
        source = """CREATE Stack1
CREATE Stack2

CALL ENQUEUE(Item)
    PUSH Item onto Stack1

CALL DEQUEUE()
    IF Stack2 is empty THEN
        WHILE Stack1 is not empty
            PUSH POP(Stack1) onto Stack2
        ENDWHILE
    ENDIF

    OUTPUT POP(Stack2)
"""
        result = self.process(source)
        self.assertIn("Stack1 <- EMPTY LIST", result.processed_source)
        self.assertIn("Stack2 <- EMPTY LIST", result.processed_source)
        self.assertIn("FUNCTION ENQUEUE ACCEPTS(Item)", result.processed_source)
        self.assertIn("Item <- REMOVE LAST ITEM FROM Stack1", result.processed_source)
        self.assertIn("APPEND Item TO Stack2", result.processed_source)
        self.assertIn('OUTPUT STRING("Queue Empty")', result.processed_source)

        parsed = AJParserFacade().parse(result.processed_source)
        self.assertTrue(parsed.success, parsed.error)

        flow = FlowDiagramEncoder().encode(parsed.ast)
        compiled = AJPythonCompiler().compile(flow)

        self.assertIn("Stack1.append(Item)", compiled.source_code)
        self.assertIn("Item = Stack1.pop(-1)", compiled.source_code)
        self.assertIn("Stack2.append(Item)", compiled.source_code)
        self.assertIn("Item = Stack2.pop(-1)", compiled.source_code)
        self.assertIn("print('Queue Empty')", compiled.source_code)

    def test_n_queens_recovery_uses_empty_string_board(self):
        source = """BEGIN
    INPUT N
    CREATE N * N board
    FUNCTION Solve ACCEPTS(Row)
        IF Row = N THEN
            OUTPUT Board
            RETURN
        ENDIF
        FOR Col <- 0 TO N-1
            IF Position(Row, Col) is safe THEN
                PLACE Queen at (Row, Col)
                CALL Solve(Row + 1)
                REMOVE Queen from (Row, Col)
            ENDIF
        ENDFOR
    ENDFUNCTION
    CALL Solve(0)
END
"""
        result = self.process(source)
        self.assertIn("Board <- CALL create_matrix(N, N, EMPTY STRING)", result.processed_source)
        self.assertIn('Board[Row][Col] <- STRING("Q")', result.processed_source)
        self.assertIn("Board[Row][Col] <- EMPTY STRING", result.processed_source)
        self.assertIn("FUNCTION is_safe ACCEPTS(Row, Col)", result.processed_source)

        parsed = AJParserFacade().parse(result.processed_source)
        self.assertTrue(parsed.success, parsed.error)

        flow = FlowDiagramEncoder().encode(parsed.ast)
        compiled = AJPythonCompiler().compile(flow)

        self.assertIn("Board = [['' for _ in range(N)] for _ in range(N)]", compiled.source_code)
        self.assertIn("Board[Row][Col] = 'Q'", compiled.source_code)
        self.assertIn("Board[Row][Col] = ''", compiled.source_code)
        self.assertIn("def is_safe(Row, Col):", compiled.source_code)

    def test_multiline_expression_join_and_matrix_multiplication_recovery(self):
        source = """BEGIN
    INPUT MatrixA
    INPUT MatrixB
    INPUT RowsA
    INPUT ColumnsA
    INPUT ColumnsB

    FOR i <- 0 TO RowsA-1
        FOR j <- 0 TO ColumnsB-1
            Result[i][j] <- 0

            FOR k <- 0 TO ColumnsA-1
                Result[i][j] <- Result[i][j] +
                                MatrixA[i][k] * MatrixB[k][j]
            ENDFOR
        ENDFOR
    ENDFOR

    OUTPUT Result
END
"""
        result = self.process(source)

        self.assertIn(
            "MatrixA <- CALL random_matrix_auto()",
            result.processed_source,
        )
        self.assertIn(
            "MatrixB <- CALL random_compatible_matrix(MatrixA)",
            result.processed_source,
        )
        self.assertIn("RowsA <- LENGTH OF MatrixA", result.processed_source)
        self.assertIn("ColumnsA <- LENGTH OF MatrixA[0]", result.processed_source)
        self.assertIn("ColumnsB <- LENGTH OF MatrixB[0]", result.processed_source)
        self.assertIn(
            "Result <- CALL create_matrix(RowsA, ColumnsB, 0)",
            result.processed_source,
        )
        self.assertIn(
            "Result[i][j] <- Result[i][j] + MatrixA[i][k] * MatrixB[k][j]",
            result.processed_source,
        )

        parsed = AJParserFacade().parse(result.processed_source)
        self.assertTrue(parsed.success, parsed.error)

        flow = FlowDiagramEncoder().encode(parsed.ast)
        compiled = AJPythonCompiler().compile(flow)

        self.assertIn(
            "MatrixA = [[random.randint(0, 9) for _ in range(_matrix_a_columns)] for _ in range(_matrix_a_rows)]",
            compiled.source_code,
        )
        self.assertIn(
            "MatrixB = [[random.randint(0, 9) for _ in range(_matrix_b_columns)] for _ in range(len(MatrixA[0]))]",
            compiled.source_code,
        )
        self.assertIn("RowsA = len(MatrixA)", compiled.source_code)
        self.assertIn("ColumnsA = len(MatrixA[0])", compiled.source_code)
        self.assertIn("ColumnsB = len(MatrixB[0])", compiled.source_code)
        self.assertIn(
            "Result = [[0 for _ in range(ColumnsB)] for _ in range(RowsA)]",
            compiled.source_code,
        )

    def test_maze_pathfinding_recovery_uses_graph_bfs(self):
        source = """BEGIN
    INPUT Maze, Start, Goal
    CREATE Queue
    MARK Start as visited
    ENQUEUE Start
    WHILE Queue is not empty
        Current <- DEQUEUE Queue
        IF Current = Goal THEN
            OUTPUT "Path Found"
            STOP
        ENDIF
        FOR EACH Neighbour of Current
            IF Neighbour not visited THEN
                MARK Neighbour as visited
                ENQUEUE Neighbour
            ENDIF
        ENDFOR
    ENDWHILE
    OUTPUT "No Path Found"
END
"""
        result = self.process(source)

        self.assertIn(
            "FUNCTION find_path ACCEPTS(Maze, Start, Goal)",
            result.processed_source,
        )
        self.assertIn("Visited <- EMPTY SET", result.processed_source)
        self.assertIn("Current <- REMOVE FIRST ITEM FROM Anonymous_Queue", result.processed_source)
        self.assertIn("FOR EACH Neighbour IN Maze[Current] DO", result.processed_source)
        self.assertIn("Maze <- CALL random_graph()", result.processed_source)

        parsed = AJParserFacade().parse(result.processed_source)
        self.assertTrue(parsed.success, parsed.error)

        flow = FlowDiagramEncoder().encode(parsed.ast)
        compiled = AJPythonCompiler().compile(flow)

        self.assertIn("def find_path(Maze, Start, Goal):", compiled.source_code)
        self.assertIn("Current = Anonymous_Queue.pop(0)", compiled.source_code)
        self.assertIn("Visited.add(Start)", compiled.source_code)
        self.assertIn("for Neighbour in Maze[Current]:", compiled.source_code)

    def test_maze_graph_is_undirected_without_invented_path_state(self):
        source = """BEGIN
    INPUT Maze, Start, Goal
    CREATE Queue
    MARK Start as visited
    ENQUEUE Start
    WHILE Queue is not empty
        Current <- DEQUEUE Queue
        IF Current = Goal THEN
            OUTPUT "Path Found"
            STOP
        ENDIF
        FOR EACH Neighbour of Current
            IF Neighbour not visited THEN
                MARK Neighbour as visited
                ENQUEUE Neighbour
            ENDIF
        ENDFOR
    ENDWHILE
    OUTPUT "No Path Found"
END
"""
        result = self.process(source)
        self.assertNotIn('OUTPUT STRING("Path: {Path}")', result.processed_source)

        parsed = AJParserFacade().parse(result.processed_source)
        self.assertTrue(parsed.success, parsed.error)
        flow = FlowDiagramEncoder().encode(parsed.ast)
        compiled = AJPythonCompiler().compile(flow)

        self.assertIn("def _random_undirected_graph():", compiled.source_code)
        self.assertIn("graph[left].append(right)", compiled.source_code)
        self.assertIn("graph[right].append(left)", compiled.source_code)
        self.assertNotIn("Path = Path[::-1]", compiled.source_code)
        self.assertNotIn("print(f'Path: {Path}')", compiled.source_code)

    def test_maze_recovery_does_not_invent_path_state(self):
        source = """BEGIN
    INPUT Maze, Start, Goal
    CREATE Queue
    MARK Start as visited
    ENQUEUE Start
    WHILE Queue is not empty
        Current <- DEQUEUE Queue
        IF Current = Goal THEN
            OUTPUT "Path Found"
            STOP
        ENDIF
        FOR EACH Neighbour of Current
            IF Neighbour not visited THEN
                MARK Neighbour as visited
                ENQUEUE Neighbour
            ENDIF
        ENDFOR
    ENDWHILE
    OUTPUT "No Path Found"
END
"""
        result = self.process(source)

        self.assertNotIn("Previous", result.processed_source)
        self.assertNotIn("Path <-", result.processed_source)
        self.assertNotIn("Walk <-", result.processed_source)

        parsed = AJParserFacade().parse(result.processed_source)
        self.assertTrue(parsed.success, parsed.error)

        flow = FlowDiagramEncoder().encode(parsed.ast)
        compiled = AJPythonCompiler().compile(flow)

        self.assertNotIn("Previous", compiled.source_code)
        self.assertNotIn("Path =", compiled.source_code)
        self.assertIn("print('Path Found')", compiled.source_code)

    def test_sort_characters_to_destination(self):
        source = """FUNCTION isAnagram ACCEPTS(str1, str2)
    IF LENGTH OF str1 != LENGTH OF str2 THEN
        RETURN BOOLEAN(False)
    ENDIF
    sort characters of str1 TO sorted1
    sort characters of str2 TO sorted2
    RETURN sorted1 == sorted2
ENDFUNCTION
"""
        result = self.process(source)
        self.assertIn("sorted1 <- CALL sort_characters(str1)", result.processed_source)
        self.assertIn("sorted2 <- CALL sort_characters(str2)", result.processed_source)

        parsed = AJParserFacade().parse(result.processed_source)
        self.assertTrue(parsed.success, parsed.error)
        flow = FlowDiagramEncoder().encode(parsed.ast)
        compiled = AJPythonCompiler().compile(flow)

        self.assertIn("sorted1 = \'\'.join(sorted(str1))", compiled.source_code)
        self.assertIn("sorted2 = \'\'.join(sorted(str2))", compiled.source_code)

    def test_inline_else_if_and_else_bodies(self):
        source = """FUNCTION intersection ACCEPTS(A, B)
    result <- EMPTY LIST
    i <- 0
    j <- 0
    WHILE i < LENGTH OF A AND j < LENGTH OF B DO
        IF A[i] == B[j] THEN
            APPEND A[i] TO result
            i <- i + 1
            j <- j + 1
        ELSE IF A[i] < B[j] THEN i <- i + 1
        ELSE j <- j + 1
        ENDIF
    ENDWHILE
    RETURN result
ENDFUNCTION
"""
        result = self.process(source)
        self.assertIn("ELSE IF A[i] < B[j] THEN\n            i <- i + 1", result.processed_source)
        self.assertIn("ELSE\n            j <- j + 1", result.processed_source)

        parsed = AJParserFacade().parse(result.processed_source)
        self.assertTrue(parsed.success, parsed.error)
        flow = FlowDiagramEncoder().encode(parsed.ast)
        compiled = AJPythonCompiler().compile(flow)
        self.assertIn("elif (A[i] < B[j]):", compiled.source_code)
        self.assertIn("else:", compiled.source_code)


if __name__ == '__main__':
    unittest.main()
