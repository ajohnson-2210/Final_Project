# ChatGPT Algorithm 17 Source-Integrity Audit — v2.67

Algorithm 17 computes the sum and average of a list using an explicit accumulation loop.

The lossy stored ChatGPT TXT export replaces exactly three authoritative assignment arrows (`←`) with literal `?` characters:

- `Sum ? 0`
- `Sum ? Sum + Number`
- `Average ? Sum / LENGTH(Numbers)`

GC188 is a narrowly scoped source-integrity recovery. It activates only when the complete Algorithm 17 signature is present and each of the three affected lines occurs exactly once. GC188 restores those glyphs to `←`; ordinary GC004 then converts `←` to canonical AJ `<-`.

`?` is never an AJ token and is never present in canonical AJ as a replacement for `<-`.

The authoritative-arrow form bypasses GC188 entirely. The algorithmic procedure is unchanged: explicit accumulation, explicit average calculation, and two explicit outputs.
