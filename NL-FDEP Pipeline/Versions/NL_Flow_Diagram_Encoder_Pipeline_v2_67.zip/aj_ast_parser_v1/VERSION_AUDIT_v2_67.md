# v2.67 Audit

## ChatGPT Algorithm 17 source-integrity recovery

Introduces GC188, a narrow recovery for exactly three assignment-arrow glyphs lost in the stored ChatGPT TXT export for Algorithm 17 (sum and average).

- `?` is source-loss evidence only.
- `?` is never an AJ token or a canonical alias for `<-`.
- Authoritative `←` source bypasses GC188 and uses ordinary GC004.
- No algorithmic reconstruction or optimisation is introduced.
- Research corpus files remain external study data and are not packaged.
