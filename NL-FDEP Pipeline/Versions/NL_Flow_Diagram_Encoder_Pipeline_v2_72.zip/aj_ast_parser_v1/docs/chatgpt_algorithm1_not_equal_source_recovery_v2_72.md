# ChatGPT Algorithm 1 not-equal source recovery — v2.72

GC194 is a narrowly scoped source-integrity recovery for the stored lossy
ChatGPT Algorithm 1 export. The stored text contains:

```text
IF LENGTH(String1) ? LENGTH(String2) THEN
```

while the authoritative study source preserves the lost relational glyph as
`≠`. GC194 therefore restores exactly that one recognised occurrence to source
`≠` before ordinary character/operator normalisation maps it to canonical AJ
`!=`.

This rule does not establish a generic relational meaning for `?`. An unrelated
form such as `IF LENGTH(Left) ? LENGTH(Right) THEN` remains unresolved and is
rejected by strict AJ parsing.

Canonical AJ remains grammar-pure: `?` never appears as an AJ token or as an
alternative to either `<-` or `!=`.
