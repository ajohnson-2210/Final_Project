# v3.92 — punctuation predicate semantic-boundary correction

v3.92 removes an unjustified executable interpretation of the compatibility helper `is_punctuation`.

## Problem

v3.91 lowered `CALL is_punctuation(x)` directly to:

```python
not str(x).isalnum() and not str(x).isspace()
```

That chooses a specific character-class definition not supplied by the AJ dialect or by many corpus sources. The corpus itself demonstrates that punctuation is not represented uniformly: DeepSeek and Gemini provide explicit but different punctuation sets, Groq supplies a regex character class, while ChatGPT, Claude and Qwen use an abstract natural-language predicate without defining its membership.

The existing ChatGPT Algorithm 5 integrity guard already recognised that converting an undefined `Character is NOT punctuation` phrase into `CALL is_punctuation(Character)` merely renames missing semantics. However, the guard was source-shape-specific, so equivalent Claude/Qwen/generic forms could still reach GC104 and then receive the compiler-invented predicate.

## Correction

- The punctuation dependency guard is now source-shape/model independent.
- Natural `x is punctuation` / `x is NOT punctuation` forms only reach GC104 when the exact `is_punctuation` helper is explicitly defined or imported by the supplied source.
- The Python compiler no longer special-cases `is_punctuation`; an explicit canonical `CALL is_punctuation(x)` compiles as the ordinary helper call `is_punctuation(x)`.
- Explicit source definitions therefore retain their own semantics and are no longer shadowed by a compiler intrinsic.
- Explicit punctuation sets and regexes remain unchanged and preserve the source-authored definitions.

No AJ_24038155 Dialect grammar change is required.

## Validation

- pytest: 976 passed, 3 skipped, 5 subtests passed
- unittest: 323 passed, 1 skipped
- AJ v1.1 SHA-256: `0d4dcdbb5a28eb5be11f72a7152e4ed55bb2296733a994573bbce50a3a862598`
- AJ v1.2 SHA-256: `414a1510d616f23e3c7a34945c16d52ad6c0b7f9bf591c66e6408c3329ef0348`
- dialect change: none
- compiler change: yes (`is_punctuation` intrinsic retired)
- normaliser change: yes (generic source-evidence guard for punctuation predicates)
