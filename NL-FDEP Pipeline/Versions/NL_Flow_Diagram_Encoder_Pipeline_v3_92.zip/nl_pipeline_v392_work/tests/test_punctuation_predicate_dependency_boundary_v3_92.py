from aj_parser import AJParserFacade
from aj_python_compiler import AJPythonCompiler
from flow_diagram import FlowDiagramEncoder
from pseudocode_profiles import PseudocodeProfile, PseudocodeProfileProcessor


def _process(source: str):
    return PseudocodeProfileProcessor().process(
        source, PseudocodeProfile.GENERIC_COMPATIBILITY
    )


def test_generic_undefined_punctuation_predicate_is_not_renamed_by_gc104():
    source = '''FUNCTION keep ACCEPTS(ch)
    IF ch is punctuation THEN
        RETURN TRUE
    ENDIF
    RETURN FALSE
ENDFUNCTION
'''
    result = _process(source)
    assert "ch is punctuation" in result.processed_source
    assert "CALL is_punctuation" not in result.processed_source
    assert all(t.rule != "GC104" for t in result.transformations)
    assert not AJParserFacade().parse(result.processed_source).success


def test_undefined_claude_style_punctuation_predicate_remains_expected_failure():
    source = '''FUNCTION removePunctuation(sentence):
    result <- ""
    FOR each ch IN sentence:
        IF ch is NOT punctuation THEN
            result <- result + ch
    RETURN result
'''
    result = _process(source)
    assert "is NOT punctuation" in result.processed_source
    assert "CALL is_punctuation" not in result.processed_source
    assert all(t.rule != "GC104" for t in result.transformations)
    assert not AJParserFacade().parse(result.processed_source).success


def test_explicit_punctuation_helper_allows_gc104_and_retains_helper_semantics():
    source = '''FUNCTION is_punctuation ACCEPTS(ch)
    RETURN ch == STRING("!")
ENDFUNCTION

FUNCTION keep ACCEPTS(ch)
    IF ch is punctuation THEN
        RETURN BOOLEAN(TRUE)
    ENDIF
    RETURN BOOLEAN(FALSE)
ENDFUNCTION
'''
    result = _process(source)
    assert "CALL is_punctuation(ch)" in result.processed_source
    assert any(t.rule == "GC104" for t in result.transformations)
    parsed = AJParserFacade().parse(result.processed_source)
    assert parsed.success, parsed.error
    compiled = AJPythonCompiler().compile(FlowDiagramEncoder().encode(parsed.ast)).source_code
    assert "if is_punctuation(ch):" in compiled
    assert ".isalnum()" not in compiled
    assert ".isspace()" not in compiled
    namespace = {}
    exec(compiled, namespace)
    assert namespace["keep"]("!") is True
    assert namespace["keep"]("$") is False


def test_direct_canonical_is_punctuation_call_is_not_compiler_redefined():
    source = '''FUNCTION is_punctuation ACCEPTS(ch)
    RETURN ch == STRING("?")
ENDFUNCTION

FUNCTION check ACCEPTS(ch)
    RETURN CALL is_punctuation(ch)
ENDFUNCTION
'''
    parsed = AJParserFacade().parse(source)
    assert parsed.success, parsed.error
    compiled = AJPythonCompiler().compile(FlowDiagramEncoder().encode(parsed.ast)).source_code
    assert "return is_punctuation(ch)" in compiled
    assert ".isalnum()" not in compiled
    assert ".isspace()" not in compiled
    namespace = {}
    exec(compiled, namespace)
    assert namespace["check"]("?") is True
    assert namespace["check"]("!") is False
