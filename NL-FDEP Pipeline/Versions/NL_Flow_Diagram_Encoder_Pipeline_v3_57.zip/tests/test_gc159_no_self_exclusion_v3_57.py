import unittest

from pseudocode_profiles import PseudocodeProfile, PseudocodeProfileProcessor


class GC159NoSelfExclusionV357Tests(unittest.TestCase):
    def setUp(self):
        self.processor = PseudocodeProfileProcessor()

    def process(self, source):
        return self.processor.process(source, PseudocodeProfile.GENERIC_COMPATIBILITY)

    def test_other_iterator_name_does_not_invent_self_exclusion(self):
        source = '''FUNCTION compare ACCEPTS(items)
    FOR EACH item IN items DO
        FOR EACH otherItem IN items DO
            OUTPUT otherItem_value
        ENDFOR
    ENDFOR
ENDFUNCTION
'''
        result = self.process(source)

        self.assertIn('OUTPUT otherItem.value', result.processed_source)
        self.assertNotIn('IF otherItem != item THEN', result.processed_source)
        self.assertTrue(any(t.rule == 'GC159' for t in result.transformations))

    def test_explicit_source_self_exclusion_is_preserved(self):
        source = '''FUNCTION compare ACCEPTS(items)
    FOR EACH item IN items DO
        FOR EACH otherItem IN items DO
            IF otherItem != item THEN
                OUTPUT otherItem_value
            ENDIF
        ENDFOR
    ENDFOR
ENDFUNCTION
'''
        result = self.process(source)

        self.assertEqual(result.processed_source.count('IF otherItem != item THEN'), 1)
        self.assertIn('OUTPUT otherItem.value', result.processed_source)

    def test_iterator_name_without_flattened_property_is_not_a_gc159_change(self):
        source = '''FUNCTION compare ACCEPTS(items)
    FOR EACH item IN items DO
        FOR EACH otherItem IN items DO
            OUTPUT otherItem
        ENDFOR
    ENDFOR
ENDFUNCTION
'''
        result = self.process(source)

        self.assertNotIn('IF otherItem != item THEN', result.processed_source)
        self.assertFalse(any(t.rule == 'GC159' for t in result.transformations))

    def test_current_and_other_flattened_properties_still_recover(self):
        source = '''FUNCTION compare ACCEPTS(items)
    FOR EACH item IN items DO
        OUTPUT item_value
        FOR EACH otherItem IN items DO
            OUTPUT otherItem_value
        ENDFOR
    ENDFOR
ENDFUNCTION
'''
        result = self.process(source)

        self.assertIn('OUTPUT item.value', result.processed_source)
        self.assertIn('OUTPUT otherItem.value', result.processed_source)
        self.assertNotIn('IF otherItem != item THEN', result.processed_source)


if __name__ == '__main__':
    unittest.main()
