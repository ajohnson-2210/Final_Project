## v3.74 AJ_24038155 Dialect v1.2 nested functions

v3.74 advances the active dialect to AJ_24038155 v1.2. v1.2 formally permits lexical nested/local `FUNCTION ... ENDFUNCTION` declarations and requires Python generation to preserve that nesting rather than hoist local helpers. Callback and first-class function-value semantics remain explicitly out of scope for a later dialect revision. GC170 now uses this feature for ChatGPT Algorithm 43: `INPUT N` becomes the external parameter of `FUNCTION unnamed_function ACCEPTS(N)`, the supplied `Hanoi` routine remains nested inside it, and the final Hanoi call stays inside the same outer computation. The former invented `input("Enter N")` / `integer_value(...)` path is removed. Full validation: 910 pytest passed, 3 skipped, 5 subtests passed; 306 unittest passed, 1 skipped. Historical AJ v1.1 SHA-256 remains `0d4dcdbb5a28eb5be11f72a7152e4ed55bb2296733a994573bbce50a3a862598`; active AJ v1.2 SHA-256 is `414a1510d616f23e3c7a34945c16d52ad6c0b7f9bf591c66e6408c3329ef0348`.

See `docs/AJ_24038155_Dialect_v1_2.md`, `docs/release_v3_74.md`, and `tests/test_aj_v12_nested_functions_v3_74.py`.

## v3.73 GC160 parent-matrix dimension inference retired

v3.73 retires GC160's special-case expansion of `parent <- 2D array to store previous cell for reconstruction` into `CALL create_matrix(LENGTH OF maze, LENGTH OF maze[0], CALL NULL())`. The source does not state that `parent` has the same dimensions as `maze`, so the declaration now remains visibly unresolved and strict AJ parsing stops before Python generation rather than inventing dimensions. The separately evidenced declaration `visited <- 2D boolean array same size as maze initialized to BOOLEAN(False)` remains supported and still lowers to a maze-sized boolean matrix. DeepSeek Algorithm 49 was already expected-fail because its maze-navigation semantics remain abstract, so no corpus parse floor changes. Full validation: 906 pytest passed, 3 skipped, 5 subtests passed; 306 unittest passed, 1 skipped. Frozen AJ_24038155 Dialect v1.1 SHA-256 remains `0d4dcdbb5a28eb5be11f72a7152e4ed55bb2296733a994573bbce50a3a862598`.

See `docs/release_v3_73.md` and `tests/test_gc160_parent_matrix_dimension_retirement_v3_73.py`.

## v3.72 multi-value OUTPUT preserves argument semantics

v3.72 separates bare comma-separated output arguments from tuple data. Source `OUTPUT a, b` now canonicalises to the output-only compatibility form `OUTPUT CALL output_values(a, b)`, which compiles deterministically to Python `print(a, b)`. Explicit tuple data remains tuple data: both `OUTPUT (a, b)` and `OUTPUT TUPLE(a, b)` canonicalise/retain `OUTPUT TUPLE(a, b)` and compile to `print((a, b))`. ChatGPT Algorithm 42 now follows the same generic output boundary rather than hard-coding a tuple. GC175's message-specific `OUTPUT STRING("Found at position {i}")` f-string recovery remains unchanged. Full validation: 903 pytest passed, 3 skipped, 5 subtests passed; 303 unittest passed, 1 skipped. Frozen AJ_24038155 Dialect v1.1 SHA-256 remains `0d4dcdbb5a28eb5be11f72a7152e4ed55bb2296733a994573bbce50a3a862598`.

## v3.71 GC175 multi-part linear-search output preserves message semantics

v3.71 narrows GC175's handling of the explicit ChatGPT Algorithm 9 output `OUTPUT "Found at position", i`. Instead of converting the two output components into tuple data, the canonical source now uses the existing AJ v1.1 placeholder form `OUTPUT STRING("Found at position {i}")`, which compiles deterministically to a Python f-string such as `print(f"Found at position {i}")`. Genuine source `TUPLE(...)` output remains tuple output. Full validation: 899 pytest passed, 3 skipped, 5 subtests passed; 303 unittest passed, 1 skipped. Frozen AJ_24038155 Dialect v1.1 SHA-256 remains `0d4dcdbb5a28eb5be11f72a7152e4ed55bb2296733a994573bbce50a3a862598`.

## v3.70 GC160 uninitialised matrix storage uses NONE fill

v3.70 changes only the exact missing-fill declaration `target <- matrix of size rows x cols`: the source-supplied dimensions are preserved while the absent cell value is represented as `NONE`, yielding `CALL create_matrix(rows, cols, NONE)` and deterministic Python `[[None for _ in range(cols)] for _ in range(rows)]`. This avoids silently inventing numeric zero while still materialising the requested writable matrix storage. Explicit zero-filled forms such as `matrix of size rows x cols initialized with 0` and `rows * cols matrix of 0s` remain zero-filled. Full validation: 899 pytest passed, 3 skipped, 5 subtests passed; 303 unittest passed, 1 skipped. Frozen AJ_24038155 Dialect v1.1 SHA-256 remains `0d4dcdbb5a28eb5be11f72a7152e4ed55bb2296733a994573bbce50a3a862598`.

See `docs/release_v3_70.md` and `tests/test_gc160_uninitialised_matrix_none_fill_v3_70.py`.

## v3.69 GC122 abstract character-frequency rescue retired

v3.69 retires the early GC122 rule that expanded `COUNT frequency of each character` into a complete dictionary-counting algorithm. The abstract operation is now preserved as unresolved source and ChatGPT corpus Algorithm 38 is explicitly expected-fail; strict AJ parsing stops before Python generation rather than inventing missing counting logic. Full validation: 897 pytest passed, 3 skipped, 5 subtests passed; 301 unittest passed, 1 skipped. Frozen AJ_24038155 Dialect v1.1 SHA-256 remains `0d4dcdbb5a28eb5be11f72a7152e4ed55bb2296733a994573bbce50a3a862598`.

See `docs/release_v3_69.md`, `tests/test_chatgpt_algorithm38_semantic_integrity.py`, and `tests/test_chatgpt_groq_corpus_regression_v3_53.py`.

## v3.68 GC161 explicit `given_capacity` state

v3.68 closes the remaining GC161 visibility mismatch between canonical pseudocode and generated Python. Source `capacity <- GIVEN CAPACITY` is recovered as the explicit class state `given_capacity <- capacity`; the Python compiler therefore emits exactly one `self.given_capacity = capacity` rather than silently introducing `self.capacity = capacity`. Once that recovered state exists, executable references to the class-state name `capacity` inside the preserved LRU methods canonicalise to `given_capacity`, so pseudocode and Python use the same stored field. The constructor parameter remains `capacity`; quoted text/comments are not state references. GC161 continues to preserve source-written method bodies and does not add missing LRU steps. Full validation: 897 pytest passed, 3 skipped, 5 subtests passed; 301 unittest passed, 1 skipped. Frozen AJ_24038155 Dialect v1.1 SHA-256 remains `0d4dcdbb5a28eb5be11f72a7152e4ed55bb2296733a994573bbce50a3a862598`.

See `docs/release_v3_68.md` and `tests/test_gc161_visible_capacity_state_v3_68.py`.

## v3.67 GC161 preserves source-written LRU method bodies

v3.67 narrows GC161 so the DeepSeek `LRUCache` recogniser may recover the explicit class/constructor surface without replacing the source-written `get` and `put` algorithms. Method bodies are retained in source order. Explicit list/dictionary operations already present in those bodies may still be mapped to existing AJ compatibility intrinsics, but missing-key branches, recency operations, eviction logic, cache writes, or any other LRU steps are no longer manufactured. The exact DeepSeek Algorithm 35 source remains executable because those LRU operations are explicitly supplied there.

See `docs/release_v3_67.md` and `tests/test_gc161_lru_body_preservation_v3_67.py`.

## v3.66 retire GC160 inferred string-to-character-list input conversion

v3.66 removes GC160's inference that a text-like `INPUT(...)` must become `CALL list_from_string(INPUT(...))` merely because the value is indexed and used with `LENGTH OF`. Both operations are valid on strings, so that evidence does not justify changing the input representation or return type. The input-resolution audit metadata is aligned with the same rule: no `STRING_TO_LIST_OF_CHARACTER` deterministic conversion is reported for this case.

Explicit `CALL list_from_string(...)` source remains supported, and the separate neutral unnamed-wrapper policy is unchanged. Full validation: 888 pytest passed, 3 skipped, 5 subtests passed; 301 unittest passed, 1 skipped. Frozen AJ_24038155 Dialect v1.1 SHA-256 remains `0d4dcdbb5a28eb5be11f72a7152e4ed55bb2296733a994573bbce50a3a862598`.

## v3.65 retire GC159 specialised level-order flattened-property inference

v3.65 removes GC159's remaining conversion of valid AJ identifiers `node_value`, `node_left`, and `node_right` into `node.value`, `node.left`, and `node.right` inside `FUNCTION LEVEL_ORDER_TRAVERSAL ACCEPTS(root)`, even when `node` is explicitly obtained from the traversal queue. The traversal context establishes the role of `node`, but it does not establish that a distinct underscored identifier denotes one of its properties. AJ_24038155 Dialect v1.1 permits underscores in identifiers and requires explicit `.` syntax for member access.

Explicit source member access such as `node.value`, `node.left`, and `node.right` remains unchanged. Historical flattened level-order fixtures now preserve their source identifiers rather than silently changing the represented algorithm. Where those identifiers appear in the validator's direct bare-read subset, ordinary declaration-before-use semantics apply; uses outside that deliberately conservative subset remain unresolved identifiers in generated code rather than being invented as members. No parser, compiler, intrinsic, or frozen AJ_24038155 Dialect v1.1 semantics change in v3.65.

## v3.64 retire GC159 Floyd flattened-property inference

v3.64 removes GC159's Floyd-specific conversion of valid AJ identifiers such as `slow_next`, `fast_next`, `tortoise_next`, and `hare_next` into `.next` member access merely because `slow`/`fast` or `tortoise`/`hare` are initialised from `head`. AJ_24038155 Dialect v1.1 permits underscores in identifiers and requires explicit `.` syntax for member access. Mixed forms such as `fast_next.next` are also preserved as written rather than being changed to `fast.next.next`.

Explicit source member access such as `slow.next` and `fast.next.next` remains unchanged. Historical flattened Floyd sources with undeclared `*_next` identifiers now reach the existing declaration-before-use semantic boundary instead of being silently repaired into a linked-list algorithm. No parser, compiler, intrinsic, or frozen AJ_24038155 Dialect v1.1 semantics change in v3.64.

## v3.63 retire GC146 updateInventory flattened transaction-property inference

v3.63 removes GC146's conversion of valid AJ identifiers `transaction_item`, `transaction_type`, and `transaction_quantity` into `transaction.item`, `transaction.type`, and `transaction.quantity` merely because they appear in `FUNCTION updateInventory ACCEPTS(inventory, transactions)`. AJ_24038155 Dialect v1.1 permits underscores in identifiers, and the function/parameter/iterator names do not establish member-access structure. Explicit source member access remains unchanged.

GC146's separate `ALERT expression` to `OUTPUT expression` surface recovery remains available. Historical sources that depended on the invented property relationship now correctly reach ordinary declaration-before-use semantics when the flattened identifiers are not otherwise declared. No parser, compiler, intrinsic, or frozen AJ_24038155 Dialect v1.1 semantics change in v3.63.

## v3.62 retire GC159 generic maze-coordinate identifier inference

v3.62 removes GC159's conversion of valid AJ identifiers such as `start_row`, `start_col`, `current_row`, `current_col`, `direction_row`, and `direction_col` into indexed forms such as `start[0]`, `current[1]`, and `direction[0]` merely because a function accepts `(maze, start, end)` and declares `directions`. AJ_24038155 Dialect v1.1 permits underscores in identifiers, and those surrounding names do not establish any particular coordinate representation.

Explicit source indexing remains unchanged. The separate explicit four-direction literal recovery and indexed-assignment token canonicalisation remain available and are independent of the retired naming inference. No parser, compiler, intrinsic, or frozen AJ_24038155 Dialect v1.1 semantics change in v3.62.

## v3.61 retire GC159 generic linked-list flattened-property inference

v3.61 removes GC159's generic conversion of valid AJ identifiers such as `current_next` into member access such as `current.next` merely because `current <- head` appears in a function accepting `head`. AJ_24038155 Dialect v1.1 permits underscores in identifiers, so assignment from `head` plus a `*_next` spelling is not sufficient evidence of object-member structure. Explicit source member access such as `current.next` remains unchanged.

The separately gated Floyd recoveries remain available for the two historical corpus vocabularies `slow`/`fast` and `tortoise`/`hare`. They no longer depend on the retired generic `head` + `*_next` path. No parser, compiler, intrinsic, or frozen AJ_24038155 Dialect v1.1 semantics change in v3.61.

## v3.60 retire GC159 generic binary-tree flattened-property inference

v3.60 removes GC159's generic conversion of valid AJ identifiers such as `node_value`, `node_left`, and `node_right` into `node.value`, `node.left`, and `node.right` merely because the source also contains an identifier named `root`. AJ_24038155 Dialect v1.1 permits underscores in identifiers, and `root` alone is not evidence that `node_*` denotes member access.

The separately gated `LEVEL_ORDER_TRAVERSAL(root)` recovery remains available when `node` is explicitly obtained from `DEQUEUE(queue)`. Its gate now also recognises the already-canonicalised intermediate spelling `node <- REMOVE FIRST ITEM FROM queue`, preserving the intended narrow behaviour after earlier queue normalisation. Explicit source member access is unchanged. No parser, compiler, intrinsic, or frozen AJ_24038155 Dialect v1.1 semantics change in v3.60.

## v3.59 retire GC159 transaction-name flattened-property inference

v3.59 removes GC159's transaction-name-based conversion of valid identifiers such as `transaction_itemID`, `transaction_item`, `transaction_type`, and `transaction_quantity` into member access merely because the source contains `FOR EACH transaction IN transactions`. The iterator and collection names are not independent evidence that those underscored identifiers denote properties of the current transaction object. Explicit member access such as `transaction.itemID` remains unchanged.

The separate GC146 `updateInventory(inventory, transactions)` recogniser is intentionally unchanged in this release and remains independently gated by its existing algorithm-specific evidence. No parser, compiler, intrinsic, or frozen AJ_24038155 Dialect v1.1 semantics change in v3.59.

## v3.58 retire GC159 generic flattened-property inference

v3.58 removes GC159's generic conversion of nested-iterator identifiers such as `item_value` and `otherItem_value` into member access such as `item.value` and `otherItem.value`. AJ_24038155 Dialect v1.1 permits underscores inside identifiers, so the spelling itself is not evidence of object/property structure; likewise, an `otherX` iterator name does not establish that its underscored uses are fields. The generic nested-iterator path now preserves the source identifier; separate specialised object-context recoveries are unchanged by this release.

The existing specialised GC159 object-context recoveries remain unchanged in this release and can be audited independently. Explicit source member access such as `otherItem.value` is preserved. No parser, compiler, intrinsic, or frozen AJ_24038155 Dialect v1.1 semantics change in v3.58.

## v3.57 GC159 self-exclusion retirement

v3.57 removes GC159's automatic insertion of `IF otherItem != item THEN` for nested `otherX` iteration over the same collection. Iterator naming alone is not evidence that the current outer element must be excluded, so compatibility normalisation now preserves the source loop body unless the source itself contains an exclusion condition.

GC159's separate flattened-property surface recovery remains unchanged in this release: forms such as `otherItem_value` may still canonicalise to `otherItem.value` under the existing nested-iteration pattern. Explicit source-written self-exclusion guards are preserved. No parser, compiler, intrinsic, or frozen AJ_24038155 Dialect v1.1 semantics change in v3.57.

## v3.56 retirement of synthetic random input inference

v3.56 retires the obsolete GC119 two-list input synthesis and the synthetic-input portion of GC118. Compatibility normalisation no longer replaces external list inputs with `CALL random_list()` or removes an external matrix input in favour of `CALL random_matrix(N, N)`. Those behaviours were early executable-test conveniences and violate the current evidence rule that normalisation may constrain or canonicalise supplied data structures but must not fabricate arbitrary input data.

External `INPUT` values are now preserved. The independent transpose surface recovery remains unchanged, so explicit `TRANSPOSE Matrix` can still canonicalise to the existing in-place transpose representation without generating matrix contents. The existing compiler intrinsics are not removed because explicit AJ may still invoke them; this release changes only automatic compatibility inference. No parser, compiler, intrinsic, or frozen AJ_24038155 Dialect v1.1 semantics change in v3.56.

## v3.55 evidenced collection query/access dispatch

v3.55 completes the approved semantic tightening for the historical collection query/access rules GC045-GC048.  `.size()`, `.front()`, `.back()`, and `.isEmpty()` are now canonicalised only when the receiver is independently established in readable lexical scope as a compatible list/set/dictionary/queue/deque/stack representation.  Method spelling alone no longer establishes collection type.  The existing meanings and historical GC IDs are preserved; subsequent canonical passes may render `~LENGTH` as `LENGTH OF` and `[LAST]` as `[-1]` as before.

The shared `LexicalEvidenceContext` now also promotes explicit instance-member collection construction from a constructor into the enclosing class evidence frame, for example `self.stack_in = Stack()` or `THIS.items <- EMPTY LIST`.  Sibling methods can therefore consume that proven field type.  Constructor-local variables are not promoted, method-local direct rebinds invalidate inherited evidence only in that method, class scopes remain isolated, and a later constructor does not forward-prove an earlier method.  This restores Gemini 40 while retaining the new refusal boundary for unproven calls such as `indexer.front()`.  No parser, compiler, intrinsic, or frozen AJ_24038155 Dialect v1.1 semantics change in v3.55.

## v3.54 Groq 37 class-state composition

v3.54 fixes two composition gaps exposed by the retained Groq algorithm 37 class.  GC241 now accepts both raw `CLASS Name` headers and headers already canonicalised to `CLASS Name ACCEPTS(...)`, so direct-child `Constructor()`/`FUNCTION` routines can still become frozen-AJ `CONSTRUCTOR`/`METHOD` blocks.  The Python compiler also infers instance fields from direct constructor identifier assignments when later class methods reference those same names without parameter shadowing.  This lets constructor state such as `array <- EMPTY LIST` and `top <- -1` compile to `self.array` and `self.top` without rewriting canonical AJ to inject `THIS.`.

The compiler-side inference is deliberately narrow: constructor-only temporaries remain local, method parameters shadow inferred fields in their own method, nested constructor assignments are not promoted, and explicit `PROPERTY`/`THIS` semantics are unchanged.  v3.54 does **not** invent Python list auto-growth.  Therefore Groq 37 now reaches its remaining source-level boundary exactly: `array = []` followed by indexed growth `array[0] = element` raises `IndexError` rather than being silently converted to append/preallocation semantics.

## v3.53 ChatGPT/Groq standing corpus integration

v3.53 adds the two supplied 50-algorithm ChatGPT and Groq research-response exports to the permanent regression corpus under `tests/corpora/`.  Corpus evaluation now decodes source bytes losslessly: UTF-8/UTF-8-SIG is preferred, with Windows-1252 fallback only when the byte stream is not valid UTF-8.  This preserves source characters such as `×` instead of replacing them with U+FFFD.

The new regression gate verifies exact 50-task extraction for both models, excludes Groq `Example:` prose from executable bodies, and runs all 100 items through the normal compatibility processor/parser with parse-rate floors (ChatGPT >= 38/50, Groq >= 45/50).  The floors catch regressions while allowing future evidence-backed improvements.  No pseudocode normalisation, parser, compiler, intrinsic, or frozen AJ_24038155 Dialect v1.1 semantics are changed.

# NL to Flow Diagram Encoder Pipeline v3.64

A dependency-free, object-oriented Python pipeline for AJ_24038155 Dialect v1.1.


## v3.52 evidence-only bare-brace collection resolution

v3.52 retires the historical GC092/GC093 variable-name heuristics for ambiguous bare `{}` initialisers. Identifier spelling such as `seen`, `visited`, `pairs`, `freq`, `counts`, `cache`, or `parent` is no longer treated as collection-type evidence. Bare braces are resolved only when later same-scope structural use proves exactly one compatible interpretation before any direct rebind: indexed access or standard dictionary operations prove dictionary semantics, while standard set insertion proves set semantics. Conflicting evidence, membership/iteration alone, quoted operation text, cross-routine use, and post-rebind operations leave `{}` unresolved. Existing indexed-write evidence retains historical GC220; the general structural-evidence path is recorded as GC250.

The release also adds a permanent internal regression corpus, extracted through the normal Qwen corpus adapter, containing the four audited Qwen bare-brace examples plus negative cases for weak/ambiguous evidence. This corpus is part of the normal pytest gate so future refactors must preserve both the positive structural proofs and the refusal boundaries. The original external research-response files are not modified. No parser, compiler, intrinsic, or frozen AJ_24038155 Dialect v1.1 semantics change in v3.52.



## v3.51 evidenced simple collection-method dispatch

v3.51 completes the separately approved semantic tightening phase for the historical simple collection-method rules GC033-GC039. Method spelling alone no longer establishes collection semantics: `.append`, `.add`, `.enqueue`, `.dequeue`, `.push`/`.push_back`, `.pop_front`, and `.pop_back` are canonicalised only when the receiver is independently evidenced in readable lexical scope as a compatible list/set/queue/deque/stack representation. The same `LexicalEvidenceContext` introduced in v3.50 now supplies routine/class isolation, inherited enclosing evidence, formal-parameter shadowing, direct-rebind invalidation, and explicit typed-parameter evidence for these rules.

The already-evidenced balanced collection paths GC200, GC202, GC213 and GC221 now consume the same lexical context instead of a source-wide name set. Existing proven corpus cases retain the same processed AJ and historical transformation IDs; a v3.50-v3.51 differential probe confirmed exact identity for representative evidenced list/set/queue/deque/stack cases. The deliberate behaviour change is limited to unproven receivers: for example `obj.append(x)` or `obj.push(x)` is no longer reclassified as an AJ list/stack operation merely from the member name. No parser, compiler, intrinsic, or frozen AJ_24038155 Dialect v1.1 semantics change in v3.51.


## v3.50 generalised structural/evidence rule-set foundation

v3.50 is a behaviour-preserving consolidation release. It introduces shared quote-aware balanced-delimiter scanning, one shared top-level-comma/outer-parenthesis tuple surface implementation, and a shared balanced member-call parser used by the existing evidenced nested collection-operation rules. The duplicated RETURN/OUTPUT tuple splitters now delegate to the same implementation, and GC220 reuses the same balanced-delimiter scanner for nested indexed-write evidence.

A reusable `LexicalEvidenceContext` now owns routine-local or inherited source evidence, parameter shadowing, and direct-rebind invalidation. Existing evidence-gated paths for set-to-list conversion (GC232), post-expansion list-backed queue operations (GC235), deque surface operations (GC237), set tuple insertion evidence collection (GC248), matrix-backed `Copy(...)` (GC247), list/stack and dictionary evidence collection now use this common representation without changing their acceptance criteria. GC246 and GC249 retain separate surface guards and historical rule IDs but share one zero-filled `create_matrix(...)` renderer.

No compatibility spelling, semantic inference, parser rule, compiler lowering, or AJ_24038155 Dialect v1.1 behaviour is added or removed in v3.50. In particular, the older globally permissive simple collection-method rules are intentionally unchanged; tightening those remains a separate semantic phase requiring explicit approval.


## v3.49 nested indexed-write dictionary evidence

v3.49 refines the existing GC220 bare-empty-braces resolution used for source forms such as `seen = {}`. GC220 already promotes a bare `{}` receiver to `EMPTY DICTIONARY` when a later indexed assignment proves mapping semantics; v3.49 extends that evidence check to balanced nested index expressions such as `seen[s[i]] = i` instead of assuming the index contains no `]`. The scanner remains assignment-only and receiver-specific, so indexed reads, `==` comparisons, writes to other receivers, membership-only use, and unrelated expressions do not become dictionary evidence. Qwen Algorithm 25 now preserves `seen` as a dictionary and executes the supplied longest-substring algorithm correctly without changing parser/compiler behaviour or frozen AJ_24038155 Dialect v1.1.


## v3.48 explicit rectangular zero-filled matrix recovery

v3.48 adds GC249 for the approved Gemini Algorithm 45 allocation spelling `rows x cols matrix filled with 0`. The exact direct-assignment form is represented through the pipeline's existing matrix-construction intrinsic as `CALL create_matrix(rows, cols, 0)`, preserving both source-supplied dimensions and the explicit zero fill. The rule is deliberately narrow: row and column dimensions must each be simple identifiers, the collection noun must be `matrix`, and the fill must be exactly zero; expression dimensions, non-zero or missing fills, `grid` spellings, and prose remain untouched. Gemini Algorithm 45 now reaches strict AJ parsing, deterministic Python compilation, and correct rectangular matrix-addition execution without changing frozen AJ_24038155 Dialect v1.1.


## v3.47 evidenced two-value tuple set-insertion recovery

v3.47 adds GC248 for the approved Gemini Algorithm 42 source form where an explicitly set-backed receiver is given a parenthesised two-value pair, such as `ADD (MIN(num, complement), MAX(num, complement)) TO pairs`. After the existing set-operation lowering has produced `CALL add_to_set(pairs, (..., ...))`, GC248 renders that explicit pair as the existing AJ `TUPLE(...)` value. The rule requires an `EMPTY SET` evidence declaration and exactly two top-level values inside one outer parenthesis pair; grouped single expressions, unproven receivers, and non-two-value payloads are unchanged. No set, tuple, parser, compiler, or frozen-dialect semantics are added.


## v3.46 evidenced 2D matrix-copy recovery

v3.46 adds GC247 for the approved Gemini Algorithm 41 `Copy(board)` operation. When a simple identifier is already evidenced as matrix-backed by `CALL create_matrix(...)` in the current lexical scope or a readable enclosing scope, the exact free one-argument `Copy(name)` form is represented as `CALL copy_2d_list(name)`. Deterministic Python lowering is `list(map(list, name))`, duplicating the outer list and every row so subsequent indexed backtracking mutations do not alter saved board snapshots. The rule refuses unproven values, shadowed parameters, direct reassignments, member calls, wrong arities, comments and quoted text. GC247 composes with GC245/GC246 and makes Gemini Algorithm 41 executable without introducing a general deep-copy rule or changing frozen AJ_24038155 Dialect v1.1.

## v3.45 explicit square zero-grid allocation recovery

v3.45 adds GC246 for the approved Gemini Algorithm 41 board declaration `N x N grid initialized to 0`. The exact direct-assignment form is represented through the pipeline's existing matrix-construction intrinsic as `CALL create_matrix(N, N, 0)`, preserving the source-supplied square dimensions and zero fill without adding matrix semantics. The rule is deliberately narrow: row and column dimensions must be the same single identifier, the fill must be exactly zero, and rectangular grids, expression dimensions, non-zero fills, missing initialisers and prose remain untouched. GC245's previously approved non-mutating singleton-set recovery composes unchanged with GC246. Gemini Algorithm 41 now reaches strict AJ parsing and deterministic Python compilation; its next independent source boundary remains the unresolved explicit `Copy(board)` operation, which v3.45 deliberately leaves visible. Frozen AJ_24038155 Dialect v1.1 is unchanged.


## v3.44 evidenced non-mutating singleton-set extension

v3.44 adds GC245 for the user-approved Gemini Algorithm 41 interpretation of expressions such as `cols + {col}` when the corresponding formal parameter is independently evidenced as set-backed by an explicit canonical call supplying `EMPTY SET` in that argument position. The expression is represented without mutation through the existing compatibility intrinsics as `CALL to_set(CALL to_list(cols) + CALL list_value(col))`; analogous diagonal expressions preserve their supplied arithmetic unchanged. Multi-member/dictionary braces, unproven parameters, cross-routine evidence, duplicate routine declarations and member-qualified receivers remain outside the rule. Gemini Algorithm 41 therefore advances past its singleton-set syntax to the next independent boundary, the explicit `N x N grid initialized to 0` board allocation, which v3.44 deliberately leaves unchanged. Frozen AJ_24038155 Dialect v1.1 is unchanged.


## v3.43 contextual list-backed Stack() state recovery

v3.43 adds GC244 for the user-confirmed Gemini Algorithm 40 interpretation that `Stack()` used as class state denotes a list-backed stack. The rule is evidence-gated: an exact zero-argument constructor member initialiser such as `self.stack_in = Stack()` is represented as `EMPTY LIST` only when that same member is subsequently used through source-supplied stack operations (`push`, `pop`, and/or `isEmpty`) in the class. Simple and nested pushes are routed to the existing AJ `APPEND` representation; existing `pop()` and empty-check lowering are reused unchanged. Local `Stack()` calls, non-zero-argument constructors, state with no stack-use evidence, and directly rebound members are refused. Gemini Algorithm 40 therefore reaches strict AJ parsing, deterministic Python compilation, and correct FIFO queue execution using two Python lists without changing frozen AJ_24038155 Dialect v1.1.


## v3.42 member-indexed assignment recovery

v3.42 adds GC242 for the approved Gemini Algorithm 37 assignment surface `object.member[index] = value`. The rule changes only the single assignment token to AJ `<-`, preserving the object/member path, index expression, and right-hand value verbatim; `==`, `!=`, `<=`, and `>=` remain untouched. Plain assignments, index-only assignments, and member-only assignments continue through the existing GC026 path. Combined with v3.40's user-confirmed `[None] * capacity` backing-array meaning and v3.41's contextual class-routine recovery, Gemini Algorithm 37 now reaches strict AJ parsing, deterministic Python compilation, and correct fixed-capacity stack execution without changing frozen AJ_24038155 Dialect v1.1.


## v3.41 contextual class-routine recovery

v3.41 adds GC241 for the user-confirmed class-context interpretation exposed by Gemini Algorithm 37. When the entire source is one explicit `CLASS` that supplies an explicit `CONSTRUCTOR(...)` plus direct-child `PROCEDURE name(...)` and/or `FUNCTION name(...)` routines, those declarations are represented with frozen AJ v1.1 class grammar: `CONSTRUCTOR ACCEPTS(...) ... ENDCONSTRUCTOR` and `METHOD name ACCEPTS(...) ... ENDMETHOD`. Missing routine/class terminators may be closed only at an unambiguous direct-child routine boundary, an explicit class terminator, or end-of-source. The rule does not invent properties, change `self`/member semantics, repair assignments, or alter return behaviour. Existing classes without an explicit constructor remain on their prior GC203/expected-failure paths. The generic call-prefix and functionless-return wrapper were also constrained so canonical `METHOD`/`CONSTRUCTOR` declarations are not rewritten as calls and a top-level `CLASS` is not wrapped merely because its methods contain `RETURN`. Gemini Algorithm 37 therefore advances to its next independent boundary: the legacy member-index assignment `self.arr[self.top_index] = item` is still left visible and is not repaired by v3.41.

## v3.40 user-confirmed NONE-filled fixed-array preallocation

v3.40 adds GC240 for the exact unfilled declaration `Array of size N`, under the project rule explicitly approved during the Gemini Algorithm 37 audit: the phrase denotes N writable slots initialised to `NONE`. The compatibility surface is `CALL create_array(N, NONE)`, reusing the existing array-construction intrinsic without changing frozen AJ v1.1 syntax. For a NONE fill, deterministic Python lowering is `[None] * N`; declarations that already specify an initial value remain under the existing GC160 behaviour. GC240 is deliberately restricted to a single identifier or non-negative integer size and refuses broader/qualified size prose. Gemini Algorithm 37 therefore now has an explicit backing-array representation, while its remaining legacy class-surface issues are kept separately visible rather than silently bundled into this rule.

## v3.39 explicit set-conversion intrinsic recovery

v3.39 adds GC238 for the exact free single-argument call `ConvertToSet(value)`. The source-explicit conversion is represented through the existing `CALL to_set(value)` compatibility intrinsic, which lowers deterministically to Python `set(value)`. Routine declarations named `ConvertToSet`, member methods, quoted text, comments, and zero/multi-argument calls remain outside GC238. Gemini Algorithm 34 therefore preserves its supplied list-to-set conversion while the existing GC232 recovery continues to represent its independently evidenced set-to-list conversion. No parser, compiler, collection semantics, or AJ_24038155 Dialect v1.1 syntax is added.

## v3.38 evidenced deque surface-operation recovery

v3.38 adds GC237 for standalone `REMOVE FRONT FROM receiver`, `REMOVE BACK FROM receiver`, and `ADD BACK value TO receiver`/intermediate `APPEND BACK value TO receiver` forms when that receiver has been explicitly initialised as `EMPTY DEQUE` in the same lexical routine. The operations map only to the existing AJ list primitives `REMOVE FIRST ITEM FROM`, `REMOVE LAST ITEM FROM`, and `APPEND ... TO ...`. Evidence is routine-local and is invalidated by direct reassignment; unproven receivers are untouched. Gemini Algorithm 28 therefore preserves its source-supplied double-ended-queue operations after v3.37's comment fix without adding deque syntax or changing AJ_24038155 Dialect v1.1.

## v3.37 early inline `//` comment detachment

v3.37 adds GC236 so text following an unquoted `//` is detached from the executable portion of the line before declaration, literal, and collection compatibility interpretation. The detached text remains in the source stream and is later represented as ordinary non-executable `COMMENT` metadata. This allows a declaration such as `deque = empty DoubleEndedQueue // Stores indices` to expose the complete `empty DoubleEndedQueue` initialiser to the existing collection rules instead of letting the comment contaminate type recovery. `//` inside quoted string literals is preserved as literal data, and standalone `// ...` lines continue through the existing comment path. No deque operations, parser features, or AJ_24038155 Dialect v1.1 syntax are added.

## v3.36 post-expansion evidenced queue-operation recovery

v3.36 adds GC235 as a narrow composition repair for queue operations exposed only after structural one-line conditional expansion. When the same lexical routine has already established a receiver as list-backed (`EMPTY LIST` or the existing `list_value(...)` representation), a newly standalone `ENQUEUE value TO receiver` is routed to the existing AJ `APPEND value TO receiver` operation; the equivalent evidenced free-call form and assignment-form dequeue counterpart share the same guard. Cross-routine evidence, unproven receivers, and receivers invalidated by direct reassignment are refused. Gemini Algorithm 26 therefore preserves its explicit child enqueue operations after GC132 expansion without adding queue semantics, parser features, or any AJ_24038155 Dialect v1.1 change.

## v3.35 explicit character-predicate intrinsic recovery

v3.35 adds GC234 for the exact free single-argument calls `IS_DIGIT(value)` and `IS_UPPERCASE(value)`. These source spellings are represented through the existing compatibility intrinsics `CALL is_digit(value)` and `CALL is_uppercase(value)`, which lower deterministically to Python `str(value).isdigit()` and `str(value).isupper()`. Routine declarations, member methods, quoted-text matches, and zero/multi-argument calls are outside GC234. Gemini Algorithm 24 therefore preserves its explicit password character tests without adding new predicate semantics or changing AJ_24038155 Dialect v1.1.

## v3.34 explicit square-root representation recovery

v3.34 adds GC233 for the exact free single-argument call `SQUARE_ROOT(value)`. With the user-approved mathematical representation, the source operation is canonicalised to AJ v1.1 exponentiation as `(value EXP 0.5)`, which lowers deterministically to Python `(value ** 0.5)`. Routine declarations named `SQUARE_ROOT`, member methods, quoted text, and zero/multi-argument calls are refused. GC233 deliberately does not add integer, floor, or range-bound coercion. Gemini Algorithm 20 therefore now preserves its explicit square-root operation through strict AJ parsing and Python compilation, while its separate use of that floating result as a Python range endpoint remains visible as an executable-correctness boundary. AJ_24038155 Dialect v1.1 remains frozen.

## v3.33 evidenced set-to-list conversion recovery

v3.33 adds GC232 for the exact free call `ConvertSetToList(name)` when the same lexical routine has already established `name` as `EMPTY SET` and no later direct reassignment invalidates that evidence. The explicit conversion is represented through the existing `CALL to_list(name)` compatibility intrinsic, which lowers deterministically to Python `list(name)`. Cross-routine evidence, forward evidence, member calls, wrong arity and unproven identifiers are refused. Gemini Algorithm 11 therefore preserves its supplied set-deduplication followed by set-to-list conversion without changing AJ_24038155 Dialect v1.1.

## v3.32 quoted dictionary-key recovery

v3.32 refines the existing GC097 simple dictionary-literal expansion so explicitly quoted string-scalar keys are rendered directly as canonical AJ `STRING(...)` expressions before the expanded indexed assignments are returned. This preserves Gemini Algorithm 10's source-evidenced vowel keys (including normal AJ escaping) while keeping the established bare-key stringification unchanged. No dictionary semantics are inferred beyond the existing GC097 literal expansion, and AJ_24038155 Dialect v1.1 remains frozen.

## v3.31 quoted scalar set-literal recovery

v3.31 adds GC231 for a non-empty Python-style brace literal whose members are all explicitly quoted string scalars. The source-evidenced set is represented through the existing compatibility intrinsics as `CALL to_set(CALL list_value(...))`, preserving punctuation characters including escaped apostrophe and double-quote members without changing the frozen AJ parser. The rule runs before raw-string wrapping and refuses dictionaries, empty braces, mixed or unquoted members, comprehensions, and string scalars containing unsupported control characters. Gemini Algorithm 5 therefore reaches the frozen AJ parser and deterministic Python compilation without inventing a punctuation predicate or changing AJ_24038155 Dialect v1.1.

## v3.30 standalone SWAP boundary fix

v3.30 narrows GC051 to the standalone procedural shorthand `SWAP(a, b)` only. A case-sensitive routine declaration such as `FUNCTION swap(a, b):` is therefore left for the ordinary function-header recovery and preserves the source identifier as `swap`, while genuine standalone `SWAP(a, b)` statements continue through the existing SWAP lowering. Calls such as `CALL swap(a, b)` and member invocations such as `obj.swap(a, b)` are also outside GC051. No new compatibility meaning is introduced, and AJ_24038155 Dialect v1.1 remains frozen.
The only external program input is AJ pseudocode.

## Pipeline

1. AJ pseudocode input
2. Lexical analysis
3. Recursive-descent parsing
4. AST construction
5. Static semantic validation
6. Machine-readable flow-diagram encoding
7. Interactive AST and flow-diagram visualisation
8. Deterministic Python compilation from `flow_diagram.json`
9. Subprocess-based behavioural testing
10. JSON reporting

## PyCharm

Open `pycharm_runner.py` and press **Run**. Configure these constants at the top
of the file when required:

- `INPUT_FILE`
- `OUTPUT_DIRECTORY`
- `OPEN_VISUALISATIONS`
- `TEST_CASES`

## Outputs

The runner creates:

- `output/ast.json`
- `output/parser_report.json`
- `output/ast_visualisation.html`
- `output/flow_diagram.json`
- `output/flow_diagram.html`
- `output/generated_program.py`
- `output/compilation_report.json`
- `output/test_report.json`
- `output/pipeline_report.json`

## Important design boundary

The AST is an internal intermediate representation. It is generated from
pseudocode and is not accepted as an external pipeline input. The compiler
accepts the machine-readable flow-diagram document produced by the encoder.


## v3.29 chained-assignment negative-infinity pass-order fix

v3.29 fixes the composition of the existing GC079 chained-assignment expansion with the existing GC151 negative-infinity representation recovery. When source such as `largest <- second <- -INFINITY` is expanded, the newly exposed assignment is now canonicalised as `second <- CALL negative_infinity()` before `largest <- second`. This preserves the source-supplied shared negative-infinity initialiser and lowers deterministically to Python `float('-inf')`. The fix is deliberately limited to the negative-infinity surfaces already accepted by GC151; positive infinity identifiers, member properties, and arbitrary chained right-hand expressions are unchanged. No new compatibility meaning is introduced, and AJ_24038155 Dialect v1.1 remains frozen.

## v3.28 direct modulus-digit string-accumulator recovery

v3.28 adds GC230 for the exact representation case where a destination is explicitly string-backed, the source directly prepends one parenthesised `MOD`/`MODULUS` result to that same accumulator, and the later generic arithmetic canonicalisation has not yet rewritten `MOD` to `MODULUS`. The guarded recovery makes only the required digit-to-string representation explicit as `CALL to_string((... MODULUS ...))`; unrelated mixed numeric/string addition, different accumulators, non-string destinations, and non-modulus expressions remain untouched. Claude Sonnet 4.6 Algorithm 2 therefore compiles without changing its supplied decimal-to-binary algorithm. AJ_24038155 Dialect v1.1 remains frozen.

## v3.27 seeded list-backed queue recovery

v3.27 adds GC229 for source forms that explicitly initialise a queue receiver from a non-empty list literal (for example `queue = [root]`) and then explicitly use that same receiver with free `DEQUEUE(queue)` / `ENQUEUE(queue, value)` operations. The earlier list-literal canonicalisation is accepted as representation evidence, and the queue operations are routed only to the existing list-backed FIFO operations (`REMOVE FIRST ITEM FROM` / `APPEND`). Unproven receivers, unrelated seeded lists, and arbitrary queue-like names remain untouched. AJ_24038155 Dialect v1.1 remains frozen.

## v3.26 explicit alphabetical sort-mode recovery

v3.26 adds GC228 for the exact free two-argument form `SORT(value, ALPHABETICAL_ORDER)`. The explicit `ALPHABETICAL_ORDER` marker is treated as source-supplied ascending alphabetical ordering and routed through the existing `sort_value` compatibility intrinsic, which lowers to Python `sorted(value)` (equivalent to `sorted(value, reverse=False)`). The rule is restricted to a simple identifier first argument and leaves arbitrary comparators, descending markers, member methods, and other arities untouched. AJ_24038155 Dialect v1.1 remains frozen.

## v3.25 evidenced regex `REPLACE_ALL` recovery

v3.25 adds GC227 for free three-argument `REPLACE_ALL(text, pattern, replacement)` calls whose quoted pattern contains direct regular-expression syntax evidence. The rule protects regex backslashes across compatibility-to-AJ string representation and lowers the supplied operation through an internal `regex_replace` intrinsic backed by Python `re.sub`. Plain literal replacement calls, member methods, and other arities remain untouched. AJ_24038155 Dialect v1.1 remains frozen.

## v3.24 trailing explanatory parenthetical comment recovery

v3.24 adds GC226 for a narrowly guarded source-surface case where an assignment already has a complete `empty <collection>` right-hand side and is followed by a trailing parenthetical beginning with explanatory `or` or `for` prose. The suffix is detached from executable syntax before literal/collection parsing, so a line such as `order = empty list (or a doubly linked list to maintain access order)` is represented as the explicit empty-list initialiser plus non-executable commentary rather than being misread as a `list(...)` constructor. Arithmetic/grouping parentheses, arbitrary calls, and non-comment parentheticals are unchanged. The existing DeepSeek LRU class recovery also accepts its legacy `FUNCTION get(key):` / `FUNCTION put(key, value):` header surface, allowing the already source-evidenced LRU logic to reach the frozen class grammar without inventing cache behaviour. AJ_24038155 Dialect v1.1 remains frozen.

## v3.23 DeepSeek 2 source-evidenced numeric STRING conversion

v3.23 adds GC225 for the exact compatibility case where a variable is independently proven numeric by a `MOD`/`MODULUS` assignment, a destination is independently proven string-backed by `EMPTY STRING`, and the source explicitly prepends `STRING(variable)` to that same string accumulator. Under those safeguards, the non-literal constructor-like source form is represented as `CALL to_string(variable)`, which lowers through the existing Python intrinsic to `str(variable)`. Quoted `STRING("...")` literals, unproven identifiers, non-string destinations, and unrelated `STRING(...)` calls are unchanged. DeepSeek Algorithm 2 therefore preserves its supplied decimal-to-binary algorithm while making only the explicit numeric-to-text conversion executable. AJ_24038155 Dialect v1.1 remains frozen.

## v3.22 Qwen 46 source-evidenced linked matrix dimensions

v3.22 adds GC224 for the exact matrix-multiplication shape `INPUT A (M x N), B (N x P)` followed by `INIT C as M x P matrix`, the complete nested `M`/`P`/`N` loops, the explicit `sum += A[i][k] * B[k][j]` accumulation, direct `C[i][j] = sum`, and `RETURN C`. Under those safeguards, annotation-only `M`, `N`, and `P` are represented by `LENGTH OF A`, `LENGTH OF B`, and `LENGTH OF B[0]`; `C` is materialised with the existing `create_matrix` intrinsic. The rule refuses independently bound dimensions, mismatched result or loop shapes, altered accumulation/index relations, conditional result writes, dimension-symbol escape, and explicit routine declarations. No matrix-multiplication logic or synthetic dimension parameter is invented. AJ_24038155 Dialect v1.1 remains frozen.

## v3.21 Qwen 45 source-evidenced rectangular matrix recovery

v3.21 adds GC223 for the exact unnamed matrix-addition shape where two supplied matrices are explicitly annotated as sharing dimensions `R x C`, the source requests `INIT result as R x C matrix`, the matching nested `0..R-1` / `0..C-1` loops directly overwrite every `result[i][j]`, and the result matrix is returned. Under those safeguards, annotation-only `R` and `C` are represented by `LENGTH OF A` and `LENGTH OF A[0]`, and the result storage is materialised with the existing `create_matrix` intrinsic. No synthetic `R`/`C` parameters are introduced. The zero fill is permitted only because the guarded source shape proves every allocated cell is overwritten before observation. Independent dimensions, mismatched bounds, conditional writes, explicit routine declarations, and non-returned targets are refused. AJ_24038155 Dialect v1.1 remains frozen.

## v3.20 Qwen 42 collection-evidence and deduplication recovery

v3.20 adds three narrowly evidenced compatibility recoveries for the Qwen 42 pair-sum form. A bare `{}` declaration is resolved to `EMPTY DICTIONARY` when a later indexed assignment on the same receiver proves mapping use (GC220), overriding weaker identifier-name set hints. A nested `list.add(expression)` is recovered with balanced-parenthesis scanning only when the receiver is independently proven list-backed (GC221); the recovered expression then continues through the existing tuple/MIN/MAX canonicalisation passes. Finally, after the stronger GC214 proof-based redundant-uniqueness rule has had first priority, an exact remaining one-argument `unique(name)` call is represented by the existing `to_set` compatibility intrinsic (GC222), producing Python `set(name)`. No pair-search logic is invented, ordering is not inferred, and AJ_24038155 Dialect v1.1 remains frozen.

## v3.19 guarded RANGE integer-offset folding

v3.19 broadens the v3.18 Python RANGE rendering cleanup into a guarded additive-integer offset fold. Within RANGE end expressions only, two or more literal integer offsets on the same left-associated `+`/`-` chain are combined while non-literal terms retain their relative order. Examples include `(Limit - 2) + 1 -> Limit - 1`, `(Index + 3) - 1 -> Index + 2`, `(Value - 4) - 2 -> Value - 6`, `(Value + 2) - 2 -> Value`, and `((LENGTH OF xs - 2) - i) + 1 -> LENGTH OF xs - 1 - i` at Python rendering time. Single-offset expressions, floats, multiplication/division, and nested right-hand additive algebra are not reassociated. AJ_24038155 Dialect v1.1 remains frozen.

## v3.18 evidenced input/helper wrapper recovery and canonical range rendering

v3.18 adds guarded GC219 for an omitted neutral outer algorithm wrapper when generic pseudocode supplies one or more bare top-level `INPUT` declarations, one or more complete indentation-style helper routines, and a single final top-level `RETURN` that calls an explicitly supplied helper. The recovery promotes only the input names to `FUNCTION unnamed_function` parameters and nests the supplied helpers/return without implementing any missing dependency. Qwen Algorithm 41 therefore parses and compiles structurally, while its undefined `isSafe(...)` and `emptyBoard(...)` routines remain source-level expected-failure dependencies. v3.18 also makes Python RANGE rendering cleaner: when inclusive-source endpoint canonicalisation has produced exactly `(X - 1) + 1`, the Python compiler emits `X` in the `range()` stop position (for example `0 TO N - 1` now renders as `range(0, N)`). This cancellation is restricted to RANGE end expressions and is not a general arithmetic optimiser. AJ_24038155 Dialect v1.1 remains frozen.

## v3.17 evidenced connected multi-list stateful-ADT recovery

v3.17 adds guarded GC218 structural recovery for multiple explicitly initialised `EMPTY LIST` states followed by multiple top-level operations. The rule requires the complete state/operation graph to be connected, every state to be actively mutated, and at least one explicit destructive cross-state transfer such as `APPEND a.pop() TO b`; it also refuses unknown call escape, state shadowing, direct rebinding, indexed writes, nested functions, free executable statements and disconnected global-list utilities. Eligible source is represented as neutral `CLASS unnamed_class` with a zero-argument constructor containing only the source-supplied empty-list initialisers. Qwen Algorithm 40 therefore becomes a trustworthy executable stateful queue abstraction while preserving its source-supplied empty-dequeue underflow. AJ_24038155 Dialect v1.1 remains frozen.

## v3.16 evidenced counted-list stateful-ADT and standalone-error recovery

v3.16 adds guarded GC216 structural recovery for an explicitly initialised counted-list ADT written as top-level state plus multiple shared-state functions. The rule requires exactly one `EMPTY LIST` state and one zero counter, at least three operations that all share both values, and source evidence for append, zero-argument list `pop()`, indexed top access, and counter `+1`/`-1` updates. Eligible source is represented as neutral `CLASS unnamed_class` with a zero-argument constructor containing only the supplied initial values; no semantic class name, constructor parameter, stack operation, or data value is invented. v3.16 also adds GC217 for an exact standalone `ERROR` statement, mapping it to AJ `RAISE STRING("ERROR")`. GC217 is statement-position only and leaves the established GC204 `RETURN ERROR` string-sentinel policy unchanged. Qwen Algorithm 37 therefore becomes a trustworthy executable without changing AJ_24038155 Dialect v1.1.

## v3.15 evidenced ordered-cache stateful-ADT recovery

v3.15 adds guarded GC215 recovery for the source shape `INIT limit, cache = orderedDict()` followed by multiple top-level operations that share the ordered key/value state. The rule activates only when the same source proves a cache-size bound (`LENGTH OF cache == limit`), keyed membership/indexing, and safe recency-helper contexts: move-to-front only for a present key, remove-back only under the full-capacity guard, and add-to-front only in the absent-key branch. The first INIT name becomes a constructor-supplied property rather than receiving a synthetic numeric default; the ordered cache becomes an AJ `DICTIONARY` property, and existing ordered-mapping compiler intrinsics provide the physical MRU/LRU lowering. The recovered wrapper is the neutral `unnamed_class`, so no semantic class name is invented. Qwen Algorithm 35 therefore becomes a trustworthy executable for positive fixed capacities without changing AJ_24038155 Dialect v1.1.

## v3.14 provable redundant-uniqueness alignment

v3.14 adds guarded GC214 semantic alignment for a final `RETURN unique(result)` abstraction only when the same routine mechanically proves that `result` is already unique: the collection is explicitly initialised as `EMPTY LIST`, every append is protected by a matching `value NOT IN result` guard that is re-evaluated before that append, and no rebinding, indexed/insert mutation, alias/call escape, repeated append under one guard, or nested-loop bypass invalidates the proof. The alignment preserves the source-created order by returning `result` directly; it does not implement a generic `unique` routine or rewrite arbitrary `unique(x)` calls. Qwen Algorithm 34 therefore becomes a trustworthy executable after source-proven semantic alignment. AJ_24038155 Dialect v1.1 remains frozen.

## v3.13 bare CALL-argument binding validation

v3.13 extends the frozen AJ v1.1 declared/assigned-before-read check to immediate bare value identifiers supplied as arguments to `CALL routine(...)`. Routine names remain syntax and are not treated as value reads, undefined external-routine policy is unchanged, and compound-expression definite-assignment analysis remains deliberately out of scope. Qwen Algorithm 30 now fails during static semantic analysis on the unbound `numTopics` argument instead of producing executable-looking Python with a latent `NameError`. Its abstract NLP/LDA routine dependencies remain source-level expected failures. AJ_24038155 Dialect v1.1 remains frozen.

## v3.12 evidenced camelCase deque-operation recovery

v3.12 adds guarded GC213 compatibility recovery for Qwen-style `popFront()`, `popBack()`, and `pushBack(value)` calls when the receiver is independently established as list-backed in the same source. The rule maps directly to the existing AJ list operations `REMOVE FIRST ITEM FROM`, `REMOVE LAST ITEM FROM`, and `APPEND ... TO ...`; arbitrary user-defined methods with the same names are not rewritten. Qwen Algorithm 28 still retains its source-level empty-deque indexing defect and is audit-locked as an expected executable-correctness failure. AJ_24038155 Dialect v1.1 remains frozen.

## v3.11 square-dimension identifier-reference recovery

v3.11 adds generic GC212 compatibility recovery for otherwise-unbound executable references to a dimension symbol explicitly established by `INPUT collection (D x D)`. The symbol resolves directly to `LENGTH OF collection` within the same routine, without creating a synthetic `D` variable. GC208 retains its exact `0 .. D-1` loop-bound ownership. Arithmetic is preserved exactly: Qwen Algorithm 27 now eliminates unbound `N`, but its source `N / 2` remains ordinary division and is audit-locked as an expected executable-correctness failure rather than silently corrected to integer division. AJ_24038155 Dialect v1.1 remains frozen.

## v3.10 omitted-`IS` non-empty predicate recovery

v3.10 adds generic GC211 compatibility recovery for the exact surface `identifier NOT EMPTY`, mapping it to the already-supported canonical empty-state test `LENGTH OF identifier > 0`. The rule is case-insensitive, quote/comment-safe, and deliberately does not broaden to blank/null/whitespace/missing predicates or member expressions. Qwen Algorithm 26 now passes without inventing tree semantics. AJ_24038155 Dialect v1.1 remains frozen.

## Research corpus and audit evidence

The complete six model-response corpora used for the research study remain external
study data and are not copied wholesale into versioned implementation ZIPs.
Study-level corpus integration checks can be run by setting `AJ_RESEARCH_CORPUS_DIR`
to an external directory containing those files. When that variable is absent,
corpus-dependent checks skip cleanly.

When an exact study occurrence motivates a general parsing or normalisation measure,
that occurrence may be retained as a focused regression fixture together with its
audit record. These selected cases are version-controlled evidence for why the
measure was introduced; they are distinct from bundling the complete research corpus.

## Flow-diagram display

The generated flowchart opens at a readable 115% scale and is centred on the
first program steps. Use **Fit diagram** to display the complete program at once.
Zoom and pan remain available.

## Compilation assurance tests

The integration tests verify that:

- the saved `flow_diagram.json` document is accepted directly by the compiler;
- the compiler produces the exact expected reference Python source;
- the compiled program executes and produces the expected output;
- the visualisation contains the readable initial-view configuration.

Run all tests with:

```bash
python -m unittest discover -s tests -v
```

## Second controlled input route: draw.io

Version 1.5 adds an optional draw.io route while preserving pseudocode as the
primary route.

Configure `pycharm_runner.py` with:

```python
INPUT_ROUTE = "DRAWIO"
SELECT_FILE_WHEN_RUNNING = True
```

The runner displays a native file chooser. The controlled version 1 convention
is deliberately limited to a single linear path:

```text
Start -> AJ statement -> AJ statement -> End
```

Each executable process or input/output shape must contain one valid AJ Dialect
statement, either directly or with an `AJ:` prefix, for example:

```text
AJ: total <- INTEGER(0)
AJ: OUTPUT STRING("Total is {total}")
```

The importer reconstructs AJ pseudocode and then reuses the existing trusted
route:

```text
draw.io -> AJ pseudocode -> AST -> canonical flow JSON -> Python -> tests
```

Branching and looped draw.io imports intentionally fail with explicit diagnostics
in this first controlled version. The existing pseudocode route continues to
support the full parser grammar.

## Interactive input selection in PyCharm

Run `pycharm_runner.py` without editing an input-route flag.

The application first asks:

```text
What would you like to import?

[Pseudocode file]
[Flow diagram file]
```

After the selection, a native file chooser opens with the matching filters:

- Pseudocode: `.aj` or `.txt`
- Controlled flow diagram: `.drawio`, `.xml` or `.svg`

Closing either dialog cancels the run cleanly.

## Pseudocode processing profiles

When **Pseudocode file** is selected in `pycharm_runner.py`, the application now
asks how the source should be processed:

1. **AJ Dialect — strict** performs only non-semantic cleanup such as removing a
   surrounding Markdown fence, normalising line endings, removing trailing
   whitespace and converting `←` to `<-`.
2. **Generic — convert compatible syntax** recognises a controlled subset of
   generic structured pseudocode and converts forms such as `SET x TO value`,
   `PRINT value`, `END IF`, `END WHILE`, `NEXT`, assignment `=`, `MOD` and `DIV`
   into AJ_24038155 Dialect syntax.
3. **General — parse without conversion** passes the supplied text to the
   existing lexer and parser exactly as read from the file. It does not repair,
   normalise or rewrite the source.

Every pseudocode run writes:

- `processed_pseudocode.aj`
- `pseudocode_processing_report.json`

The report records the selected profile, whether the source changed, and every
individual transformation. The selected profile is also included in
`pipeline_report.json` under `input_metadata`.

## Draw.io overlaid labels

Version 1.8 recognises draw.io diagrams where visible `Start` and `End` text is
stored as a separate text object placed over an empty connected terminator
shape. The importer transfers the text to the underlying shape before graph
validation. Branching and loop-back import remain outside the controlled linear
importer and are rejected explicitly.

## General draw.io control-flow graphs

The draw.io route supports both linear diagrams and general graphs containing:

- decision diamonds;
- Yes/No and True/False connector labels;
- branch joins;
- loop-back connectors;
- separate text labels over Start and End shapes.

Linear diagrams are reconstructed as AJ Dialect pseudocode and use the normal
AST pipeline. Branching or cyclic diagrams are preserved as a canonical graph
and compiled into a Python state machine. This allows control flow that cannot
be represented safely as a simple nested block structure to remain executable.

When no behavioural test oracle is supplied for an imported flow diagram, the
pipeline reports behavioural testing as `SKIPPED` after successful compilation
and Python syntax validation. This avoids comparing an imported diagram against
unrelated sample outputs.

## Version 1.10: structured Tic-Tac-Toe graph compilation

The supplied Tic-Tac-Toe draw.io graph is recognised as a structured game-flow
pattern. It is compiled into a normal Python game loop instead of a verbose
state dispatcher. The generated program validates indexes and occupied cells,
alternates players, checks all eight winning lines, declares the correct winner,
and declares a draw after nine valid moves.

The compiler reports this route as `STRUCTURED_GRAPH_OPTIMISATION`. Other
arbitrary cyclic draw.io graphs continue to use the general state-machine
compiler.

## Flow-diagram input AST outputs

When an existing draw.io flow diagram is selected, the pipeline does not create a duplicate flow-diagram visualisation. After compilation it parses the generated Python into a Python AST and writes:

- `ast.json` — nested Python AST document;
- `ast_adjacency_list.json` — graph representation of the AST;
- `ast_visualisation.html` — interactive AST tree;
- `generated_program.py` — compiled Python source.

The pseudocode input route continues to generate both AST and flow-diagram artefacts.

## Editable draw.io export

The pseudocode input route also writes `output/flow_diagram.drawio`. This is an
editable diagrams.net/draw.io XML document using standard terminator, process,
decision, input/output, subroutine, and orthogonal connector conventions.

## Initial hash-comment header stripping

Before the selected pseudocode profile is applied, the pipeline checks whether the first line begins with `#`. When it does, all lines from the beginning of the file through the first blank separator line are treated as file-header metadata and removed. This supports wrapped introductory comments where continuation lines do not themselves begin with `#`.

Example:

```text
# Algorithm description
This description may wrap across several lines.
These lines are header metadata.

FUNCTION example ACCEPTS()
    OUTPUT STRING(example)
ENDFUNCTION
```

Only the pseudocode beginning with `FUNCTION` is sent to the selected profile and parser. Hash characters occurring later in the pseudocode do not trigger this preprocessing rule. The processing report records `header_comment_removed` and `header_lines_removed` separately from profile transformation counts.

## Lossy-source assignment recovery boundary

The generic compatibility route may receive study/source exports in which a
Unicode assignment arrow was lost as ASCII `?`. This is handled only in the
upstream source-integrity stage (GC193), where `?` is recoverable to source `←`
only when its syntactic position is unambiguously an assignment: a standalone
assignment target, a `FOR` initialiser, or an inline CASE-arm assignment.

`?` is **not** AJ syntax and is never a canonical alias for `<-`. Relational
forms such as `WHILE B ? 0` or `IF A ? B THEN` are left unresolved unless an
entry in the evidence-backed lossy-glyph lookup table establishes the original
source glyph from a recognised full source signature. Table recoveries are
logged as `GC194:<evidence-id>` and restore source glyphs such as `≠`, `≤`, or
`≥`; the deterministic character lookup then maps those glyphs to strict AJ
operators (`!=`, `<=`, `>=`). There is deliberately no `?` entry in the
canonical character lookup. The strict AJ parser continues to reject `?`.
